
// Has to be run after the code in get_range.js
var selection = window.getSelection();
selection.removeAllRanges();
selection.addRange(selectRange);
