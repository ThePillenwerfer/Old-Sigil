#!/usr/bin/env python
# vim:fileencoding=utf-8
# License: GPLv3 Copyright: 2018, Kovid Goyal <kovid at kovidgoyal.net>

version = (1, 0, 4)
VERSION = '.'.join(map(str, version))

__version__ = '%s $Id$' % VERSION
