css-parser
================

[![Build Status](https://api.travis-ci.org/ebook-utils/css-parser.svg)](https://travis-ci.org/ebook-utils/css-parser)
[![Build Status](https://ci.appveyor.com/api/projects/status/fqs1n6c2lidphx1t?svg=true)](https://ci.appveyor.com/project/kovidgoyal/css-parser)

A fork of the cssutils project based on version 1.0.2.
This fork includes general bug fixes and extensions 
specific to editing and working with ebooks.

The main python source code has been modified so
that it will run without further conversion on both 
Python >= 2.7 and Python 3.X without any further
modules required.  All required modifications
are handled local to each file

For more information on usage, please see the cssutils 
documentation
