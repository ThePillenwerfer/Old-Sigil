<?xml version="1.0" ?><!DOCTYPE TS><TS language="th" version="2.1">
<context>
    <name>About</name>
    <message>
        <location filename="../../Form_Files/About.ui" line="14"/>
        <source>About</source>
        <translation>เกี่ยวกับ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="56"/>
        <source>The EPUB Editor</source>
        <translation>ตัวแก้ไข EPUB</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="70"/>
        <source>General</source>
        <translation>ทั่วไป</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="107"/>
        <source>Homepage:</source>
        <translation>โฮมเพจ:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="143"/>
        <source>Version:</source>
        <translation>รุ่น:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="170"/>
        <source>Loaded Qt:</source>
        <translation>โหลด Qt:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="200"/>
        <source>&lt;a href=&quot;http://www.gnu.org/licenses/gpl-3.0-standalone.html&quot;&gt;GNU General Public License v3&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;http://www.gnu.org/licenses/gpl-3.0-standalone.html&quot;&gt;GNU General Public License v3&lt;/a&gt; </translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="218"/>
        <source>Build time:</source>
        <translation>สร้างเวลา:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="245"/>
        <source>License:</source>
        <translation>ใบอนุญาต:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="255"/>
        <source>Authors</source>
        <translation>ผู้เขียน</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="41"/>
        <source>GNU General Public License v3</source>
        <translation>GNU General Public License v3</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="51"/>
        <source>Maintainer(s)</source>
        <translation>ผู้ดูแล</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="56"/>
        <source>Previous Maintainer(s)</source>
        <translation>ผู้ดูแลรายก่อน</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="60"/>
        <source>Code Contributors</source>
        <translation>ผู้ร่วมให้รหัส</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="68"/>
        <source>Translators</source>
        <translation>ผู้แปล</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="70"/>
        <source>Original Creator</source>
        <translation>ผู้สร้างต้นฉบับ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="71"/>
        <source>retired</source>
        <translation>retired</translation>
    </message>
</context>
<context>
    <name>AddMetadata</name>
    <message>
        <location filename="../../Form_Files/AddMetadata.ui" line="14"/>
        <source>Add metadata property</source>
        <translation>เพิ่มคุณสมบัติเมตาดาต้า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/AddMetadata.ui" line="50"/>
        <source>Metadata description</source>
        <translation>คำอธิบายเมตาดาต้า</translation>
    </message>
</context>
<context>
    <name>AddSemantics</name>
    <message>
        <location filename="../../Form_Files/AddSemantics.ui" line="14"/>
        <source>Add Semantic Property</source>
        <translation>เพิ่มคุณสมบัติเชิงตรรกะ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/AddSemantics.ui" line="56"/>
        <source>Description of Semantic Properties</source>
        <translation>คำอธิบายของคุณสมบัติเชิงความหมาย</translation>
    </message>
</context>
<context>
    <name>AllFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsAllFilesWidget.ui" line="14"/>
        <source>All Files</source>
        <translation>ไฟล์ทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsAllFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsAllFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>กรอง:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="73"/>
        <source>Directory</source>
        <translation>ไดเรคทอรี่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="74"/>
        <source>Name</source>
        <translation>ชื่อ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="75"/>
        <source>File Size (KB)</source>
        <translation>ขนาดไฟล์ (KB)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="76"/>
        <source>Type</source>
        <translation>ชนิด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="77"/>
        <source>Semantics</source>
        <translation>Semantics</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="79"/>
        <source>Properties</source>
        <translation>คุณลักษณะ</translation>
    </message>
    <message numerus="yes">
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="148"/>
        <source>%n file(s)</source>
        <translation><numerusform>%n ไฟล์</numerusform></translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="261"/>
        <source>Save Report As Comma Separated File</source>
        <translation>บันทึกรายงานเป็นไฟล์ที่แบ่งด้วยจุลภาค</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="274"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="274"/>
        <source>Cannot save report file.</source>
        <translation>บันทึกไฟล์รายงานไม่ได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="299"/>
        <source>Image</source>
        <translation>รูปภาพ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="304"/>
        <source>Audio</source>
        <translation>เสียง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="309"/>
        <source>Video</source>
        <translation>วีดีโอ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="314"/>
        <source>Font</source>
        <translation>อักษร</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="341"/>
        <source>Unknown</source>
        <translation>ไม่รู้จัก</translation>
    </message>
</context>
<context>
    <name>AppearanceWidget</name>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="14"/>
        <source>Appearance</source>
        <translation>ลักษณะ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="24"/>
        <source>Fonts / Colors</source>
        <translation>แบบอักษร/สี</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="30"/>
        <source>Book View / Preview:</source>
        <translation>มุมมองหนังสือ/ตัวอย่าง:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="39"/>
        <source>If no font is specified in the CSS for your page, the following font will be used to display within Sigil. These fonts will not be used in your actual ebook.</source>
        <translation>หากหน้าหนังสือไม่มีอักษรที่ระบุไว้ใน CSS, อักษรต่อไปนี้จะถูกใช้แสดงอยู่ภายใน Sigil อักษรเหล่านี้จะไม่ถูกใช้ในอีบุ๊คของคุณ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="59"/>
        <source>Default font size to be used for Book View and Preview
if no font-size specified in your CSS</source>
        <translation>ขนาดอักษรดั้งเดิมที่ใช้สำหรับ มุมมองหนังสือ และ ตัวอย่าง
หากไม่ได้ระบุขนาดอักษรไว้ใน CSS ของคุณ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="63"/>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="197"/>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="313"/>
        <source>Font Size:</source>
        <translation>ขนาดอักษร:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="93"/>
        <source>Default font family to be used for Book View and Preview
if no font-family specified in your CSS</source>
        <translation>กลุ่มอักษรดั้งเดิมที่ใช้สำหรับ มุมมองหนังสือ และ ตัวอย่าง
หากไม่ได้ระบุกลุ่มอักษรไว้ใน CSS ของคุณ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="97"/>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="227"/>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="346"/>
        <source>Standard Font:</source>
        <translation>อักษรมาตรฐาน:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="107"/>
        <source>Default font family to be used for Book View and Preview
if a serif font-family specified in your CSS</source>
        <translation>กลุ่มอักษรดั้งเดิมที่ใช้สำหรับ มุมมองหนังสือ และ ตัวอย่าง
หากกลุ่มอักษร Serif ไม่ได้ระบุไว้ใน CSS ของคุณ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="111"/>
        <source>Serif Font:</source>
        <translation>อักษร Serif:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="121"/>
        <source>Default font family to be used for Book View and Preview
if a sans-serif font-family specified in your CSS</source>
        <translation>แบบอักษรเริ่มต้นที่ใช้สำหรับ มุมมองหนังสือ และ ตัวอย่าง
หากแบบอักษร Serif ไม่ได้ระบุไว้ใน CSS</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="125"/>
        <source>Sans-Serif Font:</source>
        <translation>อักษร Sans-Serif:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="171"/>
        <source>CSS / Code View:</source>
        <translation>มุมมอง CSS / Code:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="181"/>
        <source>Item Colors:</source>
        <translation>รายการสี:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="194"/>
        <source>Font size to be used for text in Code View.</source>
        <translation>ขนาดอักษรที่ใช้สำหรับเนื้อหาในมุมมองโค๊ด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="224"/>
        <source>Font family to be used for text in Code View.</source>
        <translation>กลุ่มอักษรที่ใช้สำหรับเนื้อหาในมุมมองโค๊ด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="263"/>
        <source>Select an alternative color for this display item</source>
        <translation>เลือกสีอื่นเพื่อแสดงรายการนี้</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="266"/>
        <source>Custom Color...</source>
        <translation>ปรับแต่งสี...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="296"/>
        <source>Insert Special Characters:</source>
        <translation>แทรกอักษรพิเศษ:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="310"/>
        <source>Font size to be used for Insert Special Characters window</source>
        <translation>ขนาดอักษรที่ใช้สำหรับหน้าต่าง แทรกอักษรพิเศษ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="343"/>
        <source>Font family to be used for Insert Special Characters window</source>
        <translation>กลุ่มอักษรที่ใช้สำหรับหน้าต่าง แทรกอักษรพิเศษ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="388"/>
        <source>Menus</source>
        <translation>เมนู</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="394"/>
        <source>Main Menu Icon Size</source>
        <translation>ขนาดไอคอนไอคอนเมนูหลัก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="400"/>
        <source>Adjust the size of the icons in the main menu.</source>
        <translation>ปรับขนาดของไอคอนในเมนูหลัก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="476"/>
        <source>Reset all fonts and colors to the default values</source>
        <translation>คืนค่าอักษรและสีทั้งหมดไปยังค่าดั้งเดิม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="479"/>
        <source>Reset All</source>
        <translation>คืนค่าทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="204"/>
        <source>Background</source>
        <translation>พื้้นหลัง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="205"/>
        <source>Foreground</source>
        <translation>พื้นหน้า</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="206"/>
        <source>CSS Comment</source>
        <translation>หมายเหตุ CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="207"/>
        <source>CSS Property</source>
        <translation>คุณสมบัติ CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="208"/>
        <source>CSS Quote</source>
        <translation>อ้าง CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="209"/>
        <source>CSS Selector</source>
        <translation>ตัวเลือก CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="210"/>
        <source>CSS Value</source>
        <translation>ค่า CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="211"/>
        <source>Line Highlight</source>
        <translation>เน้นบรรทัด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="212"/>
        <source>Line# Background</source>
        <translation>บรรทัด# พื้นหลัง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="213"/>
        <source>Line# Foreground</source>
        <translation>บรรทัด# เบื้องหน้า</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="214"/>
        <source>Selection Background</source>
        <translation>เลือกพื้นหลัง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="215"/>
        <source>Selection Foreground</source>
        <translation>เลือกเบื้องหน้า</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="216"/>
        <source>Spelling Underline</source>
        <translation>ขีดเส้นใต้การสะกด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="217"/>
        <source>XHTML Attribute Name</source>
        <translation>ชื่อคุณสมบัติ XHTML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="218"/>
        <source>XHTML Attribute Value</source>
        <translation>ค่าคุณสมบัติ XHTML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="219"/>
        <source>XHTML CSS</source>
        <translation>XHTML CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="220"/>
        <source>XHTML CSS Comment</source>
        <translation>หมายเหตุ XHTML CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="221"/>
        <source>XHTML DocType</source>
        <translation>XHTML DocType</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="222"/>
        <source>XHTML Entity</source>
        <translation>XHTML Entity</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="223"/>
        <source>XHTML HTML Tag</source>
        <translation>XHTML HTML Tag</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="224"/>
        <source>XHTML HTML Comment</source>
        <translation>หมายเหตุ XHTML HTML</translation>
    </message>
</context>
<context>
    <name>Book</name>
    <message>
        <location filename="../../BookManipulation/Book.cpp" line="399"/>
        <source>Start</source>
        <translation>เริ่ม</translation>
    </message>
</context>
<context>
    <name>BookBrowser</name>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="61"/>
        <source>Book Browser</source>
        <translation>Book Browser</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="72"/>
        <source>Font Obfuscation</source>
        <translation>Obfuscation ตัวอักษร</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="73"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="1418"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="1525"/>
        <source>Open With</source>
        <translation>เปิดด้วย</translation>
    </message>
    <message numerus="yes">
        <location filename="../../MainUI/BookBrowser.cpp" line="127"/>
        <source>%n file(s)</source>
        <translation><numerusform>%n ไฟล์</numerusform></translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="217"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="624"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="640"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="689"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="789"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="996"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="217"/>
        <source>Are you sure you want to sort the selected files alphanumerically?</source>
        <translation>คุณต้องการเรียงไฟล์ตามลำดับอักษรใช่ไหม?</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="217"/>
        <source>This action cannot be reversed.</source>
        <translation>ไม่สามารถย้อนกลับการกระทำนี้ได้</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="243"/>
        <source>The file &quot;%1&quot; does not exist.</source>
        <translation>ไฟล์ &quot;%1&quot; ไม่มีอยู่</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="567"/>
        <source>Add Existing Files</source>
        <translation>เพิ่มไฟล์ที่มี</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="600"/>
        <source>File is not an image and cannot be used:

&quot;%1&quot;.</source>
        <translation>ไฟล์ไม่ใช่รูปภาพและไม่สามารถใช้ได้:

&quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="609"/>
        <source>File is not multimedia (image, video, audio) and cannot be inserted:

&quot;%1&quot;.</source>
        <translation>ไฟล์ไม่ใช่มัลติมีเดีย (ภาพ,วิดีโอ,เสียง) และไม่สามารถแทรกได้:

&quot;%1&quot;.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="624"/>
        <source>The multimedia file &quot;%1&quot; already exists in the book.

OK to replace?</source>
        <translation>ไฟล์มัลติมีเดีย &quot;%1&quot;  มีอยู่ในหนังสือแล้ว 

ตกลง เพื่อแทนที่?</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="635"/>
        <source>Unable to delete or replace file &quot;%1&quot;.</source>
        <translation>ไม่สามารถลบหรือแทนที่ไฟล์ &quot;%1&quot; ได้</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="640"/>
        <source>Unable to load &quot;%1&quot;

A file with this name already exists in the book.</source>
        <translation>ไม่สามารถโหลด &quot;%1&quot; ได้

ในหนังสือมีชื่อไฟล์นี้แล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="690"/>
        <source>The following file(s) were not loaded due to invalid content or not well formed XML:

%1</source>
        <translation>ไฟล์ต่อไปนี้ไม่ได้รับการโหลดเนื่องจากเนื้อหาไม่ถูกต้องหรือไม่รองรับ XML:

%1</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="704"/>
        <source>File(s) added.</source>
        <translation>เพิ่มไฟล์แล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="739"/>
        <source>Save As File</source>
        <translation>บันทึกไฟล์เป็น</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="761"/>
        <source>Unable to save the file.</source>
        <translation>บันทึกไฟล์ไม่ได้</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="769"/>
        <source>Choose the directory to save the files to</source>
        <translation>เลือกไดเร็กทอรีเพื่อบันทึกไฟล์ไว้</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="789"/>
        <source>One or more files already exists.  OK to overwrite?</source>
        <translation>มีไฟล์อยู่แล้วมากกว่าหนึ่งไฟล์ ตกลงที่จะเขียนทับ?</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="806"/>
        <source>Unable to save files.  Destination may be a directory.</source>
        <translation>ไม่สามารถบันทึกไฟล์ได้ ปลายทางอาจเป็นไดเร็กทอรี</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="814"/>
        <source>Unable to save files.</source>
        <translation>บันทึกไฟล์ไม่ได้</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="996"/>
        <source>Cannot rename files since this would result in duplicate filenames.</source>
        <translation>เปลี่ยนชื่อไฟล์ไม่ได้เพราะชื่อไฟล์นี้มีอยู่แล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1059"/>
        <source>The Nav document can not be removed.</source>
        <translation>ไม่สามารถลบเอกสาร Nav ได้</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1067"/>
        <source>Neither the NCX nor the OPF can be removed.</source>
        <translation>ทั้ง NCX และ OPF ไม่สามารถลบออกได้</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1074"/>
        <source>You cannot remove all html files.
There always has to be at least one.</source>
        <translation>คุณไม่สามารถลบไฟล์ html ทั้งหมดได้
จะต้องมีอย่างน้อยหนึ่งไฟล์เสมอ</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1214"/>
        <source>Unable to set file as cover image.</source>
        <translation>ตั้งค่าไฟล์เป็นรูปปกไม่ได้</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1399"/>
        <source>Select All</source>
        <translation>เลือกทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1400"/>
        <source>Add Blank HTML File</source>
        <translation>เพิ่มไฟล์ HTML</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1401"/>
        <source>Add Blank Stylesheet</source>
        <translation>เพิ่มไฟล์ Stylesheet</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1402"/>
        <source>Add Blank SVG Image</source>
        <translation>เพิ่มรูปภาพ SVG </translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1403"/>
        <source>Add Existing Files...</source>
        <translation>เพิ่มไฟล์ที่มี...</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1404"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="1405"/>
        <source>Add Copy</source>
        <translation>เพิ่มสำเนา</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1406"/>
        <source>Rename</source>
        <translation>เปลี่ยนชื่อ</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1407"/>
        <source>Delete</source>
        <translation>ลบ</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1408"/>
        <source>Cover Image</source>
        <translation>รูปปก</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1409"/>
        <source>Merge</source>
        <translation>รวม</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1410"/>
        <source>None</source>
        <translation>ไม่มี</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1411"/>
        <source>Use Adobe&apos;s Method</source>
        <translation>ใช้ Adobe&apos;s Method</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1412"/>
        <source>Use IDPF&apos;s Method</source>
        <translation>ใช้ IDPF&apos;s Method</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1413"/>
        <source>Sort</source>
        <translation>เรียง</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1414"/>
        <source>Renumber TOC Entries</source>
        <translation>เปลี่ยนรายการสารบัญใหม่</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1415"/>
        <source>Link Stylesheets...</source>
        <translation>เชื่อมโยงสไตล์ชีต...</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1416"/>
        <source>Add Semantics...</source>
        <translation>เพิ่มความหมาย...</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1417"/>
        <source>Validate with W3C</source>
        <translation>ตรวจสอบความถูกต้องกับ W3C</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1419"/>
        <source>Save As</source>
        <translation>บันทึกเป็น</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1433"/>
        <source>Merge with previous file, or merge multiple files into one.</source>
        <translation>ผสานกับไฟล์ก่อนหน้าหรือรวมไฟล์หลายไฟล์เข้าไว้ด้วยกัน</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1436"/>
        <source>Rename selected file(s)</source>
        <translation>เปลี่ยนชื่อไฟล์ที่เลือก</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1438"/>
        <source>Link Stylesheets to selected file(s).</source>
        <translation>เชื่อมโยงสไตล์ชีตกับไฟล์ที่เลือก</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1440"/>
        <source>Add Semantics to selected file(s).</source>
        <translation>เพิ่มความหมายลงในไฟล์ที่เลือก</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1560"/>
        <source>Other Application</source>
        <translation>แอพพลิเคชันอื่น</translation>
    </message>
</context>
<context>
    <name>BookViewEditor</name>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="722"/>
        <source>Clipboard contains HTML formatting</source>
        <translation>คลิปบอร์ดประกอบด้วยรูปแบบ HTML</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="723"/>
        <source>Do you want to paste clipboard data as plain text?</source>
        <translation>คุณต้องการวางข้อมูลคลิปบอร์ดเป็นข้อความล้วนหรือไม่?</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="938"/>
        <source>Open Tab For</source>
        <translation>เปิดแท็บสำหรับ</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="956"/>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1161"/>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1163"/>
        <source>Open With</source>
        <translation>เปิดด้วย</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="991"/>
        <source>Other Application</source>
        <translation>แอพพลิเคชันอื่น</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1039"/>
        <source>Clips</source>
        <translation>คลิป</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1049"/>
        <source>Add To Clips</source>
        <translation>เพิ่มลงในคลิป</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1147"/>
        <source>Insert File</source>
        <translation>แทรกไฟล์</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1148"/>
        <source>Undo</source>
        <translation>เลิกทำ</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1149"/>
        <source>Redo</source>
        <translation>ทำซ้ำ</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1150"/>
        <source>Cut</source>
        <translation>ตัด</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1151"/>
        <source>Copy</source>
        <translation>คัดลอก</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1152"/>
        <source>Copy Image</source>
        <translation>คัดลอกรูปภาพ</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1153"/>
        <source>Paste</source>
        <translation>วาง</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1154"/>
        <source>Select All</source>
        <translation>เลือกทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1155"/>
        <source>Open</source>
        <translation>เปิด</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1162"/>
        <source>Save As</source>
        <translation>บันทึกเป็น</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1170"/>
        <source>Inspect Element</source>
        <translation>ตรวจสอบ Element</translation>
    </message>
</context>
<context>
    <name>BookViewPreview</name>
    <message>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="267"/>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="332"/>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="338"/>
        <source>Unsupported</source>
        <translation>ไม่สนับสนุน</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="267"/>
        <source>Spellcheck mode is not supported in Book View at this time.  Switch to Code View.</source>
        <translation>โหมดตรวจการสะกดไม่ได้รับการสนับสนุนในมุมมองหนังสือในขณะนี้ เปลี่ยนไปใช้มุมมองโค้ด</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="332"/>
        <source>Replace is not supported in this view. Switch to Code View.</source>
        <translation>การแทนคำใช้ไม่ได้ในมุมมองนี้ สลับไปยัง มุมมองโค๊ด</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="338"/>
        <source>Replace All for the current file is not supported in this view. Switch to Code View.</source>
        <translation>แทนที่ทั้งหมดสำหรับไฟล์ปัจจุบันไม่ได้รับการสนับสนุนในมุมมองนี้ เปลี่ยนไปใช้มุมมองโค้ด</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="758"/>
        <source>Inspect Element</source>
        <translation>ตรวจสอบ Element</translation>
    </message>
</context>
<context>
    <name>CSSFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsCSSFilesWidget.ui" line="14"/>
        <source>CSS Files</source>
        <translation>ไฟล์ CSS</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsCSSFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsCSSFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>กรอง:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="75"/>
        <source>Name</source>
        <translation>ชื่อ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="76"/>
        <source>Size (KB)</source>
        <translation>ขนาด (KB)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="77"/>
        <source>Times Used</source>
        <translation>เวลาที่ใช้</translation>
    </message>
    <message numerus="yes">
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="142"/>
        <source>%n file(s)</source>
        <translation><numerusform>%n ไฟล์</numerusform></translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="146"/>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="273"/>
        <source>Save Report As Comma Separated File</source>
        <translation>บันทึกรายงานเป็นไฟล์ที่แบ่งด้วยจุลภาค</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="286"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="286"/>
        <source>Cannot save report file.</source>
        <translation>บันทึกไฟล์รายงานไม่ได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="297"/>
        <source>Delete From Book</source>
        <translation>ลบออกจากหนังสือ</translation>
    </message>
</context>
<context>
    <name>CSSResource</name>
    <message>
        <location filename="../../ResourceObjects/CSSResource.cpp" line="99"/>
        <source>Sigil will send your stylesheet data to the &lt;a href=&apos;http://jigsaw.w3.org/css-validator/&apos;&gt;W3C Validation Service&lt;/a&gt;.</source>
        <translation>Sigil จะส่งข้อมูลสไตล์ชีตไปที่&lt;a href=&apos;http://jigsaw.w3.org/css-validator/&apos;&gt;บริการตรวจสอบ W3C&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../../ResourceObjects/CSSResource.cpp" line="100"/>
        <source>This page should disappear once loaded after 3 seconds.</source>
        <translation>หน้านี้จะหายไปหลังจากโหลด 3 วินาที</translation>
    </message>
    <message>
        <location filename="../../ResourceObjects/CSSResource.cpp" line="101"/>
        <source>If your browser does not have javascript enabled, click on the button below.</source>
        <translation>หากบราวเซอร์ของคุณไม่ได้เปิดใช้ Javascript, คลิกที่ปุ่มด้านล่าง</translation>
    </message>
</context>
<context>
    <name>CharactersInHTMLFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsCharactersInHTMLFilesWidget.ui" line="14"/>
        <source>Characters in HTML Files</source>
        <translation>ตัวอักษรในไฟล์ HTML</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsCharactersInHTMLFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsCharactersInHTMLFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>กรอง:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsCharactersInHTMLFilesWidget.ui" line="76"/>
        <source>Characters:</source>
        <translation>ตัวอักษร:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="80"/>
        <source>Character</source>
        <translation>ตัวอักษร</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="81"/>
        <source>Decimal</source>
        <translation>เลขฐาน 10</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="82"/>
        <source>Hexadecimal</source>
        <translation>เลขฐาน 16</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="83"/>
        <source>Entity Name</source>
        <translation>ชื่อรายการ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="84"/>
        <source>Entity Description</source>
        <translation>คำอธิบายรายการ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="90"/>
        <source>&lt;p&gt;This is a list of the characters used in all HTML files.&lt;p&gt;</source>
        <translation>&lt;p&gt;รายการของตัวอักษรที่ใช้ในไฟล์ HTML ทั้งหมด&lt;p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="271"/>
        <source>Save Report As Comma Separated File</source>
        <translation>บันทึกรายงานเป็นไฟล์ที่แบ่งด้วยจุลภาค</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="284"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="284"/>
        <source>Cannot save report file.</source>
        <translation>บันทึกไฟล์รายงานไม่ได้</translation>
    </message>
</context>
<context>
    <name>ClassesInHTMLFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsClassesInHTMLFilesWidget.ui" line="14"/>
        <source>Style Classes in HTML Files</source>
        <translation>สไตล์คลาสในไฟล์ HTML</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsClassesInHTMLFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsClassesInHTMLFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>กรอง:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="83"/>
        <source>HTML File</source>
        <translation>ไฟล์ HTML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="84"/>
        <source>Element</source>
        <translation>Element</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="85"/>
        <source>Class</source>
        <translation>คลาส</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="86"/>
        <source>Matched Selector</source>
        <translation>จับคู่ที่ตรงกัน</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="87"/>
        <source>Found In</source>
        <translation>พบใน</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="93"/>
        <source>&lt;p&gt;This is a list of the style classes used in all HTML files and whether or not the style matched a selector in a linked stylesheet.&lt;p&gt;</source>
        <translation>&lt;p&gt;รายการคลาสสไตล์ที่ใช้ในไฟล์ HTML ทั้งหมดและรูปแบบตรงกับตัวเลือกในสไตล์ชีตที่เชื่อมโยงหรือไม่&lt;p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="94"/>
        <source>&lt;p&gt;NOTE:&lt;/p&gt;</source>
        <translation>&lt;p&gt;บันทึก:&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="95"/>
        <source>&lt;p&gt;Due to the complexities of CSS you must check your code manually to be certain if a style is used or not.&lt;/p&gt;</source>
        <translation>&lt;p&gt;เนื่องจากความซับซ้อนของ CSS คุณต้องตรวจสอบด้วยตนเองเพื่อให้มั่นใจว่าสไตล์ถูกใช้&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="229"/>
        <source>Save Report As Comma Separated File</source>
        <translation>บันทึกรายงานเป็นไฟล์ที่แบ่งด้วยจุลภาค</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="242"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="242"/>
        <source>Cannot save report file.</source>
        <translation>บันทึกไฟล์รายงานไม่ได้</translation>
    </message>
</context>
<context>
    <name>ClipEditor</name>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="14"/>
        <location filename="../../Dialogs/ClipEditor.cpp" line="525"/>
        <source>Clip Editor</source>
        <translation>ตัวแก้ไขคลิป</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="23"/>
        <source>Filter Name:</source>
        <translation>ชื่อตัวกรอง:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="28"/>
        <source>Filter All:</source>
        <translation>กรองทั้งหมด:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="36"/>
        <source>List only the entries containing the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="65"/>
        <source>Paste the selected entry into the active window.</source>
        <translation>วางรายการที่เลือกลงในหน้าต่างที่ใช้งานอยู่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="68"/>
        <source>Paste Clip</source>
        <translation>วางคลิป</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="91"/>
        <location filename="../../Dialogs/ClipEditor.cpp" line="636"/>
        <source>Add Entry</source>
        <translation>เพิ่มรายการ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="98"/>
        <location filename="../../Dialogs/ClipEditor.cpp" line="637"/>
        <source>Add Group</source>
        <translation>เพิ่มกลุ่ม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="123"/>
        <source>Move an entry up one entry in the same group.</source>
        <translation>ย้ายรายการหนึ่งรายการในกลุ่มเดียวกัน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="126"/>
        <location filename="../../Form_Files/ClipEditor.ui" line="156"/>
        <location filename="../../Form_Files/ClipEditor.ui" line="185"/>
        <location filename="../../Form_Files/ClipEditor.ui" line="215"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="153"/>
        <source>Move an entry to the level of its parent.</source>
        <translation>ย้ายรายการไปยังระดับ parent.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="182"/>
        <source>You must select an item immediately under a group to move it into the group.</source>
        <translation>คุณต้องเลือกรายการภายใต้กลุ่มที่จะย้ายเข้ามาในกลุ่ม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="212"/>
        <source>Move an entry down one in the group.</source>
        <translation>ย้ายรายการหนึ่งรายการลงในกลุ่ม</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="73"/>
        <source>Right click on an entry to see a context menu of actions.</source>
        <translation>คลิกขวาที่รายการเพื่อดูเมนูของการกระทำ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="74"/>
        <source>You can also right click in your document to select an entry.</source>
        <translation>นอกจากนี้คุณยังสามารถคลิกขวาในเอกสารเพื่อเลือกรายการ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="76"/>
        <source>Name</source>
        <translation>ชื่อ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="76"/>
        <source>Name of your entry or group.</source>
        <translation>ชื่อรายการหรือกลุ่มของคุณ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="77"/>
        <source>Text</source>
        <translation>ข้อความ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="77"/>
        <source>The text to insert. The text is treated like a Regex replacement expression so \1 can be used to insert the text selected in Code View when you paste the clip.</source>
        <translation>ข้อความที่จะแทรก ข้อความจะถือว่าเหมือนกับนิพจน์แทนที่ Regex ดังนั้น \1 สามารถใช้เพื่อแทรกข้อความที่เลือกในมุมมองโค้ดเมื่อคุณวางคลิป</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="81"/>
        <source>Save</source>
        <translation>บันทึก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="81"/>
        <source>Save your changes.</source>
        <translation>บันทึกการเปลี่ยนแปลง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="81"/>
        <source>If any other instances of Sigil are running they will be automatically updated with your changes.</source>
        <translation>หากมีอินสแตนซ์อื่น ๆ ของ Sigil กำลังทำงานระบบจะอัปเดตโดยอัตโนมัติกับการเปลี่ยนแปลงของคุณ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="91"/>
        <source>Cannot save entries.</source>
        <translation>บันทึกรายงานไม่ได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="135"/>
        <source>Clip entries loaded from file.</source>
        <translation>รายการคลิปที่โหลดจากไฟล์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="195"/>
        <source>You cannot select an entry and a group containing the entry.</source>
        <translation>คุณไม่สามารถเลือกรายการและกลุ่มที่มีรายการได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="282"/>
        <source>You cannot Copy or Cut groups - use drag-and-drop.</source>
        <translation>คุณไม่สามารถคัดลอกหรือตัดกลุ่ม - ใช้ลากและวาง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="354"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="354"/>
        <source>Are you sure you want to reload all entries?  This will overwrite any unsaved changes.</source>
        <translation>คุณแน่ใจหรือไม่ว่าต้องการโหลดรายการใหม่ทั้งหมด การดำเนินการนี้ทับการเปลี่ยนแปลงที่ไม่ได้บันทึก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="370"/>
        <source>Import Entries</source>
        <translation>นำเข้ารายการ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="444"/>
        <source>Export Selected Entries</source>
        <translation>ส่งออกรายการที่เลือก</translation>
    </message>
    <message numerus="yes">
        <location filename="../../Dialogs/ClipEditor.cpp" line="525"/>
        <source>CSS entries added: %n</source>
        <translation><numerusform>เพิ่มรายการ CSS แล้ว: %n</numerusform></translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="638"/>
        <source>Edit</source>
        <translation>แก้ไข</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="639"/>
        <source>Cut</source>
        <translation>ตัด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="640"/>
        <source>Copy</source>
        <translation>คัดลอก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="641"/>
        <source>Paste</source>
        <translation>วาง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="642"/>
        <source>Delete</source>
        <translation>ลบ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="643"/>
        <source>Import</source>
        <translation>นำเข้า</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="644"/>
        <source>Reload</source>
        <translation>โหลดใหม่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="645"/>
        <source>Export</source>
        <translation>ส่งออก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="646"/>
        <source>Export All</source>
        <translation>ส่งออกทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="647"/>
        <source>Collapse All</source>
        <translation>หุบทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="648"/>
        <source>Expand All</source>
        <translation>ขยายออกทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="649"/>
        <source>Autofill</source>
        <translation>การป้อนอัตโนมัติ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="729"/>
        <source>Clip entries saved.</source>
        <translation>บันทึกรายการคลิปไว้แล้ว</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="758"/>
        <source>Sigil: Clip Editor</source>
        <translation>Sigil: ตัวแก้ไขคลิป</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="759"/>
        <source>The Clip entries may have been modified.
Do you want to save your changes?</source>
        <translation>รายการคลิปอาจถูกแก้ไขแล้ว
คุณต้องการบันทึกการเปลี่ยนแปลงหรือไม่?</translation>
    </message>
</context>
<context>
    <name>ClipEditorModel</name>
    <message>
        <location filename="../../MiscEditors/ClipEditorModel.cpp" line="65"/>
        <source>Name</source>
        <translation>ชื่อ</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/ClipEditorModel.cpp" line="66"/>
        <source>Text</source>
        <translation>ข้อความ</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/ClipEditorModel.cpp" line="680"/>
        <source>Unable to create file %1</source>
        <translation>ไม่สามารถสร้างไฟล์ %1</translation>
    </message>
</context>
<context>
    <name>ClipboardHistorySelector</name>
    <message>
        <location filename="../../Form_Files/ClipboardHistorySelector.ui" line="14"/>
        <source>Select Text to Paste</source>
        <translation>เลือกข้อความที่จะวาง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipboardHistorySelector.ui" line="20"/>
        <source>Recent clipboards:</source>
        <translation>คลิปบอร์ดล่าสุด:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipboardHistorySelector.cpp" line="337"/>
        <source>Paste</source>
        <translation>วาง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipboardHistorySelector.cpp" line="339"/>
        <source>Save</source>
        <translation>บันทึก</translation>
    </message>
</context>
<context>
    <name>ClipsWindow</name>
    <message>
        <location filename="../../MainUI/ClipsWindow.cpp" line="34"/>
        <source>Clips</source>
        <translation>คลิป</translation>
    </message>
    <message>
        <location filename="../../MainUI/ClipsWindow.cpp" line="99"/>
        <source>Collapse All</source>
        <translation>หุบทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../MainUI/ClipsWindow.cpp" line="100"/>
        <source>Expand All</source>
        <translation>ขยายออกทั้งหมด</translation>
    </message>
</context>
<context>
    <name>CodeViewEditor</name>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="419"/>
        <source>Cannot insert closing tag at this position.</source>
        <translation>แทรกแท็กปิดตำแหน่งนี้ไม่ได้</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="428"/>
        <source>No open tags found at this position.</source>
        <translation>ไม่พบแท็กเปิดตำแหน่งนี้</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1176"/>
        <source>Add To Default Dictionary</source>
        <translation>เพิ่มเป็นพจนานุกรมเริ่มต้น</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1189"/>
        <source>Add To Dictionary</source>
        <translation>เพิ่มเป็นพจนานุกรม</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1206"/>
        <source>Ignore</source>
        <translation>ข้าม</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1268"/>
        <source>Reformat CSS</source>
        <translation>จัดรูปแบบ CSS</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1269"/>
        <source>Multiple Lines Per Style</source>
        <translation>หลายบรรทัดต่อสไตล์</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1270"/>
        <source>Single Line Per Style</source>
        <translation>หนึ่งบรรทัดต่อสไตล์</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1295"/>
        <source>Reformat HTML</source>
        <translation>จัดรูปแบบ HTML</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1296"/>
        <source>Mend and Prettify Code</source>
        <translation>แก้ไขและกำหนดรหัส</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1297"/>
        <source>Mend and Prettify Code - All HTML Files</source>
        <translation>แก้ไขและกำหนดรหัส  - ทุกไฟล์ HTML</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1298"/>
        <source>Mend Code</source>
        <translation>แก้ไขรหัส</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1299"/>
        <source>Mend Code - All HTML Files</source>
        <translation>แก้ไขรหัส - ทุกไฟล์ HTML</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1329"/>
        <source>Go To Link Or Style</source>
        <translation>ไปที่ลิงก์หรือสไตล์</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1352"/>
        <source>View Image</source>
        <translation>ดูภาพ</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1353"/>
        <source>Open Tab For Image</source>
        <translation>เปิดแท็บสำหรับรูปภาพ</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1379"/>
        <source>Mark Selected Text</source>
        <translation>มาร์คข้อความที่เลือก</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1381"/>
        <source>Unmark Marked Text</source>
        <translation>ไม่เลือกข้อความที่ทำมาร์คไว้</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1407"/>
        <source>Clips</source>
        <translation>คลิป</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1417"/>
        <source>Add To Clips</source>
        <translation>เพิ่มลงในคลิป</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1543"/>
        <source>You must be in an opening HTML tag to use this feature.</source>
        <translation>คุณต้องอยู่ในแท็กเปิด HTML ที่เปิดเพื่อใช้คุณลักษณะนี้</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1553"/>
        <source>You must be inside an opening HTML tag to use this feature.</source>
        <translation>คุณต้องอยู่ภายในแท็ก HTML ที่เปิดเพื่อใช้คุณลักษณะนี้</translation>
    </message>
</context>
<context>
    <name>ColorSwatchDelegate</name>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="56"/>
        <source>Background</source>
        <translation>พื้้นหลัง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="58"/>
        <source>Foreground</source>
        <translation>พื้นหน้า</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="60"/>
        <source>Selection Background</source>
        <translation>เลือกพื้นหลัง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="62"/>
        <source>Selection Foreground</source>
        <translation>เลือกเบื้องหน้า</translation>
    </message>
</context>
<context>
    <name>DeleteFiles</name>
    <message>
        <location filename="../../Form_Files/DeleteFiles.ui" line="14"/>
        <source>Delete Files</source>
        <translation>ลบไฟล์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteFiles.cpp" line="66"/>
        <source>Delete Marked Files</source>
        <translation>ลบไฟล์ที่เลือก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteFiles.cpp" line="67"/>
        <source>Delete</source>
        <translation>ลบ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteFiles.cpp" line="68"/>
        <source>File</source>
        <translation>ไฟล์</translation>
    </message>
</context>
<context>
    <name>DeleteStyles</name>
    <message>
        <location filename="../../Form_Files/DeleteStyles.ui" line="14"/>
        <source>Delete Styles</source>
        <translation>ลบสไตล์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteStyles.cpp" line="79"/>
        <source>Delete Marked Styles</source>
        <translation>ลบสไตล์ที่เลือก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteStyles.cpp" line="80"/>
        <source>Delete</source>
        <translation>ลบ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteStyles.cpp" line="81"/>
        <source>File</source>
        <translation>ไฟล์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteStyles.cpp" line="82"/>
        <source>Style</source>
        <translation>สไตล์</translation>
    </message>
</context>
<context>
    <name>EditTOC</name>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="14"/>
        <source>Edit Table Of Contents</source>
        <translation>แก้ไขสารบัญ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="52"/>
        <source>Insert a blank entry above the currently selected entry.</source>
        <translation>แทรกรายการว่างเหนือรายการที่เลือกในปัจจุบัน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="55"/>
        <source>Add Above</source>
        <translation>เพิ่มด้านบน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="62"/>
        <source>Add a blank entry below the currently selected entry.</source>
        <translation>เพิ่มรายการว่างใต้รายการที่เลือกในปัจจุบัน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="65"/>
        <source>Add Below</source>
        <translation>เพิ่มด้านล่าง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="72"/>
        <source>Delete the selected TOC entry</source>
        <translation>ลบรายการสารบัญที่เลือก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="75"/>
        <location filename="../../Dialogs/EditTOC.cpp" line="443"/>
        <source>Delete</source>
        <translation>ลบ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="82"/>
        <source>Set the destination of the TOC entry from a list of valid targets in the book.</source>
        <translation>ตั้งปลายทางของรายการสารบัญจากรายการเป้าหมายที่ถูกต้องในหนังสือ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="85"/>
        <source>Select Target</source>
        <translation>เลือกเป้าหมาย</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="110"/>
        <source>Decrease the heading level of the selected entry.
You can also use the left arrow key.</source>
        <translation>ลดระดับหัวเรื่องของรายการที่เลือก
คุณยังสามารถใช้ปุ่มลูกศรซ้าย</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="126"/>
        <location filename="../../Form_Files/EditTOC.ui" line="136"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="148"/>
        <source>Increase the heading level of the selected entry.
You can also use the right arrow key.</source>
        <translation>เพิ่มระดับหัวเรื่องของรายการที่เลือก
คุณยังสามารถใช้ปุ่มลูกศรขวา</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="85"/>
        <source>TOC Entry</source>
        <translation>รายการสารบัญ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="86"/>
        <source>Target</source>
        <translation>เป้าหมาย</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="442"/>
        <source>Rename</source>
        <translation>เปลี่ยนชื่อ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="450"/>
        <source>Move Up</source>
        <translation>ย้ายขึ้น</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="451"/>
        <source>Move Down</source>
        <translation>ย้ายลง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="457"/>
        <source>Expand All</source>
        <translation>ขยายออกทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="458"/>
        <source>Collapse All</source>
        <translation>หุบทั้งหมด</translation>
    </message>
</context>
<context>
    <name>EmbeddedPython</name>
    <message>
        <location filename="../../Misc/EmbeddedPython.cpp" line="617"/>
        <location filename="../../Misc/EmbeddedPythonPkg.cpp" line="613"/>
        <source>Embedded Python Error</source>
        <translation>ข้อผิดพลาดใน Python แบบฝัง</translation>
    </message>
</context>
<context>
    <name>FindReplace</name>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="20"/>
        <source>Find &amp; Replace</source>
        <translation>ค้นหา &amp; แทนที่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="55"/>
        <source>Hide Find and Replace</source>
        <translation>ซ่อนค้นหา &amp; แทนที่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="61"/>
        <location filename="../../Form_Files/FindReplace.ui" line="109"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="103"/>
        <source>Show/Hide Advanced Options</source>
        <translation>แสดง/ซ่อนตัวเลือกขั้นสูง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="152"/>
        <source>Find:</source>
        <translation>ค้นหา:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="184"/>
        <source>Find next match.</source>
        <translation>ค้นหาที่ตรงกันถัดไป</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="190"/>
        <source>Find</source>
        <translation>ค้นหา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="203"/>
        <source>Replace highlighted match (if any),
then find the Next match in Code View.</source>
        <translation>แทนที่การจับคู่ที่ไฮไลต์ (ถ้ามี)
แล้วหาที่ตรงกันถัดไปในมุมมองโค้ด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="210"/>
        <source>Replace/Find</source>
        <translation>แทนที่/หา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="217"/>
        <source>Replace:</source>
        <translation>แทนที่:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="249"/>
        <source>Replace highlighted match (if any) in Code View.</source>
        <translation>แทนที่ที่ตรงกันที่ไฮไลต์ (ถ้ามี) ในมุมมองโค้ด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="255"/>
        <source>Replace</source>
        <translation>แทนที่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="268"/>
        <source>Replace all matches in Code View.</source>
        <translation>แทนที่ที่ตรงกันทั้งหมดในมุมมองโค้ด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="274"/>
        <source>Replace All</source>
        <translation>แทนที่ทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="281"/>
        <source>Options:</source>
        <translation>ตัวเลือก:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="293"/>
        <source>For Regex searches, prefix your search with (?s).</source>
        <translation>สำหรับการค้นหา Regex ให้พิมพ์คำนำหน้าด้วย (?s)</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="299"/>
        <source>DotAll</source>
        <translation>DotAll</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="306"/>
        <source>For Regex searches, prefix your search with (?U).</source>
        <translation>สำหรับการค้นหา Regex ให้พิมพ์คำนำหน้าด้วย (?U)</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="312"/>
        <source>Minimal Match</source>
        <translation>จับคู่น้อยที่สุด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="319"/>
        <source>For Regex searches, tokenise/escape selection when opening Find.</source>
        <translation>สำหรับการค้นหา Regex เลือก tokenise/escape เมื่อเปิดการค้นหา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="325"/>
        <source>Auto-Tokenise</source>
        <translation>Auto-Tokenise</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="332"/>
        <source>Search from current position to end of the 
current file or book, and then wrap to the
other end to continue searching.</source>
        <translation>ค้นหาจากตำแหน่งปัจจุบันไปยังจุดสิ้นสุดของไฟล์
หรือหนังสือปัจจุบันจากปกหน้าไปอีกปกหลัง
เพื่อดำเนินการค้นหาต่อ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="337"/>
        <source>Wrap</source>
        <translation>Wrap</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="371"/>
        <source>Count all matches in Code View.</source>
        <translation>นับการที่ตรงกันทั้งหมดในมุมมองโค้ด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="377"/>
        <source>Count All</source>
        <translation>นับทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="384"/>
        <source>Mode:</source>
        <translation>โหมด:</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="179"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1435"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1436"/>
        <source>Current File</source>
        <translation>ไฟล์ปัจจุบัน</translation>
    </message>
    <message numerus="yes">
        <location filename="../../MainUI/FindReplace.cpp" line="334"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1258"/>
        <source>Matches found: %n</source>
        <translation><numerusform>พบรายการที่ตรงกัน: %n</numerusform></translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="418"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1282"/>
        <source>No replacements made</source>
        <translation>ไม่มีการเปลี่ยนแปลง</translation>
    </message>
    <message numerus="yes">
        <location filename="../../MainUI/FindReplace.cpp" line="420"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1284"/>
        <source>Replacements made: %n</source>
        <translation><numerusform>เปลี่ยนแปลง: %n</numerusform></translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="621"/>
        <source>No matches found</source>
        <translation>ไม่พบข้อมูลที่ตรงกัน</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1136"/>
        <source>This tab cannot be searched</source>
        <translation>แท็บนี้ไม่สามารถค้นหาได้</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1168"/>
        <source>Unnamed search loaded</source>
        <translation>โหลดการค้นหาที่ไม่มีชื่อ</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1171"/>
        <source>Loaded</source>
        <translation>โหลด</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1184"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1204"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1222"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1242"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1268"/>
        <source>No searches selected</source>
        <translation>ไม่ได้เลือกการค้นหา</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1425"/>
        <source>What to search for</source>
        <translation>สิ่งที่ค้นหา</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1426"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1427"/>
        <source>Normal</source>
        <translation>ปรกติ</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1427"/>
        <source>Case in-sensitive search of exactly what you type.</source>
        <translation>ค้นหาแบบไม่คำนึงถึงตัวพิมพ์เล็กและใหญ่ของสิ่งที่คุณพิมพ์</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1428"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1429"/>
        <source>Case Sensitive</source>
        <translation>อักษรบังคับ</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1429"/>
        <source>Case sensitive search of exactly what you type.</source>
        <translation>ค้นหาแบบคำนึงถึงตัวพิมพ์เล็กและใหญ่ของสิ่งที่คุณพิมพ์</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1430"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1431"/>
        <source>Regex</source>
        <translation>Regex</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1431"/>
        <source>Search for a pattern using Regular Expression syntax.</source>
        <translation>ค้นหารูปแบบโดยใช้ไวยากรณ์ Regular Expression</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1434"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1446"/>
        <source>Where to search</source>
        <translation>ตำแหน่งที่ค้นหา</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1436"/>
        <source>Restrict the find or replace to the opened file.  Hold the Ctrl key down while clicking any search buttons to temporarily restrict the search to the Current File.</source>
        <translation>จำกัดการค้นหาหรือแทนที่ไฟล์ที่เปิดอยู่ กดปุ่ม Ctrl ค้างไว้ขณะคลิกปุ่มค้นหาเพื่อ จำกัด การค้นหาชั่วคราวไปยังไฟล์ปัจจุบัน</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1437"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1438"/>
        <source>All HTML Files</source>
        <translation>ไฟล์ HTML ทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1438"/>
        <source>Find or replace in all HTML files in Code View.</source>
        <translation>ค้นหาหรือแทนที่ไฟล์ HTML ทั้งหมดในมุมมองโค้ด</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1439"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1440"/>
        <source>Selected HTML Files</source>
        <translation>ไฟล์ HTML ที่เลือก</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1440"/>
        <source>Restrict the find or replace to the HTML files selected in the Book Browser in Code View.</source>
        <translation>จำกัดการค้นหาหรือแทนที่ไฟล์ HTML ที่เลือกใน Book Browser ในมุมมองโค้ด</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1442"/>
        <source>To restrict search to selected text, use Search&amp;rarr;Mark Selected Text.</source>
        <translation>หากต้องการจำกัดการค้นหาข้อความที่เลือกให้ใช้ ค้นหา&amp;rarr; เลือกข้อความที่เลือก</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1447"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1448"/>
        <source>Marked Text</source>
        <translation>มาร์คข้อความ</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1448"/>
        <source>Restrict the find or replace to the text marked by Search&amp;rarr;Mark Selected Text.  Cleared if you use Undo, enter text, or change views or tabs.</source>
        <translation>จำกัดการค้นหาหรือแทนที่ข้อความที่ทำเครื่องหมายไว้โดยการค้นหาทำเครื่องหมายเลือกข้อความ เคลียร์ถ้าคุณใช้การเลิกทำป้อนข้อความหรือเปลี่ยนมุมมองหรือแท็บ</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1452"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1456"/>
        <source>Up</source>
        <translation>ขึ้น</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1453"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1457"/>
        <source>Down</source>
        <translation>ลง</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1454"/>
        <source>Direction to search</source>
        <translation>ทิศทางในการค้นหา</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1456"/>
        <source>Search for the previous match from your current position.</source>
        <translation>ค้นหาที่ตรงกันก่อนหน้าจากตำแหน่งปัจจุบันของคุณ</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1457"/>
        <source>Search for the next match from your current position.</source>
        <translation>ค้นหาที่ตรงกันถัดไปจากตำแหน่งปัจจุบันของคุณ</translation>
    </message>
</context>
<context>
    <name>FindReplaceQLineEdit</name>
    <message>
        <location filename="../../Misc/FindReplaceQLineEdit.cpp" line="58"/>
        <source>Tokenise Selection</source>
        <translation>เลือก tokenize</translation>
    </message>
    <message>
        <location filename="../../Misc/FindReplaceQLineEdit.cpp" line="71"/>
        <source>Save Search</source>
        <translation>บันทึกการค้นหา</translation>
    </message>
</context>
<context>
    <name>FlowTab</name>
    <message>
        <location filename="../../Tabs/FlowTab.cpp" line="1162"/>
        <source>Print %1</source>
        <translation>พิมพ์ %1</translation>
    </message>
</context>
<context>
    <name>GeneralSettingsWidget</name>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="14"/>
        <source>General Settings</source>
        <translation>ตั้งค่าทั่วไป</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="20"/>
        <source>Choose which version of Epub to use
when creating new or empty Epubs in Sigil.</source>
        <translation>เลือกรุ่นของ Epub ใช้
เมื่อสร้าง Epubs ใหม่หรือว่างเปล่าใน Sigil</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="24"/>
        <source>Create New or Empty Epubs as:</source>
        <translation>สร้าง Epubs ใหม่หรือว่างเปล่าเป็น:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="30"/>
        <source>Epub Version 2.</source>
        <translation>Epub รุ่นที่ 2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="33"/>
        <source>Version 2</source>
        <translation>รุ่นที่ 2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="43"/>
        <source>Epub Version 3.</source>
        <translation>Epub รุ่นที่ 3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="46"/>
        <source>Version 3</source>
        <translation>รุ่นที่ 3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="59"/>
        <source>Choose when your HTML code is automatically 
mended.</source>
        <translation>เลือกเมื่อโค้ด HTML ของคุณถูกซ่อมแซมโดยอัตโนมัติ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="63"/>
        <source>Mend XHTML Source Code On:</source>
        <translation>แก้ไขรหัสต้นฉบับ XHTML บน:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="69"/>
        <source>Mend when opening an Epub or HTML file, 
and when switching from Book View to Code View.</source>
        <translation>แก้ไขเมื่อเปิดไฟล์ Epub หรือ HTML
และเมื่อเปลี่ยนจาก Book View เป็น Code View</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="73"/>
        <source>Open</source>
        <translation>เปิด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="80"/>
        <source>Mend when saving an Epub.</source>
        <translation>แก้ไขเมื่อบันทึก Epub</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="83"/>
        <source>Save</source>
        <translation>บันทึก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="93"/>
        <source>Determine if Epubs are allowed to access non-multimedia remote resources.</source>
        <translation>ตรวจสอบว่า Epubs ได้รับอนุญาตให้เข้าถึงทรัพยากรระยะไกลที่ไม่ใช่มัลติมีเดียหรือไม่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="96"/>
        <source> Control Access by Epubs to non-multimedia remote resources.</source>
        <translation>ควบคุมการเข้าถึงโดย Epubs ไปยังข้อมูลระยะไกลที่ไม่ใช่มัลติมีเดีย</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="105"/>
        <source>Check to allow Epubs to access non-multimedia remote resources.</source>
        <translation>เลือกเพื่ออนุญาตให้ Epubs เข้าถึงทรัพยากรระยะไกลที่ไม่ใช่มัลติมีเดีย</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="108"/>
        <source>Epubs may access all remote resources types.</source>
        <translation>Epubs อาจเข้าถึงทรัพยากรระยะไกลทุกประเภท</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="127"/>
        <source>What CSS level to specify for W3C stylesheet validation tool (EPUB2)</source>
        <translation>ระดับ CSS ใดที่จะระบุสำหรับเครื่องมือตรวจสอบสไตล์ชีต W3C (EPUB2)</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="130"/>
        <source>EPUB2 W3C Stylesheet Validation Level:</source>
        <translation>ระดับการตรวจสอบสไตล์ชีตของ EPUB2 W3C:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="139"/>
        <source>W3C stylesheet validator will use CSS level 2 for EPUB2</source>
        <translation>เครื่องมือตรวจสอบสไตล์ชีต W3C จะใช้ CSS ระดับ 2 สำหรับ EPUB2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="142"/>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="199"/>
        <source>CSS Level 2</source>
        <translation>CSS ระดับ 2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="149"/>
        <source>W3C stylesheet validator will use CSS level 2.1 for EPUB2</source>
        <translation>เครื่องมือตรวจสอบสไตล์ชีต W3C จะใช้ CSS ระดับ 2.1 สำหรับ EPUB2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="152"/>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="209"/>
        <source>CSS Level 2.1</source>
        <translation>CSS ระดับ 2.1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="162"/>
        <source>W3C stylesheet validator will use CSS level 3 for EPUB2</source>
        <translation>เครื่องมือตรวจสอบสไตล์ชีต W3C จะใช้ CSS ระดับ 3 สำหรับ EPUB2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="165"/>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="222"/>
        <source>CSS Level 3</source>
        <translation>CSS ระดับ 3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="184"/>
        <source>What CSS Level to specify for W3C stylesheet validation tool (EPUB3)</source>
        <translation>ระดับ CSS ใดที่จะระบุสำหรับเครื่องมือตรวจสอบสไตล์ชีต W3C (EPUB3)</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="187"/>
        <source>EPUB3 W3C Stylesheet Validation Level:</source>
        <translation>ระดับการตรวจสอบสไตล์ชีตของ EPUB3 W3C:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="196"/>
        <source>W3C stylesheet validator will use CSS level 2 for EPUB3</source>
        <translation>เครื่องมือตรวจสอบสไตล์ชีต W3C จะใช้ CSS ระดับ 2 สำหรับ EPUB3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="206"/>
        <source>W3C stylesheet validator will use CSS level 2.1 for EPUB3</source>
        <translation>เครื่องมือตรวจสอบสไตล์ชีต W3C จะใช้ CSS ระดับ 2.1 สำหรับ EPUB3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="219"/>
        <source>W3C stylesheet validator will use CSS level 3 for EPUB3</source>
        <translation>เครื่องมือตรวจสอบสไตล์ชีต W3C จะใช้ CSS ระดับ 3 สำหรับ EPUB3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="235"/>
        <source>Number of clipboard history items to save between sessions (0 disables):</source>
        <translation>จำนวนรายการประวัติคลิปบอร์ดที่จะบันทึกระหว่างเซสชัน (ปิดใช้งาน 0 ครั้ง):</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="247"/>
        <source>Use to limit (or disable) clipboard history saving between sessions</source>
        <translation>ใช้เพื่อจำกัดการบันทึกประวัติคลิปบอร์ด (หรือปิดใช้งาน) ระหว่างเซสชัน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="279"/>
        <source>Set Folder where temporary files should be created</source>
        <translation>ตั้งค่าโฟลเดอร์ที่ควรสร้างไฟล์ชั่วคราว</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="290"/>
        <source>Auto</source>
        <translation>อัตโมัติ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="297"/>
        <source>Browse</source>
        <translation>เรียกดู</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/GeneralSettingsWidget.cpp" line="132"/>
        <source>Select Folder for Temporary Files</source>
        <translation>เลือกโฟลเดอร์สำหรับไฟล์ชั่วคราว</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/GeneralSettingsWidget.cpp" line="147"/>
        <source>Incorrect Folder for Temporary Files selected</source>
        <translation>โฟลเดอร์สำหรับไฟล์ชั่วคราวที่เลือกไม่ถูกต้อง</translation>
    </message>
</context>
<context>
    <name>GuideItems</name>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="110"/>
        <source>Acknowledgements</source>
        <translation>การรับรอง</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="110"/>
        <source>A passage containing acknowledgments to entities involved in the realization of the work.</source>
        <translation>ข้อความที่มีการตอบรับต่อหน่วยงานที่เกี่ยวข้องกับการทำงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="111"/>
        <source>Bibliography</source>
        <translation>บรรณานุกรม</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="111"/>
        <source>A list of works cited.</source>
        <translation>รายการงานที่อ้างถึง</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="112"/>
        <source>Text</source>
        <translation>ข้อความ</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="112"/>
        <source>The start of the main text content of a publication.</source>
        <translation>จุดเริ่มต้นของเนื้อหาข้อความหลักของสิ่งพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="113"/>
        <source>Colophon</source>
        <translation>Colophon</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="113"/>
        <source>A brief description usually located at the end of a publication, describing production notes relevant to the edition.</source>
        <translation>คำอธิบายสั้น ๆ มักจะอยู่ที่ตอนท้ายของสิ่งตีพิมพ์อธิบายบันทึกการผลิตที่เกี่ยวข้อง</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="114"/>
        <source>Copyright Page</source>
        <translation>หน้าลิขสิทธิ์</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="114"/>
        <source>The copyright page of the work.</source>
        <translation>หน้าลิขสิทธิ์ของการทำงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="115"/>
        <source>Cover</source>
        <translation>ปก</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="115"/>
        <source>The publications cover(s), jacket information, etc.</source>
        <translation>ปกสิ่งพิมพ์, แจ็คเก็ตข้อมูล ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="116"/>
        <source>Dedication</source>
        <translation>การอุทิศ</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="116"/>
        <source>An inscription addressed to one or several particular person(s).</source>
        <translation>การอุทิศถึงบุคคลใดบุคคลหนึ่งหรือหลายคน</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="117"/>
        <source>Epigraph</source>
        <translation>คำสลัก</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="117"/>
        <source>A quotation that is pertinent but not integral to the text.</source>
        <translation>ใบเสนอราคาที่เกี่ยวข้อง แต่ไม่รวมถึงข้อความ</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="118"/>
        <source>Foreword</source>
        <translation>คำนำ</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="118"/>
        <source>An introductory section that precedes the work, typically not written by the work&apos;s author.</source>
        <translation>ส่วนแนะนำที่นำเสนอผลงานโดยปกติแล้วไม่ได้เขียนโดยผู้เขียนของผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="119"/>
        <source>Glossary</source>
        <translation>อภิธานศัพท์</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="119"/>
        <source>An alphabetical list of terms in a particular domain of knowledge, with the definitions for those terms.</source>
        <translation>รายการคำศัพท์ตามตัวอักษรในโดเมนเฉพาะของความรู้โดยมีคำนิยามสำหรับคำเหล่านั้น</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="120"/>
        <source>Index</source>
        <translation>ดัชนี</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="120"/>
        <source>A detailed list, usually arranged alphabetically, of the specific information in a publication.</source>
        <translation>รายละเอียดโดยปกติจะจัดเรียงตามลำดับตัวอักษรของข้อมูลเฉพาะในสิ่งพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="121"/>
        <source>List of Illustrations</source>
        <translation>รายชื่อภาพประกอบ</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="121"/>
        <source>A listing of illustrations included in the work.</source>
        <translation>รายชื่อภาพประกอบที่รวมอยู่ในผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="122"/>
        <source>List of Tables</source>
        <translation>รายการของตาราง</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="122"/>
        <source>A listing of tables included in the work.</source>
        <translation>รายชื่อของตารางรวมอยู่ในผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="123"/>
        <source>Notes</source>
        <translation>การบันทึก</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="123"/>
        <source>A collection of notes. It can be used to identify footnotes, rear notes, marginal notes, inline notes, and similar when legacy naming conventions are not desired. Status: Deprecated - Replaced by: &apos;footnotes&apos;, &apos;rearnotes&apos;</source>
        <translation>คอลเลกชันของบันทึกย่อ สามารถใช้เพื่อระบุเชิงอรรถบันทึกย่อด้านหลังบันทึกย่อขอบกระดาษโน้ตแบบอินไลน์และอื่น ๆ เมื่อไม่ต้องการอนุสัญญาการตั้งชื่อเดิม สถานะ: เลิกใช้ - แทนที่ด้วย: &quot;เชิงอรรถ&quot;, &quot;บันทึกหลัง&quot;</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="124"/>
        <source>Preface</source>
        <translation>คำนำ</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="124"/>
        <source>An introductory section that precedes the work, typically written by the work&apos;s author.</source>
        <translation>ส่วนแนะนำที่นำเสนอผลงานเขียนโดยผู้เขียนงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="125"/>
        <source>Title Page</source>
        <translation>หน้าชื่อเรื่อง</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="125"/>
        <source>A page at the beginning of a book giving its title, authors, publisher and other publication information.</source>
        <translation>หน้าเริ่มต้นของหนังสือให้ชื่อผู้เขียน สำนักพิมพ์และสิ่งพิมพ์ ข้อมูลอื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="126"/>
        <source>Table of Contents</source>
        <translation>สารบัญ</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="126"/>
        <source>A table of contents which is a list of the headings or parts of the book or document, organized in the order in which they appear. Typically appearing in the work&apos;s frontmatter, or at the beginning of a section.</source>
        <translation>สารบัญซึ่งเป็นรายการส่วนหัวหรือส่วนของหนังสือหรือเอกสารจัดเรียงตามลำดับที่ปรากฏ โดยปกติจะปรากฏในส่วนหน้าของงานหรือที่ส่วนเริ่มต้น</translation>
    </message>
</context>
<context>
    <name>HTMLFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsHTMLFilesWidget.ui" line="14"/>
        <source>HTML Files</source>
        <translation>ไฟล์ HTML</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsHTMLFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsHTMLFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>กรอง:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="74"/>
        <source>Name</source>
        <translation>ชื่อ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="75"/>
        <source>File Size (KB)</source>
        <translation>ขนาดไฟล์ (KB)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="76"/>
        <source>All Words</source>
        <translation>คำทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="77"/>
        <source>Misspelled Words</source>
        <translation>คำที่สะกดผิด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="78"/>
        <source>Images</source>
        <translation>รูปภาพ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="79"/>
        <source>Video</source>
        <translation>วีดีโอ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="80"/>
        <source>Audio</source>
        <translation>เสียง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="81"/>
        <source>Stylesheets</source>
        <translation>สไตล์ชีต</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="82"/>
        <source>Well Formed</source>
        <translation>จัดดีแล้ว</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="171"/>
        <source>Yes</source>
        <translation>ใช่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="171"/>
        <source>No</source>
        <translation>ไม่</translation>
    </message>
    <message numerus="yes">
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="190"/>
        <source>%n file(s)</source>
        <translation><numerusform>%n ไฟล์</numerusform></translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="331"/>
        <source>Save Report As Comma Separated File</source>
        <translation>บันทึกรายงานเป็นไฟล์ที่แบ่งด้วยจุลภาค</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="344"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="344"/>
        <source>Cannot save report file.</source>
        <translation>บันทึกไฟล์รายงานไม่ได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="368"/>
        <source>Delete From Book</source>
        <translation>ลบออกจากหนังสือ</translation>
    </message>
</context>
<context>
    <name>HeadingSelector</name>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="14"/>
        <source>Generate Table Of Contents</source>
        <translation>สร้างสารบัญ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="52"/>
        <source>Change the name of the entry in the TOC.
The heading&apos;s title attribute will be updated in the document.</source>
        <translation>เปลี่ยนชื่อของรายการในสารบัญ
หัวเรื่องของชื่อเรื่องจะได้รับการอัพเดตในเอกสาร</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="56"/>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="975"/>
        <source>Rename</source>
        <translation>เปลี่ยนชื่อ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="81"/>
        <source>Decrease the heading level of the selected entry by 1.
The heading's tag will be updated in the document.
You can also use the left arrow key.</source>
        <translation>ลดระดับหัวเรื่องของรายการที่เลือกไว้ลง 1
แท็กหัวเรื่องจะได้รับการอัปเดตในเอกสาร
นอกจากนี้คุณยังสามารถใช้ปุ่มลูกศรซ้าย</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="96"/>
        <source>Increase the heading level of the selected entry by 1.
The heading's tag will be updated in the document.
You can also use the right arrow key.</source>
        <translation>เพิ่มระดับหัวเรื่องของรายการที่เลือกไว้ขึ้น 1
แท็กหัวเรื่องจะได้รับการอัปเดตในเอกสาร
นอกจากนี้คุณยังสามารถใช้ปุ่มลูกศรขวา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="130"/>
        <source>Only display the items that will be added to the Table Of Contents.
Check or uncheck an entry to determine if it will be added to the TOC.</source>
        <translation>แสดงเฉพาะไอเท็มที่จะถูกเพิ่มลงในสารบัญ
เลือกหรือยกเลิกการเลือกรายการเพื่อดูว่าจะเพิ่มข้อมูลลงในสารบัญหรือไม่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="134"/>
        <source>Show TOC items only</source>
        <translation>แสดงรายการสารบัญเท่านั้น</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="153"/>
        <source>Quickly mark which headings are included in the TOC.
You can then check or uncheck individual headings in the list above.</source>
        <translation>ทำเครื่องหมายว่าหัวเรื่องใดรวมอยู่ในสารบัญได้อย่างรวดเร็ว
จากนั้นคุณสามารถเลือกหรือยกเลิกการเลือกหัวข้อแต่ละรายการในรายการด้านบนได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="602"/>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="618"/>
        <source>Level</source>
        <translation>ระดับ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="602"/>
        <source>Included</source>
        <translation>ที่รวมอยู่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="602"/>
        <source>Hidden</source>
        <translation>ซ่อน</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="617"/>
        <source>TOC Entry / Heading Title</source>
        <translation>หัวเรื่องสารบัญ/หัวข้อหัวเรื่อง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="619"/>
        <source>Include</source>
        <translation>ประกอบด้วย</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="838"/>
        <source>Up to level</source>
        <translation>ขึ้นไปที่ระดับ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="840"/>
        <source>&lt;Select headings to include in TOC&gt;</source>
        <translation>&lt;เลือกส่วนหัวที่จะรวมไว้ในสารบัญ&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="843"/>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="904"/>
        <source>None</source>
        <translation>ไม่มี</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="849"/>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="902"/>
        <source>All</source>
        <translation>ทั้งหมด</translation>
    </message>
</context>
<context>
    <name>ImageFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsImageFilesWidget.ui" line="14"/>
        <source>Image Files</source>
        <translation>ไฟล์รูปภาพ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsImageFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsImageFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>กรอง:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsImageFilesWidget.ui" line="76"/>
        <source>Thumbnail size:</source>
        <translation>ขนาดรูปย่อ:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="88"/>
        <source>Name</source>
        <translation>ชื่อ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="89"/>
        <source>File Size (KB)</source>
        <translation>ขนาดไฟล์ (KB)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="90"/>
        <source>Times Used</source>
        <translation>เวลาที่ใช้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="91"/>
        <source>Width</source>
        <translation>กว้าง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="92"/>
        <source>Height</source>
        <translation>สูง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="93"/>
        <source>Pixels</source>
        <translation>พิกเซล</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="94"/>
        <source>Color</source>
        <translation>สี</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="97"/>
        <source>Image</source>
        <translation>รูปภาพ</translation>
    </message>
    <message numerus="yes">
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="184"/>
        <source>%n file(s)</source>
        <translation><numerusform>%n ไฟล์</numerusform></translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="188"/>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="332"/>
        <source>Save Report As Comma Separated File</source>
        <translation>บันทึกรายงานเป็นไฟล์ที่แบ่งด้วยจุลภาค</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="345"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="345"/>
        <source>Cannot save report file.</source>
        <translation>บันทึกไฟล์รายงานไม่ได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="417"/>
        <source>Delete From Book</source>
        <translation>ลบออกจากหนังสือ</translation>
    </message>
</context>
<context>
    <name>ImageTab</name>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="177"/>
        <source>shades</source>
        <translation>เฉดสี</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="177"/>
        <source>colors</source>
        <translation>สี</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="178"/>
        <source>Grayscale</source>
        <translation>โทนสีเทา</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="178"/>
        <source>Color</source>
        <translation>สี</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="293"/>
        <location filename="../../Tabs/ImageTab.cpp" line="350"/>
        <location filename="../../Tabs/ImageTab.cpp" line="353"/>
        <source>Open With</source>
        <translation>เปิดด้วย</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="328"/>
        <source>Other Application</source>
        <translation>แอพพลิเคชันอื่น</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="351"/>
        <source>Save As</source>
        <translation>บันทึกเป็น</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="352"/>
        <source>Copy Image</source>
        <translation>คัดลอกรูปภาพ</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="400"/>
        <source>Print %1</source>
        <translation>พิมพ์ %1</translation>
    </message>
</context>
<context>
    <name>ImportEPUB</name>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="166"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="167"/>
        <source>This EPUB has HTML files that are not well formed. Sigil can attempt to automatically fix these files, although this can result in data loss.

Do you want to automatically fix the files?</source>
        <translation>EPUB นี้มีไฟล์ HTML ที่ไม่สมบูรณ์ Sigil พยายามแก้ไขไฟล์เหล่านี้โดยอัตโนมัติแม้ว่าจะทำให้ข้อมูลสูญหายได้
คุณต้องการแก้ไขไฟล์โดยอัตโนมัติหรือไม่?</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="501"/>
        <source>Epub has missing or improperly specified OPF.</source>
        <translation>Epub มี OPF ที่ระบุไว้ไม่ครบถ้วนหรือไม่ถูกต้อง</translation>
    </message>
</context>
<context>
    <name>IndexEditor</name>
    <message>
        <location filename="../../Form_Files/IndexEditor.ui" line="14"/>
        <location filename="../../Dialogs/IndexEditor.cpp" line="287"/>
        <source>Index Editor</source>
        <translation>ตัวแก้ไขดัชนี</translation>
    </message>
    <message>
        <location filename="../../Form_Files/IndexEditor.ui" line="22"/>
        <source>Filter:</source>
        <translation>กรอง:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/IndexEditor.ui" line="29"/>
        <source>List only the entries containing the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/IndexEditor.ui" line="55"/>
        <location filename="../../Dialogs/IndexEditor.cpp" line="421"/>
        <source>Add Entry</source>
        <translation>เพิ่มรายการ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="66"/>
        <source>Right click on an entry to see a context menu of actions.</source>
        <translation>คลิกขวาที่รายการเพื่อดูเมนูของการกระทำ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="67"/>
        <source>You can also right click in your document to add selected text to the Index.</source>
        <translation>คุณยังสามารถคลิกขวาในเอกสารของคุณเพื่อเพิ่มข้อความที่เลือกลงในดัชนี</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="69"/>
        <source>Text to Include</source>
        <translation>ข้อความที่จะรวม</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="69"/>
        <source>The pattern to match in your document, e.g. &quot;Gutenberg&quot;. This is a regex pattern so &quot;(?i)Gutenberg&quot; ignores case when matching.</source>
        <translation>รูปแบบให้ตรงกับเอกสารของคุณเช่น &quot;Gutenberg&quot; นี่คือรูปแบบ regex ดังนั้น &quot;(?i) Gutenberg&quot; จะไม่สนใจกรณีเมื่อจับคู่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="70"/>
        <source>Index Entries</source>
        <translation>รายการดัชนี</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="70"/>
        <source>The entry to create in the Index. Leave blank to use text as is, or enter text to display.  Create multi-level entries by using &apos;/&apos; after a level name, e.g. &quot;Books/Fantasy/Alice in Wonderland&quot; or &quot;Books/Fantasy/&quot;.</source>
        <translation>รายการที่จะสร้างในดัชนี ปล่อยให้ว่างเพื่อใช้ข้อความตามที่เป็นอยู่หรือป้อนข้อความที่จะแสดง สร้างรายการหลายระดับโดยใช้ &apos;/&apos; หลังชื่อระดับเช่น &quot;หนังสือ/แฟนตาซี/อลิซในแดนมหัศจรรย์&quot; หรือ &quot;หนังสือ/แฟนตาซี&quot;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="74"/>
        <source>Save</source>
        <translation>บันทึก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="74"/>
        <source>Save your changes.</source>
        <translation>บันทึกการเปลี่ยนแปลง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="74"/>
        <source>If any other instances of Sigil are running they will be automatically updated with your changes.</source>
        <translation>หากมีอินสแตนซ์อื่น ๆ ของ Sigil กำลังทำงานระบบจะอัปเดตโดยอัตโนมัติกับการเปลี่ยนแปลงของคุณ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="84"/>
        <source>Cannot save entries.</source>
        <translation>บันทึกรายงานไม่ได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="126"/>
        <source>Index entries loaded from file.</source>
        <translation>โหลดรายการดัชนีจากไฟล์</translation>
    </message>
    <message numerus="yes">
        <location filename="../../Dialogs/IndexEditor.cpp" line="287"/>
        <source>Entries added: %n</source>
        <translation><numerusform>รายการเพิ่ม: %n</numerusform></translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="293"/>
        <source>Index files: *.ini *.txt (*.ini *.txt)</source>
        <translation>ไฟล์ดัชนี: *.ini *.txt (*.ini *.txt)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="295"/>
        <source>Load Entries From File</source>
        <translation>โหลดรายการจากไฟล์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="311"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="311"/>
        <source>Are you sure you want to reload all entries?  This will overwrite any unsaved changes.</source>
        <translation>คุณแน่ใจหรือไม่ว่าต้องการโหลดรายการใหม่ทั้งหมด การดำเนินการนี้ทับการเปลี่ยนแปลงที่ไม่ได้บันทึก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="329"/>
        <source>Save Entries to File</source>
        <translation>บันทึกรายการเป็นไฟล์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="422"/>
        <source>Edit</source>
        <translation>แก้ไข</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="423"/>
        <source>Cut</source>
        <translation>ตัด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="424"/>
        <source>Copy</source>
        <translation>คัดลอก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="425"/>
        <source>Paste</source>
        <translation>วาง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="426"/>
        <source>Delete</source>
        <translation>ลบ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="427"/>
        <source>Autofill</source>
        <translation>การป้อนอัตโนมัติ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="428"/>
        <source>Open</source>
        <translation>เปิด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="429"/>
        <source>Reload</source>
        <translation>โหลดใหม่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="430"/>
        <source>Save As</source>
        <translation>บันทึกเป็น</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="431"/>
        <source>Select All</source>
        <translation>เลือกทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="506"/>
        <source>Index entries saved.</source>
        <translation>บันทึกดัชนีไว้แล้ว</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="535"/>
        <source>Sigil: Index Editor</source>
        <translation>Sigil: ตัวแก้ไขดัชนี</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="536"/>
        <source>The Index entries may have been modified.
Do you want to save your changes?</source>
        <translation>รายการดัชนีอาจได้รับการแก้ไขแล้ว
ต้องการบันทึกการเปลี่ยนแปลงหรือไม่?</translation>
    </message>
</context>
<context>
    <name>IndexEditorModel</name>
    <message>
        <location filename="../../MiscEditors/IndexEditorModel.cpp" line="61"/>
        <source>Text to Include</source>
        <translation>ข้อความที่จะรวม</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/IndexEditorModel.cpp" line="62"/>
        <source>Index Entries</source>
        <translation>รายการดัชนี</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/IndexEditorModel.cpp" line="347"/>
        <source>Unable to create file %1</source>
        <translation>ไม่สามารถสร้างไฟล์ %1</translation>
    </message>
</context>
<context>
    <name>KeyboardShortcutsWidget</name>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="14"/>
        <source>Keyboard Shortcuts</source>
        <translation>แป้นพิมพ์ลัด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="34"/>
        <source>List only the entries containing the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="37"/>
        <source>Filter: </source>
        <translation>กรอง:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="62"/>
        <source>Name</source>
        <translation>ชื่อ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="67"/>
        <source>Shortcut</source>
        <translation>ทางลัด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="72"/>
        <source>Description</source>
        <translation>คำอธิบาย</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="82"/>
        <source>Reset all to default</source>
        <translation>คืนค่าทั้งหมดเป็นค่าเริ่มต้น</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="85"/>
        <source>Reset All</source>
        <translation>คืนค่าทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="115"/>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="125"/>
        <source>Press the key combination you want to use.</source>
        <translation>กดชุดคีย์ที่คุณต้องการใช้</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="118"/>
        <source>Shortcut:</source>
        <translation>ทางลัด:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="141"/>
        <source>Assign this keyboard shortcut, overriding any conflicting usages.</source>
        <translation>กำหนดแป้นพิมพ์ลัดนี้ มีความขัดแย้งกับสิ่งที่ใช้อยู่แล้ว</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="144"/>
        <source>Assign</source>
        <translation>กำหนด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="160"/>
        <source>Remove this keyboard shortcut.</source>
        <translation>นำแป้นพิมพ์ลัดนี้ออก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="163"/>
        <source>Remove</source>
        <translation>นำออก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/KeyboardShortcutsWidget.cpp" line="343"/>
        <source>Conflicts with: &lt;b&gt;</source>
        <translation>ขัดแย้งกับ:</translation>
    </message>
</context>
<context>
    <name>Landmarks</name>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="117"/>
        <source>Acknowledgments</source>
        <translation>การรับรอง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="117"/>
        <source>A passage containing acknowledgments to entities involved in the realization of the work.</source>
        <translation>ข้อความที่มีการตอบรับต่อหน่วยงานที่เกี่ยวข้องกับการทำงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="118"/>
        <source>Afterword</source>
        <translation>เล่ม</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="118"/>
        <source>A closing statement from the author or a person of importance to the story, typically providing insight into how the story came to be written, its significance or related events that have transpired since its timeline.</source>
        <translation>คำแถลงการปิดบัญชีจากผู้เขียนหรือบุคคลที่มีความสำคัญกับเรื่องราว โดยทั่วไปจะให้ข้อมูลเชิงลึกว่าเรื่องราวจะถูกเขียนขึ้นอย่างไร ความสำคัญหรือเหตุการณ์ที่เกี่ยวข้องซึ่งเกิดขึ้นตั้งแต่ช่วงเวลานั้น</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="119"/>
        <source>Annotation</source>
        <translation>คำอธิบายประกอบ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="119"/>
        <source>Explanatory information about passages in the work. Status: Deprecated</source>
        <translation>ข้อมูลอธิบายเกี่ยวกับอายุที่ผ่าน ๆ ในการงาน สถานะ: เลิกใช้แล้ว</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="120"/>
        <source>Appendix</source>
        <translation>ภาคผนวก</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="120"/>
        <source>Supplemental information.</source>
        <translation>ข้อมูลเพิ่มเติม</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="121"/>
        <source>Assessment</source>
        <translation>การประเมิน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="121"/>
        <source>A test, quiz, or other activity that helps measure a student&apos;s understanding of what is being taught.</source>
        <translation>การทดสอบแบบทดสอบหรือกิจกรรมอื่น ๆ ที่ช่วยวัดความเข้าใจของนักเรียนเกี่ยวกับสิ่งที่กำลังเรียนอยู่</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="122"/>
        <source>Back Matter</source>
        <translation>เรื่องหลัง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="122"/>
        <source>Ancillary material occurring after the main content of a publication, such as indices, appendices, etc.</source>
        <translation>วัสดุเสริมที่เกิดขึ้นหลังจากเนื้อหาหลักของสิ่งพิมพ์เช่นดัชนีภาคผนวก ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="123"/>
        <source>Bibliography</source>
        <translation>บรรณานุกรม</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="123"/>
        <source>A list of works cited.</source>
        <translation>รายการงานที่อ้างถึง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="124"/>
        <source>Body Matter</source>
        <translation>เนื้อเรื่อง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="124"/>
        <source>The main content of a publication.</source>
        <translation>เนื้อหาหลักของสิ่งพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="125"/>
        <source>Chapter</source>
        <translation>บท</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="125"/>
        <source>A major structural division of a piece of writing.</source>
        <translation>ส่วนโครงสร้างที่สำคัญของชิ้นงานเขียน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="126"/>
        <source>Colophon</source>
        <translation>Colophon</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="126"/>
        <source>A brief description usually located at the end of a publication, describing production notes relevant to the edition.</source>
        <translation>คำอธิบายสั้น ๆ มักจะอยู่ที่ตอนท้ายของสิ่งตีพิมพ์อธิบายบันทึกการผลิตที่เกี่ยวข้อง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="127"/>
        <source>Conclusion</source>
        <translation>ข้อสรุป</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="127"/>
        <source>An ending section that typically wraps up the work.</source>
        <translation>ส่วนที่สิ้นสุดซึ่งมักจะสรุปผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="128"/>
        <source>Contributors</source>
        <translation>ผู้มีส่วนช่วย</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="128"/>
        <source>A list of contributors to the work.</source>
        <translation>รายชื่อของผู้ให้ข้อมูลการทำงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="129"/>
        <source>Copyright Page</source>
        <translation>หน้าลิขสิทธิ์</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="129"/>
        <source>The copyright page of the work.</source>
        <translation>หน้าลิขสิทธิ์ของการทำงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="130"/>
        <source>Cover</source>
        <translation>ปก</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="130"/>
        <source>The publications cover(s), jacket information, etc.</source>
        <translation>ปกสิ่งพิมพ์, แจ็คเก็ตข้อมูล ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="131"/>
        <source>Dedication</source>
        <translation>การอุทิศ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="131"/>
        <source>An inscription addressed to one or several particular person(s).</source>
        <translation>การอุทิศถึงบุคคลใดบุคคลหนึ่งหรือหลายคน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="132"/>
        <source>Division</source>
        <translation>หมวด</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="132"/>
        <source>A major structural division that may also appear as a substructure of a part (esp. in legislation).</source>
        <translation>ส่วนโครงสร้างหลักที่อาจปรากฏเป็นโครงสร้างย่อยของส่วนหนึ่ง (esp ในกฎหมาย)</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="133"/>
        <source>Epigraph</source>
        <translation>คำสลัก</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="133"/>
        <source>A quotation that is pertinent but not integral to the text.</source>
        <translation>ใบเสนอราคาที่เกี่ยวข้อง แต่ไม่รวมถึงข้อความ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="134"/>
        <source>Epilogue</source>
        <translation>ถ้อยคำ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="134"/>
        <source>A concluding section that is typically written from a later point in time than the main story, although still part of the narrative.</source>
        <translation>ส่วนสรุปที่เขียน โดยทั่วไปเขียนในเวลาภายหลังเรื่องหลัก แม้ว่าจะยังคงเป็นส่วนหนึ่งของการเล่าเรื่อง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="135"/>
        <source>Errata</source>
        <translation>คหบดี</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="135"/>
        <source>Publication errata, in printed works typically a loose sheet inserted by hand; sometimes a bound page that contains corrections for mistakes in the work.</source>
        <translation>ที่ตีพิมพ์คหบดีในงานพิมพ์ทั่วไปแล้วจะเป็นแผ่นแทรกด้วยมือ บางครั้งหน้าที่มีการแก้ไขข้อผิดพลาดในการทำงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="136"/>
        <source>Footnotes</source>
        <translation>เชิงอรรถ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="136"/>
        <source>A collection of notes appearing at the bottom of a page.</source>
        <translation>ชุดของโน้ตที่ปรากฏที่ด้านล่างของหน้า</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="137"/>
        <source>Foreword</source>
        <translation>คำนำ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="137"/>
        <source>An introductory section that precedes the work, typically not written by the work&apos;s author.</source>
        <translation>ส่วนแนะนำที่นำเสนอผลงานโดยปกติแล้วไม่ได้เขียนโดยผู้เขียนของผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="138"/>
        <source>Front Matter</source>
        <translation>ส่วนหน้า</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="138"/>
        <source>Preliminary material to the main content of a publication, such as tables of contents, dedications, etc.</source>
        <translation>เนื้อหาเบื้องต้นเกี่ยวกับเนื้อหาหลักของสิ่งพิมพ์เช่น สารบัญ การอุทิศ เป็นต้น</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="139"/>
        <source>Glossary</source>
        <translation>อภิธานศัพท์</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="139"/>
        <source>An alphabetical list of terms in a particular domain of knowledge, with the definitions for those terms.</source>
        <translation>รายการคำศัพท์ตามตัวอักษรในโดเมนเฉพาะของความรู้โดยมีคำนิยามสำหรับคำเหล่านั้น</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="140"/>
        <source>Half Title Page</source>
        <translation>หน้าชื่อเรื่อง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="140"/>
        <source>The half title page of the work which carries just the title itself.</source>
        <translation>หน้าชื่อเรื่องของผลงานที่มีเพียงแค่ชื่อเรื่อง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="141"/>
        <source>Imprimatur</source>
        <translation>ความเห็นชอบ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="141"/>
        <source>A formal statement authorizing the publication of the work.</source>
        <translation>แถลงการณ์อย่างเป็นทางการที่อนุญาตให้เผยแพร่ผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="142"/>
        <source>Imprint</source>
        <translation>ประทับใจ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="142"/>
        <source>Information relating to the publication or distribution of the work.</source>
        <translation>ข้อมูลเกี่ยวกับการตีพิมพ์หรือเผยแพร่ผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="143"/>
        <source>Index</source>
        <translation>สารบัญ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="143"/>
        <source>A detailed list, usually arranged alphabetically, of the specific information in a publication.</source>
        <translation>รายละเอียดโดยปกติจะจัดเรียงตามลำดับตัวอักษรของข้อมูลเฉพาะในสิ่งพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="144"/>
        <source>Introduction</source>
        <translation>บทนำ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="144"/>
        <source>A section in the beginning of the work, typically introducing the reader to the scope or nature of the work&apos;s content.</source>
        <translation>ส่วนหนึ่งของจุดเริ่มต้นของงานโดยทั่วไปจะแนะนำผู้อ่านถึงขอบเขตหรือลักษณะของเนื้อหาของงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="145"/>
        <source>Landmarks</source>
        <translation>สถานที่สำคัญ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="145"/>
        <source>A collection of references to well-known/recurring components within the publication</source>
        <translation>ชุดของการอ้างอิงไปยังส่วนประกอบที่รู้จักกันดี / เกิดซ้ำภายในสิ่งพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="146"/>
        <source>List of Audio Clips</source>
        <translation>รายการคลิปเสียง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="146"/>
        <source>A listing of audio clips included in the work.</source>
        <translation>รายชื่อคลิปเสียงที่รวมอยู่ในงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="147"/>
        <source>List of Illustrations</source>
        <translation>รายชื่อภาพประกอบ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="147"/>
        <source>A listing of illustrations included in the work.</source>
        <translation>รายชื่อภาพประกอบที่รวมอยู่ในผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="148"/>
        <source>List of Tables</source>
        <translation>รายการตาราง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="148"/>
        <source>A listing of tables included in the work.</source>
        <translation>รายชื่อของตารางรวมอยู่ในผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="149"/>
        <source>List of Video Clips</source>
        <translation>รายการคลิปวีดีโอ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="149"/>
        <source>A listing of video clips included in the work.</source>
        <translation>รายการคลิปวิดีโอที่รวมอยู่ในผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="150"/>
        <source>Notice</source>
        <translation>ประกาศ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="150"/>
        <source>Information that requires special attention, and that must not be skipped or suppressed. Examples include: alert, warning, caution, danger, important.</source>
        <translation>ข้อมูลที่ต้องให้ความสนใจเป็นพิเศษและไม่ควรข้ามหรือถูกระงับ ตัวอย่างเช่น การแจ้งเตือน คำเตือน ระวัง อันตราย สำคัญ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="151"/>
        <source>Other Credits</source>
        <translation>เครดิตอื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="151"/>
        <source>Acknowledgments of previously published parts of the work, illustration credits, and permission to quote from copyrighted material.</source>
        <translation>คำขอบคุณจากส่วนที่ตีพิมพ์ก่อนหน้า ของงานภาพประกอบเครดิตและการอนุญาตให้อ้างอิงจากเนื้อหาที่มีลิขสิทธิ์</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="152"/>
        <source>Page List</source>
        <translation>รายการหน้า</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="152"/>
        <source>A list of references to pagebreaks (start locations) from a print version of the ebook</source>
        <translation>รายการการอ้างอิงถึงจุดสิ้นสุดหน้า (ตำแหน่งเริ่มต้น) จาก eBook ฉบับพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="153"/>
        <source>Part</source>
        <translation>ส่วน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="153"/>
        <source>A major structural division of a piece of writing, typically encapsulating a set of related chapters.</source>
        <translation>ส่วนโครงสร้างที่สำคัญของชิ้นส่วนของการเขียนโดยปกติจะ encapsulating ชุดของบทที่เกี่ยวข้อง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="154"/>
        <source>Preamble</source>
        <translation>คำขึ้นต้น</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="154"/>
        <source>A section in the beginning of the work, typically containing introductory and/or explanatory prose regarding the scope or nature of the work&apos;s content</source>
        <translation>ส่วนที่เป็นจุดเริ่มต้นของงานซึ่งโดยปกติแล้วจะมีร้อยแก้วแนะนำ และ/หรือ อธิบายเกี่ยวกับขอบเขตหรือลักษณะของเนื้อหาของงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="155"/>
        <source>Preface</source>
        <translation>คำนำ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="155"/>
        <source>An introductory section that precedes the work, typically written by the work&apos;s author.</source>
        <translation>ส่วนแนะนำที่นำเสนอผลงานเขียนโดยผู้เขียนงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="156"/>
        <source>Prologue</source>
        <translation>อารัมภบท</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="156"/>
        <source>An introductory section that sets the background to a story, typically part of the narrative.</source>
        <translation>ส่วนแนะนำที่กำหนดพื้นหลังของเรื่องราวโดยทั่วไปเป็นส่วนหนึ่งของการเล่าเรื่อง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="157"/>
        <source>Questions and Answers</source>
        <translation>คำถามและคำตอบ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="157"/>
        <source>A question and answer section.</source>
        <translation>ส่วนคำถามและคำตอบ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="158"/>
        <source>Rear Notes</source>
        <translation>หมายเหตุด้านหลัง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="158"/>
        <source>A collection of notes appearing at the rear (backmatter) of the work, or at the end of a section.</source>
        <translation>ชุดของโน้ตที่ปรากฏที่ด้านหลัง(ส่วนท้าย)ของงานหรือในตอนท้ายของส่วน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="159"/>
        <source>Revision History</source>
        <translation>ประวัติการแก้ไข</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="159"/>
        <source>A record of changes made to a work.</source>
        <translation>บันทึกการเปลี่ยนแปลงที่ทำกับงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="160"/>
        <source>Subchapter</source>
        <translation>หมวดย่อย</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="160"/>
        <source>A major sub-division of a chapter.</source>
        <translation>ส่วนย่อยที่สำคัญของบท</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="161"/>
        <source>Title Page</source>
        <translation>หน้าชื่อเรื่อง</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="161"/>
        <source>A page at the beginning of a book giving its title, authors, publisher and other publication information.</source>
        <translation>หน้าเริ่มต้นของหนังสือให้ชื่อผู้เขียน สำนักพิมพ์และสิ่งพิมพ์ ข้อมูลอื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="162"/>
        <source>Table of Contents</source>
        <translation>สารบัญ</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="162"/>
        <source>A table of contents which is a list of the headings or parts of the book or document, organized in the order in which they appear. Typically appearing in the work&apos;s frontmatter, or at the beginning of a section.</source>
        <translation>สารบัญซึ่งเป็นรายการส่วนหัวหรือส่วนของหนังสือหรือเอกสารจัดเรียงตามลำดับที่ปรากฏ โดยปกติจะปรากฏในส่วนหน้าของงานหรือที่ส่วนเริ่มต้น</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="163"/>
        <source>Volume</source>
        <translation>Volume</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="163"/>
        <source>A component of a collection.</source>
        <translation>ส่วนประกอบของคอลเล็กชัน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="164"/>
        <source>Warning</source>
        <translation>คำเตือน</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="164"/>
        <source>A warning or caution about specific material. Status: Deprecated - Replaced by &apos;notice&apos;.</source>
        <translation>คำเตือนหรือความระมัดระวังเกี่ยวกับวัสดุเฉพาะ สถานะ: เลิกใช้ - แทนที่ด้วย &quot;ประกาศ&quot;</translation>
    </message>
</context>
<context>
    <name>Language</name>
    <message>
        <location filename="../../Misc/Language.cpp" line="85"/>
        <source>Abkhazian</source>
        <translation>Abkhazian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="86"/>
        <source>Afar</source>
        <translation>Afar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="87"/>
        <source>Afrikaans</source>
        <translation>Afrikaans</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="88"/>
        <source>Akan</source>
        <translation>Akan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="89"/>
        <source>Albanian</source>
        <translation>Albanian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="90"/>
        <source>Amharic</source>
        <translation>Amharic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="91"/>
        <location filename="../../Misc/Language.cpp" line="92"/>
        <location filename="../../Misc/Language.cpp" line="93"/>
        <location filename="../../Misc/Language.cpp" line="94"/>
        <location filename="../../Misc/Language.cpp" line="95"/>
        <location filename="../../Misc/Language.cpp" line="96"/>
        <location filename="../../Misc/Language.cpp" line="97"/>
        <location filename="../../Misc/Language.cpp" line="98"/>
        <location filename="../../Misc/Language.cpp" line="99"/>
        <location filename="../../Misc/Language.cpp" line="100"/>
        <location filename="../../Misc/Language.cpp" line="101"/>
        <location filename="../../Misc/Language.cpp" line="102"/>
        <location filename="../../Misc/Language.cpp" line="103"/>
        <location filename="../../Misc/Language.cpp" line="104"/>
        <location filename="../../Misc/Language.cpp" line="105"/>
        <location filename="../../Misc/Language.cpp" line="106"/>
        <source>Arabic</source>
        <translation>Arabic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="92"/>
        <source>Algeria</source>
        <translation>Algeria</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="93"/>
        <source>Bahrain</source>
        <translation>Bahrain</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="94"/>
        <source>Egypt</source>
        <translation>Egypt</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="95"/>
        <source>Iraq</source>
        <translation>Iraq</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="96"/>
        <source>Jordan</source>
        <translation>Jordan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="97"/>
        <source>Kuwait</source>
        <translation>Kuwait</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="98"/>
        <source>Lebanon</source>
        <translation>Lebanon</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="99"/>
        <source>Libya</source>
        <translation>Libya</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="100"/>
        <source>Morocco</source>
        <translation>Morocco</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="101"/>
        <source>Oman</source>
        <translation>Oman</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="102"/>
        <source>Qatar</source>
        <translation>Qatar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="103"/>
        <source>Syria</source>
        <translation>Syria</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="104"/>
        <source>Tunisia</source>
        <translation>Tunisia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="105"/>
        <source>United Arab Emirates</source>
        <translation>United Arab Emirates</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="106"/>
        <source>Yemen</source>
        <translation>Yemen</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="107"/>
        <source>Aragonese</source>
        <translation>Aragonese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="108"/>
        <source>Armenian</source>
        <translation>Armenian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="109"/>
        <source>Assamese</source>
        <translation>Assamese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="110"/>
        <source>Avaric</source>
        <translation>Avaric</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="111"/>
        <source>Avestan</source>
        <translation>Avestan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="112"/>
        <source>Aymara</source>
        <translation>Aymara</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="113"/>
        <location filename="../../Misc/Language.cpp" line="114"/>
        <source>Azerbaijani</source>
        <translation>Azerbaijani</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="114"/>
        <source>Azerbaijan</source>
        <translation>Azerbaijan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="115"/>
        <source>Bambara</source>
        <translation>Bambara</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="116"/>
        <source>Bashkir</source>
        <translation>Bashkir</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="117"/>
        <source>Basque</source>
        <translation>Basque</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="118"/>
        <source>Belarusian</source>
        <translation>Belarusian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="119"/>
        <source>Bengali</source>
        <translation>Bengali</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="120"/>
        <source>Bihari</source>
        <translation>Bihari</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="121"/>
        <source>Bislama</source>
        <translation>Bislama</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="122"/>
        <source>Bosnian</source>
        <translation>Bosnian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="123"/>
        <source>Breton</source>
        <translation>Breton</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="124"/>
        <source>Bulgarian</source>
        <translation>Bulgarian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="125"/>
        <source>Burmese</source>
        <translation>Burmese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="126"/>
        <location filename="../../Misc/Language.cpp" line="127"/>
        <source>Catalan</source>
        <translation>Catalan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="127"/>
        <location filename="../../Misc/Language.cpp" line="312"/>
        <source>Spain</source>
        <translation>Spain</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="128"/>
        <source>Central Khmer</source>
        <translation>Central Khmer</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="129"/>
        <source>Chamorro</source>
        <translation>Chamorro</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="130"/>
        <source>Chechen</source>
        <translation>Chechen</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="131"/>
        <location filename="../../Misc/Language.cpp" line="132"/>
        <location filename="../../Misc/Language.cpp" line="133"/>
        <location filename="../../Misc/Language.cpp" line="134"/>
        <location filename="../../Misc/Language.cpp" line="135"/>
        <location filename="../../Misc/Language.cpp" line="136"/>
        <source>Chinese</source>
        <translation>Chinese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="132"/>
        <source>China</source>
        <translation>China</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="133"/>
        <source>Hong Kong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="134"/>
        <source>Macau</source>
        <translation>Macau</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="135"/>
        <source>Singapore</source>
        <translation>Singapore</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="136"/>
        <source>Taiwan</source>
        <translation>Taiwan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="137"/>
        <source>Church Slavic</source>
        <translation>Church Slavic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="138"/>
        <source>Chuvash</source>
        <translation>Chuvash</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="139"/>
        <source>Cornish</source>
        <translation>Cornish</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="140"/>
        <source>Corsican</source>
        <translation>Corsican</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="141"/>
        <source>Cree</source>
        <translation>Cree</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="142"/>
        <source>Croatian</source>
        <translation>Croatian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="143"/>
        <source>Czech</source>
        <translation>Czech</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="144"/>
        <location filename="../../Misc/Language.cpp" line="145"/>
        <source>Danish</source>
        <translation>Danish</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="145"/>
        <source>Denmark</source>
        <translation>Denmark</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="146"/>
        <source>Dhivehi</source>
        <translation>Dhivehi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="147"/>
        <location filename="../../Misc/Language.cpp" line="148"/>
        <location filename="../../Misc/Language.cpp" line="149"/>
        <source>Dutch</source>
        <translation>Dutch</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="148"/>
        <location filename="../../Misc/Language.cpp" line="171"/>
        <source>Belgium</source>
        <translation>Belgium</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="149"/>
        <source>Netherlands</source>
        <translation>Netherlands</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="150"/>
        <source>Dzongkha</source>
        <translation>Dzongkha</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="151"/>
        <location filename="../../Misc/Language.cpp" line="152"/>
        <location filename="../../Misc/Language.cpp" line="153"/>
        <location filename="../../Misc/Language.cpp" line="154"/>
        <location filename="../../Misc/Language.cpp" line="155"/>
        <location filename="../../Misc/Language.cpp" line="156"/>
        <location filename="../../Misc/Language.cpp" line="157"/>
        <location filename="../../Misc/Language.cpp" line="158"/>
        <location filename="../../Misc/Language.cpp" line="159"/>
        <location filename="../../Misc/Language.cpp" line="160"/>
        <location filename="../../Misc/Language.cpp" line="161"/>
        <location filename="../../Misc/Language.cpp" line="162"/>
        <location filename="../../Misc/Language.cpp" line="163"/>
        <source>English</source>
        <translation>English</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="152"/>
        <source>Australia</source>
        <translation>Australia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="153"/>
        <source>Belize</source>
        <translation>Belize</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="154"/>
        <location filename="../../Misc/Language.cpp" line="172"/>
        <source>Canada</source>
        <translation>Canada</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="155"/>
        <source>Caribbean</source>
        <translation>Caribbean</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="156"/>
        <source>Great Britain</source>
        <translation>Great Britain</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="157"/>
        <source>India</source>
        <translation>India</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="158"/>
        <location filename="../../Misc/Language.cpp" line="178"/>
        <source>Ireland</source>
        <translation>Ireland</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="159"/>
        <source>Jamaica</source>
        <translation>Jamaica</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="160"/>
        <source>Phillippines</source>
        <translation>Phillippines</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="161"/>
        <source>Trinidad</source>
        <translation>Trinidad</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="162"/>
        <source>South Africa</source>
        <translation>South Africa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="163"/>
        <source>United States</source>
        <translation>United States</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="164"/>
        <source>Esperanto</source>
        <translation>Esperanto</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="165"/>
        <source>Estonian</source>
        <translation>Estonian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="166"/>
        <source>Ewe</source>
        <translation>Ewe</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="167"/>
        <source>Faroese</source>
        <translation>Faroese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="168"/>
        <source>Fijian</source>
        <translation>Fijian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="169"/>
        <source>Finnish</source>
        <translation>Finnish</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="170"/>
        <location filename="../../Misc/Language.cpp" line="171"/>
        <location filename="../../Misc/Language.cpp" line="172"/>
        <location filename="../../Misc/Language.cpp" line="173"/>
        <location filename="../../Misc/Language.cpp" line="174"/>
        <location filename="../../Misc/Language.cpp" line="175"/>
        <source>French</source>
        <translation>French</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="173"/>
        <source>France</source>
        <translation>France</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="174"/>
        <location filename="../../Misc/Language.cpp" line="186"/>
        <source>Luxembourg</source>
        <translation>Luxembourg</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="175"/>
        <location filename="../../Misc/Language.cpp" line="187"/>
        <location filename="../../Misc/Language.cpp" line="212"/>
        <source>Switzerland</source>
        <translation>Switzerland</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="176"/>
        <source>Fulah</source>
        <translation>Fulah</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="177"/>
        <location filename="../../Misc/Language.cpp" line="178"/>
        <source>Gaelic</source>
        <translation>Gaelic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="177"/>
        <source>Scotland</source>
        <translation>Scotland</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="179"/>
        <source>Galician</source>
        <translation>Galician</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="180"/>
        <source>Ganda</source>
        <translation>Ganda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="181"/>
        <source>Georgian</source>
        <translation>Georgian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="182"/>
        <location filename="../../Misc/Language.cpp" line="183"/>
        <location filename="../../Misc/Language.cpp" line="184"/>
        <location filename="../../Misc/Language.cpp" line="185"/>
        <location filename="../../Misc/Language.cpp" line="186"/>
        <location filename="../../Misc/Language.cpp" line="187"/>
        <source>German</source>
        <translation>German</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="183"/>
        <source>Austria</source>
        <translation>Austria</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="184"/>
        <source>Germany</source>
        <translation>Germany</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="185"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="188"/>
        <source>Greek, Modern</source>
        <translation>Greek, Modern</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="189"/>
        <source>Greek</source>
        <translation>Greek</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="190"/>
        <source>Guarani</source>
        <translation>Guarani</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="191"/>
        <source>Gujarati</source>
        <translation>Gujarati</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="192"/>
        <source>Haitian</source>
        <translation>Haitian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="193"/>
        <source>Hausa</source>
        <translation>Hausa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="194"/>
        <source>Hebrew</source>
        <translation>Hebrew</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="195"/>
        <source>Herero</source>
        <translation>Herero</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="196"/>
        <source>Hindi</source>
        <translation>Hindi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="197"/>
        <source>Hiri Motu</source>
        <translation>Hiri Motu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="198"/>
        <location filename="../../Misc/Language.cpp" line="199"/>
        <source>Hungarian</source>
        <translation>Hungarian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="199"/>
        <source>Hungary</source>
        <translation>Hungary</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="200"/>
        <source>Icelandic</source>
        <translation>Icelandic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="201"/>
        <source>Ido</source>
        <translation>Ido</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="202"/>
        <source>Igbo</source>
        <translation>Igbo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="203"/>
        <source>Indonesian</source>
        <translation>Indonesian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="204"/>
        <source>Indonesian - Indonesia</source>
        <translation>Indonesian - Indonesia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="205"/>
        <source>Interlingua</source>
        <translation>Interlingua</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="206"/>
        <source>Interlingue</source>
        <translation>Interlingue</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="207"/>
        <source>Inuktitut</source>
        <translation>Inuktitut</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="208"/>
        <source>Inupiaq</source>
        <translation>Inupiaq</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="209"/>
        <source>Irish</source>
        <translation>Irish</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="210"/>
        <location filename="../../Misc/Language.cpp" line="211"/>
        <location filename="../../Misc/Language.cpp" line="212"/>
        <source>Italian</source>
        <translation>Italian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="211"/>
        <source>Italy</source>
        <translation>Italy</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="213"/>
        <source>Japanese</source>
        <translation>Japanese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="214"/>
        <source>Javanese</source>
        <translation>Javanese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="215"/>
        <source>Kalaallisut</source>
        <translation>Kalaallisut</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="216"/>
        <source>Kannada</source>
        <translation>Kannada</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="217"/>
        <source>Kanuri</source>
        <translation>Kanuri</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="218"/>
        <source>Kashmiri</source>
        <translation>Kashmiri</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="219"/>
        <source>Kazakh</source>
        <translation>Kazakh</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="220"/>
        <source>Kikuyu</source>
        <translation>Kikuyu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="221"/>
        <source>Kinyarwanda</source>
        <translation>Kinyarwanda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="222"/>
        <source>Kirghiz</source>
        <translation>Kirghiz</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="223"/>
        <source>Komi</source>
        <translation>Komi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="224"/>
        <source>Kongo</source>
        <translation>Kongo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="225"/>
        <source>Korean</source>
        <translation>Korean</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="226"/>
        <source>Kuanyama</source>
        <translation>Kuanyama</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="227"/>
        <source>Kurdish</source>
        <translation>Kurdish</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="228"/>
        <source>Lao</source>
        <translation>Lao</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="229"/>
        <source>Latin</source>
        <translation>Latin</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="230"/>
        <location filename="../../Misc/Language.cpp" line="231"/>
        <source>Latvian</source>
        <translation>Latvian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="231"/>
        <source>Latvia</source>
        <translation>Latvia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="232"/>
        <source>Limburgan</source>
        <translation>Limburgan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="233"/>
        <source>Lingala</source>
        <translation>Lingala</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="234"/>
        <source>Lithuanian</source>
        <translation>Lithuanian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="235"/>
        <source>Luba-Katanga</source>
        <translation>Luba-Katanga</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="236"/>
        <source>Luxembourgish</source>
        <translation>Luxembourgish</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="237"/>
        <source>Macedonian</source>
        <translation>Macedonian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="238"/>
        <source>Malagasy</source>
        <translation>Malagasy</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="239"/>
        <source>Malayalam</source>
        <translation>Malayalam</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="240"/>
        <location filename="../../Misc/Language.cpp" line="241"/>
        <location filename="../../Misc/Language.cpp" line="242"/>
        <source>Malay</source>
        <translation>Malay</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="241"/>
        <source>Brunei</source>
        <translation>Brunei</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="242"/>
        <source>Malaysia</source>
        <translation>Malaysia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="243"/>
        <source>Maltese</source>
        <translation>Maltese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="244"/>
        <source>Manx</source>
        <translation>Manx</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="245"/>
        <source>Maori</source>
        <translation>Maori</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="246"/>
        <source>Marathi</source>
        <translation>Marathi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="247"/>
        <source>Marshallese</source>
        <translation>Marshallese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="248"/>
        <source>Mongolian</source>
        <translation>Mongolian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="249"/>
        <source>Nauru</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="250"/>
        <source>Navajo</source>
        <translation>Navajo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="251"/>
        <location filename="../../Misc/Language.cpp" line="252"/>
        <source>Ndebele</source>
        <translation>Ndebele</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="251"/>
        <source>North</source>
        <translation>North</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="252"/>
        <source>South</source>
        <translation>South</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="253"/>
        <source>Ndonga</source>
        <translation>Ndonga</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="254"/>
        <source>Nepali</source>
        <translation>Nepali</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="255"/>
        <source>Northern, Sami</source>
        <translation>Northern, Sami</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="256"/>
        <location filename="../../Misc/Language.cpp" line="257"/>
        <location filename="../../Misc/Language.cpp" line="258"/>
        <source>Norwegian</source>
        <translation>Norwegian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="257"/>
        <source>Bokmal</source>
        <translation>Bokmal</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="258"/>
        <source>Nynorsk</source>
        <translation>Nynorsk</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="259"/>
        <source>Nyanja</source>
        <translation>Nyanja</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="260"/>
        <source>Occitan</source>
        <translation>Occitan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="261"/>
        <source>Ojibwa</source>
        <translation>Ojibwa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="262"/>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="263"/>
        <source>Oromo</source>
        <translation>Oromo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="264"/>
        <source>Ossetian</source>
        <translation>Ossetian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="265"/>
        <source>Pali</source>
        <translation>Pali</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="266"/>
        <source>Panjabi</source>
        <translation>Panjabi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="267"/>
        <source>Persian</source>
        <translation>Persian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="268"/>
        <source>Polish</source>
        <translation>Polish</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="269"/>
        <location filename="../../Misc/Language.cpp" line="270"/>
        <location filename="../../Misc/Language.cpp" line="271"/>
        <source>Portuguese</source>
        <translation>Portuguese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="270"/>
        <source>Brazil</source>
        <translation>Brazil</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="271"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="272"/>
        <source>Pushto</source>
        <translation>Pushto</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="273"/>
        <source>Quechua</source>
        <translation>Quechua</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="274"/>
        <location filename="../../Misc/Language.cpp" line="275"/>
        <location filename="../../Misc/Language.cpp" line="276"/>
        <source>Romanian</source>
        <translation>Romanian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="275"/>
        <location filename="../../Misc/Language.cpp" line="280"/>
        <source>Moldova</source>
        <translation>Moldova</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="276"/>
        <source>Romania</source>
        <translation>Romania</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="277"/>
        <source>Romansh</source>
        <translation>Romansh</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="278"/>
        <source>Rundi</source>
        <translation>Rundi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="279"/>
        <location filename="../../Misc/Language.cpp" line="280"/>
        <source>Russian</source>
        <translation>Russian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="281"/>
        <source>Samoan</source>
        <translation>Samoan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="282"/>
        <source>Sango</source>
        <translation>Sango</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="283"/>
        <source>Sanskrit</source>
        <translation>Sanskrit</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="284"/>
        <source>Sardinian</source>
        <translation>Sardinian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="285"/>
        <location filename="../../Misc/Language.cpp" line="286"/>
        <source>Serbian</source>
        <translation>Serbian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="286"/>
        <source>Serbia</source>
        <translation>Serbia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="287"/>
        <source>Shona</source>
        <translation>Shona</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="288"/>
        <source>Sichuan Yi</source>
        <translation>Sichuan Yi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="289"/>
        <source>Sindhi</source>
        <translation>Sindhi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="290"/>
        <source>Sinhala</source>
        <translation>Sinhala</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="291"/>
        <source>Slovak</source>
        <translation>Slovak</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="292"/>
        <source>Slovenian</source>
        <translation>Slovenian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="293"/>
        <source>Somali</source>
        <translation>Somali</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="294"/>
        <source>Sotho, Southern</source>
        <translation>Sotho, Southern</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="295"/>
        <location filename="../../Misc/Language.cpp" line="296"/>
        <location filename="../../Misc/Language.cpp" line="297"/>
        <location filename="../../Misc/Language.cpp" line="298"/>
        <location filename="../../Misc/Language.cpp" line="299"/>
        <location filename="../../Misc/Language.cpp" line="300"/>
        <location filename="../../Misc/Language.cpp" line="301"/>
        <location filename="../../Misc/Language.cpp" line="302"/>
        <location filename="../../Misc/Language.cpp" line="303"/>
        <location filename="../../Misc/Language.cpp" line="304"/>
        <location filename="../../Misc/Language.cpp" line="305"/>
        <location filename="../../Misc/Language.cpp" line="306"/>
        <location filename="../../Misc/Language.cpp" line="307"/>
        <location filename="../../Misc/Language.cpp" line="308"/>
        <location filename="../../Misc/Language.cpp" line="309"/>
        <location filename="../../Misc/Language.cpp" line="310"/>
        <location filename="../../Misc/Language.cpp" line="311"/>
        <location filename="../../Misc/Language.cpp" line="312"/>
        <location filename="../../Misc/Language.cpp" line="313"/>
        <location filename="../../Misc/Language.cpp" line="314"/>
        <source>Spanish</source>
        <translation>Spanish</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="296"/>
        <source>Argentina</source>
        <translation>Argentina</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="297"/>
        <source>Bolivia</source>
        <translation>Bolivia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="298"/>
        <source>Chile</source>
        <translation>Chile</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="299"/>
        <source>Columbia</source>
        <translation>Columbia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="300"/>
        <source>Costa Rica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="301"/>
        <source>Dominican Republic</source>
        <translation>Dominican Republic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="302"/>
        <source>Ecuador</source>
        <translation>Ecuador</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="303"/>
        <source>El Salvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="304"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="305"/>
        <source>Honduras</source>
        <translation>Honduras</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="306"/>
        <source>Mexico</source>
        <translation>Mexico</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="307"/>
        <source>Nicaragua</source>
        <translation>Nicaragua</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="308"/>
        <source>Panama</source>
        <translation>Panama</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="309"/>
        <source>Paraguay</source>
        <translation>Paraguay</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="310"/>
        <source>Peru</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="311"/>
        <source>Puerto Rico</source>
        <translation>Puerto Rico</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="313"/>
        <source>Uruguay</source>
        <translation>Uruguay</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="314"/>
        <source>Venezuela</source>
        <translation>Venezuela</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="315"/>
        <source>Sundanese</source>
        <translation>Sundanese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="316"/>
        <source>Swahili</source>
        <translation>Swahili</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="317"/>
        <source>Swati</source>
        <translation>Swati</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="318"/>
        <location filename="../../Misc/Language.cpp" line="319"/>
        <location filename="../../Misc/Language.cpp" line="320"/>
        <source>Swedish</source>
        <translation>Swedish</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="319"/>
        <source>Finland</source>
        <translation>Finland</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="320"/>
        <source>Sweden</source>
        <translation>Sweden</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="321"/>
        <source>Tagalog</source>
        <translation>Tagalog</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="322"/>
        <source>Tahitian</source>
        <translation>Tahitian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="323"/>
        <source>Tajik</source>
        <translation>Tajik</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="324"/>
        <source>Tamil</source>
        <translation>Tamil</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="325"/>
        <source>Tatar</source>
        <translation>Tatar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="326"/>
        <source>Telugu</source>
        <translation>Telugu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="327"/>
        <source>Thai</source>
        <translation>Thai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="328"/>
        <source>Tibetan</source>
        <translation>Tibetan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="329"/>
        <source>Tigrinya</source>
        <translation>Tigrinya</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="330"/>
        <source>Tonga</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="331"/>
        <source>Tsonga</source>
        <translation>Tsonga</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="332"/>
        <source>Tswana</source>
        <translation>Tswana</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="333"/>
        <location filename="../../Misc/Language.cpp" line="334"/>
        <source>Turkish</source>
        <translation>Turkish</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="334"/>
        <source>Turkey</source>
        <translation>Turkey</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="335"/>
        <source>Turkmen</source>
        <translation>Turkmen</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="336"/>
        <source>Twi</source>
        <translation>Twi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="337"/>
        <source>Uighur</source>
        <translation>Uighur</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="338"/>
        <location filename="../../Misc/Language.cpp" line="339"/>
        <source>Ukrainian</source>
        <translation>Ukrainian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="339"/>
        <source>Ukraine</source>
        <translation>Ukraine</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="340"/>
        <source>Urdu</source>
        <translation>Urdu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="341"/>
        <location filename="../../Misc/Language.cpp" line="342"/>
        <source>Uzbek</source>
        <translation>Uzbek</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="342"/>
        <source>Uzbekistan</source>
        <translation>Uzbekistan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="343"/>
        <source>Venda</source>
        <translation>Venda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="344"/>
        <source>Vietnamese</source>
        <translation>Vietnamese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="345"/>
        <source>Volapuk</source>
        <translation>Volapuk</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="346"/>
        <source>Walloon</source>
        <translation>Walloon</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="347"/>
        <source>Welsh</source>
        <translation>Welsh</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="348"/>
        <source>Western Frisian</source>
        <translation>Western Frisian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="349"/>
        <source>Wolof</source>
        <translation>Wolof</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="350"/>
        <source>Xhosa</source>
        <translation>Xhosa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="351"/>
        <source>Yiddish</source>
        <translation>Yiddish</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="352"/>
        <source>Yoruba</source>
        <translation>Yoruba</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="353"/>
        <source>Zhuang</source>
        <translation>Zhuang</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="354"/>
        <source>Zulu</source>
        <translation>Zulu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="355"/>
        <source>Achinese</source>
        <translation>Achinese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="356"/>
        <source>Acoli</source>
        <translation>Acoli</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="357"/>
        <source>Adangme</source>
        <translation>Adangme</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="358"/>
        <source>Adygei, Adyghe</source>
        <translation>Adygei, Adyghe</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="359"/>
        <source>Afrihili</source>
        <translation>Afrihili</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="360"/>
        <source>Afro-Asiatic languages</source>
        <translation>ภาษา Afro-Asiatic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="361"/>
        <source>Ainu</source>
        <translation>Ainu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="362"/>
        <source>Akkadian</source>
        <translation>Akkadian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="363"/>
        <source>Aleut</source>
        <translation>Aleut</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="364"/>
        <source>Algonquian languages</source>
        <translation>ภาษา Algonquian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="365"/>
        <source>Altaic languages</source>
        <translation>ภาษา Altaic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="366"/>
        <source>Angika</source>
        <translation>Angika</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="367"/>
        <source>Apache languages</source>
        <translation>ภาษา Apache</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="368"/>
        <source>Arapaho</source>
        <translation>Arapaho</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="369"/>
        <source>Arawak</source>
        <translation>Arawak</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="370"/>
        <source>Aromanian, Arumanian, Macedo-Romanian</source>
        <translation>Aromanian, Arumanian, Macedo-Romanian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="371"/>
        <source>Artificial languages</source>
        <translation>ภาษา Artificial</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="372"/>
        <source>Asturian, Asturleonese, Bable, Leonese</source>
        <translation>Asturian, Asturleonese, Bable, Leonese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="373"/>
        <source>Athapascan languages</source>
        <translation>ภาษา Athapascan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="374"/>
        <source>Australian languages</source>
        <translation>ภาษา Australian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="375"/>
        <source>Austronesian languages</source>
        <translation>ภาษา Austronesian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="376"/>
        <source>Awadhi</source>
        <translation>Awadhi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="377"/>
        <source>Balinese</source>
        <translation>Balinese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="378"/>
        <source>Baltic languages</source>
        <translation>ภาษา Baltic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="379"/>
        <source>Baluchi</source>
        <translation>Baluchi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="380"/>
        <source>Bamileke languages</source>
        <translation>ภาษา Bamileke</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="381"/>
        <source>Banda languages</source>
        <translation>ภาษา Banda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="382"/>
        <source>Bantu languages</source>
        <translation>ภาษา Bantu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="383"/>
        <source>Basa</source>
        <translation>Basa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="384"/>
        <source>Batak languages</source>
        <translation>ภาษา Batak</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="385"/>
        <source>Bedawiyet, Beja</source>
        <translation>Bedawiyet, Beja</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="386"/>
        <source>Bemba</source>
        <translation>Bemba</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="387"/>
        <source>Berber languages</source>
        <translation>ภาษา Berber</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="388"/>
        <source>Bhojpuri</source>
        <translation>Bhojpuri</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="389"/>
        <source>Bikol</source>
        <translation>Bikol</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="390"/>
        <source>Bilin, Blin</source>
        <translation>Bilin, Blin</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="391"/>
        <source>Bini, Edo</source>
        <translation>Bini, Edo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="392"/>
        <source>Bliss, Blissymbols, Blissymbolics</source>
        <translation>Bliss, Blissymbols, Blissymbolics</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="393"/>
        <source>Braj</source>
        <translation>Braj</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="394"/>
        <source>Buginese</source>
        <translation>Buginese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="395"/>
        <source>Buriat</source>
        <translation>Buriat</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="396"/>
        <source>Caddo</source>
        <translation>Caddo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="397"/>
        <source>Caucasian languages</source>
        <translation>ภาษา Caucasian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="398"/>
        <source>Cebuano</source>
        <translation>Cebuano</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="399"/>
        <source>Celtic languages</source>
        <translation>ภาษา Celtic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="400"/>
        <source>Central American Indian languages</source>
        <translation>ภาษา Central American Indian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="401"/>
        <source>Chagatai</source>
        <translation>ภาษา Chagatai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="402"/>
        <source>Chamic languages</source>
        <translation>ภาษา Chamic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="403"/>
        <source>Cherokee</source>
        <translation>Cherokee</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="404"/>
        <source>Cheyenne</source>
        <translation>Cheyenne</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="405"/>
        <source>Chibcha</source>
        <translation>Chibcha</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="406"/>
        <source>Chinook jargon</source>
        <translation>Chinook jargon</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="407"/>
        <source>Chipewyan, Dene Suline</source>
        <translation>Chipewyan, Dene Suline</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="408"/>
        <source>Choctaw</source>
        <translation>Choctaw</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="409"/>
        <source>Chuukese</source>
        <translation>Chuukese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="410"/>
        <source>Classical Nepal Bhasa/Newari, Old Newari</source>
        <translation>Classical Nepal Bhasa/Newari, Old Newari</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="411"/>
        <source>Classical Syriac</source>
        <translation>Classical Syriac</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="412"/>
        <source>Coptic</source>
        <translation>Coptic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="413"/>
        <source>Creek</source>
        <translation>Creek</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="414"/>
        <source>Creoles and pidgins</source>
        <translation>Creoles and pidgins</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="415"/>
        <source>Creoles and pidgins- English based</source>
        <translation>Creoles and pidgins- English based</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="416"/>
        <source>Creoles and pidgins- French-based</source>
        <translation>Creoles and pidgins- French-based</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="417"/>
        <source>Creoles and pidgins- Portuguese-based</source>
        <translation>Creoles and pidgins- Portuguese-based</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="418"/>
        <source>Crimean Tatar/Turkish</source>
        <translation>Crimean Tatar/Turkish</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="419"/>
        <source>Cushitic languages</source>
        <translation>ภาษา Cushitic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="420"/>
        <source>Dakota</source>
        <translation>Dakota</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="421"/>
        <source>Dargwa</source>
        <translation>Dargwa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="422"/>
        <source>Delaware</source>
        <translation>Delaware</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="423"/>
        <source>Dimili, Dimli, Zaza, Zazaki, Kirdki, Kirmanjki</source>
        <translation>Dimili, Dimli, Zaza, Zazaki, Kirdki, Kirmanjki</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="424"/>
        <source>Dinka</source>
        <translation>Dinka</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="425"/>
        <source>Dogri</source>
        <translation>Dogri</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="426"/>
        <source>Dogrib</source>
        <translation>Dogrib</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="427"/>
        <source>Dravidian languages</source>
        <translation>ภาษา Dravidian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="428"/>
        <source>Duala</source>
        <translation>Duala</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="429"/>
        <source>Dutch- Middle (ca.1050-1350)</source>
        <translation>Dutch- Middle (ca.1050-1350)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="430"/>
        <source>Dyula</source>
        <translation>Dyula</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="431"/>
        <source>Eastern Frisian</source>
        <translation>Eastern Frisian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="432"/>
        <source>Efik</source>
        <translation>Efik</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="433"/>
        <source>Egyptian (Ancient)</source>
        <translation>Egyptian (Ancient)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="434"/>
        <source>Ekajuk</source>
        <translation>Ekajuk</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="435"/>
        <source>Elamite</source>
        <translation>Elamite</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="436"/>
        <source>English- Middle (1100-1500)</source>
        <translation>English- Middle (1100-1500)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="437"/>
        <source>English- Old (ca.450-1100)</source>
        <translation>English- Old (ca.450-1100)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="438"/>
        <source>Erzya</source>
        <translation>Erzya</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="439"/>
        <source>Ewondo</source>
        <translation>Ewondo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="440"/>
        <source>Fang</source>
        <translation>Fang</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="441"/>
        <source>Fanti</source>
        <translation>Fanti</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="442"/>
        <source>Filipino, Pilipino</source>
        <translation>Filipino, Pilipino</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="443"/>
        <source>Finno-Ugrian languages</source>
        <translation>ภาษา Finno-Ugrian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="444"/>
        <source>Fon</source>
        <translation>Fon</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="445"/>
        <source>French- Middle (ca.1400-1600)</source>
        <translation>French- Middle (ca.1400-1600)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="446"/>
        <source>French- Old (842-ca.1400)</source>
        <translation>French- Old (842-ca.1400)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="447"/>
        <source>Friulian</source>
        <translation>Friulian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="448"/>
        <source>Ga</source>
        <translation>Ga</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="449"/>
        <source>Galibi Carib</source>
        <translation>Galibi Carib</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="450"/>
        <source>Gayo</source>
        <translation>Gayo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="451"/>
        <source>Gbaya</source>
        <translation>Gbaya</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="452"/>
        <source>Geez</source>
        <translation>Geez</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="453"/>
        <source>German- Middle High (ca.1050-1500)</source>
        <translation>German- Middle High (ca.1050-1500)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="454"/>
        <source>German- Old High (ca.750-1050)</source>
        <translation>German- Old High (ca.750-1050)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="455"/>
        <source>Germanic languages</source>
        <translation>ภาษา Germanic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="456"/>
        <source>Gilbertese</source>
        <translation>Gilbertese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="457"/>
        <source>Gondi</source>
        <translation>Gondi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="458"/>
        <source>Gorontalo</source>
        <translation>Gorontalo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="459"/>
        <source>Gothic</source>
        <translation>Gothic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="460"/>
        <source>Grebo</source>
        <translation>Grebo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="461"/>
        <source>Greek- Ancient (to 1453)</source>
        <translation>Greek- Ancient (to 1453)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="462"/>
        <source>Gwich&apos;in</source>
        <translation>Gwich&apos;in</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="463"/>
        <source>Haida</source>
        <translation>Haida</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="464"/>
        <source>Hawaiian</source>
        <translation>Hawaiian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="465"/>
        <source>Hiligaynon</source>
        <translation>Hiligaynon</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="466"/>
        <source>Himachali, Western Pahari languages</source>
        <translation>ภาษา Himachali, Western Pahari</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="467"/>
        <source>Hittite</source>
        <translation>Hittite</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="468"/>
        <source>Hmong, Mong</source>
        <translation>Hmong, Mong</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="469"/>
        <source>Hupa</source>
        <translation>Hupa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="470"/>
        <source>Iban</source>
        <translation>Iban</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="471"/>
        <source>Ijo languages</source>
        <translation>ภาษา Ijo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="472"/>
        <source>Iloko</source>
        <translation>Iloko</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="473"/>
        <source>Inari Sami</source>
        <translation>Inari Sami</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="474"/>
        <source>Indic languages</source>
        <translation>ภาษา Indic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="475"/>
        <source>Indo-European languages</source>
        <translation>ภาษา Indo-European</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="476"/>
        <source>Ingush</source>
        <translation>Ingush</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="477"/>
        <source>Iranian languages</source>
        <translation>ภาษา Iranian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="478"/>
        <source>Irish- Middle (900-1200)</source>
        <translation>Irish- Middle (900-1200)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="479"/>
        <source>Irish- Old (to 900)</source>
        <translation>Irish- Old (to 900)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="480"/>
        <source>Iroquoian languages</source>
        <translation>ภาษา Iroquoian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="481"/>
        <source>Jingpho, Kachin</source>
        <translation>Jingpho, Kachin</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="482"/>
        <source>Judeo-Arabic</source>
        <translation>Judeo-Arabic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="483"/>
        <source>Judeo-Persian</source>
        <translation>Judeo-Persian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="484"/>
        <source>Kabardian</source>
        <translation>Kabardian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="485"/>
        <source>Kabyle</source>
        <translation>Kabyle</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="486"/>
        <source>Kalmyk, Oirat</source>
        <translation>Kalmyk, Oirat</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="487"/>
        <source>Kamba</source>
        <translation>Kamba</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="488"/>
        <source>Kapampangan, Pampanga</source>
        <translation>Kapampangan, Pampanga</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="489"/>
        <source>Kara-Kalpak</source>
        <translation>Kara-Kalpak</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="490"/>
        <source>Karachay-Balkar</source>
        <translation>Karachay-Balkar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="491"/>
        <source>Karelian</source>
        <translation>Karelian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="492"/>
        <source>Karen languages</source>
        <translation>ภาษา Karen</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="493"/>
        <source>Kashubian</source>
        <translation>Kashubian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="494"/>
        <source>Kawi</source>
        <translation>Kawi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="495"/>
        <source>Khasi</source>
        <translation>Khasi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="496"/>
        <source>Khoisan languages</source>
        <translation>ภาษา Khoisan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="497"/>
        <source>Khotanese, Sakan</source>
        <translation>Khotanese, Sakan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="498"/>
        <source>Kimbundu</source>
        <translation>Kimbundu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="499"/>
        <source>Klingon, tlhIngan-Hol</source>
        <translation>Klingon, tlhIngan-Hol</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="500"/>
        <source>Konkani</source>
        <translation>Konkani</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="501"/>
        <source>Kosraean</source>
        <translation>Kosraean</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="502"/>
        <source>Kpelle</source>
        <translation>Kpelle</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="503"/>
        <source>Kru languages</source>
        <translation>ภาษา Kru</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="504"/>
        <source>Kumyk</source>
        <translation>Kumyk</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="505"/>
        <source>Kurukh</source>
        <translation>Kurukh</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="506"/>
        <source>Kutenai</source>
        <translation>Kutenai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="507"/>
        <source>Ladino</source>
        <translation>Ladino</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="508"/>
        <source>Lahnda</source>
        <translation>Lahnda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="509"/>
        <source>Lamba</source>
        <translation>Lamba</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="510"/>
        <source>Land Dayak languages</source>
        <translation>ภาษา Land Dayak</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="511"/>
        <source>Lezghian</source>
        <translation>Lezghian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="512"/>
        <source>Lojban</source>
        <translation>Lojban</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="513"/>
        <source>German-Low, Low Saxon</source>
        <translation>German-Low, Low Saxon</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="514"/>
        <source>Lower Sorbian</source>
        <translation>Lower Sorbian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="515"/>
        <source>Lozi</source>
        <translation>Lozi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="516"/>
        <source>Luba-Lulua</source>
        <translation>Luba-Lulua</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="517"/>
        <source>Luiseno</source>
        <translation>Luiseno</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="518"/>
        <source>Lule Sami</source>
        <translation>Lule Sami</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="519"/>
        <source>Lunda</source>
        <translation>Lunda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="520"/>
        <source>Luo (Kenya and Tanzania)</source>
        <translation>Luo (Kenya and Tanzania)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="521"/>
        <source>Lushai</source>
        <translation>Lushai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="522"/>
        <source>Madurese</source>
        <translation>Madurese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="523"/>
        <source>Magahi</source>
        <translation>Magahi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="524"/>
        <source>Maithili</source>
        <translation>Maithili</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="525"/>
        <source>Makasar</source>
        <translation>Makasar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="526"/>
        <source>Manchu</source>
        <translation>Manchu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="527"/>
        <source>Mandar</source>
        <translation>Mandar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="528"/>
        <source>Mandingo</source>
        <translation>Mandingo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="529"/>
        <source>Manipuri</source>
        <translation>Manipuri</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="530"/>
        <source>Manobo languages</source>
        <translation>ภาษา Manobo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="531"/>
        <source>Mapuche/Mapudungun</source>
        <translation>Mapuche/Mapudungun</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="532"/>
        <source>Mari</source>
        <translation>Mari</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="533"/>
        <source>Marwari</source>
        <translation>Marwari</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="534"/>
        <source>Masai</source>
        <translation>Masai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="535"/>
        <source>Mayan languages</source>
        <translation>ภาษา Mayan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="536"/>
        <source>Mende</source>
        <translation>Mende</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="537"/>
        <source>Mi&apos;kmaq, Micmac</source>
        <translation>Mi&apos;kmaq, Micmac</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="538"/>
        <source>Minangkabau</source>
        <translation>Minangkabau</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="539"/>
        <source>Mirandese</source>
        <translation>Mirandese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="540"/>
        <source>Mohawk</source>
        <translation>Mohawk</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="541"/>
        <source>Moksha</source>
        <translation>Moksha</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="542"/>
        <source>Mon-Khmer languages</source>
        <translation>ภาษา Mon-Khmer</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="543"/>
        <source>Mongo</source>
        <translation>Mongo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="544"/>
        <source>Mossi</source>
        <translation>Mossi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="545"/>
        <source>Multiple languages</source>
        <translation>ภาษา Multiple</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="546"/>
        <source>Munda languages</source>
        <translation>ภาษา Munda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="547"/>
        <source>N&apos;Ko</source>
        <translation>N&apos;Ko</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="548"/>
        <source>Nahuatl languages</source>
        <translation>ภาษา Nahuatl</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="549"/>
        <source>Neapolitan</source>
        <translation>Neapolitan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="550"/>
        <source>Nepal Bhasa/Newari</source>
        <translation>Nepal Bhasa/Newari</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="551"/>
        <source>Nias</source>
        <translation>Nias</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="552"/>
        <source>Niger-Kordofanian languages</source>
        <translation>ภาษา Niger-Kordofanian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="553"/>
        <source>Nilo-Saharan languages</source>
        <translation>ภาษา Nilo-Saharan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="554"/>
        <source>Niuean</source>
        <translation>Niuean</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="555"/>
        <source>No linguistic content/Not applicable</source>
        <translation>ไม่มีเนื้อหาทางภาษา/ไม่สามารถใช้งานได้</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="556"/>
        <source>Nogai</source>
        <translation>Nogai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="557"/>
        <source>Norse- Old</source>
        <translation>Norse- Old</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="558"/>
        <source>North American Indian languages</source>
        <translation>ภาษา North American Indian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="559"/>
        <source>Northern Frisian</source>
        <translation>Northern Frisian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="560"/>
        <source>Northern Sotho, Sepedi, Pedi</source>
        <translation>Northern Sotho, Sepedi, Pedi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="561"/>
        <source>Nubian languages</source>
        <translation>ภาษา Nubian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="562"/>
        <source>Nyamwezi</source>
        <translation>Nyamwezi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="563"/>
        <source>Nyankole</source>
        <translation>Nyankole</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="564"/>
        <source>Nyoro</source>
        <translation>Nyoro</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="565"/>
        <source>Nzima</source>
        <translation>Nzima</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="566"/>
        <source>Occitan/Provencal- Old (to 1500)</source>
        <translation>Occitan/Provencal- Old (to 1500)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="567"/>
        <source>Official/Imperial Aramaic (700-300 BCE)</source>
        <translation>Official/Imperial Aramaic (700-300 BCE)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="568"/>
        <source>Osage</source>
        <translation>Osage</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="569"/>
        <source>Otomian languages</source>
        <translation>ภาษา Otomian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="570"/>
        <source>Pahlavi</source>
        <translation>Pahlavi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="571"/>
        <source>Palauan</source>
        <translation>Palauan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="572"/>
        <source>Pangasinan</source>
        <translation>Pangasinan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="573"/>
        <source>Papiamento</source>
        <translation>Papiamento</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="574"/>
        <source>Papuan languages</source>
        <translation>ภาษา Papuan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="575"/>
        <source>Persian- Old (ca.600-400 B.C.)</source>
        <translation>Persian- Old (ca.600-400 B.C.)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="576"/>
        <source>Philippine languages</source>
        <translation>ภาษา Philippine</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="577"/>
        <source>Phoenician</source>
        <translation>Phoenician</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="578"/>
        <source>Pohnpeian</source>
        <translation>Pohnpeian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="579"/>
        <source>Prakrit languages</source>
        <translation>ภาษา Prakrit</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="580"/>
        <source>Rajasthani</source>
        <translation>Rajasthani</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="581"/>
        <source>Rapanui</source>
        <translation>Rapanui</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="582"/>
        <source>Rarotongan, Cook Islands Maori</source>
        <translation>Rarotongan, Cook Islands Maori</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="583"/>
        <source>Reserved for local use</source>
        <translation>ย้อนกลับไปใช้ตามท้องถิ่น</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="584"/>
        <source>Romance languages</source>
        <translation>ภาษา Romance</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="585"/>
        <source>Romany</source>
        <translation>Romany</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="586"/>
        <source>Salishan languages</source>
        <translation>ภาษา Salishan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="587"/>
        <source>Samaritan Aramaic</source>
        <translation>Samaritan Aramaic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="588"/>
        <source>Sami languages</source>
        <translation>ภาษา Sami</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="589"/>
        <source>Sandawe</source>
        <translation>Sandawe</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="590"/>
        <source>Santali</source>
        <translation>Santali</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="591"/>
        <source>Sasak</source>
        <translation>Sasak</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="592"/>
        <source>Scots</source>
        <translation>Scots</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="593"/>
        <source>Selkup</source>
        <translation>Selkup</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="594"/>
        <source>Semitic languages</source>
        <translation>ภาษา Semitic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="595"/>
        <source>Serer</source>
        <translation>Serer</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="596"/>
        <source>Shan</source>
        <translation>Shan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="597"/>
        <source>Sicilian</source>
        <translation>Sicilian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="598"/>
        <source>Sidamo</source>
        <translation>Sidamo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="599"/>
        <source>Sign Languages</source>
        <translation>ภาษา Sign</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="600"/>
        <source>Siksika</source>
        <translation>Siksika</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="601"/>
        <source>Sino-Tibetan languages</source>
        <translation>ภาษา Sino-Tibetan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="602"/>
        <source>Siouan languages</source>
        <translation>ภาษา Siouan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="603"/>
        <source>Skolt Sami</source>
        <translation>Skolt Sami</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="604"/>
        <source>Slave (Athapascan)</source>
        <translation>Slave (Athapascan)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="605"/>
        <source>Slavic languages</source>
        <translation>ภาษา Slavic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="606"/>
        <source>Sogdian</source>
        <translation>Sogdian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="607"/>
        <source>Songhai languages</source>
        <translation>ภาษา Songhai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="608"/>
        <source>Soninke</source>
        <translation>Soninke</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="609"/>
        <source>Sorbian languages</source>
        <translation>ภาษา Sorbian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="610"/>
        <source>South American Indian languages</source>
        <translation>ภาษา South American Indian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="611"/>
        <source>Southern Altai</source>
        <translation>Southern Altai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="612"/>
        <source>Southern Sami</source>
        <translation>Southern Sami</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="613"/>
        <source>Sranan Tongo</source>
        <translation>Sranan Tongo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="614"/>
        <source>Sukuma</source>
        <translation>Sukuma</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="615"/>
        <source>Sumerian</source>
        <translation>Sumerian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="616"/>
        <source>Susu</source>
        <translation>Susu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="617"/>
        <source>Alsatian, Swiss German, Alemannic</source>
        <translation>Alsatian, Swiss German, Alemannic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="618"/>
        <source>Syriac</source>
        <translation>Syriac</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="619"/>
        <source>Tai languages</source>
        <translation>ภาษา Tai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="620"/>
        <source>Tamashek</source>
        <translation>Tamashek</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="621"/>
        <source>Tereno</source>
        <translation>Tereno</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="622"/>
        <source>Tetum</source>
        <translation>Tetum</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="623"/>
        <source>Tigre</source>
        <translation>Tigre</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="624"/>
        <source>Timne</source>
        <translation>Timne</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="625"/>
        <source>Tiv</source>
        <translation>Tiv</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="626"/>
        <source>Tlingit</source>
        <translation>Tlingit</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="627"/>
        <source>Tok Pisin</source>
        <translation>Tok Pisin</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="628"/>
        <source>Tokelau</source>
        <translation>Tokelau</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="629"/>
        <source>Tonga (Nyasa)</source>
        <translation>Tonga (Nyasa)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="630"/>
        <source>Tsimshian</source>
        <translation>Tsimshian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="631"/>
        <source>Tumbuka</source>
        <translation>Tumbuka</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="632"/>
        <source>Tupi languages</source>
        <translation>ภาษา Tupi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="633"/>
        <source>Turkish- Ottoman (1500-1928)</source>
        <translation>Turkish- Ottoman (1500-1928)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="634"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="635"/>
        <source>Tuvinian</source>
        <translation>Tuvinian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="636"/>
        <source>Udmurt</source>
        <translation>Udmurt</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="637"/>
        <source>Ugaritic</source>
        <translation>Ugaritic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="638"/>
        <source>Umbundu</source>
        <translation>Umbundu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="639"/>
        <source>Uncoded languages</source>
        <translation>ภาษา Uncoded</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="640"/>
        <source>Undetermined</source>
        <translation>ไม่กำหนด</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="641"/>
        <source>Upper Sorbian</source>
        <translation>Upper Sorbian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="642"/>
        <source>Vai</source>
        <translation>Vai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="643"/>
        <source>Votic</source>
        <translation>Votic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="644"/>
        <source>Wakashan languages</source>
        <translation>ภาษา Wakashan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="645"/>
        <source>Waray</source>
        <translation>Waray</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="646"/>
        <source>Washo</source>
        <translation>Washo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="647"/>
        <source>Wolaitta, Wolaytta</source>
        <translation>Wolaitta, Wolaytta</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="648"/>
        <source>Yakut</source>
        <translation>Yakut</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="649"/>
        <source>Yao</source>
        <translation>Yao</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="650"/>
        <source>Yapese</source>
        <translation>Yapese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="651"/>
        <source>Yupik languages</source>
        <translation>ภาษา Yupik</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="652"/>
        <source>Zande languages</source>
        <translation>ภาษา Zande</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="653"/>
        <source>Zapotec</source>
        <translation>Zapotec</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="654"/>
        <source>Zenaga</source>
        <translation>Zenaga</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="655"/>
        <source>Zuni</source>
        <translation>Zuni</translation>
    </message>
</context>
<context>
    <name>LanguageWidget</name>
    <message>
        <location filename="../../Form_Files/PLanguageWidget.ui" line="14"/>
        <source>Language</source>
        <translation>ภาษา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PLanguageWidget.ui" line="36"/>
        <source>You must restart Sigil after changing the User Interface language.

If a translation for specific word or phrase is not available it will be displayed in English.

Use Preferences-&gt;Spellcheck Dictionaries to set the Spellcheck dictionary.</source>
        <translation>คุณต้องเริ่มต้น Sigil ใหม่หลังจากเปลี่ยนภาษาสำหรับอินเทอร์เฟซ

หากไม่สามารถแปลคำหรือวลีที่เฉพาะเจาะจงได้จะปรากฏในภาษาอังกฤษ

ใช้ การตั้งค่า-&gt; พจนานุกรมตรวจการสะกด เพื่อตั้งพจนานุกรมตรวจการสะกด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PLanguageWidget.ui" line="43"/>
        <source>User Interface Language:</source>
        <translation>ภาษาอินเทอร์เฟซ:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PLanguageWidget.ui" line="53"/>
        <source>Set the default language used by the Metadata Editor for new books.</source>
        <translation>ตั้งค่าภาษาเริ่มต้นที่ใช้โดยเครื่องมือแก้ไขข้อมูลเมตาสำหรับหนังสือใหม่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PLanguageWidget.ui" line="56"/>
        <source>Default Language For Metadata:</source>
        <translation>ภาษาเริ่มต้นสำหรับข้อมูลเมตา:</translation>
    </message>
</context>
<context>
    <name>LinkStylesheets</name>
    <message>
        <location filename="../../Form_Files/LinkStylesheets.ui" line="14"/>
        <source>Link StyleSheets</source>
        <translation>เชื่อมโยงสไตล์ชีต...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/LinkStylesheets.ui" line="43"/>
        <source>Move the selected stylesheets up in priority.

Stylesheets that are listed first take precedence over later stylesheets.</source>
        <translation>ย้ายสไตล์ชีทที่เลือกไว้ในลำดับความสำคัญ
แผ่นงานที่ระบุไว้ก่อนหน้านี้จะมีลำดับความสำคัญสูงกว่าแผ่นงานในภายหลัง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/LinkStylesheets.ui" line="48"/>
        <source>Up</source>
        <translation>ขึ้น</translation>
    </message>
    <message>
        <location filename="../../Form_Files/LinkStylesheets.ui" line="58"/>
        <source>Move the selected stylesheets down in priority.</source>
        <translation>ย้ายสไตล์ชีตที่เลือกลงในลำดับความสำคัญ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/LinkStylesheets.ui" line="61"/>
        <source>Down</source>
        <translation>ลง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/LinkStylesheets.cpp" line="60"/>
        <source>Include</source>
        <translation>ประกอบด้วย</translation>
    </message>
    <message>
        <location filename="../../Dialogs/LinkStylesheets.cpp" line="61"/>
        <source>Stylesheet</source>
        <translation>สไตล์ชีต</translation>
    </message>
</context>
<context>
    <name>LinksWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsLinksWidget.ui" line="14"/>
        <source>Links</source>
        <translation>เชื่อมโยง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsLinksWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsLinksWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>กรอง:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="71"/>
        <source>File</source>
        <translation>ไฟล์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="72"/>
        <source>Line</source>
        <translation>บรรทัด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="73"/>
        <source>ID</source>
        <translation>ไอดี</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="74"/>
        <source>Text</source>
        <translation>ข้อความ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="75"/>
        <source>Target File</source>
        <translation>ไฟล์ปลายทาง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="76"/>
        <source>Target ID</source>
        <translation>ไอดีปลายทาง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="77"/>
        <source>Target Exists?</source>
        <translation>เป้าหมายมีอยู่หรือไม่?</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="78"/>
        <source>Target Text</source>
        <translation>ข้อความเป้าหมาย</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="79"/>
        <source>Target&apos;s Target File</source>
        <translation>ไฟล์เป้าหมายของเป้าหมาย</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="80"/>
        <source>Target&apos;s Target ID</source>
        <translation>ไอดีเป้าหมายของเป้าหมาย</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="81"/>
        <source>Match?</source>
        <translation>ตรงกัน?</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="87"/>
        <source>Report shows all source and target links using the anchor tag &quot;a&quot;.</source>
        <translation>รายงานแสดงลิงก์แหล่งที่มาและเป้าหมายทั้งหมดโดยใช้แท็ก &quot;a&quot;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="156"/>
        <source>n/a</source>
        <translation>n/a</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="159"/>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="227"/>
        <source>no</source>
        <translation>ไม่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="166"/>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="229"/>
        <source>yes</source>
        <translation>ใช่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="343"/>
        <source>Save Report As Comma Separated File</source>
        <translation>บันทึกรายงานเป็นไฟล์ที่แบ่งด้วยจุลภาค</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="356"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="356"/>
        <source>Cannot save report file.</source>
        <translation>บันทึกไฟล์รายงานไม่ได้</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../Form_Files/main.ui" line="14"/>
        <source>untitled.epub[*] - Sigil</source>
        <translation>untitled.epub[*] - Sigil</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="58"/>
        <source>&amp;File</source>
        <translation>ไฟล์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="62"/>
        <source>A&amp;dd</source>
        <translation>เพิ่ม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="88"/>
        <source>&amp;Edit</source>
        <translation>แก้ใข</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="92"/>
        <source>C&amp;hange Case</source>
        <translation>เปลี่ยนตัวพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="117"/>
        <source>&amp;Insert</source>
        <translation>แทรก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="121"/>
        <source>Cli&amp;p</source>
        <translation>คลิป</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="158"/>
        <source>&amp;Help</source>
        <translation>ช่วยเหลือ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="168"/>
        <source>For&amp;mat</source>
        <translation>รูปแบบ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="172"/>
        <source>&amp;Heading</source>
        <translation>หัวเรื่อง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="213"/>
        <source>&amp;View</source>
        <translation>มุมมอง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="217"/>
        <source>&amp;Toolbars</source>
        <translation>แถบเครื่องมือ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="232"/>
        <source>&amp;Search</source>
        <translation>ค้นหา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="236"/>
        <source>Current Fil&amp;e</source>
        <translation>ไฟล์ปัจจุบัน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="268"/>
        <source>&amp;Window</source>
        <translation>หน้าต่าง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="280"/>
        <source>&amp;Tools</source>
        <translation>เครื่องมือ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="284"/>
        <source>&amp;Table Of Contents</source>
        <translation>สารบัญ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="292"/>
        <source>Spe&amp;llcheck</source>
        <translation>ตรวจการสะกด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="306"/>
        <source>&amp;Index</source>
        <translation>ดัชนี</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="317"/>
        <source>Re&amp;format HTML</source>
        <translation>จัดรูปแบบ HTML</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="324"/>
        <source>Epub&amp;3 Tools</source>
        <translation>เครื่องมือ Epub3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="349"/>
        <source>Plugins</source>
        <translation>ส่วนเสริม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="367"/>
        <location filename="../../MainUI/MainWindow.cpp" line="598"/>
        <source>File</source>
        <translation>ไฟล์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="382"/>
        <location filename="../../MainUI/MainWindow.cpp" line="337"/>
        <source>Edit</source>
        <translation>แก้ไข</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="401"/>
        <source>View</source>
        <translation>มุมมอง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="414"/>
        <source>Insert</source>
        <translation>แทรก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="431"/>
        <source>Back</source>
        <translation>ย้อนกลับ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="443"/>
        <source>Donate</source>
        <translation>บริจาค</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="455"/>
        <source>Tools</source>
        <translation>เครื่องมือ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="477"/>
        <source>Heading</source>
        <translation>หัวเรื่อง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="495"/>
        <source>Format</source>
        <translation>รูปแบบ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="512"/>
        <source>Align</source>
        <translation>ปรับตําแหน่ง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="527"/>
        <source>List</source>
        <translation>รายการ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="540"/>
        <source>Indent</source>
        <translation>ย่อหน้า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="553"/>
        <source>Change Case</source>
        <translation>เปลี่ยนตัวพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="568"/>
        <source>Text Direction</source>
        <translation>ทิศทางข้อความ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="582"/>
        <source>Clip Bar</source>
        <translation>แถบคลิป</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="617"/>
        <source>&amp;New</source>
        <translation>ใหม่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="620"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;New&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Create a new book.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ใหม่&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;สร้างหนังสือเล่มใหม่&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="625"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="634"/>
        <source>&amp;Save</source>
        <translation>บันทึก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="637"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Save&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Save the current book.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;บันทึก&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;บันทึกหนังสือปัจจุบัน&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="642"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="647"/>
        <source>Save &amp;As...</source>
        <translation>บันทึกเป็น</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="650"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Save As&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Save the current book with a different filename.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;บันทึกเป็น&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;บันทึกหนังสือปัจจุบันโดยใช้ชื่อไฟล์อื่น&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="655"/>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Shift+S</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="660"/>
        <source>Save A &amp;Copy...</source>
        <translation>บันทึกสำเนา...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="663"/>
        <source>Save a copy of your book to another file name.</source>
        <translation>บันทึกสำเนาหนังสือไปยังชื่อไฟล์อื่น</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="672"/>
        <source>Cu&amp;t</source>
        <translation>ตัด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="675"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Cut&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Cuts the selected text from the document and puts it on the clipboard.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ตัด&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ตัดข้อความที่เลือกออกจากเอกสารและวางไว้ในคลิปบอร์ด&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="686"/>
        <source>&amp;Paste</source>
        <translation>วาง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="689"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Paste&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Pastes the content from the clipboard into the book.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;วาง&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;วางเนื้อหาจากคลิปบอร์ดลงในหนังสือ&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="696"/>
        <source>&amp;Closing Tag</source>
        <translation>ปิดแท็ก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="699"/>
        <source>Insert a closing tag in Code View.</source>
        <translation>แทรกแท็กปิดในมุมมองโค้ด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="702"/>
        <source>Ctrl+.</source>
        <translation>Ctrl+.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="711"/>
        <source>&amp;Undo</source>
        <translation>ยกเลิก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="714"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Undo&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Reverts the changes of the previous operation.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ยกเลิก&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ย้อนกลับการเปลี่ยนแปลงของการทำงานก่อนหน้านี้&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="719"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="728"/>
        <source>&amp;Redo</source>
        <translation>ทำซ้ำ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="731"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Redo&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Restores the changes reverted by the previous Undo action.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ทำซ้ำ&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;เรียกคืนการเปลี่ยนแปลงหวนกลับโดยการกระทำเลิกทำก่อนหน้านี้&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="736"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="745"/>
        <source>&amp;Copy</source>
        <translation>คัดลอก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="748"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Copy&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Copies the selected text and puts it on the clipboard.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;คัดลอก&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;คัดลอกข้อความที่เลือกและใส่ลงในคลิปบอร์ด&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="762"/>
        <source>Align &amp;Left</source>
        <translation>จัดชิดซ้าย</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="765"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Align Left&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Align the paragraph to the left.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;จัดชิดซ้าย&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;จัดเรียงย่อหน้าไว้ทางซ้าย&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="779"/>
        <source>Align &amp;Right</source>
        <translation>จัดชิดขวา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="782"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Align Right&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Align the paragraph to the right.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;จัดชิดขวา&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;จัดเรียงย่อหน้าไว้ทางขวา&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="796"/>
        <source>&amp;Center</source>
        <translation>จัดกึ่งกลาง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="799"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Center&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Center the paragraph.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;จัดกึ่งกลาง&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;จัดเรียงย่อหน้าไว้กึ่งกลาง&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="804"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="816"/>
        <source>&amp;Justify</source>
        <translation>ชิดขอบ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="819"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Justify&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Align the paragraph to both the left and right margins.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ชิดขอบ&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;จัดแนวย่อหน้าให้ชิดทั้งขอบด้านซ้ายและด้านขวา&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="824"/>
        <source>Ctrl+J</source>
        <translation>Ctrl+J</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="836"/>
        <source>&amp;Bold</source>
        <translation>ตัวหนา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="839"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Bold&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Make the selected text bold.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ตัวหนา&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ทำให้ข้อความที่เลือกเป็นตัวหนา&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="844"/>
        <source>Ctrl+B</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="856"/>
        <source>&amp;Italic</source>
        <translation>ตัวเอียง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="859"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Italic&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Make the selected text italic.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ตัวเอียง&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ทำให้ข้อความที่เลือกเป็นตัวเอียง&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="864"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="873"/>
        <source>&amp;Open...</source>
        <translation>เปิด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="876"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Open&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Open a book from disk.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;เปิด&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;เปิดหนังสือจากดิสก์&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="881"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="893"/>
        <source>&amp;Underline</source>
        <translation>ขีดเส้นใต้</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="896"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Underline&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Underline the selected text.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ขีดเส้นใต้&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ทำให้ข้อความที่เลือกมีขีดเส้นใต้&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="901"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="910"/>
        <source>&amp;Quit</source>
        <translation>ปิด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="913"/>
        <source>Exit</source>
        <translation>ออก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="916"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="925"/>
        <source>&amp;About...</source>
        <translation>เกี่ยวกับ...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="928"/>
        <source>Show information about Sigil.</source>
        <translation>แสดงข้อมูลเกี่ยวกับ Sigil</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="933"/>
        <source>Add &amp;Cover...</source>
        <translation>เพิ่มปก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="936"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Add Cover&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Add a cover.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;เพิ่มปก&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;เพิ่มปก&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="947"/>
        <source>&amp;Metadata Editor...</source>
        <translation>ตัวแก้ไขข้อมูลเมตา ...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="950"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Metadata Editor&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Edit and display information about your book including the author and title.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ตัวแก้ไขข้อมูลเมตา&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;แก้ไขและแสดงข้อมูลเกี่ยวกับหนังสือรวมถึงผู้แต่งและชื่อหนังสือ&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="955"/>
        <source>F8</source>
        <translation>F8</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="964"/>
        <source>&amp;Generate Table Of Contents...</source>
        <translation>สร้างสารบัญ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="967"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Generate Table of Contents&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Generate a new Table of Contents from headings in your book.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;สร้างสารบัญ&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;สร้างสารบัญใหม่จากส่วนของหัวในหนังสือ&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="972"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="977"/>
        <source>&amp;Edit Table Of Contents...</source>
        <translation>แก้ไขสารบัญ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="980"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Edit Table of Contents&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Directly edit the existing Table of Contents.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;แก้ไขสารบัญ&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;แก้ไขสารบัญที่มีอยู่โดยตรง&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="994"/>
        <source>&amp;Book View</source>
        <translation>มุมมองหนังสือ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="997"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Book View&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Edit and display the files in your book as they will appear to readers.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;มุมมองหนังสือ&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;แก้ไขและแสดงไฟล์ในหนังสือที่ปรากฏต่อผู้อ่าน&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1011"/>
        <source>&amp;Code View</source>
        <translation>มุมมองโค้ด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1014"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Code View&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Edit and display the actual contents of the files in your book, including the formatting codes that control how your book will appear to readers.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;มุมมองโค้ด&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;แก้ไขและแสดงเนื้อหาที่แท้จริงของไฟล์ในหนังสือรวมถึงโค้ดการจัดรูปแบบที่ควบคุมวิธีที่หนังสือที่จะปรากฏต่อผู้อ่าน&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1021"/>
        <source>&amp;Toggle View State</source>
        <translation>สลับสถานะมุมมอง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1024"/>
        <source>Toggle Book View to Code View or Code View to Book View</source>
        <translation>สลับมุมมองหนังสือเป็นมุมมองโค้ด หรือ มุมมองโค้ดเป็นมุมมองหนังสือ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1027"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1036"/>
        <source>&amp;Split At Cursor</source>
        <translation>แบ่งที่เคอร์เซอร์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1039"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Split At Cursor&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Split the current file into two files using your cursor location as the dividing point.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;แบ่งที่เคอร์เซอร์&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;แบ่งไฟล์ปัจจุบันเป็นสองไฟล์โดยใช้ตำแหน่งเคอร์เซอร์เป็นจุดแบ่ง.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1044"/>
        <source>Ctrl+Return</source>
        <translation>Ctrl+Return</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1053"/>
        <source>&amp;File...</source>
        <translation>ไฟล์...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1056"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Insert File&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Select image, video or audio files from your book to insert into the text.&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;You can add files to your book by using the menu File - Add - Existing Files.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;แทรกไฟล์&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;เลือกไฟล์ ภาพ วิดีโอ หรือเสียง จากหนังสือ เพื่อแทรกลงในข้อความ&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;สามารถเพิ่มไฟล์ลงในหนังสือโดยใช้เมนู ไฟล์ - เพิ่ม - ไฟล์ที่มีอยู่&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1063"/>
        <source>Ctrl+Shift+I</source>
        <translation>Ctrl+Shift+I</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1072"/>
        <source>&amp;Special Character...</source>
        <translation>อักขระพิเศษ...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1075"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Insert Special Character&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Select a character to insert into your text.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;แทรกอักขระพิเศษ&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;เลือกตัวอักษรที่จะแทรกลงในข้อความ&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1086"/>
        <source>I&amp;D...</source>
        <translation>ไอดี...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1089"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Insert ID&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Insert or edit an anchor with an ID name to use as a link target.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;แทรกไอดี&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;แทรกหรือแก้ไข anchor ที่มีชื่อไอดีเพื่อเชื่อมโยงเป้าหมาย&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1100"/>
        <source>&amp;Link...</source>
        <translation>เชื่อมโยง...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1103"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Insert Link&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Insert or edit an anchor with a hyperlink to a target.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;แทรกเชื่อมโยง&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;แทรกหรือแก้ไข anchor ด้วยการเชื่อมโยงลิ้งไปยังเป้าหมาย&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1117"/>
        <source>&amp;Numbered List</source>
        <translation>รายการเรียงลำดับเลข</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1120"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Numbering&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Create a numbered list.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ลำดับเลข&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;สร้างรายการเรียงลำดับเลข&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1134"/>
        <source>Bulle&amp;ted List</source>
        <translation>รายการหัวข้อย่อย</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1137"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Bullets&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Create a bulleted list.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;หัวข้อย่อย&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;สร้างรายการแสดงหัวข้อย่อย&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1142"/>
        <source>Ctrl+Shift+L</source>
        <translation>Ctrl+Shift+L</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1154"/>
        <source>Stri&amp;kethrough</source>
        <translation>ขีดฆ่า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1157"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Strikethrough&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Draw a line through the selected text.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ขีดฆ่า&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;วาดเส้นผ่านข้อความที่เลือก.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1171"/>
        <source>&amp;Subscript</source>
        <translation>ตัวห้อย</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1174"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Subscript&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set the selected text slightly smaller and below the normal line.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ตัวห้อย&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ตั้งค่าข้อความที่เลือกไว้ลงล่างเล็กน้อยและต่ำกว่าบรรทัดปกติ&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1188"/>
        <source>Su&amp;perscript</source>
        <translation>ตัวยก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1191"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Superscript&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set the selected text slightly smaller and above the normal line.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ตัวยก&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ตั้งค่าข้อความที่เลือกไว้ขึ้นเล็กน้อยและอยู่เหนือบรรทัดปกติ&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1202"/>
        <source>&amp;Print...</source>
        <translation>พิมพ์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1205"/>
        <source>Print</source>
        <translation>พิมพ์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1208"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1217"/>
        <source>Print Pre&amp;view...</source>
        <translation>ตัวอย่างก่อนพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1220"/>
        <source>Print Preview</source>
        <translation>ตัวอย่างก่อนพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1225"/>
        <location filename="../../Form_Files/main.ui" line="1228"/>
        <source>Close</source>
        <translation>ปิด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1231"/>
        <source>Ctrl+Shift+W</source>
        <translation>Ctrl+Shift+W</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1240"/>
        <source>Zoom &amp;In</source>
        <translation>ขยายเข้า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1243"/>
        <source>Zoom In</source>
        <translation>ขยายเข้า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1246"/>
        <source>Ctrl+=</source>
        <translation>Ctrl+=</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1255"/>
        <source>Zoom &amp;Out</source>
        <translation>ขยายออก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1258"/>
        <source>Zoom Out</source>
        <translation>ขยายออก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1261"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1266"/>
        <source>Sho&amp;w Tag</source>
        <translation>แสดงแท็ก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1269"/>
        <source>Show the enclosing tag HTML for the cursor position in Book View.</source>
        <translation>แสดงแท็ก HTML ล้อมรอบสำหรับตำแหน่งเคอร์เซอร์ในมุมมองหนังสือ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1272"/>
        <source>Ctrl+Alt+T</source>
        <translation>Ctrl+Alt+T</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1281"/>
        <source>&amp;Find &amp;&amp; Replace...</source>
        <translation>ค้นหา &amp; แทนที่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1284"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Find &amp;amp; Replace&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Find and replace text in the document.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ค้นหา &amp; แทนที่&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ค้นหาและแทนที่ข้อความในเอกสาร&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1289"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1298"/>
        <source>Incre&amp;ase Indent</source>
        <translation>เพิ่มการย่อหน้า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1301"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Increase Indent&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Increase the indent level of the paragraph.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;เพิ่มการย่อหน้า&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;เพิ่มระดับย่อหน้าของย่อหน้า&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1306"/>
        <source>Ctrl+Alt+M</source>
        <translation>Ctrl+Alt+M</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1315"/>
        <source>&amp;Decrease Indent</source>
        <translation>ลดย่อหน้า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1318"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Decrease Indent&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Decrease the indent level of the paragraph.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ลดย่อหน้า&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ลดระดับย่อหน้าของย่อหน้า&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1323"/>
        <location filename="../../Form_Files/main.ui" line="1734"/>
        <source>Ctrl+Shift+M</source>
        <translation>Ctrl+Shift+M</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1332"/>
        <source>Te&amp;xt Direction LTR</source>
        <translation>ทิศทางข้อความ LTR</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1335"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Left-to-Right&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set paragraph direction left to right.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ซ้ายไปขวา&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ตั้งทิศทางย่อหน้าจากซ้ายไปขวา&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1348"/>
        <source>T&amp;ext Direction RTL</source>
        <translation>ทิศทางข้อความ RTL</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1351"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Right-to-Left&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set paragraph direction right to left.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ขวาไปซ้าย&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ตั้งทิศทางย่อหน้าจากขวาไปซ้าย&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1364"/>
        <source>Text Directi&amp;on Default</source>
        <translation>ทิศทางข้อความเริ่มต้น</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1367"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Default&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set paragraph direction to inherit from default.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ค่าเริ่มต้น&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ตั้งค่าย่อหน้าโดยใช้ค่าเริ่มต้น&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1376"/>
        <source>Remove &amp;Formatting</source>
        <translation>ลบการจัดรูปแบบ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1379"/>
        <source>Ctrl+Space</source>
        <translation>Ctrl+Space</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1388"/>
        <source>&amp;Lowercase</source>
        <translation>ตัวพิมพ์เล็ก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1391"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Lowercase&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set selected text to lowercase.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ตัวพิมพ์เล็ก&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ทำให้ข้อความที่เลือกเป็นตัวพิมพ์เล็ก&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1398"/>
        <source>Alt+L</source>
        <translation>Alt+L</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1407"/>
        <source>&amp;Uppercase</source>
        <translation>ตัวพิมพ์ใหญ่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1410"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Uppercase&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set selected text to uppercase.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ตัวพิมพ์ใหญ่&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ทำให้ข้อความที่เลือกเป็นตัวพิมพ์ใหญ่&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1417"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1426"/>
        <source>&amp;Titlecase</source>
        <translation>ตัวแรกของคำเป็นพิมพ์ใหญ่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1429"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Titlecase&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Capitalize the first letter of each word selected.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ตัวแรกของคำเป็นพิมพ์ใหญ่&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ทำให้ข้อความตัวอักษรแรกของคำเป็นตัวพิมพ์ใหญ่&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1442"/>
        <source>&amp;Capitalize</source>
        <translation>ตัวแรกเป็นพิมพ์ใหญ่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1445"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Capitalize&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Capitalize only the first word of the selected text.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ตัวแรกเป็นพิมพ์ใหญ่&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ทำให้ข้อความตัวอักษรแรกของคำเป็นตัวพิมพ์ใหญ่ &lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1454"/>
        <source>Sigil Website...</source>
        <translation>เว็บไซต์ Sigil...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1459"/>
        <source>&amp;Next Tab</source>
        <translation>แท็บถัดไป</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1462"/>
        <source>Ctrl+PgUp</source>
        <translation>Ctrl+PgUp</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1467"/>
        <source>&amp;Previous Tab</source>
        <translation>แท็บก่อนหน้า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1470"/>
        <source>Ctrl+PgDown</source>
        <translation>Ctrl+PgDown</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1475"/>
        <source>&amp;Close Tab</source>
        <translation>ปิดแท็บ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1478"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1483"/>
        <source>Split At &amp;Markers</source>
        <translation>แบ่งตรงที่ทำเครื่องหมาย</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1486"/>
        <source>Split At Sigil split file markers</source>
        <translation>แบ่งที่ Sigil ทำเครื่องหมายแบ่งไฟล์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1489"/>
        <source>F6</source>
        <translation>F6</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1494"/>
        <source>Split &amp;Marker</source>
        <translation>เครื่องหมายแบ่ง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1497"/>
        <source>Insert Sigil split file marker</source>
        <translation>แทรก Sigil ทำเครื่องหมายแบ่งไฟล์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1500"/>
        <source>Ctrl+Shift+Return</source>
        <translation>Ctrl+Shift+Return</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1505"/>
        <source>User &amp;Guide...</source>
        <translation>คู่มือผู้ใช้</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1508"/>
        <source>User Guide</source>
        <translation>คู่มือผู้ใช้</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1511"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1516"/>
        <source>&amp;Frequently Asked Questions...</source>
        <translation>คำถามที่พบบ่อย...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1519"/>
        <source>Frequently Asked Questions</source>
        <translation>คำถามที่พบบ่อย</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1524"/>
        <source>&amp;Tutorials...</source>
        <translation>บทเรียน...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1527"/>
        <source>Tutorials</source>
        <translation>บทเรียน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1532"/>
        <source>Well-Formed Check &amp;EPUB</source>
        <translation>ตรวจสอบ EPUB ให้มีรูปแบบอย่างดี </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1535"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Well-Formed Check EPUB&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Verify your document complies with minimum needed to be successfully parsed. This does not indicate compliance with the relevant epub standards.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;ตรวจสอบ EPUB ให้มีรูปแบบอย่างดี &lt;/span&gt;&lt;/p&gt;&lt;p&gt;ตรวจสอบว่าเอกสารของคุณสอดคล้องกับจำนวนขั้นต่ำที่จำเป็นในการแยกวิเคราะห์สำเร็จแล้ว ไม่ได้หมายความว่าสอดคล้องกับมาตรฐาน EPUB ที่เกี่ยวข้อง &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1538"/>
        <source>F7</source>
        <translation>F7</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1543"/>
        <source>Validate Stylesheets With &amp;W3C</source>
        <translation>ตรวจสอบความถูกต้องกับ W3C</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1546"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Validate Stylesheets with W3C&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Verify your CSS stylesheets comply with W3C standards using the online W3C CSS Validation Service.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ตรวจสอบความถูกต้องกับ W3C&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ยืนยันสไตล์ CSS ของคุณสอดคล้องกับมาตรฐาน W3C โดยใช้บริการตรวจสอบ W3C CSS แบบออนไลน์&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1559"/>
        <source>&amp;Spellcheck...</source>
        <translation>ตรวจการสะกด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1562"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Spellcheck&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Find all misspelled words and allow you to add them to a dictionary or ignore them.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ตรวจการสะกด&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;ค้นหาคำที่สะกดผิดทั้งหมดและอนุญาตให้คุณเพิ่มลงในพจนานุกรมหรือไม่สนใจคำเหล่านั้น&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1567"/>
        <source>Alt+Q</source>
        <translation>Alt+Q</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1575"/>
        <source>&amp;Highlight Misspelled Words</source>
        <translation>เน้นคำที่สะกดผิด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1578"/>
        <source>Enable or disable highlighting of misspelled words in Code View.</source>
        <translation>เปิดหรือปิดการเน้นคำที่สะกดผิดในมุมมองโค้ด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1583"/>
        <source>&amp;Next Misspelled Word</source>
        <translation>คำที่สะกดผิดถัดไป</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1586"/>
        <source>Find the next misspelled word in the book.</source>
        <translation>ค้นหาคำที่สะกดผิดต่อไปในหนังสือ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1589"/>
        <source>F4</source>
        <translation>F4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1594"/>
        <source>&amp;Add Misspelled Word</source>
        <translation>เพิ่มคำที่สะกดผิด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1597"/>
        <source>Add the current misspelled word under the caret to the default user dictionary.</source>
        <translation>เพิ่มคำที่สะกดผิดในปัจจุบันใต้เครื่องหมายคำพูดลงในพจนานุกรมผู้ใช้เริ่มต้น</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1602"/>
        <source>&amp;Ignore Misspelled Word</source>
        <translation>ละเว้นคำที่สะกดผิด </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1605"/>
        <source>Ignore the current misspelled word under the caret until Sigil is restarted.</source>
        <translation>ละเว้นคำที่สะกดผิดปัจจุบันใต้เครื่องหมายคำพูดจนกว่า Sigil จะเริ่มใหม่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1610"/>
        <source>&amp;Clear Ignored Words</source>
        <translation>ล้างคำที่สะกดผิด </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1613"/>
        <source>Clear currently ignored words from Spellcheck without having to restart Sigil.</source>
        <translation>ล้างคำละเว้นในขณะนี้จากการตรวจการสะกดโดยไม่ต้องเริ่ม Sigil ใหม่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1618"/>
        <source>&amp;Index Editor...</source>
        <translation>ตัวแก้ไขดัชนี</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1621"/>
        <source>Ctrl+Alt+I</source>
        <translation>Ctrl+Alt+I</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1626"/>
        <source>&amp;Delete Unused Media Files...</source>
        <translation>ลบไฟล์มีเดียที่ไม่ได้ใช้ ...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1631"/>
        <source>Delete &amp;Unused Stylesheet Classes...</source>
        <translation>ลบสไตล์ชีตคลาสที่ไม่ได้ใช้งาน...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1636"/>
        <source>&amp;Reports...</source>
        <translation>รายงาน...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1639"/>
        <source>Ctrl+Shift+R</source>
        <translation>Ctrl+Shift+R</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1648"/>
        <source>&amp;Donate...</source>
        <translation>บริจาค...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1651"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Donate&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Donate to support Sigil.&lt;/p&gt;
</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;บริจาค&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;บริจาคเพื่อยสนับสนุน Sigil.&lt;/p&gt;
</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1659"/>
        <source>Close &amp;Other Tabs</source>
        <translation>ปิดแท็บอื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1662"/>
        <source>Ctrl+Alt+W</source>
        <translation>Ctrl+Alt+W</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1667"/>
        <source>Go To &amp;Line...</source>
        <translation>ไปยังบรรทัด...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1670"/>
        <source>Ctrl+/</source>
        <translation>Ctrl+/</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1675"/>
        <source>Find &amp;Next</source>
        <translation>ค้นหาถัดไป</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1678"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1683"/>
        <source>Find &amp;Previous</source>
        <translation>ค้นหาก่อนหน้า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1686"/>
        <source>Ctrl+Shift+G</source>
        <translation>Ctrl+Shift+G</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1691"/>
        <source>Replace</source>
        <translation>แทนที่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1694"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1699"/>
        <source>&amp;Replace/Find Next</source>
        <translation>แทนที่/ค้นหาถัดไป</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1702"/>
        <source>Ctrl+]</source>
        <translation>Ctrl+]</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1707"/>
        <source>R&amp;eplace/Find Previous</source>
        <translation>แทนที่/ค้นหาก่อนหน้า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1710"/>
        <source>Ctrl+[</source>
        <translation>Ctrl+[</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1715"/>
        <source>Replace &amp;All</source>
        <translation>แทนที่ทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1718"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1723"/>
        <source>&amp;Count All</source>
        <translation>นับทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1726"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1731"/>
        <source>Mar&amp;k Selected Text</source>
        <translation>เลือกข้อความที่เลือก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1739"/>
        <source>Find &amp;Next In File</source>
        <translation>ค้นหาถัดไปในไฟล์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1744"/>
        <source>&amp;Replace Next In File</source>
        <translation>แทนที่ถัดไปในไฟล์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1749"/>
        <source>Replace &amp;All In File</source>
        <translation>แทนที่ทั้งหมดในไฟล์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1754"/>
        <source>&amp;Count All In File</source>
        <translation>นับทั้งหมดในไฟล์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1759"/>
        <source>&amp;Saved Searches...</source>
        <translation>บันทึกการค้นหา...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1762"/>
        <source>Ctrl+Alt+F</source>
        <translation>Ctrl+Alt+F</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1767"/>
        <source>&amp;Clip Editor...</source>
        <translation>ตัวแก้ไขคลิป...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1770"/>
        <source>Open the Clip Editor.</source>
        <translation>เปิดตัวแก้ไขคลิป</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1773"/>
        <source>Ctrl+Alt+C</source>
        <translation>Ctrl+Alt+C</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1778"/>
        <source>Clip &amp;1</source>
        <translation>คลิป &amp;1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1781"/>
        <source>Insert Clip 1</source>
        <translation>แทรกคลิป 1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1784"/>
        <source>Ctrl+Alt+1</source>
        <translation>Ctrl+Alt+1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1789"/>
        <source>Clip &amp;2</source>
        <translation>คลิป  &amp;2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1792"/>
        <source>Insert Clip 2</source>
        <translation>แทรกคลิป 2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1795"/>
        <source>Ctrl+Alt+2</source>
        <translation>Ctrl+Alt+2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1800"/>
        <source>Clip &amp;3</source>
        <translation>คลิป &amp;3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1803"/>
        <source>Insert Clip 3</source>
        <translation>แทรกคลิป 3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1806"/>
        <source>Ctrl+Alt+3</source>
        <translation>Ctrl+Alt+3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1811"/>
        <source>Clip &amp;4</source>
        <translation>คลิป &amp;4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1814"/>
        <source>Insert Clip 4</source>
        <translation>แทรกคลิป 4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1817"/>
        <source>Ctrl+Alt+4</source>
        <translation>Ctrl+Alt+4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1822"/>
        <source>Clip &amp;5</source>
        <translation>คลิป &amp;5</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1825"/>
        <source>Insert Clip 5</source>
        <translation>แทรกคลิป 5</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1828"/>
        <source>Ctrl+Alt+5</source>
        <translation>Ctrl+Alt+5</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1833"/>
        <source>Clip &amp;6</source>
        <translation>คลิป &amp;6</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1836"/>
        <source>Insert Clip 6</source>
        <translation>แทรกคลิป 6</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1839"/>
        <source>Ctrl+Alt+6</source>
        <translation>Ctrl+Alt+6</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1844"/>
        <source>Clip &amp;7</source>
        <translation>คลิป &amp;7</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1847"/>
        <source>Insert Clip 7</source>
        <translation>แทรกคลิป 7</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1850"/>
        <source>Ctrl+Alt+7</source>
        <translation>Ctrl+Alt+7</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1855"/>
        <source>Clip &amp;8</source>
        <translation>คลิป &amp;8</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1858"/>
        <source>Insert Clip 8</source>
        <translation>แทรกคลิป 8</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1861"/>
        <source>Ctrl+Alt+8</source>
        <translation>Ctrl+Alt+8</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1866"/>
        <source>Clip &amp;9</source>
        <translation>คลิป &amp;9</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1869"/>
        <source>Insert Clip 9</source>
        <translation>แทรกคลิป 9</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1872"/>
        <source>Ctrl+Alt+9</source>
        <translation>Ctrl+Alt+9</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1877"/>
        <source>Clip 1&amp;0</source>
        <translation>คลิป 1&amp;0</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1880"/>
        <source>Insert Clip 10</source>
        <translation>แทรกคลิป 10</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1883"/>
        <source>Ctrl+Alt+0</source>
        <translation>Ctrl+Alt+0</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1888"/>
        <source>Clip 11</source>
        <translation>คลิป 11</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1891"/>
        <source>Insert Clip 11</source>
        <translation>แทรกคลิป 11</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1896"/>
        <source>Clip 12</source>
        <translation>คลิป 12</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1899"/>
        <source>Insert Clip 12</source>
        <translation>แทรกคลิป 12</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1904"/>
        <source>Clip 13</source>
        <translation>คลิป 13</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1907"/>
        <source>Insert Clip 13</source>
        <translation>แทรกคลิป 13</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1912"/>
        <source>Clip 14</source>
        <translation>คลิป 14</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1915"/>
        <source>Insert Clip 14</source>
        <translation>แทรกคลิป 14</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1920"/>
        <source>Clip 15</source>
        <translation>คลิป 15</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1923"/>
        <source>Insert Clip 15</source>
        <translation>แทรกคลิป 15</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1928"/>
        <source>Clip 16</source>
        <translation>คลิป 16</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1931"/>
        <source>Insert Clip 16</source>
        <translation>แทรกคลิป 16</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1936"/>
        <source>Clip 17</source>
        <translation>คลิป 17</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1939"/>
        <source>Insert Clip 17</source>
        <translation>แทรกคลิป 17</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1944"/>
        <source>Clip 18</source>
        <translation>คลิป 18</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1947"/>
        <source>Insert Clip 18</source>
        <translation>แทรกคลิป 18</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1952"/>
        <source>Clip 19</source>
        <translation>คลิป 19</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1955"/>
        <source>Insert Clip 19</source>
        <translation>แทรกคลิป 19</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1960"/>
        <source>Clip 20</source>
        <translation>คลิป 20</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1963"/>
        <source>Insert Clip 20</source>
        <translation>แทรกคลิป 20</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1968"/>
        <source>&amp;Preferences...</source>
        <translation>การตั้งค่า...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1971"/>
        <source>F5</source>
        <translation>F5</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1976"/>
        <source>&amp;Zoom Reset</source>
        <translation>รีเซ็ตซูม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1979"/>
        <source>Zoom Reset</source>
        <translation>รีเซ็ตซูม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1982"/>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1994"/>
        <source>Heading &amp;1</source>
        <translation>หัวเรื่อง &amp;1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1997"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Heading 1&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a level 1 heading.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;หัวเรื่อง 1&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;จัดรูปแบบย่อหน้าเป็นหัวเรื่องระดับ 1&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2002"/>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2014"/>
        <source>Heading &amp;2</source>
        <translation>หัวเรื่อง &amp;2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2017"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Heading 2&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a level 2 heading.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;หัวเรื่อง 2&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;จัดรูปแบบย่อหน้าเป็นหัวเรื่องระดับ 2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2022"/>
        <source>Ctrl+2</source>
        <translation>Ctrl+2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2034"/>
        <source>Heading &amp;3</source>
        <translation>หัวเรื่อง &amp;3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2037"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Heading 3&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a level 3 heading.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;หัวเรื่อง 3&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;จัดรูปแบบย่อหน้าเป็นหัวเรื่องระดับ 3&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2042"/>
        <source>Ctrl+3</source>
        <translation>Ctrl+3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2054"/>
        <source>Heading &amp;4</source>
        <translation>หัวเรื่อง &amp;4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2057"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Heading 4&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a level 4 heading.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;หัวเรื่อง 4&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;จัดรูปแบบย่อหน้าเป็นหัวเรื่องระดับ 4&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2062"/>
        <source>Ctrl+4</source>
        <translation>Ctrl+4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2074"/>
        <source>Heading &amp;5</source>
        <translation>หัวเรื่อง &amp;5</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2077"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Heading 5&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a level 5 heading.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;หัวเรื่อง 5&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;จัดรูปแบบย่อหน้าเป็นหัวเรื่องระดับ 5&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2082"/>
        <source>Ctrl+5</source>
        <translation>Ctrl+5</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2094"/>
        <source>Heading &amp;6</source>
        <translation>หัวเรื่อง &amp;6</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2097"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Heading 6&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a level 6 heading.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;หัวเรื่อง 6&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;จัดรูปแบบย่อหน้าเป็นหัวเรื่องระดับ 6&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2102"/>
        <source>Ctrl+6</source>
        <translation>Ctrl+6</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2114"/>
        <source>&amp;Normal</source>
        <translation>ปรกติ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2117"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Paragraph&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a normal paragraph.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ย่อหน้า&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;จัดรูปแบบย่อหน้าเป็นย่อหน้าปกติ&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2122"/>
        <source>Ctrl+7</source>
        <translation>Ctrl+7</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2130"/>
        <source>&amp;Preserve Existing Attributes</source>
        <translation>เก็บแอตทริบิวต์ที่มีอยู่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2133"/>
        <source>When applying this style, preserve any existing attributes on the tag</source>
        <translation>เมื่อใช้สไตล์นี้ให้เก็บแอตทริบิวต์ที่มีอยู่ในแท็ก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2138"/>
        <source>Blank HTML File</source>
        <translation>ไฟล์ HTML ว่างเปล่า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2141"/>
        <source>Add a new blank HTML file to the book.</source>
        <translation>เพิ่มไฟล์ HTML ใหม่ที่ว่างเปล่าลงในหนังสือ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2150"/>
        <source>Existing Files...</source>
        <translation>ไฟล์ที่มีอยู่...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2153"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Add Existing Files&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Add files from your computer to the book.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;เพิ่มไฟล์ที่มีอยู่&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;เพิ่มไฟล์จากคอมพิวเตอร์ไปยังหนังสือ&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2160"/>
        <source>Blank Stylesheet</source>
        <translation>สไตล์ชีตว่างเปล่า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2163"/>
        <source>Add a new blank stylesheet to the book.</source>
        <translation>เพิ่มไฟล์สไตล์ชีตใหม่ที่ว่างเปล่าลงในหนังสือ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2168"/>
        <source>Blank SVG Image</source>
        <translation>รูปภาพ SVG ว่างเปล่า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2171"/>
        <source>Add a new blank svg image file to the book.</source>
        <translation>เพิ่มรูปภาพ SVG ใหม่ที่ว่างเปล่าลงในหนังสือ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2176"/>
        <source>Pre&amp;vious File</source>
        <translation>ไฟล์ก่อนหน้า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2179"/>
        <source>Open previous file of the same type.</source>
        <translation>เปิดไฟล์ก่อนหน้าประเภทเดียวกัน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2182"/>
        <source>Alt+PgUp</source>
        <translation>Alt+PgUp</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2187"/>
        <source>Next &amp;File</source>
        <translation>ไฟล์ถัดไป</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2190"/>
        <source>Open next file of the same type.</source>
        <translation>เปิดไฟล์ถัดไปประเภทเดียวกัน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2193"/>
        <source>Alt+PgDown</source>
        <translation>Alt+PgDown</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2198"/>
        <source>&amp;Add To Index Editor</source>
        <translation>เพิ่มไปยังตัวแก้ไขดัชนี</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2201"/>
        <source>Add the selected text to the Index Editor.</source>
        <translation>เพิ่มข้อความที่เลือกลงในตัวแก้ไขดัชนี</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2206"/>
        <source>&amp;Mark For Index</source>
        <translation>ทำเครื่องหมายสำหรับดัชนี</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2209"/>
        <source>Mark the selected text for inclusion in the Index.</source>
        <translation>ทำเครื่องหมายข้อความที่เลือกเพื่อรวมไว้ในดัชนี</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2212"/>
        <source>Ctrl+Shift+X</source>
        <translation>Ctrl+Shift+X</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2217"/>
        <source>&amp;Create Index</source>
        <translation>สร้างดัชนี</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2220"/>
        <source>Generate a new Index HTML file.</source>
        <translation>สร้างไฟล์ดัชนี HTML ใหม่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2225"/>
        <source>&amp;Create HTML Table Of Contents</source>
        <translation>สร้างสารบัญ HTML</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2228"/>
        <source>Create a new HTML file using the current TOC.</source>
        <translation>สร้างไฟล์ HTML ใหม่โดยใช้สารบัญปัจจุบัน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2233"/>
        <source>Book&amp;mark Location</source>
        <translation>บุ๊คมาร์คสถานที่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2236"/>
        <source>Ctrl+Alt+B</source>
        <translation>Ctrl+Alt+B</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2241"/>
        <source>&amp;Go To Link Or Style</source>
        <translation>ไปที่ลิงก์หรือสไตล์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2244"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2253"/>
        <source>&amp;Back</source>
        <translation>ย้อนกลับ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2256"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Back&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Go back to where you last went to a link or style, or bookmarked your location.&lt;/p&gt;
    </source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;ย้อนกลับ&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;กลับไปที่ตำแหน่งล่าสุดที่คุณไปที่ลิงก์หรือสไตล์หรือบุ๊กมาร์กตำแหน่งของคุณ&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2262"/>
        <source>Ctrl+\</source>
        <translation>Ctrl+\</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2267"/>
        <source>Edit/Paste From Clipboard &amp;History...</source>
        <translation>แก้ไข/วางจากประวัติคลิปบอร์ด...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2270"/>
        <source>Ctrl+Alt+V</source>
        <translation>Ctrl+Alt+V</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2275"/>
        <source>&amp;Delete Line</source>
        <translation>ลบบรรทัด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2278"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2283"/>
        <source>Manage Plugins</source>
        <translation>แก้ใขส่วนเสริม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2292"/>
        <source>Run Plugin 1</source>
        <translation>เรียกใช้ส่วนเสริม 1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2301"/>
        <source>Run Plugin 2</source>
        <translation>เรียกใช้ส่วนเสริม 2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2310"/>
        <source>Run Plugin 3</source>
        <translation>เรียกใช้ส่วนเสริม 3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2319"/>
        <source>Run Plugin 4</source>
        <translation>เรียกใช้ส่วนเสริม 4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2328"/>
        <source>Run Plugin 5</source>
        <translation>เรียกใช้ส่วนเสริม 5</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2333"/>
        <source>Mend and &amp;Prettify All HTML Files</source>
        <translation>แก้ไขและปรับแต่งไฟล์ HTML ทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2338"/>
        <source>&amp;Mend All HTML Files</source>
        <translation>แก้ไขไฟล์ HTML ทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2343"/>
        <source>&amp;Update Manifest Properties</source>
        <translation>อัพเดตสมบัติการอธิบาย</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2348"/>
        <source>Generate NC&amp;X from Nav</source>
        <translation>สร้าง NCX จาก Nav</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="325"/>
        <source>Input</source>
        <translation>นำเข้า</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="331"/>
        <source>Output</source>
        <translation>ส่งออก</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="343"/>
        <source>Validation</source>
        <translation>ตรวจสอบ</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="489"/>
        <source>Navigation cancelled as location no longer exists.</source>
        <translation>การนำทางถูกยกเลิกเนื่องจากไม่มีสถานที่อยู่อีกต่อไป</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="505"/>
        <source>Location bookmarked.</source>
        <translation>บุ๊กมาร์กตำแหน่งแล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="552"/>
        <location filename="../../MainUI/MainWindow.cpp" line="784"/>
        <location filename="../../MainUI/MainWindow.cpp" line="992"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1138"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1520"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1607"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1662"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1670"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1687"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1699"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1802"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1810"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1824"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1829"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1842"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1850"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1861"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1866"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1878"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1888"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1893"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2124"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2131"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2145"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2150"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2174"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2206"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3509"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3515"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3521"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3563"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3569"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3575"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3732"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3939"/>
        <location filename="../../MainUI/MainWindow.cpp" line="4139"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="552"/>
        <source>Are you sure you want to open this external link?

%1</source>
        <translation>คุณแน่ใจหรือไม่ว่าต้องการเปิดลิงก์ภายนอกนี้

%1</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="598"/>
        <source>was updated</source>
        <translation>อัปเดตแล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="605"/>
        <source>Warning</source>
        <translation>คำเตือน</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="605"/>
        <source>The file was NOT well formed and may be corrupted.</source>
        <translation>ไฟล์ดังกล่าวไม่ได้เกิดขึ้นและอาจเสียหาย</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="633"/>
        <source>Opening this EPUB generated warnings.</source>
        <translation>การเปิด EPUB นี้สร้างคำเตือนขึ้น</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="635"/>
        <source>Select Show Details for more information.</source>
        <translation>เลือกแสดงรายละเอียดเพื่อดูข้อมูลเพิ่มเติม</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="675"/>
        <source>Sigil is closing...</source>
        <translation>กำลังปิด Sigil...</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="725"/>
        <source>New file created.</source>
        <translation>ไฟล์ใหม่ถูกสร้าง</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="746"/>
        <source>Open File</source>
        <translation>เปิดไฟล์</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="783"/>
        <source>This file no longer exists. Click OK to remove it from the menu.
%1</source>
        <translation>ไฟล์นี้ไม่มีอยู่แล้ว คลิกตกลงเพื่อนำออกจากเมนู
%1</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="853"/>
        <source>Save File</source>
        <translation>บันทึกไฟล์</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="907"/>
        <source>Save a Copy</source>
        <translation>บันทึกสำเนา</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="969"/>
        <source>Go To Line</source>
        <translation>ไปยังบรรทัด</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="969"/>
        <source>Line #</source>
        <translation>บรรทัด #</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="992"/>
        <source>Image does not exist: </source>
        <translation>รูปภาพไม่มีอยู่:</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1054"/>
        <source>or</source>
        <translation>หรือ</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1062"/>
        <source>No CSS styles named</source>
        <translation>ไม่มีชื่อสไตล์ CSS</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1062"/>
        <source>found, or stylesheet not linked.</source>
        <translation>พบหรือสไตล์ชีสไม่ได้เชื่อมโยง</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1134"/>
        <source>&lt;html&gt;&lt;p&gt;The href &lt;b&gt;%1&lt;/b&gt; found in &lt;b&gt;%2&lt;/b&gt; does not exist (and there may be more). Splitting or merging under these conditions can result in broken links.&lt;/p&gt;&lt;p&gt;Do you still wish to continue?&lt;/p&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;p&gt;เชื่อมโยง href &lt;b&gt;%1&lt;/b&gt; ไม่พบ&lt;b&gt;%2&lt;/b&gt; ไม่มี (และอาจมีมากกว่านี้) การแบ่งหรือควบรวมภายใต้เงื่อนไขดังกล่าวอาจทำให้เกิดการเชื่อมโยงที่ไม่สมบูรณ์&lt;/p&gt;&lt;p&gt;คุณยังต้องการที่จะดำเนินการต่อหรือไม่?&lt;/p&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1156"/>
        <source>Add Cover</source>
        <translation>เพิ่มปก</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1248"/>
        <source>Unexpected error. Only image files can be used for the cover.</source>
        <translation>ข้อผิดพลาดที่ไม่คาดคิด เฉพาะไฟล์ภาพสามารถใช้สำหรับปก</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1265"/>
        <source>Cover added.</source>
        <translation>เพิ่มปกแล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1274"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1291"/>
        <source>Not Available for epub2.</source>
        <translation>ไม่สามารถใช้ได้สำหรับ EPUB2</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1282"/>
        <source>OPF Manifest Properties Updated.</source>
        <translation>คุณสมบัติ Manifest OPF อัปเดตแล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1308"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1362"/>
        <source>NCX generation failed.</source>
        <translation>สร้าง NCX ล้มเหลว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1357"/>
        <source>NCX generated.</source>
        <translation>สร้าง NCX</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1510"/>
        <source>Styles deleted.</source>
        <translation>ลบสไตล์แล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1520"/>
        <source>Reports cancelled due to XML not well formed.</source>
        <translation>รายงานถูกยกเลิกเนื่องจาก XML ไม่ได้สร้างอย่างถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1607"/>
        <source>Delete Unused Media Files cancelled due to XML not well formed.</source>
        <translation>ลบไฟล์มีเดียที่ไม่ได้ใช้ที่ยกเลิกไปเนื่องจาก XML ไม่ได้สร้างอย่างถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1660"/>
        <source>Unused media files deleted.</source>
        <translation>ลบไฟล์มีเดียที่ไม่ได้ใช้แล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1662"/>
        <source>There are no unused image, video or audio files to delete.</source>
        <translation>ไม่มีภาพวิดีโอหรือไฟล์เสียงที่ไม่ได้ใช้ที่ต้องลบ</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1670"/>
        <source>Delete Unused Styles cancelled due to XML not well formed.</source>
        <translation>ลบสไตล์ที่ไม่ได้ใช้ถูกยกเลิกเนื่องจาก XML ไม่ได้สร้างอย่างถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1687"/>
        <source>There are no unused stylesheet classes to delete.</source>
        <translation>ไม่มีชั้นสไตล์ชีตที่ไม่ได้ใช้ที่ต้องลบ</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1699"/>
        <source>You cannot insert a file at this position.</source>
        <translation>คุณไม่สามารถแทรกไฟล์ได้ที่ตำแหน่งนี้</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1706"/>
        <source>Insert File</source>
        <translation>แทรกไฟล์</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1751"/>
        <source>The file &quot;%1&quot; does not exist.</source>
        <translation>ไฟล์ &quot;%1&quot; ไม่มีอยู่</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1802"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1829"/>
        <source>You cannot insert an id at this position.</source>
        <translation>คุณไม่สามารถแทรกไอดีได้ที่ตำแหน่งนี้</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1810"/>
        <source>You must select text before inserting a new id.</source>
        <translation>คุณต้องเลือกข้อความก่อนที่จะใส่ไอดีใหม่</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1824"/>
        <source>ID is invalid - must start with a letter, followed by letter number _ : - or .</source>
        <translation>ไอดีไม่ถูกต้อง - ต้องขึ้นต้นด้วยตัวอักษรตามด้วยตัวอักษร _ : - หรือ .</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1842"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1866"/>
        <source>You cannot insert a link at this position.</source>
        <translation>คุณไม่สามารถแทรกเชื่อมโยงที่ตำแหน่งนี้ได้</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1850"/>
        <source>You must select text before inserting a new link.</source>
        <translation>คุณต้องเลือกข้อความก่อนที่จะใส่เชื่อมโยงใหม่</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1861"/>
        <source>Link is invalid - cannot contain &apos;&lt;&apos; or &apos;&gt;&apos;</source>
        <translation>การเชื่อมโยงไม่ถูกต้อง - ต้องไม่มี &apos;&lt;&apos; หรือ &apos;&gt;&apos;</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1878"/>
        <source>You cannot mark an index at this position or without selecting text.</source>
        <translation>ไม่สามารถทำเครื่องหมายดัชนีไว้ที่ตำแหน่งนี้หรือไม่เลือกข้อความ</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1888"/>
        <source>Entry is invalid - cannot contain &apos;&lt;&apos; or &apos;&gt;&apos;</source>
        <translation>รายการไม่ถูกต้อง - ต้องไม่มี &apos;&lt;&apos; หรือ &apos;&gt;&apos;</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1893"/>
        <source>You cannot mark an index at this position.</source>
        <translation>คุณไม่สามารถแทรกดัชนีได้ที่ตำแหน่งนี้</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1947"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1958"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2077"/>
        <source>Select the destination to paste into first.</source>
        <translation>เลือกปลายทางที่ต้องการวางไว้ก่อน</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1966"/>
        <source>Pasted clip entry %1.</source>
        <translation>วางรายการคลิป %1</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2124"/>
        <source>One resource selected and there is no previous resource to merge into.</source>
        <translation>ทรัพยากรที่เลือกและไม่มีทรัพยากรก่อนหน้านี้ที่จะรวมเข้าด้วยกัน</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2131"/>
        <source>Are you sure you want to merge the selected files?
This action cannot be reversed.</source>
        <translation>แน่ใจหรือไม่ว่าคุณต้องการรวมไฟล์ที่เลือกไว้?
การกระทำนี้ไม่สามารถย้อนกลับได้</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2145"/>
        <source>Merge cancelled: %1, XML not well formed.</source>
        <translation>การรวมถูกยกเลิก: %1, XML ไม่ได้สร้างอย่างถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2150"/>
        <source>Merge cancelled due to XML not well formed.</source>
        <translation>การรวมถูกยกเลิกเนื่องจาก XML ไม่ได้สร้างอย่างถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2174"/>
        <source>Cannot merge file %1</source>
        <translation>ไม่สามารถรวมไฟล์ %1</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2188"/>
        <source>Merge completed. You may need to regenerate or edit your Table Of Contents.</source>
        <translation>รวมเสร็จแล้ว คุณอาจต้องสร้างหรือแก้ไขสารบัญของคุณ</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2206"/>
        <source>Link Stylesheets cancelled: %1, XML not well formed.</source>
        <translation>การเชื่อมโยงสไตล์ซีสถูกยกเลิก:%1, XML ไม่ได้สร้างอย่างถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2351"/>
        <source>Word updated.</source>
        <translation>อัปเดตคำแล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2433"/>
        <source>File(s) deleted.</source>
        <translation>ลบไฟล์แล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2444"/>
        <source>Edit Table of Contents cancelled.</source>
        <translation>การแก้ไขสารบัญถูกยกเลิก</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2449"/>
        <source>Table Of Contents edited.</source>
        <translation>แก้ไขสารบัญแล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2467"/>
        <source>Generate TOC cancelled.</source>
        <translation>การสร้างสารบัญถูกยกเลิก</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2491"/>
        <source>Table Of Contents generated.</source>
        <translation>สร้างสารบัญแล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2493"/>
        <source>No Table Of Contents changes were necessary.</source>
        <translation>ไม่มีการเปลี่ยนแปลงในสารบัญ</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2629"/>
        <source>Text selection marked.</source>
        <translation>ข้อความที่เลือกทำเครื่องหมายไว้แล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2631"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2649"/>
        <source>Text selection unmarked.</source>
        <translation>ข้อความที่เลือกยกเลิกทำเครื่องหมายแล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2737"/>
        <source>Metadata Editor cancelled.</source>
        <translation>ตัวแก้ไขข้อมูลเมตาถูกยกเลิก</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2740"/>
        <source>Metadata edited.</source>
        <translation>ตัวแก้ไขข้อมูลเมตา</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2828"/>
        <source>RunPlugin1</source>
        <translation>เรียกใช้ส่วนเสริม 1</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2829"/>
        <source>RunPlugin2</source>
        <translation>เรียกใช้ส่วนเสริม 2</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2830"/>
        <source>RunPlugin3</source>
        <translation>เรียกใช้ส่วนเสริม 3</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2831"/>
        <source>RunPlugin4</source>
        <translation>เรียกใช้ส่วนเสริม 4</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2832"/>
        <source>RunPlugin5</source>
        <translation>เรียกใช้ส่วนเสริม 5</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2863"/>
        <source>This EPUB does not contain any CSS stylesheets to validate.</source>
        <translation>EPUB นี้ไม่มี CSS สไตล์ชีตเพื่อตรวจสอบความถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3410"/>
        <source>Line: %1, Col: %2</source>
        <translation>บรรทัด: %1, คอลัมน์: %2</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3509"/>
        <source>File cannot be split at this position.</source>
        <translation>ไม่สามารถแบ่งไฟล์ออกได้ที่ตำแหน่งนี้</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3515"/>
        <source>Cannot split since it may not be an HTML file.</source>
        <translation>ไม่สามารถแบ่งได้เนื่องจากอาจไม่ใช่ไฟล์ HTML</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3521"/>
        <source>The Nav file cannot be split.</source>
        <translation>ไม่สามารถแบ่งไฟล์ Nav ได้</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3538"/>
        <source>Split completed.</source>
        <translation>แบ่งสำเร็จ</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3563"/>
        <source>Cannot split since at least one file is not an HTML file.</source>
        <translation>ไม่สามารถแบ่งออกได้เนื่องจากไฟล์อย่างน้อยหนึ่งไฟล์ไม่ใช่ไฟล์ HTML</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3569"/>
        <source>Cannot split: %1 XML is not well formed</source>
        <translation>ไม่สามารถแยก: %1 XML ไม่ได้สร้างอย่างถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3575"/>
        <source>Cannot split since at least one file may not be an HTML file.</source>
        <translation>ไม่สามารถแบ่งได้เนื่องจากไฟล์อย่างน้อยหนึ่งไฟล์อาจไม่ใช่ไฟล์ HTML</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3608"/>
        <source>Split completed. You may need to update the Table of Contents.</source>
        <translation>แบ่งเสร็จแล้ว คุณอาจต้องแก้ไขสารบัญของคุณ</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3617"/>
        <source>No split file markers found. Use Insert-&gt;Split Marker.</source>
        <translation>ไม่พบเครื่องหมายไฟล์ที่แบ่ง ใช้ แทรก-&gt; เครื่องหมายแบ่ง</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3733"/>
        <source>The document has been modified.
Do you want to save your changes?</source>
        <translation>เอกสารได้ถูกแก้ไขแล้ว
ต้องการบันทึกการเปลี่ยนแปลงหรือไม่?</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3813"/>
        <source>No importer for file type: %1</source>
        <translation>ไม่มีตัวนำเข้าไฟล์ประเภทนี้: %1</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3820"/>
        <source>The following file was not loaded due to invalid content or not well formed XML:

%1 (line %2: %3)

Try setting the Clean Source preference to Mend XHTML Source Code on Open and reloading the file.</source>
        <translation>ไฟล์ต่อไปนี้ไม่ได้รับการโหลดเนื่องจากเนื้อหาไม่ถูกต้องหรือไม่ได้มีรูปแบบ XML::

%1 (บรรทัด %2: %3)

ลองตั้งค่าทำความสะอาดต้นฉบับเพื่อแก้ไขโค้ด XHTML เปิดและลองโหลดไฟล์ใหม่</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3825"/>
        <source>Loading file...</source>
        <translation>กำลังโหลดไฟล์...</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3839"/>
        <source>File loaded.</source>
        <translation>โหลดไฟล์แล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3866"/>
        <source>The creator of this file has encrypted it with DRM. Sigil cannot open such files.</source>
        <translation>ผู้สร้างไฟล์นี้ได้เข้ารหัสด้วย DRM Sigil ไม่สามารถเปิดไฟล์ดังกล่าวได้</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3873"/>
        <source>Cannot load EPUB: %1</source>
        <translation>ไม่สามารถ EPUB: %1</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3877"/>
        <source>Cannot load file %1: %2</source>
        <translation>ไม่สามารถไฟล์ %1: %2</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3906"/>
        <source>Saving EPUB...</source>
        <translation>กำลังบันทึก EPUB...</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3915"/>
        <source>Sigil cannot save files of type &quot;%1&quot;.
Please choose a different format.</source>
        <translation>Sigil ไม่สามารถบันทึกไฟล์ประเภท &quot;% 1&quot; 
โปรดเลือกรูปแบบอื่น</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3940"/>
        <source>This EPUB has HTML files that are not well formed and your current Clean Source preferences are set to automatically mend on Save. Saving a file that is not well formed will cause it to be automatically fixed, which very rarely may result in data loss.

Do you want to automatically mend the files before saving?</source>
        <translation>EPUB นี้มีไฟล์ HTML ที่ไม่ถูกต้องและการตั้งค่าความสะอาดต้นฉบับของคุณถูกตั้งค่าไว้เพื่อแก้ไขโดยอัตโนมัติในบันทึก การบันทึกไฟล์ที่ไม่ถูกต้องจะทำให้ไฟล์ถูกแก้ไขโดยอัตโนมัติ ซึ่งอาจทำให้ข้อมูลสูญหายเล็กน้อยได้

คุณต้องการแก้ไขไฟล์โดยอัตโนมัติก่อนทำการบันทึกหรือไม่?</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3971"/>
        <source>EPUB saved, but not all HTML files are well formed.</source>
        <translation>PUB ได้รับการบันทึกไว้ แต่ไฟล์ HTML บางส่วนไม่ถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3973"/>
        <source>EPUB saved.</source>
        <translation>บันทึก EPUB แล้ว</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3979"/>
        <source>Cannot save file %1: %2</source>
        <translation>ไม่สามารถไฟล์ %1: %2</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4114"/>
        <source>EPUB files (*.epub)</source>
        <translation>ไฟล์ EPUB  (*.epub)</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4115"/>
        <location filename="../../MainUI/MainWindow.cpp" line="4116"/>
        <location filename="../../MainUI/MainWindow.cpp" line="4117"/>
        <source>HTML files (*.htm *.html *.xhtml)</source>
        <translation>ไฟล์ HTML (*.htm *.html *.xhtml)</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4118"/>
        <source>Text files (*.txt)</source>
        <translation>ไฟล์ข้อความ (*.txt)</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4119"/>
        <source>All files (*.*)</source>
        <translation>ไฟล์ทั้งหมด  (*.*)</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4127"/>
        <source>EPUB file (*.epub)</source>
        <translation>ไฟล์ EPUB  (*.epub)</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4139"/>
        <source>%1[*] - epub%2 - %3</source>
        <translation>%1[*] - epub%2 - %3</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4210"/>
        <source>Preserve existing heading attributes is now:</source>
        <translation>รักษาคุณลักษณะส่วนหัวที่มีอยู่ตอนนี้:</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4211"/>
        <source>ON</source>
        <translation>เปิด</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4211"/>
        <source>OFF</source>
        <translation>ปิด</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4236"/>
        <source>&amp;%1 %2</source>
        <translation>&amp;%1 %2</translation>
    </message>
</context>
<context>
    <name>MarcRelators</name>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="111"/>
        <source>Abridger</source>
        <translation>Abridger</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="111"/>
        <source>A person, family, or organization contributing to a resource by shortening or condensing the original work but leaving the nature and content of the original work substantially unchanged. For substantial modifications that result in the creation of a new work, see Author.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่มีส่วนช่วยในการสร้างแหล่งที่มาโดยย่อหรือกลมกลืนงานต้นฉบับ แต่ปล่อยให้ลักษณะและเนื้อหาของงานต้นฉบับไม่เปลี่ยนแปลงอย่างมาก สำหรับการแก้ไขที่สำคัญซึ่งส่งผลให้เกิดการสร้างผลงานใหม่โปรดดูที่ผู้เขียน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="112"/>
        <source>Actor</source>
        <translation>Actor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="112"/>
        <source>Use for a person or organization who principally exhibits acting skills in a musical or dramatic presentation or entertainment.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีทักษะการแสดงดนตรีหรือการแสดงที่น่าทึ่ง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="113"/>
        <source>Adapter</source>
        <translation>Adapter</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="113"/>
        <source>Use for a person or organization who 1) reworks a musical composition, usually for a different medium, or 2) rewrites novels or stories for motion pictures or other audiovisual medium.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ 1) ปรับปรุงผลงานทางดนตรีโดยปกติสำหรับสื่อที่แตกต่างกันหรือ 2) เขียนนิยายหรือเรื่องราวสำหรับภาพเคลื่อนไหวหรือสื่อโสตทัศน์อื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="114"/>
        <source>Analyst</source>
        <translation>Analyst</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="114"/>
        <source>Use for a person or organization that reviews, examines and interprets data or information in a specific area.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ตรวจสอบตรวจสอบและตีความข้อมูลหรือข้อมูลในวงจำกัด</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="115"/>
        <source>Animator</source>
        <translation>Animator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="115"/>
        <source>Use for a person or organization who draws the two-dimensional figures, manipulates the three dimensional objects and/or also programs the computer to move objects and images for the purpose of animated film processing. Animation cameras, stands, celluloid screens, transparencies and inks are some of the tools of the animator.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ใช้ตัวเลขสองมิติจัดการวัตถุสามมิติและ / หรือโปรแกรมคอมพิวเตอร์เพื่อย้ายวัตถุและภาพเพื่อการประมวลผลภาพยนตร์แอนิเมชั่น กล้องภาพเคลื่อนไหว, ย่อมาจาก, หน้าจอเซลลูลอยด์, แผ่นใสและหมึกพิมพ์เป็นเครื่องมือบางอย่างของแอนนิเมเตอร์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="116"/>
        <source>Annotator</source>
        <translation>Annotator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="116"/>
        <source>Use for a person who writes manuscript annotations on a printed item.</source>
        <translation>ใช้สำหรับบุคคลที่เขียนบันทึกย่อของต้นฉบับบนรายการที่พิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="117"/>
        <source>Appellant</source>
        <translation>Appellant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="117"/>
        <source>A person or organization who appeals a lower court&apos;s decision.</source>
        <translation>บุคคลหรือองค์กรที่อุทธรณ์คำตัดสินของศาลล่าง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="118"/>
        <source>Appellee</source>
        <translation>Appellee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="118"/>
        <source>A person or organization against whom an appeal is taken.</source>
        <translation>บุคคลหรือองค์กรที่ถูกอุทธรณ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="119"/>
        <source>Applicant</source>
        <translation>Applicant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="119"/>
        <source>Use for a person or organization responsible for the submission of an application or who is named as eligible for the results of the processing of the application (e.g., bestowing of rights, reward, title, position).</source>
        <translation>การใช้งานสำหรับบุคคลหรือองค์กรที่รับผิดชอบในการส่งใบสมัคร หรือผู้ที่มีชื่อว่ามีสิทธิ์ได้รับผลของการดำเนินการในใบสมัคร (เช่นการให้สิทธิรางวัลรางวัลตำแหน่งตำแหน่ง)</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="120"/>
        <source>Architect</source>
        <translation>Architect</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="120"/>
        <source>Use for a person or organization who designs structures or oversees their construction.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ออกแบบโครงสร้างหรือดูแลงานก่อสร้างของตน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="121"/>
        <source>Arranger</source>
        <translation>Arranger</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="121"/>
        <source>Use for a person or organization who transcribes a musical composition, usually for a different medium from that of the original; in an arrangement the musical substance remains essentially unchanged.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ถอดความองค์ประกอบทางดนตรีโดยปกติเป็นสื่อที่แตกต่างจากต้นฉบับ ในการจัดเรียงเนื้อหาดนตรียังคงไม่เปลี่ยนแปลงเป็นหลัก</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="122"/>
        <source>Art copyist</source>
        <translation>Art copyist</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="122"/>
        <source>Use for a person (e.g., a painter or sculptor) who makes copies of works of visual art.</source>
        <translation>ใช้สำหรับบุคคล (เช่นจิตรกรหรือประติมากร) ที่ทำสำเนาผลงานศิลปะภาพ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="123"/>
        <source>Art director</source>
        <translation>Art director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="123"/>
        <source>A person contributing to a motion picture or television production by overseeing the artists and craftspeople who build the sets.</source>
        <translation>บุคคลที่มีส่วนร่วมในการผลิตภาพยนตร์หรือโทรทัศน์โดยดูแลศิลปินและช่างฝีมือที่สร้างชุด</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="124"/>
        <source>Artist</source>
        <translation>Artist</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="124"/>
        <source>Use for a person (e.g., a painter) or organization who conceives, and perhaps also implements, an original graphic design or work of art, if specific codes (e.g., [egr], [etr]) are not desired. For book illustrators, prefer Illustrator [ill]. </source>
        <translation>ใช้สำหรับบุคคล (เช่นจิตรกร) หรือองค์กรที่ตั้งครรภ์และอาจใช้การออกแบบกราฟิกหรือผลงานศิลปะดั้งเดิมหากไม่ต้องการใช้รหัสเฉพาะ (เช่น [egr], [etr]) สำหรับผู้วาดภาพประกอบหนังสือให้เลือก Illustrator [ill]</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="125"/>
        <source>Artistic director</source>
        <translation>Artistic director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="125"/>
        <source>Use for a person responsible for controlling the development of the artistic style of an entire production, including the choice of works to be presented and selection of senior production staff.</source>
        <translation>ใช้สำหรับบุคคลที่รับผิดชอบในการควบคุมการพัฒนารูปแบบศิลปะของการผลิต ทั้งหมดรวมถึงการเลือกผลงานที่จะนำเสนอและการเลือกพนักงานผลิตอาวุโส</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="126"/>
        <source>Assignee</source>
        <translation>Assignee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="126"/>
        <source>Use for a person or organization to whom a license for printing or publishing has been transferred.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีการโอนใบอนุญาตสำหรับการพิมพ์หรือเผยแพร่</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="127"/>
        <source>Associated name</source>
        <translation>Associated name</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="127"/>
        <source>Use for a person or organization associated with or found in an item or collection, which cannot be determined to be that of a Former owner [fmo] or other designated relator indicative of provenance.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เกี่ยวข้องหรือพบในรายการ หรือคอลเลคชันซึ่งไม่สามารถระบุได้ว่าเป็นของเจ้าของเดิม [fmo] หรือผู้ติดต่อที่ได้รับมอบหมายที่ระบุถึงแหล่งที่มา</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="128"/>
        <source>Attributed name</source>
        <translation>Attributed name</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="128"/>
        <source>Use for an author, artist, etc., relating him/her to a work for which there is or once was substantial authority for designating that person as author, creator, etc. of the work. </source>
        <translation>ใช้สำหรับผู้เขียนศิลปิน ฯลฯ ที่เกี่ยวข้องกับงานที่มีหรือเคยเป็นผู้มีอำนาจในการกำหนดบุคคลนั้นในฐานะผู้ประดิษฐ์ ฯลฯ ของผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="129"/>
        <source>Auctioneer</source>
        <translation>Auctioneer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="129"/>
        <source>Use for a person or organization in charge of the estimation and public auctioning of goods, particularly books, artistic works, etc.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการประมาณและการประมูลสินค้าโดยเฉพาะหนังสืองานศิลป์ ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="130"/>
        <source>Author</source>
        <translation>Author</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="130"/>
        <source>Use for a person or organization chiefly responsible for the intellectual or artistic content of a work, usually printed text. This term may also be used when more than one person or body bears such responsibility. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบส่วนใหญ่เกี่ยวกับเนื้อหาทางปัญญา หรือศิลปะของงานพิมพ์ที่พิมพ์บ่อยๆ คำนี้อาจใช้เมื่อมีบุคคลหรือร่างกายมากกว่าหนึ่งคนรับผิดชอบเช่นกัน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="131"/>
        <source>Author in quotations or text extracts</source>
        <translation>Author in quotations or text extracts</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="131"/>
        <source>Use for a person or organization whose work is largely quoted or extracted in works to which he or she did not contribute directly. Such quotations are found particularly in exhibition catalogs, collections of photographs, etc.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีการอ้างถึงผลงาน หรือได้รับการอ้างถึงในงานที่เขาหรือเธอไม่ได้ให้การสนับสนุนโดยตรง ใบเสนอราคาดังกล่าวถูกพบโดยเฉพาะอย่างยิ่งในแคตตาล็อกนิทรรศการคอลเลกชันของภาพ ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="132"/>
        <source>Author of afterword, colophon, etc.</source>
        <translation>Author of afterword, colophon, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="132"/>
        <source>Use for a person or organization responsible for an afterword, postface, colophon, etc. but who is not the chief author of a work.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบคำทับศัพท์ postface colophon ฯลฯ แต่ไม่ได้เป็นผู้เขียนหลักของงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="133"/>
        <source>Author of dialog</source>
        <translation>Author of dialog</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="133"/>
        <source>Use for a person or organization responsible for the dialog or spoken commentary for a screenplay or sound recording.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบบทสนทนาหรือคำพูดที่พูดสำหรับบทภาพยนตร์หรือการบันทึกเสียง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="134"/>
        <source>Author of introduction, etc.</source>
        <translation>Author of introduction, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="134"/>
        <source>Use for a person or organization responsible for an introduction, preface, foreword, or other critical introductory matter, but who is not the chief author.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีหน้าที่รับผิดชอบในการแนะนำบทนำคำนำหรือเรื่องแนะนำที่สำคัญอื่น ๆ แต่ผู้ที่ไม่ใช่หัวหน้าผู้เขียน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="135"/>
        <source>Author of screenplay, etc.</source>
        <translation>Author of screenplay, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="135"/>
        <source>Use for a person or organization responsible for a motion picture screenplay, dialog, spoken commentary, etc.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบบทภาพยนตร์คำพูดคำบรรยาย ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="136"/>
        <source>Autographer</source>
        <translation>Autographer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="136"/>
        <source>A person whose manuscript signature appears on an item.</source>
        <translation>บุคคลที่มีลายเซ็นต้นฉบับปรากฏอยู่ในรายการ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="137"/>
        <source>Bibliographic antecedent</source>
        <translation>Bibliographic antecedent</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="137"/>
        <source>Use for a person or organization responsible for a work upon which the work represented by the catalog record is based. This may be appropriate for adaptations, sequels, continuations, indexes, etc.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการทำงานที่งานนี้เป็นตัวแทนจากรายการสินค้า ซึ่งอาจเหมาะสมกับการดัดแปลงต่อเนื่องความต่อเนื่องดัชนี ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="138"/>
        <source>Binder</source>
        <translation>Binder</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="138"/>
        <source>Use for a person or organization responsible for the binding of printed or manuscript materials.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบการพิมพ์เอกสารหรือสิ่งพิมพ์ต้นฉบับ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="139"/>
        <source>Binding designer</source>
        <translation>Binding designer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="139"/>
        <source>Use for a person or organization responsible for the binding design of a book, including the type of binding, the type of materials used, and any decorative aspects of the binding. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการออกแบบปกหนังสือ รวมถึงประเภทของการผูกชนิดของวัสดุที่ใช้และด้านตกแต่งใด ๆ ที่มีผลผูกพัน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="140"/>
        <source>Blurb writer</source>
        <translation>Blurb writer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="140"/>
        <source>A person or organization responsible for writing a commendation or testimonial for a work, which appears on or within the publication itself, frequently on the back or dust jacket of print publications or on advertising material for all media.</source>
        <translation>บุคคลหรือองค์กรที่รับผิดชอบในการเขียนคำชมเชย หรือคำรับรองสำหรับงานซึ่งปรากฏอยู่ในหรือภายในสิ่งพิมพ์นั้นบ่อยครั้งที่ด้านหลัง หรือปกของสิ่งพิมพ์หรือวัสดุโฆษณาสำหรับสื่อทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="141"/>
        <source>Book designer</source>
        <translation>Book designer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="141"/>
        <source>Use for a person or organization responsible for the entire graphic design of a book, including arrangement of type and illustration, choice of materials, and process used. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบการออกแบบกราฟิกทั้งหมดของหนังสือ รวมถึงการจัดเรียงประเภทและภาพประกอบการเลือกใช้วัสดุและกระบวนการที่ใช้</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="142"/>
        <source>Book producer</source>
        <translation>Book producer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="142"/>
        <source>Use for a person or organization responsible for the production of books and other print media, if specific codes (e.g., [bkd], [egr], [tyd], [prt]) are not desired. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการผลิตหนังสือและสื่อสิ่งพิมพ์อื่น ๆ หากไม่ต้องการใช้รหัสเฉพาะ (เช่น [bkd], [egr], [tyd], [prt])</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="143"/>
        <source>Bookjacket designer</source>
        <translation>Bookjacket designer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="143"/>
        <source>Use for a person or organization responsible for the design of flexible covers designed for or published with a book, including the type of materials used, and any decorative aspects of the bookjacket. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการออกแบบปกแบบยืดหยุ่น ที่ออกแบบมาสำหรับหรือเผยแพร่พร้อมกับหนังสือรวมทั้งประเภทของวัสดุ ที่ใช้และด้านตกแต่งใด ๆ ของชุดหนังสือ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="144"/>
        <source>Bookplate designer</source>
        <translation>Bookplate designer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="144"/>
        <source>Use for a person or organization responsible for the design of a book owner&apos;s identification label that is most commonly pasted to the inside front cover of a book. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการออกแบบฉลาก ระบุเจ้าของหนังสือที่วางไว้ส่วนใหญ่ไปยังหน้าปกด้านในของหนังสือ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="145"/>
        <source>Bookseller</source>
        <translation>Bookseller</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="145"/>
        <source>Use for a person or organization who makes books and other bibliographic materials available for purchase. Interest in the materials is primarily lucrative.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ทำให้หนังสือและเอกสารทางบรรณานุกรมอื่น ๆ สามารถซื้อได้ ความสนใจในวัสดุที่เป็นประโยชน์หลัก</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="146"/>
        <source>Braille embosser</source>
        <translation>Braille embosser</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="146"/>
        <source>A person, family, or organization involved in manufacturing a resource by embossing Braille cells using a stylus, special embossing printer, or other device.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่เกี่ยวข้องกับการผลิตทรัพยากรโดยการแกะสลักเซลล์อักษรเบรลล์ โดยใช้สไตลัสเครื่องพิมพ์นูนพิเศษหรืออุปกรณ์อื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="147"/>
        <source>Broadcaster</source>
        <translation>Broadcaster</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="147"/>
        <source>A person, family, or organization involved in broadcasting a resource to an audience via radio, television, webcast, etc.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่เกี่ยวข้องในการเผยแพร่แหล่งข้อมูลให้กับผู้ชมทางวิทยุ โทรทัศน์ การออกอากาศ ทางเว็บ ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="148"/>
        <source>Calligrapher</source>
        <translation>Calligrapher</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="148"/>
        <source>Use for a person or organization who writes in an artistic hand, usually as a copyist and or engrosser.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เขียนด้วยมือศิลปะโดยปกติจะเป็นผู้คัดลอกและหรือนักลงทุน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="149"/>
        <source>Cartographer</source>
        <translation>Cartographer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="149"/>
        <source>Use for a person or organization responsible for the creation of maps and other cartographic materials.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการสร้างแผนที่และวัสดุการพิมพ์อื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="150"/>
        <source>Caster</source>
        <translation>Caster</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="150"/>
        <source>A person, family, or organization involved in manufacturing a resource by pouring a liquid or molten substance into a mold and leaving it to solidify to take the shape of the mold.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่เกี่ยวข้องในการผลิตทรัพยากรด้วยการเทสาร ที่เป็นของเหลวหรือหลอมเหลวลงในแม่พิมพ์และ ปล่อยให้แข็งตัวเพื่อให้ได้รูปร่างของแม่พิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="151"/>
        <source>Censor</source>
        <translation>Censor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="151"/>
        <source>Use for a censor, bowdlerizer, expurgator, etc., official or private. </source>
        <translation>ใช้สำหรับการเซ็นเซอร์, bowdlerizer, expurgator ฯลฯ อย่างเป็นทางการหรือส่วนตัว</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="152"/>
        <source>Choreographer</source>
        <translation>Choreographer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="152"/>
        <source>Use for a person or organization who composes or arranges dances or other movements (e.g., &quot;master of swords&quot;) for a musical or dramatic presentation or entertainment.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ประกอบขึ้นหรือจัดเตรียมการเต้นรำหรือการเคลื่อนไหวอื่น ๆ (เช่น &quot;ต้นแบบของดาบ&quot;) เพื่อนำเสนอหรือนำเสนอดนตรีหรือการแสดงที่น่าทึ่ง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="153"/>
        <source>Cinematographer</source>
        <translation>Cinematographer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="153"/>
        <source>Use for a person or organization who is in charge of the images captured for a motion picture film. The cinematographer works under the supervision of a director, and may also be referred to as director of photography. Do not confuse with videographer.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบภาพที่ถ่ายสำหรับภาพยนตร์ภาพเคลื่อนไหว การถ่ายทำภาพยนตร์ทำงานภายใต้การกำกับดูแลของผู้กำกับและอาจเรียกว่าผู้กำกับภาพ ไม่สับสนกับ videographer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="154"/>
        <source>Client</source>
        <translation>Client</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="154"/>
        <source>Use for a person or organization for whom another person or organization is acting.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่บุคคลหรือองค์กรอื่นทำหน้าที่</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="155"/>
        <source>Collection registrar</source>
        <translation>Collection registrar</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="155"/>
        <source>A curator who lists or inventories the items in an aggregate work such as a collection of items or works.</source>
        <translation>ภัณฑารักษ์ที่แสดงรายการหรือสะสมสิ่งของในงานรวมเช่นชุดของรายการหรือผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="156"/>
        <source>Collector</source>
        <translation>Collector</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="156"/>
        <source>Use for a person or organization who has brought together material from various sources that has been arranged, described, and cataloged as a collection. A collector is neither the creator of the material nor a person to whom manuscripts in the collection may have been addressed.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รวบรวมเนื้อหาจากแหล่งต่างๆที่ได้รับการจัดอธิบายและจัดทำเป็นชุดเก็บรวบรวม นักสะสมไม่ได้เป็นผู้สร้างเนื้อหาหรือบุคคลที่อาจเขียนต้นฉบับในชุดเก็บรวบรวม</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="157"/>
        <source>Collotyper</source>
        <translation>Collotyper</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="157"/>
        <source>Use for a person or organization responsible for the production of photographic prints from film or other colloid that has ink-receptive and ink-repellent surfaces.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการผลิตภาพพิมพ์จากฟิล์ม หรือคอลลอยด์อื่นที่มีพื้นผิวที่รับหมึกและไม่ติดหมึก</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="158"/>
        <source>Colorist</source>
        <translation>Colorist</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="158"/>
        <source>A person or organization responsible for applying color to drawings, prints, photographs, maps, moving images, etc.</source>
        <translation>บุคคลหรือองค์กรที่รับผิดชอบในการใช้สีกับภาพวาดภาพพิมพ์ภาพแผนที่ภาพเคลื่อนไหวภาพ ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="159"/>
        <source>Commentator</source>
        <translation>Commentator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="159"/>
        <source>Use for a person or organization who provides interpretation, analysis, or a discussion of the subject matter on a recording, motion picture, or other audiovisual medium.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ให้การตีความการวิเคราะห์ หรือการอภิปรายเรื่องเกี่ยวกับการบันทึกภาพเคลื่อนไหว หรือสื่อโสตทัศน์อื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="160"/>
        <source>Commentator for written text</source>
        <translation>Commentator for written text</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="160"/>
        <source>Use for a person or organization responsible for the commentary or explanatory notes about a text. For the writer of manuscript annotations in a printed book, use Annotator [ann].</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบคำอธิบาย หรือคำอธิบายเกี่ยวกับข้อความ สำหรับผู้เขียนบันทึกย่อต้นฉบับในหนังสือที่พิมพ์ให้ใช้ Annotator [ann]</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="161"/>
        <source>Compiler</source>
        <translation>Compiler</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="161"/>
        <source>Use for a person or organization who produces a work or publication by selecting and putting together material from the works of various persons or bodies.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ผลิตงาน หรือสิ่งตีพิมพ์โดยเลือกและรวบรวมวัสดุจากผลงานของบุคคลหรือหน่วยงานต่างๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="162"/>
        <source>Complainant</source>
        <translation>Complainant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="162"/>
        <source>Use for the party who applies to the courts for redress, usually in an equity proceeding.</source>
        <translation>ใช้สำหรับฝ่ายที่ให้คำตอบต่อศาลตามคำร้องขอให้ชดใช้ซึ่งโดยปกติแล้วจะดำเนินการในส่วนได้เสีย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="163"/>
        <source>Complainant-appellant</source>
        <translation>Complainant-appellant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="163"/>
        <source>Use for a complainant who takes an appeal from one court or jurisdiction to another to reverse the judgment, usually in an equity proceeding.</source>
        <translation>ใช้สำหรับผู้ถูกร้องเรียนที่อุทธรณ์จากศาล หรือเขตอำนาจศาลหนึ่งแห่งต่ออีกศาลหนึ่งเพื่อคัดค้านการตัดสิน โดยปกติในการดำเนินการเกี่ยวกับทุน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="164"/>
        <source>Complainant-appellee</source>
        <translation>Complainant-appellee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="164"/>
        <source>Use for a complainant against whom an appeal is taken from one court or jurisdiction to another to reverse the judgment, usually in an equity proceeding.</source>
        <translation>ใช้สำหรับผู้ร้องเรียนต่อผู้ที่อุทธรณ์ถูกนำตัวจากศาล หรือเขตอำนาจศาลหนึ่งไปยังอีกฝ่ายหนึ่งเพื่อคัดค้านการตัดสิน โดยปกติในการดำเนินการเกี่ยวกับทุน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="165"/>
        <source>Composer</source>
        <translation>Composer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="165"/>
        <source>Use for a person or organization who creates a musical work, usually a piece of music in manuscript or printed form.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่สร้างผลงานทางดนตรีโดยปกติจะเป็น เพลงในรูปแบบตัวต่อตัวหรือแบบพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="166"/>
        <source>Compositor</source>
        <translation>Compositor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="166"/>
        <source>Use for a person or organization responsible for the creation of metal slug, or molds made of other materials, used to produce the text and images in printed matter. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการสร้างกระสุนโลหะ หรือแม่พิมพ์ที่ทำจากวัสดุอื่น ๆ ที่ใช้ในการผลิตข้อความและภาพในสิ่งพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="167"/>
        <source>Conceptor</source>
        <translation>Conceptor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="167"/>
        <source>Use for a person or organization responsible for the original idea on which a work is based, this includes the scientific author of an audio-visual item and the conceptor of an advertisement.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบต่อแนวคิดเดิมที่เป็นผลงาน ซึ่งรวมถึงผู้เขียนทางวิทยาศาสตร์ของรายการภาพ และเสียงและแนวความคิดในการโฆษณา</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="168"/>
        <source>Conductor</source>
        <translation>Conductor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="168"/>
        <source>Use for a person who directs a performing group (orchestra, chorus, opera, etc.) in a musical or dramatic presentation or entertainment.</source>
        <translation>ใช้สำหรับผู้ที่นำแสดงกลุ่มที่มีประสิทธิภาพ (ออร์เคสตรานักร้องโอเปร่า ฯลฯ ) ในการนำเสนอดนตรีหรือละครหรือความบันเทิง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="169"/>
        <source>Conservator</source>
        <translation>Conservator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="169"/>
        <source>A person or organization responsible for documenting, preserving, or treating printed or manuscript material, works of art, artifacts, or other media.</source>
        <translation>บุคคลหรือองค์กรที่รับผิดชอบในการจัดทำเอกสารการเก็บรักษา หรือการจัดการงานพิมพ์หรืองานเขียนด้วยลายมืองานศิลปะสิ่งประดิษฐ์หรือสื่ออื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="170"/>
        <source>Consultant</source>
        <translation>Consultant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="170"/>
        <source>Use for a person or organization relevant to a resource, who is called upon for professional advice or services in a specialized field of knowledge or training.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เกี่ยวข้องกับทรัพยากรผู้ซึ่งได้รับการเรียกหา คำแนะนำหรือบริการระดับมืออาชีพในสาขาความรู้เฉพาะทางหรือการฝึกอบรม</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="171"/>
        <source>Consultant to a project</source>
        <translation>Consultant to a project</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="171"/>
        <source>Use for a person or organization relevant to a resource, who is engaged specifically to provide an intellectual overview of a strategic or operational task and by analysis, specification, or instruction, to create or propose a cost-effective course of action or solution.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เกี่ยวข้องกับทรัพยากรที่มีส่วนร่วม เพื่อให้ภาพรวมทางปัญญาของงานเชิงกลยุทธ์ หรือการดำเนินงานและโดยการวิเคราะห์ข้อกำหนดหรือคำแนะนำ เพื่อสร้างหรือเสนอแนวทาง หรือการแก้ปัญหาอย่างคุ้มค่า</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="172"/>
        <source>Contestant</source>
        <translation>Contestant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="172"/>
        <source>Use for the party who opposes, resists, or disputes, in a court of law, a claim, decision, result, etc.</source>
        <translation>ใช้สำหรับฝ่ายที่คัดค้านต่อต้านหรือข้อพิพาทในชั้นศาลข้อเรียกร้องการตัดสินใจผล ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="173"/>
        <source>Contestant-appellant</source>
        <translation>Contestant-appellant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="173"/>
        <source>Use for a contestant who takes an appeal from one court of law or jurisdiction to another to reverse the judgment.</source>
        <translation>ใช้สำหรับผู้เข้าประกวดที่อุทธรณ์จากศาลยุติธรรมหนึ่งศาล หรือเขตอำนาจศาลอื่นเพื่อแย่งชิงคำตัดสิน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="174"/>
        <source>Contestant-appellee</source>
        <translation>Contestant-appellee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="174"/>
        <source>Use for a contestant against whom an appeal is taken from one court of law or jurisdiction to another to reverse the judgment.</source>
        <translation>ใช้สำหรับผู้แข่งขันที่มีการยื่นอุทธรณ์จากศาล หรือเขตอำนาจศาลหนึ่งแห่งไปยังอีกศาลหนึ่ง เพื่อคัดค้านการตัดสิน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="175"/>
        <source>Contestee</source>
        <translation>Contestee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="175"/>
        <source>Use for the party defending a claim, decision, result, etc. being opposed, resisted, or disputed in a court of law.</source>
        <translation>ใช้สำหรับฝ่ายปกป้องการเรียกร้องการตัดสินผล ฯลฯ ถูกต่อต้านคัดค้านหรือโต้แย้งในกฏหมาย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="176"/>
        <source>Contestee-appellant</source>
        <translation>Contestee-appellant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="176"/>
        <source>Use for a contestee who takes an appeal from one court or jurisdiction to another to reverse the judgment.</source>
        <translation>ใช้สำหรับผู้เข้าประกวดที่อุทธรณ์จากศาล หรือเขตอำนาจศาลหนึ่งไปยังอีกศาลหนึ่งเพื่อกลับคำตัดสิน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="177"/>
        <source>Contestee-appellee</source>
        <translation>Contestee-appellee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="177"/>
        <source>Use for a contestee against whom an appeal is taken from one court or jurisdiction to another to reverse the judgment.</source>
        <translation>ใช้สำหรับผู้เข้าประกวดที่มีการอุทธรณ์คำตัดสินจากศาล หรือเขตอำนาจศาลหนึ่งแห่งต่อศาลอื่นเพื่อคัดค้านการตัดสิน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="178"/>
        <source>Contractor</source>
        <translation>Contractor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="178"/>
        <source>Use for a person or organization relevant to a resource, who enters into a contract with another person or organization to perform a specific task.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เกี่ยวข้องกับทรัพยากรที่ทำสัญญากับบุคคลหรือองค์กรอื่นเพื่อดำเนินงานเฉพาะ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="179"/>
        <source>Contributor</source>
        <translation>Contributor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="179"/>
        <source>Use for a person or organization one whose work has been contributed to a larger work, such as an anthology, serial publication, or other compilation of individual works. Do not use if the sole function in relation to a work is as author, editor, compiler or translator.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีผลงานเป็นจำนวนมากเช่นงานกวีนิพนธ์การพิมพ์แบบอนุกรมหรือการรวบรวมงานบุคคลอื่น ๆ อย่าใช้ถ้าฟังก์ชัน แต่เพียงผู้เดียวที่เกี่ยวข้องกับงานเป็นผู้แต่งผู้เรียบเรียงเรียบเรียงหรือแปลภาษา</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="180"/>
        <source>Copyright claimant</source>
        <translation>Copyright claimant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="180"/>
        <source>Use for a person or organization listed as a copyright owner at the time of registration. Copyright can be granted or later transferred to another person or organization, at which time the claimant becomes the copyright holder.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ระบุว่าเป็นเจ้าของลิขสิทธิ์ในขณะที่ลงทะเบียน ลิขสิทธิ์สามารถได้รับหรือโอนไปยังบุคคลหรือองค์กรอื่นในภายหลัง ในขณะที่ผู้อ้างสิทธิ์เป็นผู้ถือลิขสิทธิ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="181"/>
        <source>Copyright holder</source>
        <translation>Copyright holder</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="181"/>
        <source>Use for a person or organization to whom copy and legal rights have been granted or transferred for the intellectual content of a work. The copyright holder, although not necessarily the creator of the work, usually has the exclusive right to benefit financially from the sale and use of the work to which the associated copyright protection applies.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่คัดลอกและได้รับสิทธิ์ตามกฎหมาย หรือโอนกรรมสิทธิ์สำหรับเนื้อหาทางปัญญาของผลงาน ผู้ถือลิขสิทธิ์แม้ว่าจะไม่จำเป็นต้องเป็นผู้สร้างผลงาน แต่ก็มักจะมีสิทธิ์ในการได้รับผลประโยชน์ทางการเงินจากการขาย และการใช้งานซึ่งมีการคุ้มครองลิขสิทธิ์ที่เกี่ยวข้อง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="182"/>
        <source>Corrector</source>
        <translation>Corrector</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="182"/>
        <source>Use for a person or organization who is a corrector of manuscripts, such as the scriptorium official who corrected the work of a scribe. For printed matter, use Proofreader.</source>
        <translation>ช้สำหรับบุคคลหรือองค์กรที่เป็นผู้เรียบเรียงต้นฉบับเช่นเจ้าหน้าที่ของ scriptorium ที่แก้ไขการทำงานของอาลักษณ์ สำหรับสิ่งพิมพ์ให้ใช้เครื่องพิสูจน์อักษร</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="183"/>
        <source>Correspondent</source>
        <translation>Correspondent</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="183"/>
        <source>Use for a person or organization who was either the writer or recipient of a letter or other communication.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เป็นนักเขียนหรือผู้รับจดหมายหรือการสื่อสารอื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="184"/>
        <source>Costume designer</source>
        <translation>Costume designer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="184"/>
        <source>Use for a person or organization who designs or makes costumes, fixes hair, etc., for a musical or dramatic presentation or entertainment.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ออกแบบหรือแต่งกายแต่งหน้าทำผม ฯลฯ เพื่อนำเสนอหรือนำเสนอดนตรีหรือละคร</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="185"/>
        <source>Court governed</source>
        <translation>Court governed</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="185"/>
        <source>A court governed by court rules, regardless of their official nature (e.g., laws, administrative regulations.)</source>
        <translation>ศาลที่ควบคุมโดยกฎของศาลโดยไม่คำนึงถึงลักษณะอย่างเป็นทางการ (เช่นกฎหมายกฎระเบียบด้านการบริหาร)</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="186"/>
        <source>Court reporter</source>
        <translation>Court reporter</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="186"/>
        <source>A person, family, or organization contributing to a resource by preparing a court&apos;s opinions for publication.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่มีส่วนร่วมในทรัพยากรโดยการจัดทำข้อคิดเห็นของศาลในการตีพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="187"/>
        <source>Cover designer</source>
        <translation>Cover designer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="187"/>
        <source>Use for a person or organization responsible for the graphic design of a book cover, album cover, slipcase, box, container, etc. For a person or organization responsible for the graphic design of an entire book, use Book designer; for book jackets, use Bookjacket designer.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบการออกแบบกราฟิกปกหนังสือปกอัลบั้มปกกล่องกล่องเก็บ ฯลฯ สำหรับบุคคลหรือองค์กรที่รับผิดชอบการออกแบบกราฟิกของหนังสือทั้งเล่มให้ใช้นักออกแบบหนังสือ สำหรับเสื้อแจ็คเก็ตหนังสือให้ใช้นักออกแบบ Bookjacket</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="188"/>
        <source>Creator</source>
        <translation>Creator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="188"/>
        <source>Use for a person or organization responsible for the intellectual or artistic content of a work.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบเนื้อหาทางปัญญาหรือศิลปะของผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="189"/>
        <source>Curator of an exhibition</source>
        <translation>Curator of an exhibition</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="189"/>
        <source>Use for a person or organization responsible for conceiving and organizing an exhibition.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการจัดระเบียบการจัดนิทรรศการ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="190"/>
        <source>Dancer</source>
        <translation>Dancer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="190"/>
        <source>Use for a person or organization who principally exhibits dancing skills in a musical or dramatic presentation or entertainment.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีทักษะการเต้นเป็นหลักในการนำเสนอหรือความบันเทิงด้านดนตรีหรือละคร</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="191"/>
        <source>Data contributor</source>
        <translation>Data contributor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="191"/>
        <source>Use for a person or organization that submits data for inclusion in a database or other collection of data.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ส่งข้อมูลเพื่อรวมไว้ในฐานข้อมูลหรือข้อมูลอื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="192"/>
        <source>Data manager</source>
        <translation>Data manager</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="192"/>
        <source>Use for a person or organization responsible for managing databases or other data sources.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการจัดการฐานข้อมูลหรือแหล่งข้อมูลอื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="193"/>
        <source>Dedicatee</source>
        <translation>Dedicatee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="193"/>
        <source>Use for a person or organization to whom a book, manuscript, etc., is dedicated (not the recipient of a gift).</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีหนังสือหนังสือต้นฉบับเป็นต้น (ไม่ใช่ผู้รับของขวัญ)</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="194"/>
        <source>Dedicator</source>
        <translation>Dedicator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="194"/>
        <source>Use for the author of a dedication, which may be a formal statement or in epistolary or verse form.</source>
        <translation>ใช้สำหรับผู้เขียนอุทิศซึ่งอาจเป็นคำสั่งอย่างเป็นทางการหรือในรูปแบบจดหมายหรือบทกวี</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="195"/>
        <source>Defendant</source>
        <translation>Defendant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="195"/>
        <source>Use for the party defending or denying allegations made in a suit and against whom relief or recovery is sought in the courts, usually in a legal action.</source>
        <translation>ใช้สำหรับบุคคลที่ปกป้องหรือปฏิเสธข้อกล่าวหาที่กระทำขึ้นในคดีอาญา และต่อหน้าผู้ที่ได้รับการบรรเทาทุกข์ หรือการกู้คืนในศาลโดยปกติจะอยู่ในระหว่างการดำเนินคดี</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="196"/>
        <source>Defendant-appellant</source>
        <translation>Defendant-appellant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="196"/>
        <source>Use for a defendant who takes an appeal from one court or jurisdiction to another to reverse the judgment, usually in a legal action.</source>
        <translation>ใช้สำหรับจำเลยที่อุทธรณ์จากศาลหรือเขตอำนาจศาลหนึ่งไปยังอีกศาลหนึ่ง เพื่อคัดค้านคำตัดสินโดยปกติจะอยู่ในระหว่างการดำเนินคดี</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="197"/>
        <source>Defendant-appellee</source>
        <translation>Defendant-appellee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="197"/>
        <source>Use for a defendant against whom an appeal is taken from one court or jurisdiction to another to reverse the judgment, usually in a legal action.</source>
        <translation>ใช้สำหรับจำเลยที่อุทธรณ์ถูกนำออกจากศาลหรือเขตอำนาจศาลหนึ่งไปยังอีกศาลหนึ่ง เพื่อกลับคำพิพากษาโดยปกติจะอยู่ในระหว่างการดำเนินคดี</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="198"/>
        <source>Degree grantor</source>
        <translation>Degree grantor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="198"/>
        <source>Use for the organization granting a degree for which the thesis or dissertation described was presented.</source>
        <translation>ใช้สำหรับองค์กรที่มอบปริญญาที่เสนอวิทยานิพนธ์หรือวิทยานิพนธ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="199"/>
        <source>Delineator</source>
        <translation>Delineator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="199"/>
        <source>Use for a person or organization executing technical drawings from others&apos; designs.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ใช้ภาพวาดทางเทคนิคจากการออกแบบของผู้อื่น</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="200"/>
        <source>Depicted</source>
        <translation>Depicted</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="200"/>
        <source>Use for an entity depicted or portrayed in a work, particularly in a work of art.</source>
        <translation>ใช้สำหรับเอนทิตีที่วาดภาพหรือแสดงในผลงานโดยเฉพาะในผลงานศิลปะ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="201"/>
        <source>Depositor</source>
        <translation>Depositor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="201"/>
        <source>Use for a person or organization placing material in the physical custody of a library or repository without transferring the legal title.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่วางเนื้อหาในการดูแลด้านกายภาพของห้องสมุด หรือพื้นที่เก็บข้อมูลโดยไม่ต้องโอนชื่อตามกฎหมาย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="202"/>
        <source>Designer</source>
        <translation>Designer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="202"/>
        <source>Use for a person or organization responsible for the design if more specific codes (e.g., [bkd], [tyd]) are not desired.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบการออกแบบหากไม่ต้องการใช้รหัสเฉพาะเจาะจงมากขึ้น (เช่น [bkd], [tyd])</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="203"/>
        <source>Director</source>
        <translation>Director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="203"/>
        <source>Use for a person or organization who is responsible for the general management of a work or who supervises the production of a performance for stage, screen, or sound recording.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีหน้าที่รับผิดชอบในการจัดการทั่วไปของงาน หรือผู้กำกับดูแลการสร้างผลการปฏิบัติงานสำหรับการจัดเวทีการบันทึกเสียง หรือการบันทึกเสียง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="204"/>
        <source>Dissertant</source>
        <translation>Dissertant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="204"/>
        <source>Use for a person who presents a thesis for a university or higher-level educational degree.</source>
        <translation>ใช้สำหรับผู้ที่เสนอวิทยานิพนธ์สำหรับมหาวิทยาลัยหรือระดับการศึกษาระดับสูงขึ้น</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="205"/>
        <source>Distribution place</source>
        <translation>Distribution place</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="205"/>
        <source>A place from which a resource, e.g., a serial, is distributed.</source>
        <translation>เป็นสถานที่ซึ่งเป็นทรัพยากรเช่นซีเรียล, มีการกระจาย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="206"/>
        <source>Distributor</source>
        <translation>Distributor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="206"/>
        <source>Use for a person or organization that has exclusive or shared marketing rights for an item.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีสิทธิด้านการตลาดเฉพาะหรือแชร์สำหรับรายการ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="207"/>
        <source>Donor</source>
        <translation>Donor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="207"/>
        <source>Use for a person or organization who is the donor of a book, manuscript, etc., to its present owner. Donors to previous owners are designated as Former owner [fmo] or Inscriber [ins].</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เป็นผู้บริจาคหนังสือต้นฉบับ ฯลฯ ให้แก่เจ้าของปัจจุบัน ผู้บริจาคให้กับเจ้าของเดิมจะได้รับมอบหมายให้เป็นเจ้าของเดิม [fmo] หรือ Inscriber [ins]</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="208"/>
        <source>Draftsman</source>
        <translation>Draftsman</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="208"/>
        <source>Use for a person or organization who prepares artistic or technical drawings. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เตรียมภาพวาดทางศิลปะหรือทางเทคนิค</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="209"/>
        <source>Dubious author</source>
        <translation>Dubious author</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="209"/>
        <source>Use for a person or organization to which authorship has been dubiously or incorrectly ascribed.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ผู้แต่งได้รับการกำหนดอย่างไม่น่าสงสัยหรือไม่ถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="210"/>
        <source>Editor</source>
        <translation>Editor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="210"/>
        <source>Use for a person or organization who prepares for publication a work not primarily his/her own, such as by elucidating text, adding introductory or other critical matter, or technically directing an editorial staff.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เตรียมตัวตีพิมพ์ผลงานที่ไม่ได้เป็นส่วนสำคัญของตนเอง เช่นโดยการอธิบายข้อความเพิ่มเรื่องสำคัญหรือเรื่องสำคัญอื่น ๆ หรือเทคนิคการกำกับดูแลเจ้าหน้าที่บรรณาธิการ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="211"/>
        <source>Editor of compilation</source>
        <translation>Editor of compilation</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="211"/>
        <source>A person, family, or organization contributing to a collective or aggregate work by selecting and putting together works, or parts of works, by one or more creators. For compilations of data, information, etc., that result in new works, see compiler.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่มีส่วนร่วมในการทำงานร่วมกัน หรือรวมโดยการเลือกและรวบรวมผลงานหรือบางส่วนของผลงานโดยผู้สร้างรายหนึ่งรายหรือหลายคน สำหรับข้อมูลคอมไพล์ข้อมูลข้อมูล ฯลฯ ซึ่งเป็นผลให้เกิดผลงานใหม่โปรดดูที่คอมไพเลอร์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="212"/>
        <source>Editor of moving image work</source>
        <translation>Editor of moving image work</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="212"/>
        <source>A person, family, or organization responsible for assembling, arranging, and trimming film, video, or other moving image formats, including both visual and audio aspects.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่รับผิดชอบในการรวบรวมจัด และตัดแต่งภาพยนตร์วิดีโอหรือรูปแบบภาพเคลื่อนไหวอื่น ๆ รวมทั้งด้านภาพและเสียง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="213"/>
        <source>Electrician</source>
        <translation>Electrician</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="213"/>
        <source>Use for a person responsible for setting up a lighting rig and focusing the lights for a production, and running the lighting at a performance.</source>
        <translation>ใช้สำหรับผู้รับผิดชอบในการติดตั้งอุปกรณ์แสงสว่างและเน้นไฟสำหรับการผลิตและใช้แสงสว่างในการทำงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="214"/>
        <source>Electrotyper</source>
        <translation>Electrotyper</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="214"/>
        <source>Use for a person or organization who creates a duplicate printing surface by pressure molding and electrodepositing of metal that is then backed up with lead for printing.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่สร้างพื้นผิวการพิมพ์ที่ซ้ำกันโดยการขึ้นรูปด้วยความดัน และการฝังฝุ่นด้วยไฟฟ้าจากโลหะที่ได้รับการสำรองข้อมูลแล้วพร้อมด้วยตะกั่วสำหรับการพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="215"/>
        <source>Engineer</source>
        <translation>Engineer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="215"/>
        <source>Use for a person or organization that is responsible for technical planning and design, particularly with construction.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบด้านการวางแผน และการออกแบบด้านเทคนิคโดยเฉพาะอย่างยิ่งกับการก่อสร้าง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="216"/>
        <source>Engraver</source>
        <translation>Engraver</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="216"/>
        <source>Use for a person or organization who cuts letters, figures, etc. on a surface, such as a wooden or metal plate, for printing.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ตัดตัวอักษรตัวเลข ฯลฯ บนพื้นผิวเช่นแผ่นไม้หรือโลหะสำหรับพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="217"/>
        <source>Etcher</source>
        <translation>Etcher</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="217"/>
        <source>Use for a person or organization who produces text or images for printing by subjecting metal, glass, or some other surface to acid or the corrosive action of some other substance.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ผลิตข้อความหรือภาพเพื่อการพิมพ์โดยการทำให้โลหะแก้วหรือพื้นผิวอื่น ๆ เกิดเป็นกรดหรือกัดกร่อนของสารอื่น</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="218"/>
        <source>Event place</source>
        <translation>Event place</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="218"/>
        <source>A place where an event such as a conference or a concert took place.</source>
        <translation>สถานที่จัดกิจกรรมเช่นการประชุมหรือคอนเสิร์ตเกิดขึ้น</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="219"/>
        <source>Expert</source>
        <translation>Expert</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="219"/>
        <source>Use for a person or organization in charge of the description and appraisal of the value of goods, particularly rare items, works of art, etc. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการอธิบาย และประเมินมูลค่าสินค้าโดยเฉพาะ สินค้าที่หายาก ผลงานศิลปะ ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="220"/>
        <source>Facsimilist</source>
        <translation>Facsimilist</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="220"/>
        <source>Use for a person or organization that executed the facsimile.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ดำเนินการโทรสาร</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="221"/>
        <source>Field director</source>
        <translation>Field director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="221"/>
        <source>Use for a person or organization that manages or supervises the work done to collect raw data or do research in an actual setting or environment (typically applies to the natural and social sciences).</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่จัดการและ ดูแลงานที่ทำเพื่อรวบรวมข้อมูลดิบ หรือทำการวิจัยในสภาพแวดล้อมหรือสภาพแวดล้อมที่แท้จริง (โดยปกติจะใช้กับวิทยาศาสตร์ธรรมชาติและสังคมศาสตร์)</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="222"/>
        <source>Film director</source>
        <translation>Film director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="222"/>
        <source>A director responsible for the general management and supervision of a filmed performance.</source>
        <translation>ผู้กำกับดูแลการจัดการทั่วไปและการกำกับดูแลผลงานที่ถ่ายทำ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="223"/>
        <source>Film distributor</source>
        <translation>Film distributor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="223"/>
        <source>A person, family, or organization involved in distributing a moving image resource to theatres or other distribution channels.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่เกี่ยวข้องกับการเผยแพร่แหล่งข้อมูลภาพเคลื่อนไหว ไปยังโรงภาพยนตร์หรือช่องทางการจัดจำหน่ายอื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="224"/>
        <source>Film editor</source>
        <translation>Film editor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="224"/>
        <source>Use for a person or organization who is an editor of a motion picture film. This term is used regardless of the medium upon which the motion picture is produced or manufactured (e.g., acetate film, video tape). </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เป็นบรรณาธิการของภาพยนตร์ภาพยนตร์ คำนี้ใช้โดยไม่คำนึงถึงสื่อที่ผลิตหรือผลิตภาพเคลื่อนไหว (เช่นฟิล์มอะซิเทต เทปวิดีโอ)</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="225"/>
        <source>Film producer</source>
        <translation>Film producer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="225"/>
        <source>A producer responsible for most of the business aspects of a film.</source>
        <translation>ผู้ผลิตที่รับผิดชอบด้านธุรกิจส่วนใหญ่ของภาพยนตร์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="226"/>
        <source>Filmmaker</source>
        <translation>Filmmaker</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="226"/>
        <source>A person, family or organization responsible for creating an independent or personal film. A filmmaker is individually responsible for the conception and execution of all aspects of the film.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่รับผิดชอบในการสร้างภาพยนตร์อิสระหรือภาพยนตร์ส่วนตัว ผู้กำกับภาพยนตร์เป็นผู้รับผิดชอบต่อความคิดและการดำเนินการทุกด้านของภาพยนตร์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="227"/>
        <source>First party</source>
        <translation>First party</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="227"/>
        <source>Use for a person or organization who is identified as the only party or the party of the first part. In the case of transfer of right, this is the assignor, transferor, licensor, grantor, etc. Multiple parties can be named jointly as the first party.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ระบุว่าเป็นฝ่ายเดียวหรือฝ่ายในส่วนแรก ในกรณีโอนกรรมสิทธิ์เป็นผู้รับโอนผู้ให้อนุญาตผู้อนุญาต ฯลฯ คู่สัญญาหลายฝ่ายสามารถตั้งชื่อร่วมกันได้ในฐานะบุคคลที่หนึ่ง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="228"/>
        <source>Forger</source>
        <translation>Forger</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="228"/>
        <source>Use for a person or organization who makes or imitates something of value or importance, especially with the intent to defraud. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ทำให้ หรือเลียนแบบสิ่งที่มีคุณค่า หรือมีความสำคัญโดยเฉพาะอย่างยิ่งกับเจตนาที่จะฉ้อโกง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="229"/>
        <source>Former owner</source>
        <translation>Former owner</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="229"/>
        <source>Use for a person or organization who owned an item at any time in the past. Includes those to whom the material was once presented. A person or organization giving the item to the present owner is designated as Donor [dnr].</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เป็นเจ้าของสินค้าเมื่อใดก็ได้ในอดีต รวมถึงเนื้อหาที่นำเสนอครั้งเดียว บุคคลหรือองค์กรที่ให้ของขวัญแก่เจ้าของปัจจุบันจะได้รับมอบหมายให้เป็นผู้บริจาค [dnr]</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="230"/>
        <source>Funder</source>
        <translation>Funder</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="230"/>
        <source>Use for a person or organization that furnished financial support for the production of the work.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ให้การสนับสนุนทางการเงินสำหรับการผลิตผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="231"/>
        <source>Geographic information specialist</source>
        <translation>Geographic information specialist</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="231"/>
        <source>Use for a person responsible for geographic information system (GIS) development and integration with global positioning system data.</source>
        <translation>ใช้สำหรับผู้รับผิดชอบด้านการพัฒนาระบบสารสนเทศภูมิศาสตร์ (GIS) และการผสานรวมกับข้อมูลระบบตำแหน่งทั่วโลก</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="232"/>
        <source>Honoree</source>
        <translation>Honoree</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="232"/>
        <source>Use for a person or organization in memory or honor of whom a book, manuscript, etc. is donated. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่อยู่ในความทรงจำหรือเป็นเกียรติแก่ผู้ที่ได้รับบริจาคหนังสือหนังสือต้นฉบับ ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="233"/>
        <source>Host</source>
        <translation>Host</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="233"/>
        <source>Use for a person who is invited or regularly leads a program (often broadcast) that includes other guests, performers, etc. (e.g., talk show host).</source>
        <translation>ใช้สำหรับผู้ที่ได้รับเชิญหรือเป็นประจำนำโปรแกรม (ออกอากาศบ่อย) ซึ่งมีบุคคลอื่นนักแสดง ฯลฯ (เช่นโฮสต์รายการทอล์คโชว์)</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="234"/>
        <source>Host institution</source>
        <translation>Host institution</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="234"/>
        <source>An organization hosting the event, exhibit, conference, etc., which gave rise to a resource, but having little or no responsibility for the content of the resource.</source>
        <translation>องค์กรที่เป็นเจ้าภาพจัดงานจัดแสดงการประชุม ฯลฯ ซึ่งก่อให้เกิดทรัพยากร แต่มีความรับผิดชอบน้อยมากหรือไม่เกี่ยวกับเนื้อหาของทรัพยากร</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="235"/>
        <source>Illuminator</source>
        <translation>Illuminator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="235"/>
        <source>Use for a person or organization responsible for the decoration of a work (especially manuscript material) with precious metals or color, usually with elaborate designs and motifs.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการตกแต่งผลงาน (โดยเฉพาะเอกสารต้นฉบับ) ด้วยโลหะมีค่าหรือสีซึ่งมักใช้ลวดลายและลวดลายที่ประณีต</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="236"/>
        <source>Illustrator</source>
        <translation>Illustrator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="236"/>
        <source>Use for a person or organization who conceives, and perhaps also implements, a design or illustration, usually to accompany a written text.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ตั้งครรภ์และอาจใช้การออกแบบ หรือภาพประกอบโดยปกติจะมาพร้อมกับข้อความที่เป็นลายลักษณ์อักษร</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="237"/>
        <source>Inscriber</source>
        <translation>Inscriber</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="237"/>
        <source>Use for a person who has written a statement of dedication or gift.</source>
        <translation>ใช้สำหรับผู้ที่เขียนคำแถลงอุทิศหรือของขวัญ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="238"/>
        <source>Instrumentalist</source>
        <translation>Instrumentalist</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="238"/>
        <source>Use for a person or organization who principally plays an instrument in a musical or dramatic presentation or entertainment.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีส่วนสำคัญในการแสดงดนตรีหรือการแสดงที่น่าทึ่ง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="239"/>
        <source>Interviewee</source>
        <translation>Interviewee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="239"/>
        <source>Use for a person or organization who is interviewed at a consultation or meeting, usually by a reporter, pollster, or some other information gathering agent.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ได้รับการสัมภาษณ์ในการให้คำปรึกษา หรือการประชุมโดยปกติแล้วโดยนักข่าวนักสำรวจความคิดเห็น หรือตัวแทนรวบรวมข้อมูลอื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="240"/>
        <source>Interviewer</source>
        <translation>Interviewer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="240"/>
        <source>Use for a person or organization who acts as a reporter, pollster, or other information gathering agent in a consultation or meeting involving one or more individuals.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ทำหน้าที่เป็นนักข่าวนักสำรวจความคิดเห็น หรือผู้รวบรวมข้อมูลอื่น ๆ ในการให้คำปรึกษาหรือการประชุมที่เกี่ยวข้องกับบุคคลอย่างน้อยหนึ่งคน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="241"/>
        <source>Inventor</source>
        <translation>Inventor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="241"/>
        <source>Use for a person or organization who first produces a particular useful item, or develops a new process for obtaining a known item or result.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่สร้างรายการที่เป็นประโยชน์เป็นครั้งแรก หรือพัฒนากระบวนการใหม่สำหรับการได้รับรายการหรือผลลัพธ์ที่เป็นที่รู้จัก</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="242"/>
        <source>Issuing body</source>
        <translation>Issuing body</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="242"/>
        <source>A person, family or organization issuing a work, such as an official organ of the body.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่ออกผลงานเป็นอวัยวะอย่างเป็นทางการของร่างกาย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="243"/>
        <source>Judge</source>
        <translation>Judge</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="243"/>
        <source>A person who hears and decides on legal matters in court.</source>
        <translation>บุคคลที่ได้ยินและตัดสินใจเรื่องกฎหมายในศาล</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="244"/>
        <source>Jurisdiction governed</source>
        <translation>Jurisdiction governed</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="244"/>
        <source>A jurisdiction governed by a law, regulation, etc., that was enacted by another jurisdiction.</source>
        <translation>เขตอำนาจศาลที่ควบคุมโดยกฎหมายข้อบังคับ ฯลฯ ซึ่งได้รับการตราขึ้นโดยเขตอำนาจศาลอื่น</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="245"/>
        <source>Laboratory</source>
        <translation>Laboratory</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="245"/>
        <source>Use for an institution that provides scientific analyses of material samples.</source>
        <translation>ใช้สำหรับสถาบันที่ให้การวิเคราะห์ทางวิทยาศาสตร์เกี่ยวกับตัวอย่างวัสดุ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="246"/>
        <source>Laboratory director</source>
        <translation>Laboratory director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="246"/>
        <source>Use for a person or organization that manages or supervises work done in a controlled setting or environment. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่จัดการหรือดูแลงานที่ทำในสถานที่ควบคุมหรือสภาพแวดล้อม</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="247"/>
        <source>Landscape architect</source>
        <translation>Landscape architect</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="247"/>
        <source>Use for a person or organization whose work involves coordinating the arrangement of existing and proposed land features and structures.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ทำงานเกี่ยวข้องกับการประสานงาน ในการจัดโครงสร้างและองค์ประกอบที่มีอยู่และที่เสนอไว้</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="248"/>
        <source>Lead</source>
        <translation>Lead</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="248"/>
        <source>Use to indicate that a person or organization takes primary responsibility for a particular activity or endeavor. Use with another relator term or code to show the greater importance this person or organization has regarding that particular role. If more than one relator is assigned to a heading, use the Lead relator only if it applies to all the relators.</source>
        <translation>ใช้เพื่อระบุว่าบุคคลหรือองค์กรรับผิดชอบหลักสำหรับกิจกรรมหรือความพยายามเฉพาะอย่างใดอย่างหนึ่ง ใช้กับคำหรือรหัส relator อื่นเพื่อแสดงความสำคัญยิ่งขึ้นที่บุคคลหรือองค์กรนี้มีเกี่ยวกับบทบาทเฉพาะดังกล่าว หากมีการกำหนด relator ให้กับหัวเรื่องมากกว่าหนึ่ง relator ให้ใช้ Relator ตะกั่วเฉพาะเมื่อใช้กับ relators ทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="249"/>
        <source>Lender</source>
        <translation>Lender</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="249"/>
        <source>Use for a person or organization permitting the temporary use of a book, manuscript, etc., such as for photocopying or microfilming.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่อนุญาตให้มีการใช้หนังสือต้นฉบับหรืออื่น ๆ เช่นการถ่ายเอกสารหรือการถ่ายทำภาพยนตร์แบบชั่วคราว</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="250"/>
        <source>Libelant</source>
        <translation>Libelant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="250"/>
        <source>Use for the party who files a libel in an ecclesiastical or admiralty case.</source>
        <translation>ใช้สำหรับบุคคลที่เขียนจดหมายหมิ่นประมาทในกรณีที่เกี่ยวกับศาสนาหรือการทหารเรือ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="251"/>
        <source>Libelant-appellant</source>
        <translation>Libelant-appellant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="251"/>
        <source>Use for a libelant who takes an appeal from one ecclesiastical court or admiralty to another to reverse the judgment.</source>
        <translation>ใช้เป็นคำหมิ่นประมาทที่อุทธรณ์จากศาลฝ่ายสงฆ์แห่งหนึ่ง หรือกระทรวงทหารเรือไปยังอีกฝ่ายหนึ่งเพื่อกลับคำตัดสิน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="252"/>
        <source>Libelant-appellee</source>
        <translation>Libelant-appellee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="252"/>
        <source>Use for a libelant against whom an appeal is taken from one ecclesiastical court or admiralty to another to reverse the judgment.</source>
        <translation>ใช้สำหรับการหมิ่นประมาทต่อผู้ที่มีการอุทธรณ์จากศาล ฝ่ายพระศาสนจักรคนหนึ่งหรือพลเรือตรีอีกฝ่ายหนึ่งเพื่อคัดค้านการตัดสิน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="253"/>
        <source>Libelee</source>
        <translation>Libelee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="253"/>
        <source>Use for a party against whom a libel has been filed in an ecclesiastical court or admiralty.</source>
        <translation>ใช้สำหรับบุคคลที่ถูกหมิ่นประมาทถูกฟ้องในศาลหรือกระทรวงทหารเรือ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="254"/>
        <source>Libelee-appellant</source>
        <translation>Libelee-appellant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="254"/>
        <source>Use for a libelee who takes an appeal from one ecclesiastical court or admiralty to another to reverse the judgment.</source>
        <translation>ใช้สำหรับคำเบิกความที่อุทธรณ์จากศาลฝ่ายพระศาสนจักรแห่งหนึ่ง หรือกระทรวงทหารเรือไปยังอีกฝ่ายหนึ่งเพื่อกลับคำตัดสิน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="255"/>
        <source>Libelee-appellee</source>
        <translation>Libelee-appellee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="255"/>
        <source>Use for a libelee against whom an appeal is taken from one ecclesiastical court or admiralty to another to reverse the judgment.</source>
        <translation>ใช้สำหรับคำเบิกความที่ผู้อุทธรณ์ถูกนำออกจากศาลฝ่าย พระศาสนจักรแห่งหนึ่งหรือกระทรวงทหารเรือ ไปยังอีกฝ่ายหนึ่งเพื่อกลับคำตัดสิน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="256"/>
        <source>Librettist</source>
        <translation>Librettist</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="256"/>
        <source>Use for a person or organization who is a writer of the text of an opera, oratorio, etc.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เป็นนักเขียนข้อความของโอเปร่า oratorio ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="257"/>
        <source>Licensee</source>
        <translation>Licensee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="257"/>
        <source>Use for a person or organization who is an original recipient of the right to print or publish.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เป็นผู้รับต้นฉบับในการพิมพ์หรือเผยแพร่</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="258"/>
        <source>Licensor</source>
        <translation>Licensor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="258"/>
        <source>Use for person or organization who is a signer of the license, imprimatur, etc. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เป็นผู้ลงนามในใบอนุญาตการให้ความยินยอม ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="259"/>
        <source>Lighting designer</source>
        <translation>Lighting designer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="259"/>
        <source>Use for a person or organization who designs the lighting scheme for a theatrical presentation, entertainment, motion picture, etc.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ออกแบบระบบแสงสว่างเพื่อนำเสนอการแสดงละครบันเทิงภาพเคลื่อนไหว ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="260"/>
        <source>Lithographer</source>
        <translation>Lithographer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="260"/>
        <source>Use for a person or organization who prepares the stone or plate for lithographic printing, including a graphic artist creating a design directly on the surface from which printing will be done.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เตรียมหิน หรือแผ่นสำหรับพิมพ์ภาพ รวมถึงศิลปินกราฟิกที่สร้างการออกแบบโดยตรง บนพื้นผิวที่จะพิมพ์งาน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="261"/>
        <source>Lyricist</source>
        <translation>Lyricist</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="261"/>
        <source>Use for a person or organization who is the a writer of the text of a song.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เป็นนักเขียนข้อความเพลง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="262"/>
        <source>Manufacture place</source>
        <translation>Manufacture place</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="262"/>
        <source>The place of manufacture (e.g., printing, duplicating, casting, etc.) of a resource in a published form.</source>
        <translation>สถานที่ผลิต (เช่นการพิมพ์ซ้ำทำหล่อ ฯลฯ ) ของรีซอร์สในรูปแบบที่เผยแพร่</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="263"/>
        <source>Manufacturer</source>
        <translation>Manufacturer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="263"/>
        <source>Use for a person or organization that makes an artifactual work (an object made or modified by one or more persons). Examples of artifactual works include vases, cannons or pieces of furniture.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ทำผลงานประดิษฐ์ (วัตถุที่ทำหรือแก้ไขโดยบุคคลหนึ่งหรือหลายคน) ตัวอย่างของงานประดิษฐ์ ได้แก่ แจกันปืนใหญ่หรือชิ้นส่วนเฟอร์นิเจอร์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="264"/>
        <source>Marbler</source>
        <translation>Marbler</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="264"/>
        <source>The entity responsible for marbling paper, cloth, leather, etc. used in construction of a resource.</source>
        <translation>นิติบุคคลที่รับผิดชอบในการทำหินอ่อนกระดาษผ้าหนัง ฯลฯ ที่ใช้ในการสร้างทรัพยากร</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="265"/>
        <source>Markup editor</source>
        <translation>Markup editor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="265"/>
        <source>Use for a person or organization performing the coding of SGML, HTML, or XML markup of metadata, text, etc.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ทำรหัสของ SGML, HTML หรือ XML มาร์กอัปของข้อมูลเมตาข้อความ ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="266"/>
        <source>Medium</source>
        <translation>Medium</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="266"/>
        <source>A person held to be a channel of communication between the earthly world and a different world.</source>
        <translation>คนถือเป็นช่องทางในการสื่อสารระหว่างโลกกับโลกที่แตกต่างกัน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="267"/>
        <source>Metadata contact</source>
        <translation>Metadata contact</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="267"/>
        <source>Use for a person or organization primarily responsible for compiling and maintaining the original description of a metadata set (e.g., geospatial metadata set).</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบหลักในการจัดทำและเก็บรักษาคำอธิบายเดิมของชุดข้อมูลเมตา (เช่นชุดข้อมูลเมตาดาต้าเชิงพื้นที่)</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="268"/>
        <source>Metal-engraver</source>
        <translation>Metal-engraver</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="268"/>
        <source>Use for a person or organization responsible for decorations, illustrations, letters, etc. cut on a metal surface for printing or decoration.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบ ในการตกแต่ง ภาพประกอบ จดหมาย ฯลฯ บนพื้นโลหะเพื่อพิมพ์หรือตกแต่ง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="269"/>
        <source>Minute taker</source>
        <translation>Minute taker</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="269"/>
        <source>A person, family, or organization responsible for recording the minutes of a meeting.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่รับผิดชอบในการบันทึกรายงานการประชุม</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="270"/>
        <source>Moderator</source>
        <translation>Moderator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="270"/>
        <source>Use for a person who leads a program (often broadcast) where topics are discussed, usually with participation of experts in fields related to the discussion.</source>
        <translation>ใช้สำหรับผู้ที่นำโปรแกรม (มักออกอากาศ) ซึ่งจะมีการกล่าวถึงหัวข้อ โดยปกติแล้วจะมีการมีส่วนร่วมของผู้เชี่ยวชาญในสาขาต่างๆ ที่เกี่ยวข้องกับการอภิปราย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="271"/>
        <source>Monitor</source>
        <translation>Monitor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="271"/>
        <source>Use for a person or organization that supervises compliance with the contract and is responsible for the report and controls its distribution. Sometimes referred to as the grantee, or controlling agency.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่กำกับดูแลการปฏิบัติตามสัญญาและรับผิดชอบในรายงานและควบคุมการแจกจ่าย บางครั้งเรียกว่าผู้รับมอบหรือหน่วยงานที่ควบคุม</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="272"/>
        <source>Music copyist</source>
        <translation>Music copyist</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="272"/>
        <source>Use for a person who transcribes or copies musical notation</source>
        <translation>ใช้สำหรับบุคคลที่ถอดเสียงหรือคัดลอกโน้ตดนตรี</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="273"/>
        <source>Musical director</source>
        <translation>Musical director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="273"/>
        <source>Use for a person responsible for basic music decisions about a production, including coordinating the work of the composer, the sound editor, and sound mixers, selecting musicians, and organizing and/or conducting sound for rehearsals and performances.</source>
        <translation>ใช้สำหรับผู้ที่รับผิดชอบในการตัดสินใจเกี่ยวกับดนตรีขั้นพื้นฐาน เกี่ยวกับการผลิตรวมถึงการประสานงานของผู้แต่งโปรแกรมแก้ไขเสียง และเครื่องผสมเสียงการเลือกนักดนตรีและการจัดระเบียบ และ/หรือการดำเนินการเสียงสำหรับการซ้อมและการแสดง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="274"/>
        <source>Musician</source>
        <translation>Musician</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="274"/>
        <source>Use for a person or organization who performs music or contributes to the musical content of a work when it is not possible or desirable to identify the function more precisely.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ดำเนินการเพลง หรือก่อให้เกิดเนื้อหาทางดนตรีของผลงานเมื่อไม่สามารถทำได้ หรือต้องการให้ระบุฟังก์ชันได้อย่างแม่นยำมากขึ้น</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="275"/>
        <source>Narrator</source>
        <translation>Narrator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="275"/>
        <source>Use for a person who is a speaker relating the particulars of an act, occurrence, or course of events.</source>
        <translation>ใช้สำหรับบุคคลที่เป็นผู้พูดเกี่ยวกับรายละเอียดของการกระทำเหตุการณ์หรือเหตุการณ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="276"/>
        <source>Onscreen presenter</source>
        <translation>Onscreen presenter</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="276"/>
        <source>A performer contributing to an expression of a work by appearing on screen in nonfiction moving image materials or introductions to fiction moving image materials to provide contextual or background information. Use when another term (e.g., Narrator, Host) is either not applicable or not desired.</source>
        <translation>นักแสดงที่มีส่วนร่วมในการแสดงออกของงาน โดยการปรากฏบนหน้าจอในวัสดุภาพเคลื่อนไหวที่เป็นสารคดี หรือแนะนำวัสดุนิยายสำหรับเคลื่อนย้ายภาพเพื่อให้ข้อมูลบริบทหรือพื้นหลัง ใช้เมื่อคำอื่น (เช่นผู้บรรยาย, โฮสต์) ไม่สามารถใช้ได้หรือไม่ต้องการ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="277"/>
        <source>Opponent</source>
        <translation>Opponent</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="277"/>
        <source>Use for a person or organization responsible for opposing a thesis or dissertation.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เป็นผู้คัดค้านวิทยานิพนธ์หรือวิทยานิพนธ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="278"/>
        <source>Organizer of meeting</source>
        <translation>Organizer of meeting</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="278"/>
        <source>Use for a person or organization responsible for organizing a meeting for which an item is the report or proceedings.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการจัดการประชุมซึ่งรายการนั้นเป็นรายงานหรือการดำเนินคดี</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="279"/>
        <source>Originator</source>
        <translation>Originator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="279"/>
        <source>Use for a person or organization performing the work, i.e., the name of a person or organization associated with the intellectual content of the work. This category does not include the publisher or personal affiliation, or sponsor except where it is also the corporate author.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ปฏิบัติงานเช่น ชื่อของบุคคลหรือองค์กรที่เกี่ยวข้องกับเนื้อหาทางปัญญาของผลงาน หมวดหมู่นี้ไม่รวมถึงผู้จัดพิมพ์หรือความร่วมมือส่วนบุคคลหรือสปอนเซอร์ยกเว้นกรณีที่เป็นนักเขียนองค์กร</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="280"/>
        <source>Other</source>
        <translation>Other</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="280"/>
        <source>Use for relator codes from other lists which have no equivalent in the MARC list or for terms which have not been assigned a code.</source>
        <translation>ใช้สำหรับรหัส relator จากรายการอื่นที่ไม่มีรายการที่เทียบเท่าในรายการ MARC หรือสำหรับคำที่ไม่ได้รับการกำหนดรหัส</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="281"/>
        <source>Owner</source>
        <translation>Owner</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="281"/>
        <source>Use for a person or organization that currently owns an item or collection.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เป็นเจ้าของสินค้าหรือคอลเลคชันในปัจจุบัน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="282"/>
        <source>Panelist</source>
        <translation>Panelist</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="282"/>
        <source> performer contributing to a resource by participating in a program (often broadcast) where topics are discussed, usually with participation of experts in fields related to the discussion.</source>
        <translation>นักแสดงที่มีส่วนร่วมในทรัพยากรโดยการเข้าร่วมในโปรแกรม (มักจะออกอากาศ) ซึ่งจะมีการกล่าวถึงหัวข้อ โดยปกติแล้วจะมีการมีส่วนร่วมของผู้เชี่ยวชาญในสาขาที่เกี่ยวข้องกับการอภิปราย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="283"/>
        <source>Papermaker</source>
        <translation>Papermaker</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="283"/>
        <source>Use for a person or organization responsible for the production of paper, usually from wood, cloth, or other fibrous material.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการผลิตกระดาษ โดยทั่วไปจากไม้วัสดุผ้าหรือวัสดุเส้นใยอื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="284"/>
        <source>Patent applicant</source>
        <translation>Patent applicant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="284"/>
        <source>Use for a person or organization that applied for a patent.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ยื่นขอรับสิทธิบัตร</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="285"/>
        <source>Patent holder</source>
        <translation>Patent holder</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="285"/>
        <source>Use for a person or organization that was granted the patent referred to by the item. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ได้รับสิทธิบัตรที่ระบุโดยรายการ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="286"/>
        <source>Patron</source>
        <translation>Patron</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="286"/>
        <source>Use for a person or organization responsible for commissioning a work. Usually a patron uses his or her means or influence to support the work of artists, writers, etc. This includes those who commission and pay for individual works.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการว่าจ้างงาน โดยปกติผู้อุปถัมภ์ใช้วิธีหรืออิทธิพลของตนเพื่อสนับสนุนการทำงานของศิลปินนักเขียน ฯลฯ ซึ่งรวมถึงผู้ที่ทำหน้าที่และจ่ายค่างานแต่ละอย่าง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="287"/>
        <source>Performer</source>
        <translation>Performer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="287"/>
        <source>Use for a person or organization who exhibits musical or acting skills in a musical or dramatic presentation or entertainment, if specific codes for those functions ([act], [dnc], [itr], [voc], etc.) are not used. If specific codes are used, [prf] is used for a person whose principal skill is not known or specified.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีทักษะด้านดนตรี หรือการแสดงในงานนำเสนอดนตรีหรืองานนำเสนอที่น่าทึ่งหรือความบันเทิงหากไม่มีการใช้รหัสเฉพาะสำหรับฟังก์ชั่นเหล่านั้น ([กระทำ], [dnc], [itr], [เสียง] ฯลฯ . หากมีการใช้รหัสเฉพาะ [prf] จะใช้สำหรับบุคคลที่ไม่มีการระบุหรือระบุทักษะหลัก</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="288"/>
        <source>Permitting agency</source>
        <translation>Permitting agency</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="288"/>
        <source>Use for an authority (usually a government agency) that issues permits under which work is accomplished.</source>
        <translation>ใช้สำหรับผู้มีอำนาจ (โดยปกติคือหน่วยงานรัฐบาล) ที่ออกใบอนุญาตภายใต้การทำงานที่สามารถทำได้</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="289"/>
        <source>Photographer</source>
        <translation>Photographer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="289"/>
        <source>Use for a person or organization responsible for taking photographs, whether they are used in their original form or as reproductions.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการถ่ายภาพไม่ว่าจะเป็นรูปแบบเดิมหรือเป็นสำเนาก็ตาม</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="290"/>
        <source>Plaintiff</source>
        <translation>Plaintiff</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="290"/>
        <source>Use for the party who complains or sues in court in a personal action, usually in a legal proceeding.</source>
        <translation>ใช้สำหรับฝ่ายที่ร้องเรียนหรือฟ้องร้องต่อศาลในการดำเนินการส่วนบุคคล ซึ่งโดยปกติจะดำเนินการทางกฎหมาย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="291"/>
        <source>Plaintiff-appellant</source>
        <translation>Plaintiff-appellant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="291"/>
        <source>Use for a plaintiff who takes an appeal from one court or jurisdiction to another to reverse the judgment, usually in a legal proceeding.</source>
        <translation>ใช้สำหรับโจทก์ที่อุทธรณ์จากศาลหรือเขตอำนาจศาลหนึ่งไปยังอีกศาลหนึ่ง เพื่อคัดค้านคำตัดสินโดยปกติจะอยู่ในกระบวนการทางกฎหมาย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="292"/>
        <source>Plaintiff-appellee</source>
        <translation>Plaintiff-appellee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="292"/>
        <source>Use for a plaintiff against whom an appeal is taken from one court or jurisdiction to another to reverse the judgment, usually in a legal proceeding.</source>
        <translation>ใช้สำหรับโจทก์ที่อุทธรณ์ถูกนำออกจากศาล หรือเขตอำนาจศาลหนึ่งไปยังอีกศาลหนึ่งเพื่อคัดค้านคำตัดสิน โดยปกติจะอยู่ในกระบวนการทางกฎหมาย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="293"/>
        <source>Platemaker</source>
        <translation>Platemaker</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="293"/>
        <source>Use for a person or organization responsible for the production of plates, usually for the production of printed images and/or text.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการผลิตแผ่นดิสก์โดยปกติสำหรับการผลิตภาพพิมพ์และ/หรือข้อความ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="294"/>
        <source>Praeses</source>
        <translation>Praeses</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="294"/>
        <source>A person who is the faculty moderator of an academic disputation, normally proposing a thesis and participating in the ensuing disputation.</source>
        <translation>บุคคลที่เป็นผู้ดูแลคณาจารย์ด้านการโต้แย้งทางวิชาการ โดยปกติจะเสนอวิทยานิพนธ์และมีส่วนร่วมในการโต้แย้งที่ตามมา</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="295"/>
        <source>Presenter</source>
        <translation>Presenter</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="295"/>
        <source>A person or organization mentioned in an &apos;X presents&apos; credit for moving image materials and who is associated with production, finance, or distribution in some way. A vanity credit; in early years, normally the head of a studio.</source>
        <translation>บุคคลหรือองค์กรที่ระบุในเครดิต &apos;X presents&apos; สำหรับการย้ายเนื้อหาภาพและผู้ที่เกี่ยวข้องกับการผลิตการเงินหรือการจัดจำหน่ายในลักษณะใด เครดิตโต๊ะเครื่องแป้ง; ในช่วงต้นปีปกติหัวของสตูดิโอ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="296"/>
        <source>Printer</source>
        <translation>Printer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="296"/>
        <source>Use for a person or organization who prints texts, whether from type or plates.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่พิมพ์ข้อความไม่ว่าจะเป็นประเภทหรือจาน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="297"/>
        <source>Printer of plates</source>
        <translation>Printer of plates</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="297"/>
        <source>Use for a person or organization who prints illustrations from plates. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่พิมพ์ภาพประกอบจากจาน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="298"/>
        <source>Printmaker</source>
        <translation>Printmaker</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="298"/>
        <source>Use for a person or organization who makes a relief, intaglio, or planographic printing surface.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีส่วนช่วยในการถ่ายภาพ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="299"/>
        <source>Process contact</source>
        <translation>Process contact</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="299"/>
        <source>Use for a person or organization primarily responsible for performing or initiating a process, such as is done with the collection of metadata sets.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบหลักในการดำเนินการหรือเริ่มกระบวนการเช่นทำกับชุดชุดข้อมูลเมตา</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="300"/>
        <source>Producer</source>
        <translation>Producer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="300"/>
        <source>Use for a person or organization responsible for the making of a motion picture, including business aspects, management of the productions, and the commercial success of the work.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการสร้างภาพเคลื่อนไหวรวมถึงแง่มุมทางธุรกิจการ จัดการการผลิต และความสำเร็จ ในเชิงพาณิชย์ของผลงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="301"/>
        <source>Production company</source>
        <translation>Production company</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="301"/>
        <source>An organization that is responsible for financial, technical, and organizational management of a production for stage, screen, audio recording, television, webcast, etc.</source>
        <translation>องค์กรที่รับผิดชอบด้านการเงินด้านเทคนิคและการจัดการองค์กรสำหรับการผลิตเวทีจอภาพ การบันทึกเสียง โทรทัศน์ การออกอากาศ ทางเว็บ ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="302"/>
        <source>Production designer</source>
        <translation>Production designer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="302"/>
        <source>A person or organization responsible for designing the overall visual appearance of a moving image production.</source>
        <translation>บุคคลหรือองค์กรที่รับผิดชอบในการออกแบบภาพลักษณ์โดยรวมของการสร้างภาพเคลื่อนไหว</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="303"/>
        <source>Production manager</source>
        <translation>Production manager</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="303"/>
        <source>Use for a person responsible for all technical and business matters in a production.</source>
        <translation>ใช้สำหรับบุคคลที่รับผิดชอบด้านเทคนิคและธุรกิจทั้งหมดในการผลิต</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="304"/>
        <source>Production personnel</source>
        <translation>Production personnel</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="304"/>
        <source>Use for a person or organization associated with the production (props, lighting, special effects, etc.) of a musical or dramatic presentation or entertainment.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เกี่ยวข้องกับการผลิต (props, แสง, เอฟเฟ็กต์พิเศษ ฯลฯ ) ของการนำเสนอดนตรีหรือละครหรือความบันเทิง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="305"/>
        <source>Production place</source>
        <translation>Production place</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="305"/>
        <source>The place of production (e.g., inscription, fabrication, construction, etc.) of a resource in an unpublished form.</source>
        <translation>สถานที่ผลิต (เช่นการจารึก การสร้าง การก่อสร้าง ฯลฯ ) ของแหล่งข้อมูลในรูปแบบที่ไม่ได้เผยแพร่</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="306"/>
        <source>Programmer</source>
        <translation>Programmer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="306"/>
        <source>Use for a person or organization responsible for the creation and/or maintenance of computer program design documents, source code, and machine-executable digital files and supporting documentation.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการสร้าง และ/หรือดูแลรักษาเอกสารการออกแบบโปรแกรมคอมพิวเตอร์ซอร์สโค้ด และไฟล์ดิจิทัลที่สามารถใช้คอมพิวเตอร์ได้และเอกสารประกอบ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="307"/>
        <source>Project director</source>
        <translation>Project director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="307"/>
        <source>Use for a person or organization with primary responsibility for all essential aspects of a project, or that manages a very large project that demands senior level responsibility, or that has overall responsibility for managing projects, or provides overall direction to a project manager.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีความรับผิดชอบหลักสำหรับทุกด้านที่สำคัญของโครงการ หรือจัดการโครงการขนาดใหญ่ที่ต้องการความรับผิดชอบในระดับอาวุโส หรือมีความรับผิดชอบโดยรวมในการจัดการโครงการหรือให้ทิศทางโดยรวมแก่ผู้จัดการโครงการ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="308"/>
        <source>Proofreader</source>
        <translation>Proofreader</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="308"/>
        <source>Use for a person who corrects printed matter. For manuscripts, use Corrector [crr].</source>
        <translation>ใช้สำหรับบุคคลที่แก้ไขปัญหาสิ่งพิมพ์ สำหรับต้นฉบับใช้ Corrector [crr]</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="309"/>
        <source>Provider</source>
        <translation>Provider</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="309"/>
        <source>A person or organization who produces, publishes, manufactures, or distributes a resource if specific codes are not desired (e.g. [mfr], [pbl].)</source>
        <translation>บุคคลหรือองค์กรที่ผลิตเผยแพร่จัดจำหน่ายหรือแจกจ่ายทรัพยากรหากไม่ต้องการระบุรหัสใด ๆ (เช่น [mfr], [pbl])</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="310"/>
        <source>Publication place </source>
        <translation>Publication place </translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="310"/>
        <source>The place where a resource is published.</source>
        <translation>สถานที่ที่มีการเผยแพร่รีซอร์ส</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="311"/>
        <source>Publisher</source>
        <translation>สำนักพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="311"/>
        <source>Use for a person or organization that makes printed matter, often text, but also printed music, artwork, etc. available to the public.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ทำสิ่งพิมพ์ซึ่งมักเป็นข้อความ แต่ยังสามารถพิมพ์งานดนตรีงานศิลปะ ฯลฯ ให้สาธารณชนได้</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="312"/>
        <source>Publishing director</source>
        <translation>Publishing director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="312"/>
        <source>Use for a person or organization who presides over the elaboration of a collective work to ensure its coherence or continuity. This includes editors-in-chief, literary editors, editors of series, etc.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เป็นประธานในการจัดทำผลงานร่วมกัน เพื่อให้มั่นใจว่ามีความเชื่อมโยงกันหรือต่อเนื่อง ซึ่งรวมถึงบรรณาธิการ - หัวหน้าบรรณาธิการวรรณกรรมบรรณาธิการชุด ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="313"/>
        <source>Puppeteer</source>
        <translation>Puppeteer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="313"/>
        <source>Use for a person or organization who manipulates, controls, or directs puppets or marionettes in a musical or dramatic presentation or entertainment.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ควบคุมการควบคุมหรือนำแสดงโดยหุ่นเชิดหรือหุ่นเชิดในการนำเสนอหรือบันเทิง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="314"/>
        <source>Radio director</source>
        <translation>Radio director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="314"/>
        <source>A director responsible for the general management and supervision of a radio program.</source>
        <translation>ผู้อำนวยการด้านการจัดการและการกำกับดูแลทั่วไปของรายการวิทยุ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="315"/>
        <source>Radio producer</source>
        <translation>Radio producer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="315"/>
        <source>A producer responsible for most of the business aspects of a radio program.</source>
        <translation>ผู้ผลิตที่รับผิดชอบด้านธุรกิจส่วนใหญ่ของรายการวิทยุ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="316"/>
        <source>Recipient</source>
        <translation>Recipient</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="316"/>
        <source>Use for a person or organization to whom correspondence is addressed.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่มีการติดต่อกัน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="317"/>
        <location filename="../../Misc/MarcRelators.cpp" line="318"/>
        <source>Recording engineer</source>
        <translation>Recording engineer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="317"/>
        <source>Use for a person or organization who supervises the technical aspects of a sound or video recording session.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ดูแลด้านเทคนิคของช่วงการบันทึกเสียงหรือวิดีโอ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="318"/>
        <source>A person contributing to a resource by supervising the technical aspects of a sound or video recording session.</source>
        <translation>บุคคลที่ให้ข้อมูลเกี่ยวกับทรัพยากรโดยการดูแลด้านเทคนิคของช่วงการบันทึกเสียงหรือวิดีโอ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="319"/>
        <source>Redactor</source>
        <translation>Redactor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="319"/>
        <source>Use for a person or organization who writes or develops the framework for an item without being intellectually responsible for its content.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เขียน หรือพัฒนากรอบงานสำหรับรายการ โดยไม่ต้องรับผิดชอบด้านเนื้อหาในด้านสติปัญญา</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="320"/>
        <source>Renderer</source>
        <translation>Renderer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="320"/>
        <source>Use for a person or organization who prepares drawings of architectural designs (i.e., renderings) in accurate, representational perspective to show what the project will look like when completed.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เตรียมภาพวาดของการออกแบบสถาปัตยกรรม (เช่น renderings) ในมุมมองที่ถูกต้องและเป็นตัวแทนเพื่อแสดงว่าโครงการจะมีลักษณะเป็นอย่างไรเมื่อทำเสร็จ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="321"/>
        <source>Reporter</source>
        <translation>Reporter</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="321"/>
        <source>Use for a person or organization who writes or presents reports of news or current events on air or in print.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เขียน หรือนำเสนอรายงานข่าว หรือเหตุการณ์ปัจจุบันทางอากาศ หรือในรูปแบบการพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="322"/>
        <source>Repository</source>
        <translation>Repository</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="322"/>
        <source>Use for an agency that hosts data or material culture objects and provides services to promote long term, consistent and shared use of those data or objects.</source>
        <translation>ใช้สำหรับเอเจนซี่ที่เป็นโฮสต์ข้อมูลหรือวัตถุวัฒนธรรมทางวัฒนธรรม และให้บริการเพื่อส่งเสริมการใช้ข้อมูล หรือวัตถุเหล่านี้ในระยะยาวสม่ำเสมอและใช้ร่วมกัน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="323"/>
        <source>Research team head</source>
        <translation>Research team head</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="323"/>
        <source>Use for a person who directed or managed a research project.</source>
        <translation>ใช้สำหรับบุคคลที่กำกับหรือบริหารโครงการวิจัย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="324"/>
        <source>Research team member</source>
        <translation>Research team member</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="324"/>
        <source>Use for a person who participated in a research project but whose role did not involve direction or management of it.</source>
        <translation>ใช้สำหรับบุคคลที่มีส่วนร่วมในโครงการวิจัย แต่บทบาทของเขาไม่ได้เกี่ยวข้องกับทิศทางหรือการจัดการของ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="325"/>
        <source>Researcher</source>
        <translation>Researcher</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="325"/>
        <source>Use for a person or organization responsible for performing research. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการทำการวิจัย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="326"/>
        <source>Respondent</source>
        <translation>Respondent</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="326"/>
        <source>Use for the party who makes an answer to the courts pursuant to an application for redress, usually in an equity proceeding.</source>
        <translation>ใช้สำหรับฝ่ายที่ให้คำตอบต่อศาลตามคำร้องขอให้ชดใช้ซึ่งโดยปกติแล้วจะดำเนินการในส่วนได้เสีย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="327"/>
        <source>Respondent-appellant</source>
        <translation>Respondent-appellant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="327"/>
        <source>Use for a respondent who takes an appeal from one court or jurisdiction to another to reverse the judgment, usually in an equity proceeding.</source>
        <translation>ใช้สำหรับผู้ถูกร้องเรียนที่อุทธรณ์จากศาล หรือเขตอำนาจศาลหนึ่งแห่งต่ออีกศาลหนึ่งเพื่อคัดค้านการตัดสิน โดยปกติในการดำเนินการเกี่ยวกับทุน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="328"/>
        <source>Respondent-appellee</source>
        <translation>Respondent-appellee</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="328"/>
        <source>Use for a respondent against whom an appeal is taken from one court or jurisdiction to another to reverse the judgment, usually in an equity proceeding.</source>
        <translation>ใช้สำหรับผู้ถูกร้องเรียนซึ่งมีการอุทธรณ์คำตัดสินจากศาล หรือเขตอำนาจศาลหนึ่งแห่งต่อศาลอื่นเพื่อคัดค้านคำตัดสิน ซึ่งโดยปกติจะดำเนินการในส่วนได้เสีย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="329"/>
        <source>Responsible party</source>
        <translation>Responsible party</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="329"/>
        <source>Use for a person or organization legally responsible for the content of the published material.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบตามกฎหมายต่อเนื้อหาของเนื้อหาที่เผยแพร่</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="330"/>
        <source>Restager</source>
        <translation>Restager</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="330"/>
        <source>Use for a person or organization, other than the original choreographer or director, responsible for restaging a choreographic or dramatic work and who contributes minimal new content.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรอื่นนอกเหนือจากนักออกแบบท่าเต้น หรือผู้กำกับที่เป็นผู้รับผิดชอบในการจัดเตรียมงานออกแบบท่าเต้น หรือการแสดงละครและมีส่วนร่วมในเนื้อหาใหม่ ๆ น้อย ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="331"/>
        <source>Restorationist</source>
        <translation>Restorationist</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="331"/>
        <source>A person, family, or organization responsible for the set of technical, editorial, and intellectual procedures aimed at compensating for the degradation of an item by bringing it back to a state as close as possible to its original condition.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่รับผิดชอบในชุดของขั้นตอนด้านเทคนิค บรรณาธิการและทางปัญญาเพื่อชดเชยการย่อยสลายของรายการ โดยการนำกลับไปอยู่ในสถานะใกล้เคียงกับสภาพเดิมมากที่สุด</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="332"/>
        <source>Reviewer</source>
        <translation>Reviewer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="332"/>
        <source>Use for a person or organization responsible for the review of a book, motion picture, performance, etc.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในการตรวจทานหนังสือภาพเคลื่อนไหวประสิทธิภาพ ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="333"/>
        <source>Rubricator</source>
        <translation>Rubricator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="333"/>
        <source>Use for a person or organization responsible for parts of a work, often headings or opening parts of a manuscript, that appear in a distinctive color, usually red.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบในส่วนของผลงาน ซึ่งมักเป็นส่วนหัวหรือเปิดส่วนต่างๆของต้นฉบับที่ปรากฏในสีที่โดดเด่นมักเป็นสีแดง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="334"/>
        <source>Scenarist</source>
        <translation>Scenarist</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="334"/>
        <source>Use for a person or organization who is the author of a motion picture screenplay.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เป็นผู้เขียนบทภาพยนตร์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="335"/>
        <source>Scientific advisor</source>
        <translation>Scientific advisor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="335"/>
        <source>Use for a person or organization who brings scientific, pedagogical, or historical competence to the conception and realization on a work, particularly in the case of audio-visual items.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่นำความสามารถทางวิทยาศาสตร์การสอน หรือประวัติศาสตร์ไปสู่ความคิด และการรับรู้ถึงผลงานโดยเฉพาะอย่างยิ่งในกรณีของภาพและเสียง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="336"/>
        <source>Scribe</source>
        <translation>Scribe</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="336"/>
        <source>Use for a person who is an amanuensis and for a writer of manuscripts proper. For a person who makes pen-facsimiles, use Facsimilist [fac].</source>
        <translation>ใช้สำหรับคนที่เป็น amanuensis และสำหรับนักเขียนต้นฉบับที่เหมาะสม สำหรับคนที่ใช้ปากกาโทรสารให้ใช้ Facsimilist [fac]</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="337"/>
        <source>Sculptor</source>
        <translation>Sculptor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="337"/>
        <source>Use for a person or organization who models or carves figures that are three-dimensional representations.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ทำแบบจำลองหรือแกะสลักตัวเลขที่เป็นตัวแทนสามมิติ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="338"/>
        <source>Second party</source>
        <translation>Second party</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="338"/>
        <source>Use for a person or organization who is identified as the party of the second part. In the case of transfer of right, this is the assignee, transferee, licensee, grantee, etc. Multiple parties can be named jointly as the second party.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ระบุว่าเป็นฝ่ายในส่วนที่สอง ในกรณีโอนกรรมสิทธิ์เป็นผู้รับโอนผู้รับโอนผู้รับใบอนุญาต ฯลฯ หลายฝ่ายสามารถตั้งชื่อร่วมกันได้ในฐานะบุคคลที่สอง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="339"/>
        <source>Secretary</source>
        <translation>Secretary</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="339"/>
        <source>Use for a person or organization who is a recorder, redactor, or other person responsible for expressing the views of a organization.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เป็นผู้บันทึก redactor หรือบุคคลอื่นที่รับผิดชอบในการแสดงความคิดเห็นขององค์กร</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="340"/>
        <source>Seller</source>
        <translation>Seller</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="340"/>
        <source>A former owner of an item who sold that item to another owner.</source>
        <translation>เจ้าของเดิมของสินค้าที่ขายสินค้าให้กับเจ้าของคนอื่น</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="341"/>
        <source>Set designer</source>
        <translation>Set designer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="341"/>
        <source>Use for a person or organization who translates the rough sketches of the art director into actual architectural structures for a theatrical presentation, entertainment, motion picture, etc. Set designers draw the detailed guides and specifications for building the set.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่แปลภาพร่างคร่าวๆของผู้กำกับศิลป์ ในโครงสร้างทางสถาปัตยกรรมที่แท้จริงสำหรับการนำเสนอบันเทิงบันเทิงภาพเคลื่อนไหว ฯลฯ ผู้ออกแบบชุดจะวาดคำแนะนำโดยละเอียดและข้อกำหนดสำหรับการสร้างชุด</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="342"/>
        <source>Setting</source>
        <translation>Setting</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="342"/>
        <source>An entity in which the activity or plot of a work takes place, e.g. a geographic place, a time period, a building, an event.</source>
        <translation>หน่วยงานที่กิจกรรมหรือพล็อตของงานเกิดขึ้นเช่น สถานที่ทางภูมิศาสตร์ระยะเวลาอาคารเหตุการณ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="343"/>
        <source>Signer</source>
        <translation>Signer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="343"/>
        <source>Use for a person whose signature appears without a presentation or other statement indicative of provenance. When there is a presentation statement, use Inscriber [ins].</source>
        <translation>ใช้สำหรับบุคคลที่มีลายเซ็นปรากฏขึ้นโดยไม่มีการนำเสนอหรือข้อความอื่นที่บ่งบอกถึงแหล่งที่มา เมื่อมีการนำเสนอใช้ Inscriber [ins]</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="344"/>
        <source>Singer</source>
        <translation>Singer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="344"/>
        <source>Use for a person or organization who uses his/her/their voice with or without instrumental accompaniment to produce music. A performance may or may not include actual words.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ใช้เสียงของตนโดยมีหรือไม่มีอุปกรณ์ที่ใช้ในการผลิตเพลง ประสิทธิภาพอาจหรือไม่อาจรวมถึงคำที่เป็นจริง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="345"/>
        <source>Sound designer</source>
        <translation>Sound designer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="345"/>
        <source>Use for a person who produces and reproduces the sound score (both live and recorded), the installation of microphones, the setting of sound levels, and the coordination of sources of sound for a production.</source>
        <translation>ใช้สำหรับผู้ที่ผลิตและทำซ้ำคะแนนเสียง (ทั้งสดและบันทึก) การติดตั้งไมโครโฟนการตั้งระดับเสียงและการประสานงานของแหล่งกำเนิดเสียงสำหรับการผลิต</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="346"/>
        <source>Speaker</source>
        <translation>Speaker</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="346"/>
        <source>Use for a person who participates in a program (often broadcast) and makes a formalized contribution or presentation generally prepared in advance.</source>
        <translation>ใช้สำหรับผู้ที่เข้าร่วมในโครงการ (มักออกอากาศ) และมีส่วนร่วมหรือการจัดทำเป็นทางการโดยทั่วไปซึ่งจัดทำขึ้นล่วงหน้า</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="347"/>
        <source>Sponsor</source>
        <translation>Sponsor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="347"/>
        <source>Use for a person or organization that issued a contract or under the auspices of which a work has been written, printed, published, etc.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ทำสัญญาหรือภายใต้การดูแลของงานที่ได้รับการเขียนพิมพ์พิมพ์เผยแพร่เป็นต้น</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="348"/>
        <source>Stage director</source>
        <translation>Stage director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="348"/>
        <source>A person or organization contributing to a stage resource through the overall management and supervision of a performance.</source>
        <translation>บุคคลหรือองค์กรที่มีส่วนร่วมในทรัพยากรขั้นตอนโดยผ่านการจัดการโดยรวมและการกำกับดูแลผลการปฏิบัติงาน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="349"/>
        <source>Stage manager</source>
        <translation>Stage manager</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="349"/>
        <source>Use for a person who is in charge of everything that occurs on a performance stage, and who acts as chief of all crews and assistant to a director during rehearsals.</source>
        <translation>ใช้สำหรับบุคคลที่รับผิดชอบทุกสิ่งทุกอย่างที่เกิดขึ้นบนเวทีการแสดง และผู้ที่ทำหน้าที่เป็นหัวหน้าทีมทั้งหมด และเป็นผู้ช่วยผู้กำกับในระหว่างการฝึกซ้อม</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="350"/>
        <source>Standards body</source>
        <translation>Standards body</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="350"/>
        <source>Use for an organization responsible for the development or enforcement of a standard.</source>
        <translation>ใช้สำหรับองค์กรที่รับผิดชอบในการพัฒนาหรือบังคับใช้มาตรฐาน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="351"/>
        <source>Stereotyper</source>
        <translation>Stereotyper</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="351"/>
        <source>Use for a person or organization who creates a new plate for printing by molding or copying another printing surface.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่สร้างแผ่นใหม่สำหรับการพิมพ์โดยการขึ้นรูปหรือทำสำเนาผิวงานพิมพ์อื่น</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="352"/>
        <source>Storyteller</source>
        <translation>Storyteller</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="352"/>
        <source>Use for a person relaying a story with creative and/or theatrical interpretation.</source>
        <translation>ใช้สำหรับบุคคลที่ถ่ายทอดเรื่องราวด้วยการตีความความคิดสร้างสรรค์และ / หรือการแสดงละคร</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="353"/>
        <source>Supporting host</source>
        <translation>Supporting host</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="353"/>
        <source>Use for a person or organization that supports (by allocating facilities, staff, or other resources) a project, program, meeting, event, data objects, material culture objects, or other entities capable of support. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่สนับสนุน (โดยการจัดสรรสิ่งอำนวยความสะดวกพนักงานหรือทรัพยากรอื่น ๆ ) โครงการโครงการการประชุมเหตุการณ์วัตถุข้อมูลวัตถุวัฒนธรรมทางวัตถุหรือหน่วยงานอื่น ๆ ที่สามารถสนับสนุนได้</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="354"/>
        <source>Surveyor</source>
        <translation>Surveyor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="354"/>
        <source>Use for a person or organization who does measurements of tracts of land, etc. to determine location, forms, and boundaries.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ทำหน้าที่วัดพื้นที่ทำการเกษตร ฯลฯ เพื่อกำหนดตำแหน่งรูปแบบและขอบเขต</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="355"/>
        <source>Teacher</source>
        <translation>Teacher</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="355"/>
        <source>Use for a person who, in the context of a resource, gives instruction in an intellectual subject or demonstrates while teaching physical skills. </source>
        <translation>ใช้สำหรับผู้ที่อยู่ในบริบทของทรัพยากรให้คำแนะนำ ในเรื่องทางปัญญาหรือแสดงให้เห็นขณะที่สอนทักษะทางกายภาพ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="356"/>
        <source>Technical director</source>
        <translation>Technical director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="356"/>
        <source>Use for a person who is ultimately in charge of scenery, props, lights and sound for a production.</source>
        <translation>ใช้สำหรับคนที่รับผิดชอบในท้ายที่สุดในฉากทัศนียภาพอุปกรณ์ประกอบฉากไฟและเสียงสำหรับการผลิต</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="357"/>
        <source>Television director</source>
        <translation>Television director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="357"/>
        <source>A director responsible for the general management and supervision of a television program.</source>
        <translation>ผู้อำนวยการที่รับผิดชอบด้านการจัดการทั่วไปและการกำกับดูแลของรายการโทรทัศน์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="358"/>
        <source>Television producer</source>
        <translation>Television producer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="358"/>
        <source>A producer responsible for most of the business aspects of a television program.</source>
        <translation>ผู้ผลิตที่รับผิดชอบด้านธุรกิจส่วนใหญ่ของรายการโทรทัศน์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="359"/>
        <source>Thesis advisor</source>
        <translation>Thesis advisor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="359"/>
        <source>Use for a person under whose supervision a degree candidate develops and presents a thesis, mémoire, or text of a dissertation. </source>
        <translation>ใช้สำหรับบุคคลที่อยู่ภายใต้การควบคุมของผู้สมัครระดับปริญญาพัฒนาและนำเสนอวิทยานิพนธ์ mémoire หรือข้อความของวิทยานิพนธ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="360"/>
        <source>Transcriber</source>
        <translation>Transcriber</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="360"/>
        <source>Use for a person who prepares a handwritten or typewritten copy from original material, including from dictated or orally recorded material. For makers of pen-facsimiles, use Facsimilist [fac].</source>
        <translation>ใช้สำหรับบุคคลที่เตรียมสำเนาที่เขียนด้วยลายมือหรือพิมพ์ดีด จากเนื้อหาต้นฉบับรวมทั้งเนื้อหาที่เขียนด้วยลายมือหรือบันทึกด้วยวาจา สำหรับผู้ผลิตปากกาโทรสารให้ใช้ Facsimilist [fac]</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="361"/>
        <source>Translator</source>
        <translation>Translator</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="361"/>
        <source>Use for a person or organization who renders a text from one language into another, or from an older form of a language into the modern form.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่แสดงผลข้อความจาก ภาษาหนึ่งไปยังอีกภาษาหนึ่งหรือจากแบบฟอร์มเก่า ของภาษาลงในแบบฟอร์มที่ทันสมัย</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="362"/>
        <source>Type designer</source>
        <translation>Type designer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="362"/>
        <source>Use for a person or organization who designed the type face used in a particular item. </source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ออกแบบใบหน้าประเภทที่ใช้ในรายการใดรายการหนึ่ง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="363"/>
        <source>Typographer</source>
        <translation>Typographer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="363"/>
        <source>Use for a person or organization primarily responsible for choice and arrangement of type used in an item. If the typographer is also responsible for other aspects of the graphic design of a book (e.g., Book designer [bkd]), codes for both functions may be needed.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบหลักในการเลือกและจัดเรียงประเภทที่ใช้ในรายการ หากผู้จัดทำภาพพิมพ์ยังรับผิดชอบด้านอื่น ๆ ของการออกแบบกราฟิกของหนังสือ (เช่น Book designer [bkd]) อาจจำเป็นต้องใช้รหัสสำหรับทั้งสองฟังก์ชัน</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="364"/>
        <source>University place</source>
        <translation>University place</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="364"/>
        <source>A place where a university that is associated with a resource is located, for example, a university where an academic dissertation or thesis was presented.</source>
        <translation>สถานที่ที่มีมหาวิทยาลัยที่เชื่อมโยงกับแหล่งข้อมูล เช่น มหาวิทยาลัยที่มีวิทยานิพนธ์วิทยานิพนธ์หรือวิทยานิพนธ์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="365"/>
        <source>Videographer</source>
        <translation>Videographer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="365"/>
        <source>Use for a person or organization in charge of a video production, e.g. the video recording of a stage production as opposed to a commercial motion picture. The videographer may be the camera operator or may supervise one or more camera operators. Do not confuse with cinematographer.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่รับผิดชอบการผลิตวิดีโอเช่น การบันทึกวิดีโอการผลิตบนเวทีเมื่อเทียบกับภาพเคลื่อนไหวเชิงพาณิชย์ ผู้ถ่ายภาพอาจเป็นผู้ดำเนินการกล้องหรืออาจกำกับดูแลผู้ประกอบการกล้องอย่างน้อยหนึ่งราย อย่าสับสนกับการถ่ายทำภาพยนตร์</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="366"/>
        <source>Voice actor</source>
        <translation>Voice actor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="366"/>
        <source>An actor contributing to a resource by providing the voice for characters in radio and audio productions and for animated characters in moving image works, as well as by providing voice overs in radio and television commercials, dubbed resources, etc.</source>
        <translation>นักแสดงที่มีส่วนร่วมในทรัพยากรโดยการให้เสียงสำหรับตัวละคร ในการผลิตรายการวิทยุและเสียงและตัวละครที่มีชีวิตชีวา ในการย้ายผลงานภาพรวมทั้งการให้เสียงพากย์ในโฆษณาทางวิทยุและโทรทัศน์แหล่งข้อมูลที่ถูกกล่าวถึงเป็นต้น</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="367"/>
        <source>Witness</source>
        <translation>Witness</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="367"/>
        <source>Use for a person who verifies the truthfulness of an event or action. </source>
        <translation>ใช้สำหรับผู้ที่ตรวจสอบความถูกต้องของเหตุการณ์หรือการกระทำ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="368"/>
        <source>Wood-engraver</source>
        <translation>Wood-engraver</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="368"/>
        <source>Use for a person or organization who makes prints by cutting the image in relief on the end-grain of a wood block.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ทำภาพพิมพ์โดยการตัดภาพด้วยสบายใจที่ปลายธัญพืชของบล็อกไม้</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="369"/>
        <source>Woodcutter</source>
        <translation>Woodcutter</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="369"/>
        <source>Use for a person or organization who makes prints by cutting the image in relief on the plank side of a wood block.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่ทำภาพพิมพ์โดยการตัดภาพด้วยความโล่งใจที่ด้านข้างของแผ่นไม้</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="370"/>
        <source>Writer of accompanying material</source>
        <translation>Writer of accompanying material</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="370"/>
        <source>Use for a person or organization who writes significant material which accompanies a sound recording or other audiovisual material.</source>
        <translation>ใช้สำหรับบุคคลหรือองค์กรที่เขียนเนื้อหาสำคัญซึ่งมาพร้อมกับการบันทึกเสียงหรือวัสดุโสตทัศน์อื่น ๆ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="371"/>
        <source>Writer of added commentary</source>
        <translation>Writer of added commentary</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="371"/>
        <source>A person, family, or organization contributing to an expression of a work by providing an interpretation or critical explanation of the original work.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่มีส่วนร่วมในการแสดงออกของงาน โดยให้คำอธิบายหรือคำอธิบายที่สำคัญเกี่ยวกับงานต้นฉบับ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="372"/>
        <source>Writer of added lyrics</source>
        <translation>Writer of added lyrics</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="372"/>
        <source>A writer of words added to an expression of a musical work. For lyric writing in collaboration with a composer to form an original work, see lyricist.</source>
        <translation>นักเขียนคำเพิ่มการแสดงออกของงานดนตรี สำหรับการเขียนเนื้อเพลงในความร่วมมือกับนักแต่งเพลงเพื่อสร้างผลงานต้นฉบับให้ดูที่นักแต่งบทเพลง</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="373"/>
        <source>Writer of added text</source>
        <translation>Writer of added text</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="373"/>
        <source>A person, family, or organization contributing to a non-textual resource by providing text for the non-textual work (e.g., writing captions for photographs, descriptions of maps.)</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่มีส่วนร่วมในทรัพยากรที่ไม่ใช่ตัวตน โดยการให้ข้อความสำหรับงานที่ไม่ใช่ข้อความ (เช่นการเขียนคำอธิบายภาพภาพถ่ายคำอธิบายแผนที่)</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="374"/>
        <source>Writer of introduction</source>
        <translation>Writer of introduction</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="374"/>
        <source>A person, family, or organization contributing to a resource by providing an introduction to the original work.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่มีส่วนร่วมในทรัพยากรโดยการแนะนำบทประพันธ์ต้นฉบับ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="375"/>
        <source>Writer of preface</source>
        <translation>Writer of preface</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="375"/>
        <source>A person, family, or organization contributing to a resource by providing a preface to the original work.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่มีส่วนร่วมในทรัพยากรโดยการให้คำนำในงานต้นฉบับ</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="376"/>
        <source>Writer of supplementary textual content</source>
        <translation>Writer of supplementary textual content</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="376"/>
        <source>A person, family, or organization contributing to a resource by providing supplementary textual content (e.g., an introduction, a preface) to the original work.</source>
        <translation>บุคคลครอบครัวหรือองค์กรที่มีส่วนร่วมในทรัพยากรโดยการจัดหาเนื้อหาต้นฉบับเดิม (เช่นบทนำคำนำ) กับงานต้นฉบับ</translation>
    </message>
</context>
<context>
    <name>MetaEditor</name>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="20"/>
        <source>MetaData Editor</source>
        <translation>ตัวแก้ไขข้อมูลเมตา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="52"/>
        <source>Add a new metadata element.</source>
        <translation>เพิ่มองค์ประกอบข้อมูลเมตาใหม่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="55"/>
        <source>Add Metadata</source>
        <translation>เพิ่มเมตาดาต้า</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="62"/>
        <source>Remove a metadata element or property.</source>
        <translation>ลบองค์ประกอบหรือคุณสมบัติ metadata</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="65"/>
        <source>Remove</source>
        <translation>นำออก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="72"/>
        <source>Add a new property or attribute to an existing metadata element.</source>
        <translation>เพิ่มคุณสมบัติหรือแอตทริบิวต์ใหม่ลงในองค์ประกอบข้อมูลเมตาที่มีอยู่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="75"/>
        <source>Add Property</source>
        <translation>เพิ่มองค์ประกอบ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="97"/>
        <source>Move selected metadata element or property up.</source>
        <translation>ย้ายองค์ประกอบหรือข้อมูลเมตาข้อมูลที่เลือกขึ้น</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="100"/>
        <location filename="../../Form_Files/MetaEditor.ui" line="113"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="110"/>
        <source>Move selected metadata element or property down.</source>
        <translation>ย้ายองค์ประกอบหรือข้อมูลเมตาข้อมูลที่เลือกลง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="148"/>
        <source>Double-click in cell to edit its value.  Minimum metadata consists of main language, title, and at least one creator.</source>
        <translation>ดับเบิลคลิกที่เซลล์เพื่อแก้ไขค่า ข้อมูลเมตาต่ำสุดประกอบด้วยภาษาหลักชื่อและผู้สร้างอย่างน้อยหนึ่งคน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="172"/>
        <source>Use OK to commit your metdata changes to the epub, otherwise use Cancel.</source>
        <translation>ใช้ตกลงเพื่อยืนยันการเปลี่ยนแปลงข้อมูลเมตาของกับ epub ไม่เช่นนั้นให้ใช้ยกเลิก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="52"/>
        <source>Name</source>
        <translation>ชื่อ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="52"/>
        <source>Value</source>
        <translation>ค่า</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="171"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="234"/>
        <source>[ISBN here]</source>
        <translation>[ป้อน ISBN]</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="175"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="239"/>
        <source>[ISSN here]</source>
        <translation>[ป้อน ISSN]</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="179"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="244"/>
        <source>[DOI here]</source>
        <translation>[ป้อน DOI]</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="183"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="249"/>
        <source>[UUID here]</source>
        <translation>[ป้อน UUID]</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="194"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="267"/>
        <source>[Author name here]</source>
        <translation>[ป้อนชื่อผู้เขียน]</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="200"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="272"/>
        <source>[Creator name here]</source>
        <translation>[ป้อนชื่อผู้สร้าง]</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="204"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="276"/>
        <source>[Contributor name here]</source>
        <translation>[ป้อนชื่อผู้ร่วมให้ข้อมูล]</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="254"/>
        <source>[Custom identifier here]</source>
        <translation>[ป้อนที่กำหนดเอง]</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="443"/>
        <source>[Place value here]</source>
        <translation>[วางค่า]</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="478"/>
        <source>[Your value here]</source>
        <translation>[วางค่าของคุณ]</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="542"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="644"/>
        <source>Author</source>
        <translation>ผู้เขียน</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="542"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="644"/>
        <source>Represents a primary author of the book or publication</source>
        <translation>หมายถึงผู้ประพันธ์หลักของหนังสือหรือสิ่งพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="543"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="648"/>
        <source>Subject</source>
        <translation>เรื่อง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="543"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="648"/>
        <source>An arbitrary phrase or keyword describing the subject in question. Use multiple &apos;subject&apos; elements if needed.</source>
        <translation>วลีหรือคำอธิบายที่อธิบายเรื่องที่เป็นปัญหา ใช้องค์ประกอบ &apos;เรื่อง&apos; หลายแบบถ้าจำเป็น</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="544"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="649"/>
        <source>Description</source>
        <translation>คำอธิบาย</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="544"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="649"/>
        <source>Description of the publication&apos;s content.</source>
        <translation>คำอธิบายเนื้อหาของสิ่งพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="545"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="650"/>
        <source>Publisher</source>
        <translation>สำนักพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="545"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="650"/>
        <source>An entity responsible for making the publication available.</source>
        <translation>นิติบุคคลที่รับผิดชอบในการจัดทำสิ่งตีพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="546"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="651"/>
        <source>Date: Publication</source>
        <translation>วันที่: สิ่งพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="546"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="651"/>
        <source>The date of publication.</source>
        <translation>วันที่ตีพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="547"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="652"/>
        <source>Date: Creation</source>
        <translation>วันที่: สร้าง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="547"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="652"/>
        <source>The date of creation.</source>
        <translation>วันที่สร้าง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="548"/>
        <source>Date: Issued</source>
        <translation>วันที่: ออก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="548"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="549"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="653"/>
        <source>The date of modification.</source>
        <translation>วันที่ของการแก้ใข</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="549"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="653"/>
        <source>Date: Modification</source>
        <translation>วันที่: แก้ไข</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="550"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="654"/>
        <source>Type</source>
        <translation>ชนิด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="550"/>
        <source>Used to indicate that the given EPUB Publication is of a specialized type..</source>
        <translation>ใช้เพื่อระบุว่าสิ่งพิมพ์ EPUB มีให้เป็นประเภทพิเศษ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="551"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="655"/>
        <source>Format</source>
        <translation>รูปแบบ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="551"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="655"/>
        <source>The media type or dimensions of the publication. Best practice is to use a value from a controlled vocabulary (e.g. MIME media types).</source>
        <translation>ประเภทมีเดียหรือมิติของสิ่งพิมพ์ แนวทางปฏิบัติที่ดีที่สุดคือการใช้ค่าจากคำศัพท์ควบคุม (เช่น MIME media types)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="552"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="656"/>
        <source>Source</source>
        <translation>แหล่งที่มา</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="552"/>
        <source>Identifies the related resource(s) from which this EPUB Publication is derived.</source>
        <translation>ระบุแหล่งที่มาที่เกี่ยวข้องได้มาซึ่งสิงพิมพ์ EPUB นี้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="553"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="657"/>
        <source>Language</source>
        <translation>ภาษา</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="553"/>
        <source>Specifies the language of the publication. Select from the dropdown menu</source>
        <translation>ระบุภาษาของสิ่งตีพิมพ์ เลือกจากเมนูแบบตัวเลือก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="554"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="658"/>
        <source>Relation</source>
        <translation>Relation</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="554"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="658"/>
        <source>A reference to a related resource. The recommended best practice is to identify the referenced resource by means of a string or number conforming to a formal identification system.</source>
        <translation>การอ้างอิงถึงทรัพยากรที่เกี่ยวข้อง แนวทางปฏิบัติที่ดีที่สุดที่แนะนำคือการระบุแหล่งอ้างอิงโดยใช้สตริง หรือหมายเลขที่สอดคล้องกับระบบระบุตัวตนอย่างเป็นทางการ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="555"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="659"/>
        <source>Coverage</source>
        <translation>Coverage</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="555"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="659"/>
        <source>The extent or scope of the content of the publication&apos;s content.</source>
        <translation>ขอบเขตหรือขอบเขตของเนื้อหาเนื้อหาของสิ่งพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="556"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="660"/>
        <source>Rights</source>
        <translation>Rights</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="556"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="660"/>
        <source>Information about rights held in and over the publication. Rights information often encompasses Intellectual Property Rights (IPR), Copyright, and various Property Rights. If the Rights element is absent, no assumptions may be made about any rights held in or over the publication.</source>
        <translation>ข้อมูลเกี่ยวกับสิทธิในสิ่งพิมพ์ ข้อมูลเกี่ยวกับสิทธิมักครอบคลุมถึงสิทธิในทรัพย์สินทางปัญญา (IPR) ลิขสิทธิ์และสิทธิในทรัพย์สินต่างๆ หากไม่พบองค์ประกอบสิทธิ์จะไม่มีการตั้งสมมติฐานใด ๆ เกี่ยวกับสิทธิใด ๆ ที่ถือครองอยู่ในหรือเหนือสิ่งพิมพ์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="557"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="646"/>
        <source>Creator</source>
        <translation>Creator</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="557"/>
        <source>Represents the name of a person, organization, etc. responsible for the creation of the content of an EPUB Publication. The role property can be attached to the element to indicate the function the creator played in the creation of the content.</source>
        <translation>หมายถึงชื่อของบุคคลองค์กร ฯลฯ ที่รับผิดชอบในการสร้างเนื้อหาของ EPUB Publication คุณสามารถแนบพร็อพเพอร์ตี้บทบาทกับองค์ประกอบเพื่อระบุถึงฟังก์ชันที่ผู้สร้างเล่นในการสร้างเนื้อหา</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="558"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="647"/>
        <source>Contributor</source>
        <translation>Contributor</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="558"/>
        <source>Represents the name of a person, organization, etc. that played a secondary role in the creation of the content of an EPUB Publication. The role property can be attached to the element to indicate the function the creator played in the creation of the content.</source>
        <translation>หมายถึงชื่อของบุคคลองค์กร ฯลฯ ที่มีบทบาทรองในการสร้างเนื้อหาของ EPUB Publication คุณสามารถแนบพร็อพเพอร์ตี้บทบาทกับองค์ประกอบเพื่อระบุถึงฟังก์ชันที่ผู้สร้างเล่นในการสร้างเนื้อหา</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="559"/>
        <source>Belongs to Collection</source>
        <translation>Belongs to Collection</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="559"/>
        <source>Identifies the name of a collection to which the EPUB Publication belongs. An EPUB Publication may belong to one or more collections.</source>
        <translation>ระบุชื่อของคอลเล็กชันที่เป็น EPUB Publication EPUB Publication อาจเป็นของคอลเลกชันอย่างน้อยหนึ่งคอลเลคชัน</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="560"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="645"/>
        <source>Title</source>
        <translation>Title</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="560"/>
        <source>A title of the publication.  A publication may have only one main title but may have numerous other title types.  These include main, subtitle, short, collection, edition, and expanded title types.</source>
        <translation>ชื่อเรื่องของสิ่งตีพิมพ์ สิ่งพิมพ์อาจมีเพียงชื่อเดียว แต่อาจมีชื่ออื่น ๆ อีกมากมาย ซึ่งรวมถึงหลักคำบรรยายสั้น ๆ การรวบรวมฉบับและขยายชนิดชื่อเรื่อง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="561"/>
        <source>Identifier: DOI</source>
        <translation>Identifier: DOI</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="561"/>
        <source>Digital Object Identifier associated with the given EPUB publication.</source>
        <translation>ตัวระบุวัตถุดิจิทัลที่เชื่อมโยงกับสิ่งตีพิมพ์ EPUB ที่กำหนด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="562"/>
        <source>Identifier: ISBN</source>
        <translation>Identifier: ISBN</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="562"/>
        <source>International Standard Book Number associated with the given EPUB publication.</source>
        <translation>หมายเลขหนังสือมาตรฐานสากลที่เชื่อมโยงกับสิ่งพิมพ์ EPUB ที่กำหนด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="563"/>
        <source>Identifier: ISSN</source>
        <translation>Identifier: ISSN</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="563"/>
        <source>International Standard Serial Number associated with the given EPUB publication.</source>
        <translation>หมายเลขประจำผลิตภัณฑ์มาตรฐานสากลที่เชื่อมโยงกับสิ่งพิมพ์ EPUB ที่ระบุ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="564"/>
        <source>Identifier: UUID</source>
        <translation>Identifier: UUID</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="564"/>
        <source>A Universally Unique Idenitifier generated for this EPUB publication.</source>
        <translation>Unified Unique Idenitifier ที่สร้างขึ้นสำหรับสิ่งพิมพ์ EPUB นี้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="566"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="669"/>
        <source>Custom Element</source>
        <translation>องค์ประกอบที่กำหนดเอง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="566"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="669"/>
        <source>[Custom element]</source>
        <translation>[องค์ประกอบที่กำหนดเอง]</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="566"/>
        <source>An empty metadata element you can modify.</source>
        <translation>องค์ประกอบข้อมูลเมตาที่ว่างเปล่าที่คุณสามารถแก้ไขได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="593"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="696"/>
        <source>Id Attribute</source>
        <translation>Id Attribute</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="593"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="696"/>
        <source>Optional, typically short, unique identifier string used as an attribute in the Package (opf) document.</source>
        <translation>ตัวเลือกสตริงตัวระบุที่สั้นและไม่เหมือนใครใช้เป็นแอตทริบิวต์ในเอกสาร Package (opf)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="594"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="697"/>
        <source>XML Language</source>
        <translation>XML Language</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="594"/>
        <source>Optional, language specifying attribute.  Uses same codes as dc:language. Not for use with dc:langauge, dc:date, or dc:identifier metadata elements.</source>
        <translation>แอตทริบิวต์การระบุภาษาที่เป็นตัวเลือก ใช้รหัสเดียวกันกับ dc:language ไม่ใช้กับ dc:langauge, dc:date dc:identifier ข้อมูล metadata</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="595"/>
        <source>Text Direction: rtl</source>
        <translation>Text Direction: rtl</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="595"/>
        <source>Optional text direction attribute for this metadata item. right-to-left (rtl). Not for use with dc:language, dc:date, or dc:identifier metadata elements.</source>
        <translation>แอตทริบิวต์ทิศทางข้อความเสริมสำหรับรายการข้อมูลเมตานี้ ขวาไปซ้าย (rtl) ไม่ใช้กับ dc: language, dc: date หรือ dc: identifier metadata elements</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="596"/>
        <source>Text Direction: ltr</source>
        <translation>Text Direction: ltr</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="596"/>
        <source>Optional text direction attribute for this metadata item. left-to-right (ltr). Not for use with dc:language, dc:date, or dc:identifier metadata elements.</source>
        <translation>แอตทริบิวต์ทิศทางข้อความเสริมสำหรับรายการข้อมูลเมตานี้ ซ้ายไปขวา (ltr) ไม่ใช้กับ dc: language, dc: date หรือ dc: identifier metadata elements</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="597"/>
        <source>Title Type: main</source>
        <translation>Title Type: main</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="597"/>
        <source>Indicates the associated title is the main title of the publication.  Only one main title should exist.</source>
        <translation>ระบุชื่อที่เกี่ยวข้องเป็นชื่อหลักของสิ่งตีพิมพ์ ควรมีเพียงชื่อเดียวเท่านั้น</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="598"/>
        <source>Title Type: subtitle</source>
        <translation>Title Type: subtitle</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="598"/>
        <source>Indicates that the associated title is a subtitle of the publication if one exists..</source>
        <translation>ระบุว่าชื่อที่เกี่ยวข้องเป็นคำบรรยายของสิ่งพิมพ์ถ้ามีอยู่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="599"/>
        <source>Title Type: short</source>
        <translation>Title Type: short</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="599"/>
        <source>Indicates that the associated title is a shortened title of the publication if one exists.</source>
        <translation>ระบุว่าชื่อที่เกี่ยวข้องเป็นชื่อสั้นของสิ่งตีพิมพ์หากมีอยู่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="600"/>
        <source>Title Type: collection</source>
        <translation>Title Type: collection</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="600"/>
        <source>Indicates that the associated title is the title of a collection that includes this publication belongs to, if one exists.</source>
        <translation>ระบุว่าชื่อที่เกี่ยวข้องเป็นชื่อของคอลเล็กชันที่มีสิ่งพิมพ์นี้เป็นของถ้ามีอยู่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="601"/>
        <source>Title Type: edition</source>
        <translation>Title Type: edition</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="601"/>
        <source>Indicates that the associated title is an edition title for this publications if one exists.</source>
        <translation>ระบุว่าชื่อที่เชื่อมโยงเป็นชื่อฉบับสำหรับสิ่งพิมพ์นี้ถ้ามีอยู่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="602"/>
        <source>Title Type: expanded</source>
        <translation>Title Type: expanded</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="602"/>
        <source>Indicates that the associated title is an expanded title for this publication if one exists.</source>
        <translation>ระบุว่าชื่อที่เชื่อมโยงเป็นชื่อที่ขยายสำหรับสิ่งพิมพ์นี้หากมีอยู่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="603"/>
        <source>Alternate Script</source>
        <translation>Alternate Script</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="603"/>
        <source>Provides an alternate expression of the associated property value in a language and script identified by an alternate-language attribute.</source>
        <translation>แสดงนิพจน์อื่นของค่าคุณสมบัติที่เกี่ยวข้องในภาษาและสคริปต์ที่ระบุโดยแอตทริบิวต์ภาษาอื่น</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="604"/>
        <source>Alternate Language</source>
        <translation>Alternate Language</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="604"/>
        <source>Language code for the language used in the associated alternate-script property value.</source>
        <translation>รหัสภาษาสำหรับภาษาที่ใช้ในค่าคุณสมบัติสคริปต์ alternate ที่เชื่อมโยง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="605"/>
        <source>Collection Type: set</source>
        <translation>Collection Type: set</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="605"/>
        <source>Property used with belongs-to-collection. Indicates the form or nature of a collection. The value &apos;set&apos; should be used for a finite collection of works that together constitute a single intellectual unit; typically issued together and able to be sold as a unit..</source>
        <translation>ทรัพย์สินที่ใช้กับการเก็บรวบรวมเป็นของสะสม ระบุรูปแบบหรือลักษณะของคอลเล็กชัน ควรตั้งค่า &quot;ชุด&quot; สำหรับการเก็บรวบรวมผลงานที่ จำกัด ซึ่งเป็นหน่วยทางปัญญาเพียงชุดเดียว ออกโดยทั่วไปและสามารถขายเป็นหน่วย ..</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="606"/>
        <source>Collection Type: series</source>
        <translation>Collection Type: series</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="606"/>
        <source>Property used with belongs-to-collection. Indicates the form or nature of a collection. The value &apos;series&apos;&apos; should be used for a sequence of related works that are formally identified as a group; typically open-ended with works issued individually over time.</source>
        <translation>ทรัพย์สินที่ใช้กับการเก็บรวบรวมเป็นของสะสม ระบุรูปแบบหรือลักษณะของคอลเล็กชัน ควรใช้ชุดค่า &apos;ซีรีส์&apos; สำหรับชุดของผลงานที่เกี่ยวข้องซึ่งได้รับการระบุอย่างเป็นทางการเป็นกลุ่ม โดยทั่วไปแล้วจะเป็นแบบเปิดกว้างซึ่งมีผลงานออกมาทีละครั้ง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="607"/>
        <source>Display Sequence</source>
        <translation>Display Sequence</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="607"/>
        <source>Indicates the numeric position in which to display the current property relative to identical metadata properties (e.g., to indicate the order in which to render multiple titles or multiple authors).</source>
        <translation>ระบุตำแหน่งตัวเลขที่จะแสดงพร็อพเพอร์ตี้ปัจจุบันที่สัมพันธ์กับคุณสมบัติของเมทาดาตที่เหมือนกัน (เช่นเพื่อระบุลำดับการแสดงผลหลายชื่อหรือผู้แต่งหลายคน)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="608"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="698"/>
        <source>File as</source>
        <translation>File as</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="608"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="698"/>
        <source>Provides the normalized form of the associated property for sorting. Typically used with author, creator, and contributor names.</source>
        <translation>ให้รูปแบบปกติของคุณสมบัติที่เกี่ยวข้องสำหรับการเรียงลำดับ ใช้โดยทั่วไปกับชื่อผู้สร้างผู้สร้างและผู้ร่วมเขียนข้อความ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="609"/>
        <source>Group Position</source>
        <translation>Group Position</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="609"/>
        <source>Indicates the numeric position in which the EPUB Publication is ordered relative to other works belonging to the same group (whether all EPUB Publications or not).</source>
        <translation>ระบุตำแหน่งตัวเลขที่ EPUB Publication ถูกสั่งให้เทียบกับงานอื่น ๆ ที่อยู่ในกลุ่มเดียวกัน (ไม่ว่าจะเป็น EPUB Publications หรือไม่ก็ตาม)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="610"/>
        <source>Identifier Type</source>
        <translation>Identifier Type</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="610"/>
        <source>Indicates the form or nature of an identifier. When the identifier-type value is drawn from a code list or other formal enumeration, the scheme attribute should be used to identify its source.</source>
        <translation>บ่งชี้รูปหรือลักษณะของตัวระบุ เมื่อระบุค่าประเภทตัวระบุจากรายการรหัสหรือการแจงนับเป็นทางการอื่น ๆ ควรใช้แอตทริบิวต์ scheme เพื่อระบุแหล่งที่มา</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="611"/>
        <source>Meta Authority</source>
        <translation>Meta Authority</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="611"/>
        <source>Identifies the party or authority responsible for an instance of package metadata.</source>
        <translation>ระบุบุคคลหรือหน่วยงานที่รับผิดชอบต่ออินสแตนซ์ของข้อมูลเมตาของแพคเกจ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="612"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="699"/>
        <source>Role</source>
        <translation>Role</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="612"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="699"/>
        <source>Describes the nature of work performed by a creator or contributor (e.g., that the person is the author or editor of a work).  Typically used with the marc:relators scheme for a controlled vocabulary.</source>
        <translation>อธิบายลักษณะของงานที่ทำโดยผู้สร้างหรือผู้ร่วมให้ข้อมูล (เช่นว่าบุคคลนั้นเป็นผู้เขียนหรือผู้แก้ไขงาน) โดยปกติจะใช้กับรูปแบบ marc:relators สำหรับคำศัพท์ควบคุม</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="613"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="700"/>
        <source>Scheme</source>
        <translation>Scheme</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="613"/>
        <source>This attribute is typically added to dc:identifier, dc:source: dc:creator, or dc:contributor to indicate the controlled vocabulary system employed. (e.g. marc:relators to specify valid values for the role property.</source>
        <translation>แอตทริบิวต์นี้จะเพิ่มเป็น dc:identifier, dc:source: dc:creator หรือ dc:contributor เพื่อระบุระบบคำศัพท์ที่ควบคุม (เช่น marc:relators เพื่อระบุค่าที่ถูกต้องสำหรับคุณสมบัติ Role</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="614"/>
        <source>Source of Pagination</source>
        <translation>Source of Pagination</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="614"/>
        <source>Indicates a unique aspect of an adapted source resource that has been retained in the given Rendition of the EPUB Publication. This specification defines the pagination value to indicate that the referenced source element is the source of the pagebreak properties defined in the content. This value should be set whenever pagination is included and the print source is known. Valid values: pagination.</source>
        <translation>บ่งบอกถึงลักษณะเฉพาะของแหล่งข้อมูลที่ปรับเปลี่ยนมาซึ่งได้รับการเก็บรักษาไว้ในการตีความของ EPUB Publication ข้อกำหนดนี้กำหนดค่าการแบ่งหน้าเพื่อระบุว่าอิลิเมนต์ต้นทางที่อ้างถึงเป็นแหล่งที่มา ของคุณสมบัติการแบ่งหน้าที่กำหนดไว้ในเนื้อหา ค่านี้ควรตั้งค่าเมื่อรวมเลขหน้าและแหล่งที่มาของงานพิมพ์เป็นที่รู้จัก ค่าที่ถูกต้อง: pagination</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="615"/>
        <source>Custom Property</source>
        <translation>องค์ประกอบที่กำหนดเอง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="615"/>
        <source>[Custom property/attribute]</source>
        <translation>[องค์ประกอบ/แอตทริบิวต์ที่กำหนดเอง]</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="615"/>
        <source>An empty metadata property or attribute you can modify.</source>
        <translation>คุณสมบัติหรือแอตทริบิวต์ของข้อมูลเมตาที่ว่างเปล่าคุณสามารถแก้ไขได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="645"/>
        <source>The main title of the epub publication.  Only one title may exist.</source>
        <translation>ชื่อเรื่องหลักของการตีพิมพ์ epub อาจมีเพียงชื่อเดียวเท่านั้น</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="646"/>
        <source>Represents the name of a person, organization, etc. responsible for the creation of the content of an EPUB Publication. The attributes opf:role, opf:scheme and opf:file-as can be attached to the element to indicate the function the creator played in the creation of the content.</source>
        <translation>หมายถึงชื่อของบุคคลองค์กร ฯลฯ ที่รับผิดชอบในการสร้างเนื้อหาของสิงพิมพ์ EPUB คุณลักษณะ opf: role, opf: scheme และ opf: file-as สามารถแนบไปกับ element เพื่อระบุถึงฟังก์ชันที่ผู้สร้างเล่นในการสร้างเนื้อหา</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="647"/>
        <source>Represents the name of a person, organization, etc. that played a secondary role in the creation of the content of an EPUB Publication&apos;</source>
        <translation>หมายถึงชื่อของบุคคลองค์กร ฯลฯ ที่มีบทบาทรองในการสร้างเนื้อหาของสิงพิมพ์ EPUB</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="654"/>
        <source>The nature or genre of the content of the resource.</source>
        <translation>ลักษณะหรือประเภทของเนื้อหาของแหล่งอ้างอิง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="656"/>
        <source>A reference to a resource from which the present publication is derived.</source>
        <translation>การอ้างอิงไปยังแหล่งอ้างอิงที่มีการตีพิมพ์ในปัจจุบัน</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="657"/>
        <source>A language used in the publication. Choose a RFC5646 value.</source>
        <translation>ภาษาที่ใช้ในการตีพิมพ์ เลือกค่า RFC5646</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="661"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="662"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="663"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="664"/>
        <source>Identifier</source>
        <translation>ตัวบ่งชี้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="661"/>
        <source>Digital Object Identifier</source>
        <translation>ตัวระบุวัตถุดิจิทัล</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="662"/>
        <source>International Standard Book Number</source>
        <translation>หมายเลขหนังสือมาตรฐานสากล</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="663"/>
        <source>International Standard Serial Number</source>
        <translation>หมายเลขผลิตภัณฑ์มาตรฐานสากล</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="664"/>
        <source>Universally Unique Identifier</source>
        <translation>ตัวบ่งชี้ที่ไม่ซ้ำกันในระดับสากล</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="665"/>
        <source>Identifier: Custom</source>
        <translation>ตัวบ่งชี้: กำหนดเอง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="665"/>
        <source>A custom identifier based on a specified scheme</source>
        <translation>ตัวระบุที่กำหนดเองตามรูปแบบที่ระบุ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="666"/>
        <source>Series</source>
        <translation>ซีรีส์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="666"/>
        <source>Series title or name (from calibre)</source>
        <translation>ชื่อหรือชื่อของซีรีส์ (จากcalibre)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="667"/>
        <source>Series Index</source>
        <translation>ดัชนีซีรี่ส์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="667"/>
        <source>Index of this book in the series (from calibre)</source>
        <translation>ดัชนีของหนังสือเล่มนี้ในซีรีส์ (จากcalibre)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="668"/>
        <source>Title for Sorting</source>
        <translation>ชื่อสำหรับการเรียงลำดับ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="668"/>
        <source>Version of ebook title to use for sorting(from calibre)</source>
        <translation>รุ่นของชื่อ ebook ที่จะใช้สำหรับการเรียงลำดับ (จากcalibre)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="669"/>
        <source>An empty metadata element for you to modify</source>
        <translation>องค์ประกอบข้อมูลเมตาที่ว่างเปล่าสำหรับให้คุณแก้ไข</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="697"/>
        <source>Optional, language specifying attribute.  Uses same codes as dc:language. Not for use with dc:language, dc:date, or dc:identifier metadata elements.</source>
        <translation>แอตทริบิวต์ระบุภาษาที่ระบุ ใช้รหัสเดียวกันกับ dc: language ไม่ใช้กับ dc: language, dc: date หรือ dc: identifier metadata elements</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="700"/>
        <source>This attribute is typically added to dc:identifier to indicate the type of identifier being used: DOI, ISBN, ISSN, or UUID.</source>
        <translation>แอตทริบิวต์นี้มักจะถูกเพิ่มลงใน dc:identifier เพื่อระบุประเภทของตัวระบุที่ใช้: DOI, ISBN, ISSN หรือ UUID</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="701"/>
        <source>Event</source>
        <translation>เหตุการณ์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="701"/>
        <source>This attribute is typically added to dc:date elements to specify the date type: publication, creation, or modification.</source>
        <translation>แอตทริบิวต์นี้จะถูกเพิ่มเป็น dc:date elements เพื่อระบุประเภทวันที่: publication, creation หรือ modification</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="702"/>
        <source>Custom Attribute</source>
        <translation>แอตทริบิวต์ที่กำหนดเอง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="702"/>
        <source>[Custom metadata property/attribute]</source>
        <translation>[คุณสมบัติเมตาดาต้าที่กำหนดเอง/แอตทริบิวต์]</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="702"/>
        <source>An empty metadata attribute you can modify.</source>
        <translation>แอตทริบิวต์ข้อมูลเมตาที่ว่างเปล่าที่คุณสามารถแก้ไขได้</translation>
    </message>
</context>
<context>
    <name>NCXResource</name>
    <message>
        <location filename="../../ResourceObjects/NCXResource.cpp" line="159"/>
        <location filename="../../ResourceObjects/NCXResource.cpp" line="161"/>
        <source>Start</source>
        <translation>เริ่ม</translation>
    </message>
</context>
<context>
    <name>OPFModel</name>
    <message>
        <location filename="../../MainUI/OPFModel.cpp" line="595"/>
        <source>A filename cannot contains the character &quot;%1&quot;.</source>
        <translation>ชื่อไฟล์ไม่สามารถมีอักขระ &quot;%1&quot;</translation>
    </message>
    <message>
        <location filename="../../MainUI/OPFModel.cpp" line="606"/>
        <source>The filename cannot be empty.</source>
        <translation>ชื่อไฟล์ต้องไม่ว่างเปล่า</translation>
    </message>
    <message>
        <location filename="../../MainUI/OPFModel.cpp" line="613"/>
        <source>The filename &quot;%1&quot; is already in use.
</source>
        <translation>ชื่อไฟล์ &quot;%1&quot; มีการใช้งานอยู่แล้ว
</translation>
    </message>
</context>
<context>
    <name>OPFResource</name>
    <message>
        <location filename="../../ResourceObjects/OPFResource.cpp" line="1118"/>
        <source>[Title here]</source>
        <translation>[ป้อนหัวเรื่อง]</translation>
    </message>
    <message>
        <location filename="../../ResourceObjects/OPFResource.cpp" line="1120"/>
        <source>[Main title here]</source>
        <translation>[ป้อนหัวเรื่องหลัก]</translation>
    </message>
</context>
<context>
    <name>OpenWithName</name>
    <message>
        <location filename="../../Form_Files/OpenWithName.ui" line="14"/>
        <source>Open With Application Name</source>
        <translation>เปิดด้วยแอ็พพลิเคชันชื่อ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/OpenWithName.ui" line="20"/>
        <source>Enter the name to display in the Open With menu for this application:</source>
        <translation>ป้อนชื่อที่จะแสดงในเมนูเปิดด้วยสำหรับแอปพลิเคชันนี้:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/OpenWithName.ui" line="48"/>
        <source>Filename:</source>
        <translation>ชื่อไฟล์:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/OpenWithName.ui" line="55"/>
        <source>Menu Name:</source>
        <translation>ชื่อเมนู:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/OpenWithName.ui" line="62"/>
        <source>No File</source>
        <translation>ไม่มีไฟล์</translation>
    </message>
</context>
<context>
    <name>PluginRunner</name>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="14"/>
        <source>Plugin Runner</source>
        <translation>ส่วนเสริมกำลังทำงาน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="28"/>
        <source>Plugin:</source>
        <translation>ส่วนเสริม:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="48"/>
        <source>Start</source>
        <translation>เริ่ม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="61"/>
        <source>Cancel</source>
        <translation>ยกเลิก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="90"/>
        <source>Message</source>
        <translation>ข่าวสาร</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="103"/>
        <source>Details...</source>
        <translation>รายละเอียด...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="110"/>
        <source>OK</source>
        <translation>ตกลง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="139"/>
        <source>Status: </source>
        <translation>สถานะ: </translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="104"/>
        <source>Error: A plugin by that name does not exist</source>
        <translation>ข้อผิดพลาด: ส่วนเสริมชื่อนี้ไม่มี</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="135"/>
        <source>Error: Interpreter</source>
        <translation>ข้อผิดพลาด: Interpreter</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="135"/>
        <source>has no path set</source>
        <translation>ยังไม่มีเส้นทางที่กำหนด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="148"/>
        <source>Installation Error: plugin launcher</source>
        <translation>ข้อผิดพลาดในการติดตั้ง: ปลั๊กอิน launcher</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="149"/>
        <source>does not exist</source>
        <translation>ไม่มีอยู่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="154"/>
        <source>Error: plugin engine</source>
        <translation>ข้อผิดพลาด: ปลั๊กอิน engine</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="155"/>
        <source>is not supported (yet!)</source>
        <translation>ไม่สนับสนุน (ยัง!)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="161"/>
        <source>Status: ready</source>
        <translation>สถานะ: พร้อมแล้ว</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="223"/>
        <source>Error: plugin can not start</source>
        <translation>ข้อผิดพลาด: ส่วนเสริมไม่สามารถเริ่มต้นได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="371"/>
        <source>Status: running</source>
        <translation>สถานะ: กำลังทำงาน</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="388"/>
        <source>Launcher process crashed</source>
        <translation>กระบวนการเปิดใช้งานล้มเหลว</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="399"/>
        <source>Status: finished</source>
        <translation>สถานะ: เสร็จแล้ว</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="406"/>
        <source>Status: failed</source>
        <translation>สถานะ: ล้มเหลว</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="412"/>
        <location filename="../../Dialogs/PluginRunner.cpp" line="421"/>
        <source>Status: No Changes Made</source>
        <translation>สถานะ: ไม่มีการเปลี่ยนแปลงเกิดขึ้น</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="420"/>
        <source>Error: Plugin Tried to Remove the Last XHTML file .. aborting changes</source>
        <translation>ข้อผิดพลาด: ปลั๊กอินพยายามลบไฟล์ XHTML ล่าสุด .. ยกเลิกการเปลี่ยนแปลง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="484"/>
        <location filename="../../Dialogs/PluginRunner.cpp" line="555"/>
        <source>Status:</source>
        <translation>สถานะ:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="511"/>
        <source>Plugin failed to start</source>
        <translation>ส่วนเสริมล้มเหลวในการเริ่มต้น</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="519"/>
        <source>Status: error</source>
        <translation>สถานะ: ผิดพลาด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="533"/>
        <source>Plugin cancelled</source>
        <translation>ส่วนเสริมถูกยกเลิก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="534"/>
        <source>Status: cancelled</source>
        <translation>สถานะ: ถูกยกเลิก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="627"/>
        <source>Error Parsing Result XML:  </source>
        <translation>ข้อผิดพลาดในการแยกวิเคราะห์ผล XML:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="684"/>
        <location filename="../../Dialogs/PluginRunner.cpp" line="699"/>
        <source>Status: checking</source>
        <translation>สถานะ: กำลังตรวจสอบ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="688"/>
        <source>Incorrect XHTML:</source>
        <translation>XHTML ไม่ถูกต้อง:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="688"/>
        <source>Line/Col</source>
        <translation>บรรทัด/คอลัมน์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="715"/>
        <source>Check Report</source>
        <translation>ตรวจสอบรายงาน</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="716"/>
        <source>Incorrect XHTML/XML Detected
Are you Sure You Want to Continue?</source>
        <translation>ตรวจพบ XHTML / XML ไม่ถูกต้อง
คุณแน่ใจหรือไม่ ว่าคุณต้องการดำเนินการต่อ?</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="734"/>
        <source>Status: cleaning up - deleting files</source>
        <translation>สถานะ: กำลังทำความสะอาด - ลบไฟล์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="759"/>
        <source>Status: deleting</source>
        <translation>สถานะ: กำลังลบ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="798"/>
        <source>Status: Loading</source>
        <translation>สถานะ: กำลังอ่าน</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="809"/>
        <source>Input Plugin</source>
        <translation>ใส่ส่วนเสริม</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="810"/>
        <source>Your current book will be completely replaced losing any unsaved changes ...  Are you sure you want to proceed</source>
        <translation>หนังสือเล่มปัจจุบันของคุณจะถูกแทนที่โดยสมบูรณ์ซึ่งจะสูญเสียการเปลี่ยนแปลงที่ไม่ได้บันทึกไว้ ... คุณแน่ใจหรือไม่ว่าต้องการดำเนินการต่อ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="836"/>
        <source>Status: adding</source>
        <translation>สถานะ: กำลังเพิ่ม</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="877"/>
        <source>Status: cleaning up - modifying files</source>
        <translation>สถานะ: กำลังทำความสะอาด - แก้ใขไฟล์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="906"/>
        <source>Status: modifying</source>
        <translation>สถานะ: กำลังปรับเปลี่ยน</translation>
    </message>
</context>
<context>
    <name>PluginWidget</name>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="14"/>
        <location filename="../../Form_Files/PPluginWidget.ui" line="167"/>
        <source>Plugins</source>
        <translation>ส่วนเสริม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="28"/>
        <source>Assign as Plugin 1</source>
        <translation>กำหนดให้เป็นส่วนเสริม 1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="75"/>
        <source>Name</source>
        <translation>ชื่อ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="80"/>
        <source>Version</source>
        <translation>รุ่น</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="85"/>
        <source>Author</source>
        <translation>Author</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="90"/>
        <source>Type</source>
        <translation>ชนิด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="95"/>
        <source>Interpreter</source>
        <translation>ตัวแปลภาษา </translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="109"/>
        <source>≥Python3.4:</source>
        <translation>≥Python3.4:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="128"/>
        <source>Auto</source>
        <translation>อัตโมัติ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="135"/>
        <source>Set</source>
        <translation>กำหนด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="174"/>
        <source>Add Plugin</source>
        <translation>เพิ่มส่วนเสริม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="181"/>
        <source>Remove All</source>
        <translation>นำออกทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="188"/>
        <source>Remove Plugin</source>
        <translation>ลบส่วนเสริม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="214"/>
        <source>Path to Interpreter Executable</source>
        <translation>เส้นทางตัวแปลภาษา </translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="224"/>
        <source>Should the bundled Python interpreter be used if present?</source>
        <translation>ใช้แปลภาษา  Python ที่มีมาจะใช้ในกรณีปัจจุบัน?</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="227"/>
        <source>Use Bundled Python</source>
        <translation>ใช้ Python ที่มีมา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="234"/>
        <source>Assign as Plugin 2</source>
        <translation>กำหนดให้เป็นส่วนเสริม 2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="241"/>
        <source>Assign as Plugin 3</source>
        <translation>กำหนดให้เป็นส่วนเสริม 3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="248"/>
        <source>Assign as Plugin 4</source>
        <translation>กำหนดให้เป็นส่วนเสริม 4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="255"/>
        <source>Assign as Plugin 5</source>
        <translation>กำหนดให้เป็นส่วนเสริม 5</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="184"/>
        <source>Select Plugin Zip Archive</source>
        <translation>เลือกส่วนเสริมไฟล์ Zip</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="184"/>
        <source>Plugin Files (*.zip)</source>
        <translation>ไฟส่วนเสริม (*.zip)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="200"/>
        <source>Error: Plugin plugin.xml is invalid or not supported on your operating system.</source>
        <translation>ข้อผิดพลาด: ส่วนเสริม plugin.xml ไม่ถูกต้องหรือไม่ได้รับการสนับสนุนบนระบบปฏิบัติการของคุณ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="203"/>
        <source>Warning: A plugin by that name already exists</source>
        <translation>คำเตือน: มีส่วนเสริมชื่อนี้อยู่แล้ว</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="206"/>
        <source>Error: Plugin Could Not be Unzipped.</source>
        <translation>ข้อผิดพลาด: ไม่สามารถคลายซิปส่วนเสริมได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="209"/>
        <source>Error: Plugin not a valid Sigil plugin.</source>
        <translation>ข้อผิดพลาด: ส่วนเสริมไม่ใช่ส่วนเสริม Sigil ที่ถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="249"/>
        <source>Nothing is Selected.</source>
        <translation>ไม่มีการเลือก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="307"/>
        <source>Remove All Plugins</source>
        <translation>ลบส่วนเสริมทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="308"/>
        <source>Are you sure sure you want to remove all of your plugins?</source>
        <translation>คุณแน่ใจหรือไม่ว่าต้องการจะลบส่วนเสริมทั้งหมด?</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="366"/>
        <source>Select Interpreter</source>
        <translation>เลือกตัวแปลภาษา </translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="391"/>
        <source>Incorrect Interpreter Path selected</source>
        <translation>เส้นทางตัวแปลที่เลือกไม่ถูกต้อง</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../../Form_Files/Preferences.ui" line="14"/>
        <source>Preferences</source>
        <translation>การตั้งค่า</translation>
    </message>
    <message>
        <location filename="../../Dialogs/Preferences.cpp" line="102"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/Preferences.cpp" line="102"/>
        <source>Changes will take effect when you restart Sigil.</source>
        <translation>การเปลี่ยนแปลงจะมีผลเมื่อคุณเริ่มต้น Sigil ใหม่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/Preferences.cpp" line="174"/>
        <source>Open Preferences Location</source>
        <translation>เปิดสถานที่ตั้งของการตั้งค่า</translation>
    </message>
</context>
<context>
    <name>PreserveEntitiesWidget</name>
    <message>
        <location filename="../../Form_Files/PPreserveEntitiesWidget.ui" line="14"/>
        <source>Preserve Entities</source>
        <translation>เก็บรายการ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPreserveEntitiesWidget.ui" line="32"/>
        <source>Entities to Preserve</source>
        <translation>รายการที่เก็บ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPreserveEntitiesWidget.ui" line="47"/>
        <source>Enter or paste entities to add to the list.
Entities can be separated by lines, commas, or spaces.</source>
        <translation>ป้อนหรือวางเอนทิตีเพื่อเพิ่มลงในรายการ
เอนทิตีสามารถคั่นด้วยบรรทัดเครื่องหมายจุลภาคหรือช่องว่าง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPreserveEntitiesWidget.ui" line="51"/>
        <source>Add</source>
        <translation>เพิ่ม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPreserveEntitiesWidget.ui" line="58"/>
        <source>Remove</source>
        <translation>นำออก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPreserveEntitiesWidget.ui" line="65"/>
        <source>Remove All</source>
        <translation>นำออกทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PreserveEntitiesWidget.cpp" line="63"/>
        <source>Add Entities</source>
        <translation>เพิ่มรายการ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PreserveEntitiesWidget.cpp" line="63"/>
        <source>Entities:</source>
        <translation>รายการ:</translation>
    </message>
</context>
<context>
    <name>PreviewWindow</name>
    <message>
        <location filename="../../MainUI/PreviewWindow.cpp" line="43"/>
        <location filename="../../MainUI/PreviewWindow.cpp" line="260"/>
        <source>Preview</source>
        <translation>ตัวอย่าง</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../BookManipulation/Book.cpp" line="1051"/>
        <source>Merging Files..</source>
        <translation>กำลังรวมไฟล์..</translation>
    </message>
    <message>
        <location filename="../../BookManipulation/BookReports.cpp" line="53"/>
        <location filename="../../BookManipulation/BookReports.cpp" line="124"/>
        <source>Collecting classes...</source>
        <translation>กำลังรวบรวมคลาส...</translation>
    </message>
    <message>
        <location filename="../../BookManipulation/CleanSource.cpp" line="292"/>
        <source>Cleaning...</source>
        <translation>กำลังทำความสะอาด...</translation>
    </message>
    <message>
        <location filename="../../BookManipulation/Index.cpp" line="47"/>
        <source>Creating Index...</source>
        <translation>กำลังสร้างดัชนี...</translation>
    </message>
    <message>
        <location filename="../../BookManipulation/Index.cpp" line="47"/>
        <source>Cancel</source>
        <translation>ยกเลิก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/Reports.cpp" line="115"/>
        <source>Creating reports...</source>
        <translation>กำลังสร้างรายงาน...</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="112"/>
        <source>Cannot read EPUB: %1</source>
        <translation>ไม่สามารถอ่าน EPUB: %1</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="222"/>
        <source>The OPF file does not contain a valid spine.</source>
        <translation>ไฟล์ OPF ไม่มีส่วนประกอบที่ถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="223"/>
        <location filename="../../Importers/ImportEPUB.cpp" line="760"/>
        <location filename="../../Importers/ImportEPUB.cpp" line="763"/>
        <source>Sigil has created a new one for you.</source>
        <translation>Sigil ได้สร้างใหม่สำหรับคุณ</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="260"/>
        <source>Error parsing encryption xml.
Line: %1 Column %2 - %3</source>
        <translation>เกิดข้อผิดพลาดในการแยกวิเคราะห์การเข้ารหัส xml
บบรทัด: %1 คอลัมน์ %2 - %3</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="392"/>
        <source>Cannot unzip EPUB: %1</source>
        <translation>ไม่สามารถแยกซิปไฟล์ EPUB: %1</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="432"/>
        <location filename="../../Importers/ImportEPUB.cpp" line="441"/>
        <location filename="../../Importers/ImportEPUB.cpp" line="458"/>
        <location filename="../../Importers/ImportEPUB.cpp" line="466"/>
        <source>Cannot extract file: %1</source>
        <translation>ไม่สามารถแยกซิปไฟล์: %1</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="479"/>
        <source>Cannot open EPUB: %1</source>
        <translation>ไม่สามารถเปิด EPUB: %1</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="531"/>
        <source>Unable to parse container.xml file.
Line: %1 Column %2 - %3</source>
        <translation>ไม่สามารถแยกวิเคราะห์ไฟล์ containers.xml
บรรทัด: %1 คอลัมน์ %2 - %3</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="539"/>
        <source>No appropriate OPF file found</source>
        <translation>ไม่พบไฟล์ที่สมควรเป็น OPF</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="590"/>
        <source>Unable to read OPF file.
Line: %1 Column %2 - %3</source>
        <translation>ไม่สามารถอ่านไฟล์ OPF ได้
บรรทัด: %1 คอลัมน์ %2 - %3</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="681"/>
        <source>The OPF manifest contains duplicate ids for: %1</source>
        <translation>ไฟล์ Manifest OPF มีรหัสที่ซ้ำกันสำหรับ: %1</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="682"/>
        <source>A temporary id has been assigned to load this EPUB. You should edit your OPF file to remove the duplication.</source>
        <translation>มีการกำหนดรหัสชั่วคราวเพื่อโหลด EPUB นี้ คุณควรแก้ไขไฟล์ OPF เพื่อลบการทำซ้ำ</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="726"/>
        <source>The OPF file did not identify the NCX file correctly.</source>
        <translation>ไฟล์ OPF ไม่ได้ระบุไฟล์ NCX อย่างถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="727"/>
        <source>Sigil has used the following file as the NCX:</source>
        <translation>Sigil ใช้ไฟล์ต่อไปนี้เป็น NCX:</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="755"/>
        <source>Sigil has created a template NCX</source>
        <translation>Sigil ได้สร้างแม่แบบ NCX</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="756"/>
        <source>to support epub2 backwards compatibility.</source>
        <translation>เพื่อสนับสนุนความเข้ากันได้ของ epub2</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="759"/>
        <source>The OPF file does not contain an NCX file.</source>
        <translation>ไฟล์ OPF ไม่มีไฟล์ NCX</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="762"/>
        <source>The NCX file is not present in this EPUB.</source>
        <translation>ไฟล์ NCX ไม่มีอยู่ใน EPUB นี้</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="582"/>
        <source>Adding Existing Files..</source>
        <translation>เพิ่มไฟล์ที่มี...</translation>
    </message>
    <message>
        <location filename="../../Misc/OpenExternally.cpp" line="196"/>
        <source>Applications</source>
        <translation>แอพพลิเคชัน</translation>
    </message>
    <message>
        <location filename="../../Misc/OpenExternally.cpp" line="206"/>
        <source>Open With</source>
        <translation>เปิดด้วย</translation>
    </message>
    <message>
        <location filename="../../Misc/SearchOperations.cpp" line="44"/>
        <source>Counting occurrences..</source>
        <translation>นับเหตุการณ์ที่เกิดขึ้น..</translation>
    </message>
    <message>
        <location filename="../../Misc/SearchOperations.cpp" line="64"/>
        <source>Replacing search term...</source>
        <translation>กำลังแทนที่คำค้นหา...</translation>
    </message>
    <message>
        <location filename="../../Misc/TOCHTMLWriter.cpp" line="105"/>
        <source>Table of Contents</source>
        <translation>สารบัญ</translation>
    </message>
    <message>
        <location filename="../../Misc/UpdateChecker.cpp" line="97"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Misc/UpdateChecker.cpp" line="98"/>
        <source>&lt;p&gt;A newer version of Sigil is available, version &lt;b&gt;%1&lt;/b&gt;.&lt;br/&gt;&lt;p&gt;Would you like to go to the download page?&lt;/p&gt;</source>
        <translation>&lt;p&gt;มี Sigil รุ่นใหม่กว่าออกแล้ว รุ่น&lt;b&gt;%1&lt;/b&gt;.&lt;br/&gt;&lt;p&gt;คุณต้องการไปที่หน้าดาวน์โหลดหรือไม่?&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Misc/Utility.cpp" line="428"/>
        <source>Cannot read file %1:
%2.</source>
        <translation>ไม่สามารถไฟล์ %1:
%2</translation>
    </message>
    <message>
        <location filename="../../Misc/Utility.cpp" line="543"/>
        <source>Sigil has encountered a problem.</source>
        <translation>Sigil ประสบปัญหา</translation>
    </message>
    <message>
        <location filename="../../Misc/Utility.cpp" line="544"/>
        <source>Sigil may need to close.</source>
        <translation>Sigil อาจจำเป็นต้องปิด</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/IndexHTMLWriter.cpp" line="70"/>
        <source>Index</source>
        <translation>สารบัญ</translation>
    </message>
    <message>
        <location filename="../../SourceUpdates/UniversalUpdates.cpp" line="207"/>
        <location filename="../../SourceUpdates/UniversalUpdates.cpp" line="273"/>
        <source>Invalid HTML file: %1</source>
        <translation>ไฟล์ HTML ไม่ถูกต้อง: %1</translation>
    </message>
    <message>
        <location filename="../../SourceUpdates/UniversalUpdates.cpp" line="316"/>
        <source>Invalid OPF file: %1</source>
        <translation>ไฟล์ OPF ไม่ถูกต้อง: %1</translation>
    </message>
    <message>
        <location filename="../../SourceUpdates/UniversalUpdates.cpp" line="341"/>
        <source>Invalid NCX file: %1</source>
        <translation>ไฟล์ NCX ไม่ถูกต้อง: %1</translation>
    </message>
</context>
<context>
    <name>RenameTemplate</name>
    <message>
        <location filename="../../Form_Files/RenameTemplate.ui" line="20"/>
        <source>Rename Files</source>
        <translation>เปลี่ยนชื่อไฟล์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/RenameTemplate.ui" line="28"/>
        <source>Enter the starting name to use for renaming all selected files, e.g.:

    filename001
    filename08.xhtml
    .html

All numbers at the END of the filename you enter will be replaced sequentially
starting at the number provided (default is 1 if no number is provided),  with
leading 0's added to match the number of digits used.

If you provide a file extension it will be used for all files, otherwise the
current extensions will be kept.  If you just provide a file extension (e.g. .xhtml)
then only file extensions will be updated.  Be careful that any extension you use is 
valid for all selected files.
</source>
        <translation>ป้อนชื่อเริ่มต้นที่จะใช้สำหรับเปลี่ยนชื่อไฟล์ที่เลือกทั้งหมดเช่น:

    filename001
    filename08.xhtml
    .html

ตัวเลขทั้งหมดในตอนท้ายของชื่อไฟล์ที่คุณป้อนจะถูกแทนที่ตามลำดับ
เริ่มต้นที่หมายเลขที่ระบุ (ค่าเริ่มต้นคือ 1 ถ้าไม่มีการระบุหมายเลข) โดยมีการเพิ่มจำนวน 0 นำเข้าเพื่อให้ตรงกับตัวเลขที่ใช้

หากคุณมีนามสกุลไฟล์จะใช้สำหรับไฟล์ทั้งหมด
มิฉะนั้นนามสกุลไฟล์จะถูกเก็บไว้ หากคุณเพียงแค่ให้นามสกุลไฟล์ (เช่น. xhtml)
แล้วนามสกุลไฟล์ที่จะได้รับการปรับปรุง  
โปรดใช้ความระมัดระวังว่านามสกุลใด ๆ ที่คุณใช้จะใช้ได้กับไฟล์ที่เลือกทั้งหมด
</translation>
    </message>
    <message>
        <location filename="../../Form_Files/RenameTemplate.ui" line="45"/>
        <source>Rename Files Starting At: </source>
        <translation>เปลี่ยนชื่อไฟล์ที่เริ่มต้นที่:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/RenameTemplate.ui" line="52"/>
        <source>Section0001</source>
        <translation>Section0001</translation>
    </message>
</context>
<context>
    <name>Reports</name>
    <message>
        <location filename="../../Form_Files/Reports.ui" line="14"/>
        <source>Reports</source>
        <translation>รายงาน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/Reports.ui" line="51"/>
        <source>Refresh</source>
        <translation>รีเฟรช</translation>
    </message>
</context>
<context>
    <name>SearchEditor</name>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="14"/>
        <source>Saved Searches</source>
        <translation>บันทึกการค้นหา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="23"/>
        <source>Filter Name:</source>
        <translation>ชื่อตัวกรอง:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="28"/>
        <source>Filter All:</source>
        <translation>กรองทั้งหมด:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="36"/>
        <source>List only the entries containing the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="65"/>
        <source>Load the selected entry into the Find &amp; Replace window.</source>
        <translation>โหลดรายการที่เลือกไว้ในหน้าต่าง ค้นหา&amp;แทนที</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="68"/>
        <source>Load Search</source>
        <translation>โหลดการค้นหา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="91"/>
        <source>Run Find using the selected entry.
If a group is selected, find the first entry in the list, 
then if not found look for the second entry in the list, etc.</source>
        <translation>เรียกใช้ค้นหาโดยใช้รายการที่เลือก
หากเลือกกลุ่มให้ค้นหารายการแรกในรายการ
จากนั้นหากไม่พบให้มองหารายการที่สองในรายการ ฯลฯ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="96"/>
        <location filename="../../Dialogs/SearchEditor.cpp" line="68"/>
        <source>Find</source>
        <translation>หา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="103"/>
        <source>Run Replace using the selected entry.
If a group is selected, loop through each entry
and stop at the first successful replace.</source>
        <translation>แทนที่โดยใช้รายการที่เลือก
หากเลือกกลุ่มให้วนผ่านแต่ละรายการ
และหยุดที่การแทนที่ที่ประสบความสำเร็จครั้งแรก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="108"/>
        <location filename="../../Dialogs/SearchEditor.cpp" line="69"/>
        <source>Replace</source>
        <translation>แทนที่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="131"/>
        <source>Run Replace/Find using the selected entry.
If a group is selected, loop through each entry
and stop at the first successful replace/find.</source>
        <translation>เรียกใช้แทนที่/ค้นหาโดยใช้รายการที่เลือก
หากเลือกกลุ่มให้วนผ่านแต่ละรายการ
และหยุดที่แทนที่/ค้นหาที่ประสบความสำเร็จครั้งแรก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="136"/>
        <source>Replace/Find</source>
        <translation>แทนที่/หา</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="143"/>
        <source>Run Replace All for the selected entries in the order selected.
Select a group to replace all entries in the group in order.</source>
        <translation>เรียกใช้แทนที่ทั้งหมดสำหรับรายการที่เลือกตามลำดับที่เลือก
เลือกกลุ่มเพื่อแทนที่รายการทั้งหมดในกลุ่มตามลำดับ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="147"/>
        <source>Replace All</source>
        <translation>แทนที่ทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="170"/>
        <source>Run Count All for the selected entries in the order selected,
including entries in selected groups.</source>
        <translation>เรียกใช้นับสำหรับรายการที่เลือกตามลำดับที่เลือก
รวมถึงรายการในกลุ่มที่เลือก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="174"/>
        <source>Count All</source>
        <translation>นับทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="199"/>
        <source>Move an entry up one level in the same group.</source>
        <translation>ย้ายรายการหนึ่งระดับขึ้นไปในกลุ่มเดียวกัน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="202"/>
        <location filename="../../Form_Files/SearchEditor.ui" line="232"/>
        <location filename="../../Form_Files/SearchEditor.ui" line="261"/>
        <location filename="../../Form_Files/SearchEditor.ui" line="291"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="229"/>
        <source>Move an entry to the level of its parent.</source>
        <translation>ย้ายรายการไปยังระดับ parent.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="258"/>
        <source>You must select an item immediately under a group to move it into the group.</source>
        <translation>คุณต้องเลือกรายการภายใต้กลุ่มที่จะย้ายเข้ามาในกลุ่ม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="288"/>
        <source>Move an entry down one level in the same group.</source>
        <translation>ย้ายรายการหนึ่งระดับลงไปในกลุ่มเดียวกัน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="354"/>
        <source>Click Apply to load Find &amp; Replace with the selected search.  Click OK to load your search, save your data, and close.</source>
        <translation>คลิกนำไปใช้เพื่อโหลดค้นหาและแทนที่ด้วยการค้นหาที่เลือก คลิกตกลงเพื่อโหลดการค้นหาของคุณบันทึกข้อมูลของคุณและปิด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="62"/>
        <source>All searches default to Regex, All HTML Files, Down.</source>
        <translation>การค้นหาทั้งหมดเริ่มต้นเป็น Regex, ไฟล์ HTML ทั้งหมด, ค้นลง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="63"/>
        <source>Hold Ctrl down while clicking Find, Replace, etc. to temporarily search only the Current File.</source>
        <translation>กด Ctrl ค้างไว้ขณะคลิก ค้นหา, แทนที่ ฯลฯ เพื่อค้นหาเฉพาะไฟล์ปัจจุบันเท่านั้น</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="64"/>
        <source>Right click on an entry to see a context menu of actions.</source>
        <translation>คลิกขวาที่รายการเพื่อดูเมนูของการกระทำ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="65"/>
        <source>You can also right click on the Find text box in the Find &amp; Replace window to select an entry.</source>
        <translation>คุณยังสามารถคลิกขวาที่กล่องค้นหาในหน้าต่างค้นหาและแทนที่เพื่อเลือกรายการ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="67"/>
        <source>Name</source>
        <translation>ชื่อ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="67"/>
        <source>Name of your entry or group.</source>
        <translation>ชื่อรายการหรือกลุ่มของคุณ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="68"/>
        <source>The text to put into the Find box.</source>
        <translation>ข้อความที่จะใส่ลงในช่องค้นหา</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="69"/>
        <source>The text to put into the Replace box.</source>
        <translation>ข้อความที่จะใส่ลงในช่องแทนที่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="73"/>
        <source>Save</source>
        <translation>บันทึก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="73"/>
        <source>Save your changes.</source>
        <translation>บันทึกการเปลี่ยนแปลง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="73"/>
        <source>If any other instances of Sigil are running they will be automatically updated with your changes.</source>
        <translation>หากมีอินสแตนซ์อื่น ๆ ของ Sigil กำลังทำงานระบบจะอัปเดตโดยอัตโนมัติกับการเปลี่ยนแปลงของคุณ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="90"/>
        <source>Cannot save entries.</source>
        <translation>บันทึกรายงานไม่ได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="170"/>
        <source>Saved Searches loaded from file.</source>
        <translation>บันทึกการค้นหาที่บันทึกไว้จากไฟล์</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="206"/>
        <source>You cannot select more than one entry when using this action.</source>
        <translation>คุณไม่สามารถเลือกรายการมากกว่าหนึ่งรายการเมื่อใช้การดำเนินการนี้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="214"/>
        <source>You cannot select a group for this action.</source>
        <translation>คุณไม่สามารถเลือกกลุ่มสำหรับการดำเนินการนี้ได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="260"/>
        <source>You cannot select an entry and a group containing the entry.</source>
        <translation>คุณไม่สามารถเลือกรายการและกลุ่มที่มีรายการได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="343"/>
        <source>You cannot Copy or Cut groups - use drag-and-drop.</source>
        <translation>คุณไม่สามารถคัดลอกหรือตัดกลุ่ม - ใช้ลากและวาง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="410"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="410"/>
        <source>Are you sure you want to reload all entries?  This will overwrite any unsaved changes.</source>
        <translation>คุณแน่ใจหรือไม่ว่าต้องการโหลดรายการใหม่ทั้งหมด การดำเนินการนี้ทับการเปลี่ยนแปลงที่ไม่ได้บันทึก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="426"/>
        <source>Import Search Entries</source>
        <translation>นำเข้ารายการค้นหา</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="499"/>
        <source>Export Selected Searches</source>
        <translation>ส่งออกการค้นหาที่เลือก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="664"/>
        <source>Add Entry</source>
        <translation>เพิ่มรายการ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="665"/>
        <source>Add Group</source>
        <translation>เพิ่มกลุ่ม</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="666"/>
        <source>Edit</source>
        <translation>แก้ไข</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="667"/>
        <source>Cut</source>
        <translation>ตัด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="668"/>
        <source>Copy</source>
        <translation>คัดลอก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="669"/>
        <source>Paste</source>
        <translation>วาง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="670"/>
        <source>Delete</source>
        <translation>ลบ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="671"/>
        <source>Import</source>
        <translation>นำเข้า</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="672"/>
        <source>Reload</source>
        <translation>โหลดใหม่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="673"/>
        <source>Export</source>
        <translation>ส่งออก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="674"/>
        <source>Export All</source>
        <translation>ส่งออกทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="675"/>
        <source>Collapse All</source>
        <translation>หุบทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="676"/>
        <source>Expand All</source>
        <translation>ขยายออกทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="753"/>
        <source>Search entries saved.</source>
        <translation>ค้นหารายการที่บันทึกไว้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="782"/>
        <source>Sigil: Saved Searches</source>
        <translation>Sigil: การค้นหาที่บันทึกไว้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="783"/>
        <source>The Search entries may have been modified.
Do you want to save your changes?</source>
        <translation>รายการค้นหาอาจได้รับการแก้ไขแล้ว
คุณต้องการบันทึกการเปลี่ยนแปลงหรือไม่?</translation>
    </message>
</context>
<context>
    <name>SearchEditorModel</name>
    <message>
        <location filename="../../MiscEditors/SearchEditorModel.cpp" line="66"/>
        <source>Name</source>
        <translation>ชื่อ</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/SearchEditorModel.cpp" line="67"/>
        <source>Find</source>
        <translation>หา</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/SearchEditorModel.cpp" line="68"/>
        <source>Replace</source>
        <translation>แทนที่</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/SearchEditorModel.cpp" line="604"/>
        <source>Unable to create file %1</source>
        <translation>ไม่สามารถสร้างไฟล์ %1</translation>
    </message>
</context>
<context>
    <name>SelectCharacter</name>
    <message>
        <location filename="../../Form_Files/SelectCharacter.ui" line="14"/>
        <source>Insert Special Character</source>
        <translation>แทรกตัวอักษรพิเศษ</translation>
    </message>
</context>
<context>
    <name>SelectFiles</name>
    <message>
        <location filename="../../Form_Files/SelectFiles.ui" line="14"/>
        <source>Insert File</source>
        <translation>แทรกไฟล์</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectFiles.ui" line="46"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectFiles.ui" line="49"/>
        <source>Filter:</source>
        <translation>กรอง:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectFiles.ui" line="59"/>
        <source>Choose which image, video, or audio files from your computer to add to
your book and automatically insert into your document.</source>
        <translation>เลือก ไฟล์รูปภาพ วิดีโอ หรือเสียง จากคอมพิวเตอร์เพื่อเพิ่มลงในหนังสือ
และแทรกลงในเอกสารของคุณโดยอัตโนมัติ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectFiles.ui" line="63"/>
        <source>Other Files...</source>
        <translation>ไฟล์อื่น ๆ...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectFiles.ui" line="129"/>
        <source>Thumbnail size:</source>
        <translation>ขนาดรูปย่อ:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="80"/>
        <source>All</source>
        <translation>ทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="81"/>
        <source>Images</source>
        <translation>รูปภาพ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="82"/>
        <source>Video</source>
        <translation>วีดีโอ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="83"/>
        <source>Audio</source>
        <translation>เสียง</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="127"/>
        <source>Files In the Book</source>
        <translation>ไฟล์ในหนังสือ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="130"/>
        <source>Thumbnails</source>
        <translation>ขนาดรูปย่อ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="286"/>
        <source>shades</source>
        <translation>เฉดสี</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="286"/>
        <source>colors</source>
        <translation>สี</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="287"/>
        <source>Grayscale</source>
        <translation>โทนสีเทา</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="287"/>
        <source>Color</source>
        <translation>สี</translation>
    </message>
</context>
<context>
    <name>SelectHyperlink</name>
    <message>
        <location filename="../../Form_Files/SelectHyperlink.ui" line="14"/>
        <source>Select Target</source>
        <translation>เลือกเป้าหมาย</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectHyperlink.ui" line="22"/>
        <source>List only the entries that match the text you enter.</source>
        <translation>แสดงเฉพาะรายการที่ตรงกับข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectHyperlink.ui" line="25"/>
        <source>Filter:</source>
        <translation>กรอง:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectHyperlink.ui" line="58"/>
        <source>Enter the target URL for this hyperlink.  You can select or 
double click on existing destinations in your book from the list above.</source>
        <translation>ป้อน URL เป้าหมายสำหรับการเชื่อมโยงหลายมิตินี้ คุณสามารถเลือก
หรือคลิกสองครั้งที่ปลายทางที่มีอยู่ในหนังสือของคุณจากรายการด้านบน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectHyperlink.ui" line="62"/>
        <source>Target:</source>
        <translation>เป้าหมาย:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectHyperlink.cpp" line="61"/>
        <source>Targets in the Book</source>
        <translation>เป้าหมายในหนังสือ:</translation>
    </message>
</context>
<context>
    <name>SelectId</name>
    <message>
        <location filename="../../Form_Files/SelectId.ui" line="14"/>
        <source>Insert ID </source>
        <translation>แทรกไอดี</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectId.ui" line="22"/>
        <source>Enter an ID name to use as a destination for hyperlinks, notes, and TOC entries.

The dropdown box shows existing ID names in the current file.

ID names must be unique and start with a letter.</source>
        <translation>ป้อนชื่อรหัสเพื่อใช้เป็นปลายทางสำหรับไฮเปอร์ลิงก์โน้ตและรายการสารบัญ

กล่องรายการจะแสดงชื่อ ID ที่มีอยู่ในไฟล์ปัจจุบัน

ชื่อต้องไม่ซ้ำกันและเริ่มต้นด้วยตัวอักษร</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectId.ui" line="29"/>
        <source>ID:</source>
        <translation>ไอดี:</translation>
    </message>
</context>
<context>
    <name>SelectIndexTitle</name>
    <message>
        <location filename="../../Form_Files/SelectIndexTitle.ui" line="14"/>
        <source>Mark For Index</source>
        <translation>ทำเครื่องหมายสำหรับดัชนี</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectIndexTitle.ui" line="22"/>
        <source>Enter the index entry to create for the selected text.</source>
        <translation>ป้อนรายการดัชนีเพื่อสร้างสำหรับข้อความที่เลือก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectIndexTitle.ui" line="25"/>
        <source>Index Entry:</source>
        <translation>รายการดัชนี:</translation>
    </message>
</context>
<context>
    <name>SpellCheckWidget</name>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="14"/>
        <source>Spellcheck Dictionaries</source>
        <translation>พจนานุกรมตรวจการสะกด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="34"/>
        <source>Dictionary:</source>
        <translation>พจนานุกรม:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="64"/>
        <source>Highlight misspelled words in Code View.</source>
        <translation>เน้นคำที่สะกดผิดในมุมมองโค้ด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="67"/>
        <source>Highlight Misspelled Words</source>
        <translation>เน้นคำที่สะกดผิด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="74"/>
        <source>Check words with numbers in them.</source>
        <translation>ตรวจสอบคำที่มีตัวเลขอยู่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="77"/>
        <source>Check Numbers</source>
        <translation>ตรวจสอบหมายเลข</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="130"/>
        <source>User Dictionaries</source>
        <translation>ใช้พจนานุกรม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="138"/>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="222"/>
        <source>Add</source>
        <translation>เพิ่ม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="145"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="212"/>
        <source>Rename</source>
        <translation>เปลี่ยนชื่อ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="152"/>
        <source>Copy</source>
        <translation>คัดลอก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="159"/>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="236"/>
        <source>Remove</source>
        <translation>นำออก</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="162"/>
        <source>Remove the selected dictionary.

You cannot remove the last dictionary.</source>
        <translation>ลบพจนานุกรมที่เลือก

คุณไม่สามารถลบพจนานุกรมล่าสุดได้</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="189"/>
        <source>Mark which dictionaries are enabled for
spell checking.

Select a dictionary to display its words,
and to make it the default dictionary.</source>
        <translation>ทำเครื่องหมายที่พจนานุกรมใช้เพื่อ
ตรวจสอบตัวสะกด

เลือกพจนานุกรมเพื่อแสดงคำศัพท์
และเพื่อให้เป็นพจนานุกรมเริ่มต้น</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="203"/>
        <source>User Dictionary Word List</source>
        <translation>พจนานุกรมคำศัพท์ของผู้ใช้</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="218"/>
        <source>Enter or paste words to add to the dictionary.
Words can be separated by lines, commas, or spaces.</source>
        <translation>ป้อนหรือวางคำเพื่อเพิ่มลงในพจนานุกรม
คำสามารถคั่นด้วยบรรทัดเครื่องหมายจุลภาคหรือช่องว่าง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="229"/>
        <source>Edit</source>
        <translation>แก้ไข</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="243"/>
        <source>Remove All</source>
        <translation>นำออกทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="272"/>
        <source>The default dictionary is used when you add words to the
default dictionary or use the shortcuts for Add Misspelled Words.</source>
        <translation>พจนานุกรมเริ่มต้นจะใช้เมื่อคุณเพิ่มคำลงในพจนานุกรมเริ่มต้น
หรือใช้ทางลัดเพื่อเพิ่มคำที่สะกดผิด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="276"/>
        <source>Default Dictionary:</source>
        <translation>พจนานุกรมเริ่มต้น:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="283"/>
        <source>none</source>
        <translation>ไม่มี</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="52"/>
        <source>Enable</source>
        <translation>เปิดใช้งาน</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="53"/>
        <source>Dictionary</source>
        <translation>พจนานุกรม</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="109"/>
        <source>Add Dictionary</source>
        <translation>เพิ่มพจนานุกรม</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="109"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="212"/>
        <source>Name:</source>
        <translation>ชื่อ:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="123"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="163"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="225"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="233"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="252"/>
        <source>Error</source>
        <translation>ข้อผิดพลาด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="123"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="225"/>
        <source>A user dictionary already exists with this name!</source>
        <translation>มีพจนานุกรมผู้ใช้ที่มีชื่อนี้แล้ว!</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="132"/>
        <source>Add Words</source>
        <translation>เพิ่มคำ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="132"/>
        <source>Words:</source>
        <translation>คำ:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="163"/>
        <source>Could not create file!</source>
        <translation>ไม่สามารถสร้างไฟล์!</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="233"/>
        <source>Could not rename file!</source>
        <translation>ไม่สามารถเปลี่ยนชื่อไฟล์!</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="252"/>
        <source>You cannot delete the last dictionary.</source>
        <translation>คุณไม่สามารถลบพจนานุกรมล่าสุดได้</translation>
    </message>
</context>
<context>
    <name>SpellcheckEditor</name>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="14"/>
        <source>Spellcheck</source>
        <translation>ตรวจสอบการสะกด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="22"/>
        <source>Filter:</source>
        <translation>กรอง:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="29"/>
        <source>List only the entries containing the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="58"/>
        <source>Ignore the selected words until Sigil
is restarted or a new book is opened.</source>
        <translation>ละเว้นคำที่เลือกจนกว่า Sigil จะเริ่มใหม่
หรือเปิดหนังสือใหม่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="62"/>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="532"/>
        <source>Ignore</source>
        <translation>ข้าม</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="91"/>
        <source>Add the selected words to the
dictionary selected below.</source>
        <translation>เพิ่มคำที่เลือกลงในพจนานุกรม
ที่เลือกด้านล่าง</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="95"/>
        <source>Add To Dictionary:</source>
        <translation>เพิ่มลงในพจนานุกรม:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="134"/>
        <source>Change all occurrences of the selected word  in
HTML files to the word you select or type below.
The selected word does not have to be misspelled.</source>
        <translation>เปลี่ยนเหตุการณ์ที่เกิดขึ้นทั้งหมดของคำที่เลือกไว้ในไฟล์ HTML
เป็นคำที่คุณเลือกหรือพิมพ์ด้านล่าง
คำที่เลือกไม่จำเป็นต้องสะกดผิด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="139"/>
        <source>Change Selected Word To:</source>
        <translation>เปลี่ยนคำที่เลือกไปที่:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="181"/>
        <source>Show All Words</source>
        <translation>แสดงคำทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="188"/>
        <source>Sort words as AaBbCc instead of ABCabc.</source>
        <translation>จัดเรียงคำเป็น AaBbCc ด้วย ABCabc</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="191"/>
        <source>Case-Insensitive Sort</source>
        <translation>การจัดเรียงตัวพิมพ์เล็กและใหญ่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="215"/>
        <source>Re-check the HTML files for misspelled words.
Use if you edit any HTML files while Spellcheck is open.</source>
        <translation>ตรวจสอบไฟล์ HTML สำหรับคำที่สะกดผิด
ใช้ถ้าคุณแก้ไขไฟล์ HTML ใด ๆ ในขณะที่ตรวจสอบการสะกดถูกเปิดอยู่</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="219"/>
        <source>Refresh</source>
        <translation>รีเฟรช</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="53"/>
        <source>f</source>
        <comment>Filter</comment>
        <translation>f</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="54"/>
        <source>s</source>
        <comment>ShowAllWords</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="55"/>
        <source>c</source>
        <comment>Case-InsensitiveSort</comment>
        <translation>c</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="56"/>
        <source>r</source>
        <comment>Refresh</comment>
        <translation>r</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="154"/>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="177"/>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="216"/>
        <source>No words selected.</source>
        <translation>ไม่มีคำที่เลือก</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="170"/>
        <source>Ignored word(s).</source>
        <translation>คำที่ละเลย</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="205"/>
        <source>Added word(s) to dictionary.</source>
        <translation>เพิ่มคำลงในพจนานุกรมแล้ว</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="207"/>
        <source>Added word(s) to dictionary. The dictionary is not enabled in Preferences.</source>
        <translation>เพิ่มคำลงในพจนานุกรมแล้ว ไม่ได้เปิดใช้พจนานุกรมในการตั้งค่า</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="222"/>
        <source>The new word cannot contain &quot;&lt;&quot;, &quot;&gt;&quot;, or &quot;&amp;&quot;.</source>
        <translation>คำใหม่ไม่สามารถมี &quot;&lt;&quot;, &quot;&gt;&quot; หรือ &quot;&amp;&quot;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="233"/>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="301"/>
        <source>No</source>
        <translation>ไม่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="252"/>
        <source>Word</source>
        <translation>คำ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="253"/>
        <source>Count</source>
        <translation>นับ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="254"/>
        <source>Misspelled?</source>
        <translation>คำที่สะกดผิด?</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="299"/>
        <source>Yes</source>
        <translation>ใช่</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="314"/>
        <source>Misspelled Words</source>
        <translation>คำที่สะกดผิด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="314"/>
        <source>Total Unique Words</source>
        <translation>คำที่ไม่ซ้ำทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="533"/>
        <source>Add to Dictionary</source>
        <translation>เพิ่มลงในพจนานุกรม</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="534"/>
        <source>Find in Text</source>
        <translation>ค้นหาในข้อความ</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="535"/>
        <source>Select All</source>
        <translation>เลือกทั้งหมด</translation>
    </message>
</context>
<context>
    <name>StylesInCSSFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsStylesInCSSFilesWidget.ui" line="14"/>
        <source>Style Classes in CSS Files</source>
        <translation>คลาสสไตล์ในไฟล์ CSS</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsStylesInCSSFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>แสดงรายการเฉพาะชื่อไฟล์ที่มีข้อความที่คุณป้อน</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsStylesInCSSFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>กรอง:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="86"/>
        <source>CSS File</source>
        <translation>ไฟล์ CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="87"/>
        <source>Class Selector</source>
        <translation>ตัวเลือกคลาส</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="88"/>
        <source>Used In HTML File</source>
        <translation>ใช้ในไฟล์ HTML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="94"/>
        <source>&lt;p&gt;This is a list of the class based selectors in all CSS files and whether or not the selector was matched from a style in an HTML file.&lt;p&gt;</source>
        <translation>&lt;p&gt;นี่คือรายการของตัวเลือกคลาสที่อยู่ในไฟล์ CSS ทั้งหมดหรือไม่และตัวเลือกที่ถูกจับคู่จากสไตล์ในไฟล์ HTML&lt;p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="95"/>
        <source>&lt;p&gt;NOTE:&lt;/p&gt;</source>
        <translation>&lt;p&gt;บันทึก:&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="96"/>
        <source>&lt;p&gt;Due to the complexities of CSS you must check your code manually to be certain if a style is used or not.&lt;/p&gt;</source>
        <translation>&lt;p&gt;เนื่องจากความซับซ้อนของ CSS คุณต้องตรวจสอบด้วยตนเองเพื่อให้มั่นใจว่าสไตล์ถูกใช้&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="252"/>
        <source>Save Report As Comma Separated File</source>
        <translation>บันทึกรายงานเป็นไฟล์ที่แบ่งด้วยจุลภาค</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="265"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="265"/>
        <source>Cannot save report file.</source>
        <translation>บันทึกไฟล์รายงานไม่ได้</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="276"/>
        <source>Delete From Stylesheet</source>
        <translation>ลบจากสไตล์ชีต</translation>
    </message>
</context>
<context>
    <name>TabBar</name>
    <message>
        <location filename="../../Tabs/TabBar.cpp" line="80"/>
        <source>Close Other Tabs</source>
        <translation>ปิดแท็บอื่น ๆ</translation>
    </message>
</context>
<context>
    <name>TabManager</name>
    <message>
        <location filename="../../Tabs/TabManager.cpp" line="218"/>
        <source>Cannot edit file</source>
        <translation>ไม่สามารถแก้ใขไฟล์</translation>
    </message>
</context>
<context>
    <name>TableOfContents</name>
    <message>
        <location filename="../../MainUI/TableOfContents.cpp" line="42"/>
        <source>Table Of Contents</source>
        <translation>สารบัญ</translation>
    </message>
    <message>
        <location filename="../../MainUI/TableOfContents.cpp" line="123"/>
        <source>The file &quot;%1&quot; does not exist.</source>
        <translation>ไฟล์ &quot;%1&quot; ไม่มีอยู่</translation>
    </message>
    <message>
        <location filename="../../MainUI/TableOfContents.cpp" line="154"/>
        <source>Collapse All</source>
        <translation>หุบทั้งหมด</translation>
    </message>
    <message>
        <location filename="../../MainUI/TableOfContents.cpp" line="155"/>
        <source>Expand All</source>
        <translation>ขยายออกทั้งหมด</translation>
    </message>
</context>
<context>
    <name>TextTab</name>
    <message>
        <location filename="../../Tabs/TextTab.cpp" line="309"/>
        <source>Print %1</source>
        <translation>พิมพ์ %1</translation>
    </message>
</context>
<context>
    <name>Utility</name>
    <message>
        <location filename="../../Misc/Utility.cpp" line="656"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Misc/Utility.cpp" line="657"/>
        <source>The requested file name contains non-ASCII characters. You should only use ASCII characters in filenames. Using non-ASCII characters can prevent the EPUB from working with some readers.

Continue using the requested filename?</source>
        <translation>ชื่อไฟล์ที่มีอักขระที่ไม่ใช่ ASCII คุณควรใช้อักขระ ASCII ในชื่อไฟล์เท่านั้น การใช้อักขระที่ไม่ใช่ ASCII สามารถทำให้ EPUB ไม่ทำงานร่วมกับผู้อ่านบางรายได้ &quot;ดำเนินการต่อโดยใช้ชื่อไฟล์ที่ต้องการ&quot;</translation>
    </message>
</context>
<context>
    <name>ValidationResultsView</name>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="44"/>
        <source>Validation Results</source>
        <translation>ผลการตรวจสอบความถูกต้อง</translation>
    </message>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="227"/>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="231"/>
        <source>N/A</source>
        <translation>N/A</translation>
    </message>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="254"/>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="270"/>
        <source>Message</source>
        <translation>ข่าวสาร</translation>
    </message>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="255"/>
        <source>No problems found!</source>
        <translation>ไม่พบปัญหา!</translation>
    </message>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="270"/>
        <source>File</source>
        <translation>ไฟล์</translation>
    </message>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="270"/>
        <source>Line</source>
        <translation>บรรทัด</translation>
    </message>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="270"/>
        <source>Offset</source>
        <translation>ชดเชย</translation>
    </message>
</context>
<context>
    <name>ViewImage</name>
    <message>
        <location filename="../../Form_Files/ViewImage.ui" line="20"/>
        <source>View Image</source>
        <translation>ดูภาพ</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ViewImage.ui" line="33"/>
        <source>about:blank</source>
        <translation>about:blank</translation>
    </message>
</context>
<context>
    <name>WellFormedCheckComponent</name>
    <message>
        <location filename="../../Tabs/WellFormedCheckComponent.cpp" line="42"/>
        <source>&lt;p&gt;The operation you requested cannot be performed because &lt;b&gt;%1&lt;/b&gt; is not a well-formed XML document.&lt;/p&gt;&lt;p&gt;An error was found &lt;b&gt;at or above line %2: %3.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;The &lt;i&gt;Fix Manually&lt;/i&gt; option will let you fix the problem by hand.&lt;/p&gt;</source>
        <translation>&lt;p&gt;ไม่สามารถดำเนินการตามที่คุณขอได้เนื่องจาก &lt;b&gt;%1&lt;/b&gt; ไม่ใช่เอกสาร XML ที่สร้างอย่างถูกต้อง&lt;/p&gt;&lt;p&gt;พบปัญหา&lt;b&gt;ที่หรือเหนือรรทัด %2: %3.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;ตัวเลือก &lt;i&gt;การแก้ไขด้วยตนเอง&lt;/i&gt; จะช่วยให้คุณสามารถแก้ไขปัญหาได้ด้วยตนเอง&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Tabs/WellFormedCheckComponent.cpp" line="47"/>
        <source>&lt;p&gt;The &lt;i&gt;Fix Automatically&lt;/i&gt; option will instruct Sigil to try to repair the document. &lt;b&gt;This option may lead to loss of data!&lt;/b&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;ตัวเลือก&lt;i&gt; แก้ไขโดยอัตโนมัติ&lt;/i&gt; จะสั่งให้ Sigil พยายามซ่อมแซมเอกสาร&lt;b&gt;ตัวเลือกนี้อาจทำให้ข้อมูลสูญหาย!&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Tabs/WellFormedCheckComponent.cpp" line="54"/>
        <source>Fix &amp;Automatically</source>
        <translation>แก้ไขโดยอัตโนมัติ</translation>
    </message>
    <message>
        <location filename="../../Tabs/WellFormedCheckComponent.cpp" line="56"/>
        <source>Fix &amp;Manually</source>
        <translation>แก้ไขด้วยตนเอง</translation>
    </message>
</context>
<context>
    <name>XMLEntities</name>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="97"/>
        <source>quotation mark</source>
        <translation>quotation mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="98"/>
        <source>ampersand</source>
        <translation>ampersand</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="99"/>
        <source>apostrophe</source>
        <translation>apostrophe</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="100"/>
        <source>less-than sign</source>
        <translation>less-than sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="101"/>
        <source>greater-than sign</source>
        <translation>greater-than sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="102"/>
        <source>no-break space</source>
        <translation>no-break space</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="103"/>
        <source>inverted exclamation mark</source>
        <translation>inverted exclamation mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="104"/>
        <source>cent sign</source>
        <translation>cent sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="105"/>
        <source>pound sign</source>
        <translation>pound sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="106"/>
        <source>currency sign</source>
        <translation>currency sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="107"/>
        <source>yen sign</source>
        <translation>yen sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="108"/>
        <source>broken bar</source>
        <translation>broken bar</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="109"/>
        <source>section sign</source>
        <translation>section sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="110"/>
        <source>diaeresis</source>
        <translation>diaeresis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="111"/>
        <source>copyright symbol</source>
        <translation>copyright symbol</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="112"/>
        <source>feminine ordinal indicator</source>
        <translation>feminine ordinal indicator</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="113"/>
        <source>left-pointing double angle quotation mark</source>
        <translation>left-pointing double angle quotation mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="114"/>
        <source>not sign</source>
        <translation>not sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="115"/>
        <source>soft hyphen</source>
        <translation>soft hyphen</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="116"/>
        <source>registered sign</source>
        <translation>registered sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="117"/>
        <source>macron</source>
        <translation>macron</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="118"/>
        <source>degree symbol</source>
        <translation>degree symbol</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="119"/>
        <source>plus-minus sign</source>
        <translation>plus-minus sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="120"/>
        <source>superscript two</source>
        <translation>superscript two</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="121"/>
        <source>superscript three</source>
        <translation>superscript three</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="122"/>
        <source>acute accent</source>
        <translation>acute accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="123"/>
        <source>micro sign</source>
        <translation>micro sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="124"/>
        <source>pilcrow sign</source>
        <translation>pilcrow sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="125"/>
        <source>middle dot</source>
        <translation>middle dot</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="126"/>
        <source>cedilla</source>
        <translation>cedilla</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="127"/>
        <source>superscript one</source>
        <translation>superscript one</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="128"/>
        <source>masculine ordinal indicator</source>
        <translation>masculine ordinal indicator</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="129"/>
        <source>right-pointing double angle quotation mark</source>
        <translation>right-pointing double angle quotation mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="130"/>
        <source>vulgar fraction one quarter</source>
        <translation>vulgar fraction one quarter</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="131"/>
        <source>vulgar fraction one half</source>
        <translation>vulgar fraction one half</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="132"/>
        <source>vulgar fraction three quarters</source>
        <translation>vulgar fraction three quarters</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="133"/>
        <source>inverted question mark</source>
        <translation>inverted question mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="134"/>
        <source>Latin capital letter A with grave accent</source>
        <translation>Latin capital letter A with grave accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="135"/>
        <source>Latin capital letter A with acute accent</source>
        <translation>Latin capital letter A with acute accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="136"/>
        <source>Latin capital letter A with circumflex</source>
        <translation>Latin capital letter A with circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="137"/>
        <source>Latin capital letter A with tilde</source>
        <translation>Latin capital letter A with tilde</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="138"/>
        <source>Latin capital letter A with diaeresis</source>
        <translation>Latin capital letter A with diaeresis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="139"/>
        <source>Latin capital letter A with ring above</source>
        <translation>Latin capital letter A with ring above</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="140"/>
        <source>Latin capital letter AE</source>
        <translation>Latin capital letter AE</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="141"/>
        <source>Latin capital letter C with cedilla</source>
        <translation>Latin capital letter C with cedilla</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="142"/>
        <source>Latin capital letter E with grave accent</source>
        <translation>Latin capital letter E with grave accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="143"/>
        <source>Latin capital letter E with acute accent</source>
        <translation>Latin capital letter E with acute accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="144"/>
        <source>Latin capital letter E with circumflex</source>
        <translation>Latin capital letter E with circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="145"/>
        <source>Latin capital letter E with diaeresis</source>
        <translation>Latin capital letter E with diaeresis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="146"/>
        <source>Latin capital letter I with grave accent</source>
        <translation>Latin capital letter I with grave accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="147"/>
        <source>Latin capital letter I with acute accent</source>
        <translation>Latin capital letter I with acute accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="148"/>
        <source>Latin capital letter I with circumflex</source>
        <translation>Latin capital letter I with circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="149"/>
        <source>Latin capital letter I with diaeresis</source>
        <translation>Latin capital letter I with diaeresis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="150"/>
        <source>Latin capital letter Eth</source>
        <translation>Latin capital letter Eth</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="151"/>
        <source>Latin capital letter N with tilde</source>
        <translation>Latin capital letter N with tilde</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="152"/>
        <source>Latin capital letter O with grave accent</source>
        <translation>Latin capital letter O with grave accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="153"/>
        <source>Latin capital letter O with acute accent</source>
        <translation>Latin capital letter O with acute accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="154"/>
        <source>Latin capital letter O with circumflex</source>
        <translation>Latin capital letter O with circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="155"/>
        <source>Latin capital letter O with tilde</source>
        <translation>Latin capital letter O with tilde</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="156"/>
        <source>Latin capital letter O with diaeresis</source>
        <translation>Latin capital letter O with diaeresis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="157"/>
        <source>multiplication sign</source>
        <translation>multiplication sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="158"/>
        <source>Latin capital letter O with stroke</source>
        <translation>Latin capital letter O with stroke</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="159"/>
        <source>Latin capital letter U with grave accent</source>
        <translation>Latin capital letter U with grave accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="160"/>
        <source>Latin capital letter U with acute accent</source>
        <translation>Latin capital letter U with acute accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="161"/>
        <source>Latin capital letter U with circumflex</source>
        <translation>Latin capital letter U with circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="162"/>
        <source>Latin capital letter U with diaeresis</source>
        <translation>Latin capital letter U with diaeresis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="163"/>
        <source>Latin capital letter Y with acute accent</source>
        <translation>Latin capital letter Y with acute accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="164"/>
        <source>Latin capital letter THORN</source>
        <translation>Latin capital letter THORN</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="165"/>
        <source>Latin small letter sharp s</source>
        <translation>Latin small letter sharp s</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="166"/>
        <source>Latin small letter a with grave accent</source>
        <translation>Latin small letter a with grave accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="167"/>
        <source>Latin small letter a with acute accent</source>
        <translation>Latin small letter a with acute accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="168"/>
        <source>Latin small letter a with circumflex</source>
        <translation>Latin small letter a with circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="169"/>
        <source>Latin small letter a with tilde</source>
        <translation>Latin small letter a with tilde</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="170"/>
        <source>Latin small letter a with diaeresis</source>
        <translation>Latin small letter a with diaeresis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="171"/>
        <source>Latin small letter a with ring above</source>
        <translation>Latin small letter a with ring above</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="172"/>
        <source>Latin small letter ae</source>
        <translation>Latin small letter ae</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="173"/>
        <source>Latin small letter c with cedilla</source>
        <translation>Latin small letter c with cedilla</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="174"/>
        <source>Latin small letter e with grave accent</source>
        <translation>Latin small letter e with grave accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="175"/>
        <source>Latin small letter e with acute accent</source>
        <translation>Latin small letter e with acute accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="176"/>
        <source>Latin small letter e with circumflex</source>
        <translation>Latin small letter e with circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="177"/>
        <source>Latin small letter e with diaeresis</source>
        <translation>Latin small letter e with diaeresis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="178"/>
        <source>Latin small letter i with grave accent</source>
        <translation>Latin small letter i with grave accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="179"/>
        <source>Latin small letter i with acute accent</source>
        <translation>Latin small letter i with acute accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="180"/>
        <source>Latin small letter i with circumflex</source>
        <translation>Latin small letter i with circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="181"/>
        <source>Latin small letter i with diaeresis</source>
        <translation>Latin small letter i with diaeresis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="182"/>
        <source>Latin small letter eth</source>
        <translation>Latin small letter eth</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="183"/>
        <source>Latin small letter n with tilde</source>
        <translation>Latin small letter n with tilde</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="184"/>
        <source>Latin small letter o with grave accent</source>
        <translation>Latin small letter o with grave accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="185"/>
        <source>Latin small letter o with acute accent</source>
        <translation>Latin small letter o with acute accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="186"/>
        <source>Latin small letter o with circumflex</source>
        <translation>Latin small letter o with circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="187"/>
        <source>Latin small letter o with tilde</source>
        <translation>Latin small letter o with tilde</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="188"/>
        <source>Latin small letter o with diaeresis</source>
        <translation>Latin small letter o with diaeresis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="189"/>
        <source>division sign</source>
        <translation>division sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="190"/>
        <source>Latin small letter o with stroke</source>
        <translation>Latin small letter o with stroke</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="191"/>
        <source>Latin small letter u with grave accent</source>
        <translation>Latin small letter u with grave accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="192"/>
        <source>Latin small letter u with acute accent</source>
        <translation>Latin small letter u with acute accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="193"/>
        <source>Latin small letter u with circumflex</source>
        <translation>Latin small letter u with circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="194"/>
        <source>Latin small letter u with diaeresis</source>
        <translation>Latin small letter u with diaeresis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="195"/>
        <source>Latin small letter y with acute accent</source>
        <translation>Latin small letter y with acute accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="196"/>
        <source>Latin small letter thorn</source>
        <translation>Latin small letter thorn</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="197"/>
        <source>Latin small letter y with diaeresis</source>
        <translation>Latin small letter y with diaeresis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="198"/>
        <source>Latin capital ligature oe</source>
        <translation>Latin capital ligature oe</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="199"/>
        <source>Latin small ligature oe</source>
        <translation>Latin small ligature oe</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="200"/>
        <source>Latin capital letter s with caron</source>
        <translation>Latin capital letter s with caron</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="201"/>
        <source>Latin small letter s with caron</source>
        <translation>Latin small letter s with caron</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="202"/>
        <source>Latin capital letter y with diaeresis</source>
        <translation>Latin capital letter y with diaeresis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="203"/>
        <source>Latin small letter f with hook</source>
        <translation>Latin small letter f with hook</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="204"/>
        <source>modifier letter circumflex accent</source>
        <translation>modifier letter circumflex accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="205"/>
        <source>small tilde</source>
        <translation>small tilde</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="206"/>
        <source>Greek capital letter Alpha</source>
        <translation>Greek capital letter Alpha</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="207"/>
        <source>Greek capital letter Beta</source>
        <translation>Greek capital letter Beta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="208"/>
        <source>Greek capital letter Gamma</source>
        <translation>Greek capital letter Gamma</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="209"/>
        <source>Greek capital letter Delta</source>
        <translation>Greek capital letter Delta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="210"/>
        <source>Greek capital letter Epsilon</source>
        <translation>Greek capital letter Epsilon</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="211"/>
        <source>Greek capital letter Zeta</source>
        <translation>Greek capital letter Zeta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="212"/>
        <source>Greek capital letter Eta</source>
        <translation>Greek capital letter Eta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="213"/>
        <source>Greek capital letter Theta</source>
        <translation>Greek capital letter Theta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="214"/>
        <source>Greek capital letter Iota</source>
        <translation>Greek capital letter Iota</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="215"/>
        <source>Greek capital letter Kappa</source>
        <translation>Greek capital letter Kappa</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="216"/>
        <source>Greek capital letter Lambda</source>
        <translation>Greek capital letter Lambda</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="217"/>
        <source>Greek capital letter Mu</source>
        <translation>Greek capital letter Mu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="218"/>
        <source>Greek capital letter Nu</source>
        <translation>Greek capital letter Nu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="219"/>
        <source>Greek capital letter Xi</source>
        <translation>Greek capital letter Xi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="220"/>
        <source>Greek capital letter Omicron</source>
        <translation>Greek capital letter Omicron</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="221"/>
        <source>Greek capital letter Pi</source>
        <translation>Greek capital letter Pi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="222"/>
        <source>Greek capital letter Rho</source>
        <translation>Greek capital letter Rho</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="223"/>
        <source>Greek capital letter Sigma</source>
        <translation>Greek capital letter Sigma</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="224"/>
        <source>Greek capital letter Tau</source>
        <translation>Greek capital letter Tau</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="225"/>
        <source>Greek capital letter Upsilon</source>
        <translation>Greek capital letter Upsilon</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="226"/>
        <source>Greek capital letter Phi</source>
        <translation>Greek capital letter Phi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="227"/>
        <source>Greek capital letter Chi</source>
        <translation>Greek capital letter Chi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="228"/>
        <source>Greek capital letter Psi</source>
        <translation>Greek capital letter Psi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="229"/>
        <source>Greek capital letter Omega</source>
        <translation>Greek capital letter Omega</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="230"/>
        <source>Greek small letter alpha</source>
        <translation>Greek small letter alpha</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="231"/>
        <source>Greek small letter beta</source>
        <translation>Greek small letter beta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="232"/>
        <source>Greek small letter gamma</source>
        <translation>Greek small letter gamma</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="233"/>
        <source>Greek small letter delta</source>
        <translation>Greek small letter delta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="234"/>
        <source>Greek small letter epsilon</source>
        <translation>Greek small letter epsilon</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="235"/>
        <source>Greek small letter zeta</source>
        <translation>Greek small letter zeta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="236"/>
        <source>Greek small letter eta</source>
        <translation>Greek small letter eta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="237"/>
        <source>Greek small letter theta</source>
        <translation>Greek small letter theta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="238"/>
        <source>Greek small letter iota</source>
        <translation>Greek small letter iota</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="239"/>
        <source>Greek small letter kappa</source>
        <translation>Greek small letter kappa</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="240"/>
        <source>Greek small letter lambda</source>
        <translation>Greek small letter lambda</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="241"/>
        <source>Greek small letter mu</source>
        <translation>Greek small letter mu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="242"/>
        <source>Greek small letter nu</source>
        <translation>Greek small letter nu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="243"/>
        <source>Greek small letter xi</source>
        <translation>Greek small letter xi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="244"/>
        <source>Greek small letter omicron</source>
        <translation>Greek small letter omicron</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="245"/>
        <source>Greek small letter pi</source>
        <translation>Greek small letter pi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="246"/>
        <source>Greek small letter rho</source>
        <translation>Greek small letter rho</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="247"/>
        <source>Greek small letter final sigma</source>
        <translation>Greek small letter final sigma</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="248"/>
        <source>Greek small letter sigma</source>
        <translation>Greek small letter sigma</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="249"/>
        <source>Greek small letter tau</source>
        <translation>Greek small letter tau</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="250"/>
        <source>Greek small letter upsilon</source>
        <translation>Greek small letter upsilon</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="251"/>
        <source>Greek small letter phi</source>
        <translation>Greek small letter phi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="252"/>
        <source>Greek small letter chi</source>
        <translation>Greek small letter chi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="253"/>
        <source>Greek small letter psi</source>
        <translation>Greek small letter psi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="254"/>
        <source>Greek small letter omega</source>
        <translation>Greek small letter omega</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="255"/>
        <source>Greek theta symbol</source>
        <translation>Greek theta symbol</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="256"/>
        <source>Greek Upsilon with hook symbol</source>
        <translation>Greek Upsilon with hook symbol</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="257"/>
        <source>Greek pi symbol</source>
        <translation>Greek pi symbol</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="258"/>
        <source>en space</source>
        <translation>en space</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="259"/>
        <source>em space</source>
        <translation>em space</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="260"/>
        <source>thin space</source>
        <translation>thin space</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="261"/>
        <source>zero-width non-joiner</source>
        <translation>zero-width non-joiner</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="262"/>
        <source>zero-width joiner</source>
        <translation>zero-width joiner</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="263"/>
        <source>left-to-right mark</source>
        <translation>left-to-right mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="264"/>
        <source>right-to-left mark</source>
        <translation>right-to-left mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="265"/>
        <source>en dash</source>
        <translation>en dash</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="266"/>
        <source>em dash</source>
        <translation>em dash</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="267"/>
        <source>left single quotation mark</source>
        <translation>left single quotation mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="268"/>
        <source>right single quotation mark</source>
        <translation>right single quotation mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="269"/>
        <source>single low-9 quotation mark</source>
        <translation>single low-9 quotation mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="270"/>
        <source>left double quotation mark</source>
        <translation>left double quotation mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="271"/>
        <source>right double quotation mark</source>
        <translation>right double quotation mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="272"/>
        <source>double low-9 quotation mark</source>
        <translation>double low-9 quotation mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="273"/>
        <source>dagger, obelisk</source>
        <translation>dagger, obelisk</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="274"/>
        <source>double dagger, double obelisk</source>
        <translation>double dagger, double obelisk</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="275"/>
        <source>bullet</source>
        <translation>bullet</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="276"/>
        <source>horizontal ellipsis</source>
        <translation>horizontal ellipsis</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="277"/>
        <source>per mille sign</source>
        <translation>per mille sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="278"/>
        <source>prime</source>
        <translation>prime</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="279"/>
        <source>double prime</source>
        <translation>double prime</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="280"/>
        <source>single left-pointing angle quotation mark</source>
        <translation>single left-pointing angle quotation mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="281"/>
        <source>single right-pointing angle quotation mark</source>
        <translation>single right-pointing angle quotation mark</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="282"/>
        <source>overline</source>
        <translation>overline</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="283"/>
        <source>fraction slash</source>
        <translation>fraction slash</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="284"/>
        <source>euro sign</source>
        <translation>euro sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="285"/>
        <source>black-letter capital I</source>
        <translation>black-letter capital I</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="286"/>
        <source>script capital P</source>
        <translation>script capital P</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="287"/>
        <source>black-letter capital R</source>
        <translation>black-letter capital R</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="288"/>
        <source>trademark symbol</source>
        <translation>trademark symbol</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="289"/>
        <source>alef symbol</source>
        <translation>alef symbol</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="290"/>
        <source>leftwards arrow</source>
        <translation>leftwards arrow</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="291"/>
        <source>upwards arrow</source>
        <translation>upwards arrow</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="292"/>
        <source>rightwards arrow</source>
        <translation>rightwards arrow</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="293"/>
        <source>downwards arrow</source>
        <translation>downwards arrow</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="294"/>
        <source>left right arrow</source>
        <translation>left right arrow</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="295"/>
        <source>downwards arrow with corner leftwards</source>
        <translation>downwards arrow with corner leftwards</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="296"/>
        <source>leftwards double arrow</source>
        <translation>leftwards double arrow</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="297"/>
        <source>upwards double arrow</source>
        <translation>upwards double arrow</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="298"/>
        <source>rightwards double arrow</source>
        <translation>rightwards double arrow</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="299"/>
        <source>downwards double arrow</source>
        <translation>downwards double arrow</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="300"/>
        <source>left right double arrow</source>
        <translation>left right double arrow</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="301"/>
        <source>for all</source>
        <translation>for all</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="302"/>
        <source>partial differential</source>
        <translation>partial differential</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="303"/>
        <source>there exists</source>
        <translation>there exists</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="304"/>
        <source>empty set</source>
        <translation>empty set</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="305"/>
        <source>nabla</source>
        <translation>nabla</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="306"/>
        <source>element of</source>
        <translation>element of</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="307"/>
        <source>not an element of</source>
        <translation>not an element of</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="308"/>
        <source>contains as member</source>
        <translation>contains as member</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="309"/>
        <source>n-ary product</source>
        <translation>n-ary product</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="310"/>
        <source>n-ary summation</source>
        <translation>n-ary summation</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="311"/>
        <source>minus sign</source>
        <translation>minus sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="312"/>
        <source>asterisk operator</source>
        <translation>asterisk operator</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="313"/>
        <source>square root</source>
        <translation>square root</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="314"/>
        <source>proportional to</source>
        <translation>proportional to</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="315"/>
        <source>infinity</source>
        <translation>infinity</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="316"/>
        <source>angle</source>
        <translation>angle</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="317"/>
        <source>logical and</source>
        <translation>logical and</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="318"/>
        <source>logical or</source>
        <translation>logical or</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="319"/>
        <source>intersection</source>
        <translation>intersection</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="320"/>
        <source>union</source>
        <translation>union</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="321"/>
        <source>integral</source>
        <translation>integral</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="322"/>
        <source>therefore sign</source>
        <translation>therefore sign</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="323"/>
        <source>tilde operator</source>
        <translation>tilde operator</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="324"/>
        <source>congruent to</source>
        <translation>congruent to</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="325"/>
        <source>almost equal to</source>
        <translation>almost equal to</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="326"/>
        <source>not equal to</source>
        <translation>not equal to</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="327"/>
        <source>identical to</source>
        <translation>identical to</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="328"/>
        <source>less-than or equal to</source>
        <translation>less-than or equal to</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="329"/>
        <source>greater-than or equal to</source>
        <translation>greater-than or equal to</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="330"/>
        <source>subset of</source>
        <translation>subset of</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="331"/>
        <source>superset of</source>
        <translation>superset of</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="332"/>
        <source>not a subset of</source>
        <translation>not a subset of</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="333"/>
        <source>subset of or equal to</source>
        <translation>subset of or equal to</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="334"/>
        <source>superset of or equal to</source>
        <translation>superset of or equal to</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="335"/>
        <source>circled plus</source>
        <translation>circled plus</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="336"/>
        <source>circled times</source>
        <translation>circled times</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="337"/>
        <source>up tack</source>
        <translation>up tack</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="338"/>
        <source>dot operator</source>
        <translation>dot operator</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="339"/>
        <source>left ceiling</source>
        <translation>left ceiling</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="340"/>
        <source>right ceiling</source>
        <translation>right ceiling</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="341"/>
        <source>left floor</source>
        <translation>left floor</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="342"/>
        <source>right floor</source>
        <translation>right floor</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="343"/>
        <source>left-pointing angle bracket</source>
        <translation>left-pointing angle bracket</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="344"/>
        <source>right-pointing angle bracket</source>
        <translation>right-pointing angle bracket</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="345"/>
        <source>lozenge</source>
        <translation>lozenge</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="346"/>
        <source>black spade suit</source>
        <translation>black spade suit</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="347"/>
        <source>black club suit</source>
        <translation>black club suit</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="348"/>
        <source>black heart suit</source>
        <translation>black heart suit</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="349"/>
        <source>black diamond suit</source>
        <translation>black diamond suit</translation>
    </message>
</context>
</TS>