<?xml version="1.0" ?><!DOCTYPE TS><TS language="ca" version="2.1">
<context>
    <name>About</name>
    <message>
        <location filename="../../Form_Files/About.ui" line="14"/>
        <source>About</source>
        <translation>Quant al Sigil</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="56"/>
        <source>The EPUB Editor</source>
        <translation>L&apos;editor d&apos;EPUB</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="70"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="107"/>
        <source>Homepage:</source>
        <translation>Lloc web:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="143"/>
        <source>Version:</source>
        <translation>Versió:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="170"/>
        <source>Loaded Qt:</source>
        <translation>Versió de Qt:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="200"/>
        <source>&lt;a href=&quot;http://www.gnu.org/licenses/gpl-3.0-standalone.html&quot;&gt;GNU General Public License v3&lt;/a&gt;</source>
        <translation>&lt;a href=&quot;http://www.gnu.org/licenses/gpl-3.0-standalone.html&quot;&gt;Llicència Pública General GNU v3&lt;/a&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="218"/>
        <source>Build time:</source>
        <translation>Data de muntatge:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="245"/>
        <source>License:</source>
        <translation>Llicència:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/About.ui" line="255"/>
        <source>Authors</source>
        <translation>Autors</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="41"/>
        <source>GNU General Public License v3</source>
        <translation>Llicència Pública General GNU v3</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="51"/>
        <source>Maintainer(s)</source>
        <translation>Mantenidors/s</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="56"/>
        <source>Previous Maintainer(s)</source>
        <translation>Mantenidors anteriors</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="60"/>
        <source>Code Contributors</source>
        <translation>Programadors contribuïdors</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="68"/>
        <source>Translators</source>
        <translation>Traductor</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="70"/>
        <source>Original Creator</source>
        <translation>Creador original</translation>
    </message>
    <message>
        <location filename="../../Dialogs/About.cpp" line="71"/>
        <source>retired</source>
        <translation>retirat</translation>
    </message>
</context>
<context>
    <name>AddMetadata</name>
    <message>
        <location filename="../../Form_Files/AddMetadata.ui" line="14"/>
        <source>Add metadata property</source>
        <translation>Afegeix una propietat a les metadades</translation>
    </message>
    <message>
        <location filename="../../Form_Files/AddMetadata.ui" line="50"/>
        <source>Metadata description</source>
        <translation>Descripció amb metadades</translation>
    </message>
</context>
<context>
    <name>AddSemantics</name>
    <message>
        <location filename="../../Form_Files/AddSemantics.ui" line="14"/>
        <source>Add Semantic Property</source>
        <translation>Afegeix una propietat semàntica</translation>
    </message>
    <message>
        <location filename="../../Form_Files/AddSemantics.ui" line="56"/>
        <source>Description of Semantic Properties</source>
        <translation>Descripció de les propietats semàntiques</translation>
    </message>
</context>
<context>
    <name>AllFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsAllFilesWidget.ui" line="14"/>
        <source>All Files</source>
        <translation>Tots els fitxers</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsAllFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>Mostra només els noms de fitxer que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsAllFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="73"/>
        <source>Directory</source>
        <translation>Carpeta</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="74"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="75"/>
        <source>File Size (KB)</source>
        <translation>Mida del fitxer (kB)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="76"/>
        <source>Type</source>
        <translation>Tipus</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="77"/>
        <source>Semantics</source>
        <translation>Semàntica</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="79"/>
        <source>Properties</source>
        <translation>Propietats</translation>
    </message>
    <message numerus="yes">
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="148"/>
        <source>%n file(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="261"/>
        <source>Save Report As Comma Separated File</source>
        <translation>Desa l&apos;informe com a fitxer de text separat per comes</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="274"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="274"/>
        <source>Cannot save report file.</source>
        <translation>No es pot desar el fitxer d&apos;informe.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="299"/>
        <source>Image</source>
        <translation>Imatge</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="304"/>
        <source>Audio</source>
        <translation>Àudio</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="309"/>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="314"/>
        <source>Font</source>
        <translation>Tipus de lletra</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/AllFilesWidget.cpp" line="341"/>
        <source>Unknown</source>
        <translation>Desconegut</translation>
    </message>
</context>
<context>
    <name>AppearanceWidget</name>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="14"/>
        <source>Appearance</source>
        <translation>Aparença</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="24"/>
        <source>Fonts / Colors</source>
        <translation>Fonts / Colors</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="30"/>
        <source>Book View / Preview:</source>
        <translation>Vista de llibre / Vista prèvia:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="39"/>
        <source>If no font is specified in the CSS for your page, the following font will be used to display within Sigil. These fonts will not be used in your actual ebook.</source>
        <translation>Si no s&apos;especifica cap font al CSS per a la vostra pàgina, la font següent es farà servir per ser visualitzada al Sigil. Aquestes fonts no es faran servir en el vostre llibre electrònic actual.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="59"/>
        <source>Default font size to be used for Book View and Preview
if no font-size specified in your CSS</source>
        <translation>Cos de lletra per defecte que es farà servir a la vista de llibre i a la vista prèvia
si no hi ha cap cos de lletra especificat al CSS</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="63"/>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="197"/>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="313"/>
        <source>Font Size:</source>
        <translation>Cos de lletra:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="93"/>
        <source>Default font family to be used for Book View and Preview
if no font-family specified in your CSS</source>
        <translation>Família de lletra per defecte que es farà servir a la vista de llibre i a la vista prèvia
si no hi ha cap tipus de lletra especificat al CSS</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="97"/>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="227"/>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="346"/>
        <source>Standard Font:</source>
        <translation>Tipus de lletra estàndard:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="107"/>
        <source>Default font family to be used for Book View and Preview
if a serif font-family specified in your CSS</source>
        <translation>Família de lletra per defecte que es farà servir a la vista de llibre i a la vista prèvia
si al CSS s&apos;especifica un tipus de lletra serif</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="111"/>
        <source>Serif Font:</source>
        <translation>Tipus de lletra serif:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="121"/>
        <source>Default font family to be used for Book View and Preview
if a sans-serif font-family specified in your CSS</source>
        <translation>Família de lletra per defecte que es farà servir a la vista de llibre i a la vista prèvia
si al CSS s&apos;especifica un tipus de lletra de pal sec</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="125"/>
        <source>Sans-Serif Font:</source>
        <translation>Tipus de lletra de pal sec:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="171"/>
        <source>CSS / Code View:</source>
        <translation>CSS / Vista de codi:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="181"/>
        <source>Item Colors:</source>
        <translation>Color dels elements:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="194"/>
        <source>Font size to be used for text in Code View.</source>
        <translation>Cos de lletra que es farà servir pel text a la vista de codi.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="224"/>
        <source>Font family to be used for text in Code View.</source>
        <translation>Família de lletra que es farà servir pel text a la vista de codi.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="263"/>
        <source>Select an alternative color for this display item</source>
        <translation>Selecciona un color alternatiu per a l&apos;element de visualització</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="266"/>
        <source>Custom Color...</source>
        <translation>Color personalitzat...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="296"/>
        <source>Insert Special Characters:</source>
        <translation>Inserció de caràcters especials:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="310"/>
        <source>Font size to be used for Insert Special Characters window</source>
        <translation>Cos de lletra que es farà servir a la finestra d&apos;inserció de caràcters especials</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="343"/>
        <source>Font family to be used for Insert Special Characters window</source>
        <translation>Família de lletra que es farà servir a la finestra d&apos;inserció de caràcters especials</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="388"/>
        <source>Menus</source>
        <translation>Menús</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="394"/>
        <source>Main Menu Icon Size</source>
        <translation>Mida de les icones del menú principal</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="400"/>
        <source>Adjust the size of the icons in the main menu.</source>
        <translation>Ajusteu la mida de les icones al menú principal.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="476"/>
        <source>Reset all fonts and colors to the default values</source>
        <translation>Reinicia tots els tipus de lletra i els colors als seus valors predeterminats</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PAppearanceWidget.ui" line="479"/>
        <source>Reset All</source>
        <translation>Reinicia-ho tot</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="204"/>
        <source>Background</source>
        <translation>Fons</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="205"/>
        <source>Foreground</source>
        <translation>Primer pla</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="206"/>
        <source>CSS Comment</source>
        <translation>Comentari CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="207"/>
        <source>CSS Property</source>
        <translation>Propietat CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="208"/>
        <source>CSS Quote</source>
        <translation>Text entre cometes CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="209"/>
        <source>CSS Selector</source>
        <translation>Selector CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="210"/>
        <source>CSS Value</source>
        <translation>Valor CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="211"/>
        <source>Line Highlight</source>
        <translation>Ressaltat de línia</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="212"/>
        <source>Line# Background</source>
        <translation>Fons de la numeració de línia</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="213"/>
        <source>Line# Foreground</source>
        <translation>Primer pla de la numeració de línia</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="214"/>
        <source>Selection Background</source>
        <translation>Selecció del fons</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="215"/>
        <source>Selection Foreground</source>
        <translation>Selecció del primer pla</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="216"/>
        <source>Spelling Underline</source>
        <translation>Subratllat de la correcció ortogràfica</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="217"/>
        <source>XHTML Attribute Name</source>
        <translation>Nom d&apos;atribut XHTML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="218"/>
        <source>XHTML Attribute Value</source>
        <translation>Valor d&apos;atribut XHTML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="219"/>
        <source>XHTML CSS</source>
        <translation>CSS XHTML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="220"/>
        <source>XHTML CSS Comment</source>
        <translation>Comentari CSS XHTML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="221"/>
        <source>XHTML DocType</source>
        <translation>DocType XHTML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="222"/>
        <source>XHTML Entity</source>
        <translation>Entitat XHTML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="223"/>
        <source>XHTML HTML Tag</source>
        <translation>Etiqueta HTML XHTML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="224"/>
        <source>XHTML HTML Comment</source>
        <translation>Comentari HTML XHTML</translation>
    </message>
</context>
<context>
    <name>Book</name>
    <message>
        <location filename="../../BookManipulation/Book.cpp" line="399"/>
        <source>Start</source>
        <translation>Inici</translation>
    </message>
</context>
<context>
    <name>BookBrowser</name>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="61"/>
        <source>Book Browser</source>
        <translation>Navegador del llibre</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="72"/>
        <source>Font Obfuscation</source>
        <translation>Ofuscament dels tipus de lletra</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="73"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="1418"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="1525"/>
        <source>Open With</source>
        <translation>Obre amb</translation>
    </message>
    <message numerus="yes">
        <location filename="../../MainUI/BookBrowser.cpp" line="127"/>
        <source>%n file(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="217"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="624"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="640"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="689"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="789"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="996"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="217"/>
        <source>Are you sure you want to sort the selected files alphanumerically?</source>
        <translation>Esteu segur que voleu ordenar els arxius seleccionats alfanumèricament?</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="217"/>
        <source>This action cannot be reversed.</source>
        <translation>Aquesta acció no es pot desfer.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="243"/>
        <source>The file &quot;%1&quot; does not exist.</source>
        <translation>El fitxer «%1» no existeix.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="567"/>
        <source>Add Existing Files</source>
        <translation>Afegeix fitxers</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="600"/>
        <source>File is not an image and cannot be used:

&quot;%1&quot;.</source>
        <translation>El fitxer no es pot utilitzar ja que no és una imatge:

«%1».</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="609"/>
        <source>File is not multimedia (image, video, audio) and cannot be inserted:

&quot;%1&quot;.</source>
        <translation>El fitxer no es pot inserir ja que no és un fitxer multimèdia (imatge, vídeo, àudio):

«%1».</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="624"/>
        <source>The multimedia file &quot;%1&quot; already exists in the book.

OK to replace?</source>
        <translation>El fitxer multimèdia «%1» ja existeix dins el llibre.

Voleu reemplaçar-lo?</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="635"/>
        <source>Unable to delete or replace file &quot;%1&quot;.</source>
        <translation>No s&apos;ha pogut esborrar ni reemplaçar el fitxer «%1».</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="640"/>
        <source>Unable to load &quot;%1&quot;

A file with this name already exists in the book.</source>
        <translation>No s&apos;ha pogut carregar «%1»

Al llibre, ja hi ha un fitxer amb el mateix nom.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="690"/>
        <source>The following file(s) were not loaded due to invalid content or not well formed XML:

%1</source>
        <translation>No s&apos;han pogut carregar els fitxers següents ja que tenen contingut incorrecte o XML mal format:

%1</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="704"/>
        <source>File(s) added.</source>
        <translation>Fitxers afegits.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="739"/>
        <source>Save As File</source>
        <translation>Desa com a fitxer</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="761"/>
        <source>Unable to save the file.</source>
        <translation>No s&apos;ha pogut desar el fitxer.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="769"/>
        <source>Choose the directory to save the files to</source>
        <translation>Escolliu el directori on voleu desar els fitxers</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="789"/>
        <source>One or more files already exists.  OK to overwrite?</source>
        <translation>Un o més fitxers ja existeixen.  Voleu sobreescriure&apos;ls?</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="806"/>
        <source>Unable to save files.  Destination may be a directory.</source>
        <translation>No s&apos;ha pogut desar els fitxers. La destinació ha de ser un directori.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="814"/>
        <source>Unable to save files.</source>
        <translation>No s&apos;ha pogut desar els fitxers.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="996"/>
        <source>Cannot rename files since this would result in duplicate filenames.</source>
        <translation>No s&apos;ha pogut canviar el nom dels fitxers ja que es repetirien noms.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1059"/>
        <source>The Nav document can not be removed.</source>
        <translation>No es pot esborrar el document NAV.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1067"/>
        <source>Neither the NCX nor the OPF can be removed.</source>
        <translation>No es poden eliminar els fitxers NCX i OPF.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1074"/>
        <source>You cannot remove all html files.
There always has to be at least one.</source>
        <translation>No podeu esborrar tots els fitxers HTML.
Com a mínim, n&apos;hi ha d&apos;haver un.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1214"/>
        <source>Unable to set file as cover image.</source>
        <translation>No s&apos;ha pogut establir el fitxer com a imatge de la coberta.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1399"/>
        <source>Select All</source>
        <translation>Selecciona-ho tot</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1400"/>
        <source>Add Blank HTML File</source>
        <translation>Afegeix un fitxer HTML en blanc</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1401"/>
        <source>Add Blank Stylesheet</source>
        <translation>Afegeix un full d&apos;estils en blanc</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1402"/>
        <source>Add Blank SVG Image</source>
        <translation>Afegeix una imatge SVG en blanc</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1403"/>
        <source>Add Existing Files...</source>
        <translation>Afegeix fitxers...</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1404"/>
        <location filename="../../MainUI/BookBrowser.cpp" line="1405"/>
        <source>Add Copy</source>
        <translation>Afegeix una còpia</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1406"/>
        <source>Rename</source>
        <translation>Canvia el nom</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1407"/>
        <source>Delete</source>
        <translation>Esborrar</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1408"/>
        <source>Cover Image</source>
        <translation>Imatge de la coberta</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1409"/>
        <source>Merge</source>
        <translation>Combina</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1410"/>
        <source>None</source>
        <translation>Cap</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1411"/>
        <source>Use Adobe&apos;s Method</source>
        <translation>Utilitza el mètode d&apos;Adobe</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1412"/>
        <source>Use IDPF&apos;s Method</source>
        <translation>Utilitza el mètode de l&apos;IDPF</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1413"/>
        <source>Sort</source>
        <translation>Ordena</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1414"/>
        <source>Renumber TOC Entries</source>
        <translation>Torna a numerar les entrades de la taula de continguts</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1415"/>
        <source>Link Stylesheets...</source>
        <translation>Enllaça-hi fulls d&apos;estils...</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1416"/>
        <source>Add Semantics...</source>
        <translation>Afegeix informació semàntica...</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1417"/>
        <source>Validate with W3C</source>
        <translation>Valida amb el W3C</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1419"/>
        <source>Save As</source>
        <translation>Anomena i desa</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1433"/>
        <source>Merge with previous file, or merge multiple files into one.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1436"/>
        <source>Rename selected file(s)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1438"/>
        <source>Link Stylesheets to selected file(s).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1440"/>
        <source>Add Semantics to selected file(s).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="1560"/>
        <source>Other Application</source>
        <translation>Una altra aplicació</translation>
    </message>
</context>
<context>
    <name>BookViewEditor</name>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="722"/>
        <source>Clipboard contains HTML formatting</source>
        <translation>El porta-retalls conté format HTML</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="723"/>
        <source>Do you want to paste clipboard data as plain text?</source>
        <translation>Voleu copiar les dades del porta-retalls com a text pla?</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="938"/>
        <source>Open Tab For</source>
        <translation>Obre una pestanya per</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="956"/>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1161"/>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1163"/>
        <source>Open With</source>
        <translation>Obre amb</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="991"/>
        <source>Other Application</source>
        <translation>Una altra aplicació</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1039"/>
        <source>Clips</source>
        <translation>Retalls</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1049"/>
        <source>Add To Clips</source>
        <translation>Afegeix als retalls</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1147"/>
        <source>Insert File</source>
        <translation>Inserireix un fitxer</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1148"/>
        <source>Undo</source>
        <translation>Desfés</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1149"/>
        <source>Redo</source>
        <translation>Refés</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1150"/>
        <source>Cut</source>
        <translation>Retalla</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1151"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1152"/>
        <source>Copy Image</source>
        <translation>Copia la imatge</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1153"/>
        <source>Paste</source>
        <translation>Enganxa</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1154"/>
        <source>Select All</source>
        <translation>Selecciona-ho tot</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1155"/>
        <source>Open</source>
        <translation>Obre</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1162"/>
        <source>Save As</source>
        <translation>Anomena i desa</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewEditor.cpp" line="1170"/>
        <source>Inspect Element</source>
        <translation>Inspecciona l&apos;element</translation>
    </message>
</context>
<context>
    <name>BookViewPreview</name>
    <message>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="267"/>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="332"/>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="338"/>
        <source>Unsupported</source>
        <translation>No admès</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="267"/>
        <source>Spellcheck mode is not supported in Book View at this time.  Switch to Code View.</source>
        <translation>El mode de correcció ortogràfica no s&apos;admet, de moment, en la vista de llibre. Canvieu a vista de codi.</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="332"/>
        <source>Replace is not supported in this view. Switch to Code View.</source>
        <translation>L&apos;opció de reemplaçar no s&apos;admet en aquesta vista. Canvieu a vista de codi.</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="338"/>
        <source>Replace All for the current file is not supported in this view. Switch to Code View.</source>
        <translation>L&apos;opció de reemplaçar-ho tot no s&apos;admet en aquesta vista. Canvieu a vista de codi.</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/BookViewPreview.cpp" line="758"/>
        <source>Inspect Element</source>
        <translation>Inspecciona l&apos;element</translation>
    </message>
</context>
<context>
    <name>CSSFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsCSSFilesWidget.ui" line="14"/>
        <source>CSS Files</source>
        <translation>Fitxers CSS</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsCSSFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>Mostra només els noms de fitxers que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsCSSFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="75"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="76"/>
        <source>Size (KB)</source>
        <translation>Mida (kB)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="77"/>
        <source>Times Used</source>
        <translation>Vegades que s&apos;utilitza</translation>
    </message>
    <message numerus="yes">
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="142"/>
        <source>%n file(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="146"/>
        <source>KB</source>
        <translation>kB</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="273"/>
        <source>Save Report As Comma Separated File</source>
        <translation>Desa un informe com a fitxer de text separat per comes</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="286"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="286"/>
        <source>Cannot save report file.</source>
        <translation>No es pot desar el fitxer de l&apos;informe.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CSSFilesWidget.cpp" line="297"/>
        <source>Delete From Book</source>
        <translation>Elimina-ho del llibre</translation>
    </message>
</context>
<context>
    <name>CSSResource</name>
    <message>
        <location filename="../../ResourceObjects/CSSResource.cpp" line="99"/>
        <source>Sigil will send your stylesheet data to the &lt;a href=&apos;http://jigsaw.w3.org/css-validator/&apos;&gt;W3C Validation Service&lt;/a&gt;.</source>
        <translation>El Sigil enviarà el full d&apos;estil al &lt;a href=&apos;http://jigsaw.w3.org/css-validator/&apos;&gt;Servei de validació del W3C &lt;/a&gt;.</translation>
    </message>
    <message>
        <location filename="../../ResourceObjects/CSSResource.cpp" line="100"/>
        <source>This page should disappear once loaded after 3 seconds.</source>
        <translation>La pàgina hauria de desaparèixer 3 segons després d&apos;haver-se carregat.</translation>
    </message>
    <message>
        <location filename="../../ResourceObjects/CSSResource.cpp" line="101"/>
        <source>If your browser does not have javascript enabled, click on the button below.</source>
        <translation>Si el navegador no té activat el javascript, feu clic al botó de sota.</translation>
    </message>
</context>
<context>
    <name>CharactersInHTMLFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsCharactersInHTMLFilesWidget.ui" line="14"/>
        <source>Characters in HTML Files</source>
        <translation>Caràcters als fitxers HTML</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsCharactersInHTMLFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>Mostra només els noms de fitxers que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsCharactersInHTMLFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsCharactersInHTMLFilesWidget.ui" line="76"/>
        <source>Characters:</source>
        <translation>Caràcters:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="80"/>
        <source>Character</source>
        <translation>Caràcter</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="81"/>
        <source>Decimal</source>
        <translation>Decimal</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="82"/>
        <source>Hexadecimal</source>
        <translation>Hexadecimal</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="83"/>
        <source>Entity Name</source>
        <translation>Nom de l&apos;entitat</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="84"/>
        <source>Entity Description</source>
        <translation>Descripció de l&apos;entitat</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="90"/>
        <source>&lt;p&gt;This is a list of the characters used in all HTML files.&lt;p&gt;</source>
        <translation>&lt;p&gt;Llista dels caràcters utilitzats a tots els fitxers HTML.&lt;p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="271"/>
        <source>Save Report As Comma Separated File</source>
        <translation>Desa l&apos;informe com a fitxer de text separat per comes</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="284"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/CharactersInHTMLFilesWidget.cpp" line="284"/>
        <source>Cannot save report file.</source>
        <translation>No es pot desar el fitxer de l&apos;informe.</translation>
    </message>
</context>
<context>
    <name>ClassesInHTMLFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsClassesInHTMLFilesWidget.ui" line="14"/>
        <source>Style Classes in HTML Files</source>
        <translation>Classes d&apos;estil dels fitxers HTML</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsClassesInHTMLFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>Mostra només els noms de fitxers que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsClassesInHTMLFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="83"/>
        <source>HTML File</source>
        <translation>Fitxer HTML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="84"/>
        <source>Element</source>
        <translation>Element</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="85"/>
        <source>Class</source>
        <translation>Classe</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="86"/>
        <source>Matched Selector</source>
        <translation>Selector coincident</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="87"/>
        <source>Found In</source>
        <translation>Trobat a</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="93"/>
        <source>&lt;p&gt;This is a list of the style classes used in all HTML files and whether or not the style matched a selector in a linked stylesheet.&lt;p&gt;</source>
        <translation>&lt;p&gt;Llista de les classes d&apos;estil utilitzades a tots els fitxers HTML, tan si coincideixen o no amb un selector d&apos;un full d&apos;estils enllaçat.&lt;p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="94"/>
        <source>&lt;p&gt;NOTE:&lt;/p&gt;</source>
        <translation>&lt;p&gt;NOTA:&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="95"/>
        <source>&lt;p&gt;Due to the complexities of CSS you must check your code manually to be certain if a style is used or not.&lt;/p&gt;</source>
        <translation>&lt;p&gt;La complexitat del CSS obliga a revisar el codi manualment per comprovar si un estil s&apos;utilitza o no.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="229"/>
        <source>Save Report As Comma Separated File</source>
        <translation>Desa un informe com a fitxer de text separat per comes</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="242"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ClassesInHTMLFilesWidget.cpp" line="242"/>
        <source>Cannot save report file.</source>
        <translation>No es pot desar el fitxer d&apos;informe.</translation>
    </message>
</context>
<context>
    <name>ClipEditor</name>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="14"/>
        <location filename="../../Dialogs/ClipEditor.cpp" line="525"/>
        <source>Clip Editor</source>
        <translation>Editor de retalls</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="23"/>
        <source>Filter Name:</source>
        <translation>Filtra el nom:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="28"/>
        <source>Filter All:</source>
        <translation>Filtra-ho tot:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="36"/>
        <source>List only the entries containing the text you enter.</source>
        <translation>Mostra només les entrades que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="65"/>
        <source>Paste the selected entry into the active window.</source>
        <translation>Enganxa l&apos;entrada seleccionada a la finestra activa.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="68"/>
        <source>Paste Clip</source>
        <translation>Enganxa el retall</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="91"/>
        <location filename="../../Dialogs/ClipEditor.cpp" line="636"/>
        <source>Add Entry</source>
        <translation>Afegeix una entrada</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="98"/>
        <location filename="../../Dialogs/ClipEditor.cpp" line="637"/>
        <source>Add Group</source>
        <translation>Afegeix un grup</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="123"/>
        <source>Move an entry up one entry in the same group.</source>
        <translation>Mou una entrada una posició amunt dins del seu grup.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="126"/>
        <location filename="../../Form_Files/ClipEditor.ui" line="156"/>
        <location filename="../../Form_Files/ClipEditor.ui" line="185"/>
        <location filename="../../Form_Files/ClipEditor.ui" line="215"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="153"/>
        <source>Move an entry to the level of its parent.</source>
        <translation>Mou una entrada al mateix nivell que la seva matriu.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="182"/>
        <source>You must select an item immediately under a group to move it into the group.</source>
        <translation>Cal que l&apos;element estigui just a sota del grup per poder-lo moure dins.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipEditor.ui" line="212"/>
        <source>Move an entry down one in the group.</source>
        <translation>Mou una entrada una posició avall dins del seu grup.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="73"/>
        <source>Right click on an entry to see a context menu of actions.</source>
        <translation>Cliqueu amb el botó dret sobre una entrada per mostrar
un menú d&apos;accions contextual.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="74"/>
        <source>You can also right click in your document to select an entry.</source>
        <translation>També podeu seleccionar una entrada fent clic amb el botó dret al document.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="76"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="76"/>
        <source>Name of your entry or group.</source>
        <translation>Nom de l&apos;entrada o del grup.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="77"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="77"/>
        <source>The text to insert. The text is treated like a Regex replacement expression so \1 can be used to insert the text selected in Code View when you paste the clip.</source>
        <translation>El text per inserir. Aquest text es tracta com un reemplaçament d&apos;expressió regular, de manera que es pot utilitzar \1 per inserir el text seleccionat quan s&apos;enganxa el retall en la vista de codi.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="81"/>
        <source>Save</source>
        <translation>Desa</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="81"/>
        <source>Save your changes.</source>
        <translation>Desa els canvis.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="81"/>
        <source>If any other instances of Sigil are running they will be automatically updated with your changes.</source>
        <translation>Si hi ha altres instàncies del Sigil executant-se, se n&apos;actualitzaran automàticament els canvis.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="91"/>
        <source>Cannot save entries.</source>
        <translation>No es poden desar les entrades.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="135"/>
        <source>Clip entries loaded from file.</source>
        <translation>Entrades de retalls carregades del fitxer.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="195"/>
        <source>You cannot select an entry and a group containing the entry.</source>
        <translation>No es pot seleccionar a la vegada una entrada i el grup que la conté.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="282"/>
        <source>You cannot Copy or Cut groups - use drag-and-drop.</source>
        <translation>Els grups no es poden copiar ni retallar. Podeu arrossegar-los i deixar-los anar.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="354"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="354"/>
        <source>Are you sure you want to reload all entries?  This will overwrite any unsaved changes.</source>
        <translation>Esteu segur que voleu tornar a carregar totes les entrades? Tots els canvis sense desar es sobreescriuran.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="370"/>
        <source>Import Entries</source>
        <translation>Importa entrades</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="444"/>
        <source>Export Selected Entries</source>
        <translation>Exporta les entrades seleccionades</translation>
    </message>
    <message numerus="yes">
        <location filename="../../Dialogs/ClipEditor.cpp" line="525"/>
        <source>CSS entries added: %n</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="638"/>
        <source>Edit</source>
        <translation>Edita</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="639"/>
        <source>Cut</source>
        <translation>Retalla</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="640"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="641"/>
        <source>Paste</source>
        <translation>Enganxa</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="642"/>
        <source>Delete</source>
        <translation>Esborra</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="643"/>
        <source>Import</source>
        <translation>Importa</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="644"/>
        <source>Reload</source>
        <translation>Torna a carregar</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="645"/>
        <source>Export</source>
        <translation>Exporta</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="646"/>
        <source>Export All</source>
        <translation>Exporta-ho tot</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="647"/>
        <source>Collapse All</source>
        <translation>Redueix-ho tot</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="648"/>
        <source>Expand All</source>
        <translation>Amplia-ho tot</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="649"/>
        <source>Autofill</source>
        <translation>Emplena automàticament</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="729"/>
        <source>Clip entries saved.</source>
        <translation>S&apos;han desat les entrades de retall.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="758"/>
        <source>Sigil: Clip Editor</source>
        <translation>Sigil: Editor de retalls</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipEditor.cpp" line="759"/>
        <source>The Clip entries may have been modified.
Do you want to save your changes?</source>
        <translation>Les entrades de retalls poden haver estat modificades.
Voleu desar-ne els canvis?</translation>
    </message>
</context>
<context>
    <name>ClipEditorModel</name>
    <message>
        <location filename="../../MiscEditors/ClipEditorModel.cpp" line="65"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/ClipEditorModel.cpp" line="66"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/ClipEditorModel.cpp" line="680"/>
        <source>Unable to create file %1</source>
        <translation>No s&apos;ha pogut crear el fitxer %1</translation>
    </message>
</context>
<context>
    <name>ClipboardHistorySelector</name>
    <message>
        <location filename="../../Form_Files/ClipboardHistorySelector.ui" line="14"/>
        <source>Select Text to Paste</source>
        <translation>Selecciona el text per enganxar</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ClipboardHistorySelector.ui" line="20"/>
        <source>Recent clipboards:</source>
        <translation>Porta-retalls recents:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipboardHistorySelector.cpp" line="337"/>
        <source>Paste</source>
        <translation>Enganxa</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ClipboardHistorySelector.cpp" line="339"/>
        <source>Save</source>
        <translation>Desa</translation>
    </message>
</context>
<context>
    <name>ClipsWindow</name>
    <message>
        <location filename="../../MainUI/ClipsWindow.cpp" line="34"/>
        <source>Clips</source>
        <translation>Retalls</translation>
    </message>
    <message>
        <location filename="../../MainUI/ClipsWindow.cpp" line="99"/>
        <source>Collapse All</source>
        <translation>Redueix-ho tot</translation>
    </message>
    <message>
        <location filename="../../MainUI/ClipsWindow.cpp" line="100"/>
        <source>Expand All</source>
        <translation>Amplia-ho tot</translation>
    </message>
</context>
<context>
    <name>CodeViewEditor</name>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="419"/>
        <source>Cannot insert closing tag at this position.</source>
        <translation>No es pot inserir una etiqueta de tancament en aquesta posició.</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="428"/>
        <source>No open tags found at this position.</source>
        <translation>No s&apos;han trobat etiquetes obertes en aquesta posició.</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1176"/>
        <source>Add To Default Dictionary</source>
        <translation>Afegeix al diccionari predeterminat</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1189"/>
        <source>Add To Dictionary</source>
        <translation>Afegeix al diccionari</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1206"/>
        <source>Ignore</source>
        <translation>Ignora-ho</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1268"/>
        <source>Reformat CSS</source>
        <translation>Tornar a formatar el CSS</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1269"/>
        <source>Multiple Lines Per Style</source>
        <translation>Estil en diverses línies</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1270"/>
        <source>Single Line Per Style</source>
        <translation>Estil en una sola línia</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1295"/>
        <source>Reformat HTML</source>
        <translation>Reformata l&apos;HTML</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1296"/>
        <source>Mend and Prettify Code</source>
        <translation>Repara i poleix el codi</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1297"/>
        <source>Mend and Prettify Code - All HTML Files</source>
        <translation>Repara i poleix el codi - Tots els fitxers HTML</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1298"/>
        <source>Mend Code</source>
        <translation>Repara el codi</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1299"/>
        <source>Mend Code - All HTML Files</source>
        <translation>Reapara el codi - Tots els fitxers HTML</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1329"/>
        <source>Go To Link Or Style</source>
        <translation>Vés a l&apos;enllaç o a l&apos;estil</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1352"/>
        <source>View Image</source>
        <translation>Visualitza la imatge</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1353"/>
        <source>Open Tab For Image</source>
        <translation>Obre una pestanya amb la imatge</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1379"/>
        <source>Mark Selected Text</source>
        <translation>Marca el text seleccionat</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1381"/>
        <source>Unmark Marked Text</source>
        <translation>Desmarca el text marcat</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1407"/>
        <source>Clips</source>
        <translation>Retalls</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1417"/>
        <source>Add To Clips</source>
        <translation>Afegeix als retalls</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1543"/>
        <source>You must be in an opening HTML tag to use this feature.</source>
        <translation>Aquesta característica només es pot utilitzar en una etiqueta HTML d&apos;obertura.</translation>
    </message>
    <message>
        <location filename="../../ViewEditors/CodeViewEditor.cpp" line="1553"/>
        <source>You must be inside an opening HTML tag to use this feature.</source>
        <translation>Aquesta característica només es pot utilitzar dins d&apos;una etiqueta HTML d&apos;obertura.</translation>
    </message>
</context>
<context>
    <name>ColorSwatchDelegate</name>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="56"/>
        <source>Background</source>
        <translation>Fons</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="58"/>
        <source>Foreground</source>
        <translation>Primer pla</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="60"/>
        <source>Selection Background</source>
        <translation>Seleccionar fons</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/AppearanceWidget.cpp" line="62"/>
        <source>Selection Foreground</source>
        <translation>Seleccionar primer pla</translation>
    </message>
</context>
<context>
    <name>DeleteFiles</name>
    <message>
        <location filename="../../Form_Files/DeleteFiles.ui" line="14"/>
        <source>Delete Files</source>
        <translation>Esborrar fitxers</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteFiles.cpp" line="66"/>
        <source>Delete Marked Files</source>
        <translation>Eliminar els fitxers marcats</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteFiles.cpp" line="67"/>
        <source>Delete</source>
        <translation>Esborrar</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteFiles.cpp" line="68"/>
        <source>File</source>
        <translation>Fitxer</translation>
    </message>
</context>
<context>
    <name>DeleteStyles</name>
    <message>
        <location filename="../../Form_Files/DeleteStyles.ui" line="14"/>
        <source>Delete Styles</source>
        <translation>Esborrar estils</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteStyles.cpp" line="79"/>
        <source>Delete Marked Styles</source>
        <translation>Esborrar Estils</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteStyles.cpp" line="80"/>
        <source>Delete</source>
        <translation>Esborrar</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteStyles.cpp" line="81"/>
        <source>File</source>
        <translation>Fitxer</translation>
    </message>
    <message>
        <location filename="../../Dialogs/DeleteStyles.cpp" line="82"/>
        <source>Style</source>
        <translation>Estil</translation>
    </message>
</context>
<context>
    <name>EditTOC</name>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="14"/>
        <source>Edit Table Of Contents</source>
        <translation>Edita la taula de continguts</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="52"/>
        <source>Insert a blank entry above the currently selected entry.</source>
        <translation>Insereix una entrada en blanc damunt l&apos;entrada seleccionada actual.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="55"/>
        <source>Add Above</source>
        <translation>Afegeix al damunt</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="62"/>
        <source>Add a blank entry below the currently selected entry.</source>
        <translation>Insereix una entrada en blanc sota l&apos;entrada seleccionada actual.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="65"/>
        <source>Add Below</source>
        <translation>Afegeix a sota</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="72"/>
        <source>Delete the selected TOC entry</source>
        <translation>Esborra l&apos;entrada seleccionada de la taula de continguts</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="75"/>
        <location filename="../../Dialogs/EditTOC.cpp" line="443"/>
        <source>Delete</source>
        <translation>Esborra</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="82"/>
        <source>Set the destination of the TOC entry from a list of valid targets in the book.</source>
        <translation>Estableix la destinació de l&apos;entrada de la taula de continguts d&apos;entre una llista de possibles objectius del llibre.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="85"/>
        <source>Select Target</source>
        <translation>Selecciona l&apos;objectiu</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="110"/>
        <source>Decrease the heading level of the selected entry.
You can also use the left arrow key.</source>
        <translation>Disminueix el nivell d&apos;encapçalament de l&apos;entrada seleccionada.
També podeu utilitzar la fletxa esquerra.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="126"/>
        <location filename="../../Form_Files/EditTOC.ui" line="136"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/EditTOC.ui" line="148"/>
        <source>Increase the heading level of the selected entry.
You can also use the right arrow key.</source>
        <translation>Augmenta el nivell de capçalera de l&apos;entrada seleccionada.
També podeu utilitzar la fletxa dreta.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="85"/>
        <source>TOC Entry</source>
        <translation>Entrada de la taula de continguts</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="86"/>
        <source>Target</source>
        <translation>Objectiu</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="442"/>
        <source>Rename</source>
        <translation>Canvia el nom</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="450"/>
        <source>Move Up</source>
        <translation>Moure a dalt</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="451"/>
        <source>Move Down</source>
        <translation>Moure a sota</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="457"/>
        <source>Expand All</source>
        <translation>Amplia-ho tot</translation>
    </message>
    <message>
        <location filename="../../Dialogs/EditTOC.cpp" line="458"/>
        <source>Collapse All</source>
        <translation>Redueix-ho tot</translation>
    </message>
</context>
<context>
    <name>EmbeddedPython</name>
    <message>
        <location filename="../../Misc/EmbeddedPython.cpp" line="617"/>
        <location filename="../../Misc/EmbeddedPythonPkg.cpp" line="613"/>
        <source>Embedded Python Error</source>
        <translation>Error Python incrustat</translation>
    </message>
</context>
<context>
    <name>FindReplace</name>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="20"/>
        <source>Find &amp; Replace</source>
        <translation>Cerca i reemplaça</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="55"/>
        <source>Hide Find and Replace</source>
        <translation>Oculta cerca i reemplaça</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="61"/>
        <location filename="../../Form_Files/FindReplace.ui" line="109"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="103"/>
        <source>Show/Hide Advanced Options</source>
        <translation>Mostra/oculta les opcions avançades</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="152"/>
        <source>Find:</source>
        <translation>Cerca:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="184"/>
        <source>Find next match.</source>
        <translation>Cerca la següent coincidència.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="190"/>
        <source>Find</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="203"/>
        <source>Replace highlighted match (if any),
then find the Next match in Code View.</source>
        <translation>Reemplaça la coincidència ressaltada (si n&apos;hi ha alguna)
i cerca la coincidència següent, a la vista de codi.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="210"/>
        <source>Replace/Find</source>
        <translation>Reemplaça i cerca</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="217"/>
        <source>Replace:</source>
        <translation>Reemplaça:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="249"/>
        <source>Replace highlighted match (if any) in Code View.</source>
        <translation>Reemplaça la coincidència ressaltada (si n&apos;hi ha alguna), a la vista de codi.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="255"/>
        <source>Replace</source>
        <translation>Reemplaça</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="268"/>
        <source>Replace all matches in Code View.</source>
        <translation>Reemplaça totes les coincidències, a la vista de codi.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="274"/>
        <source>Replace All</source>
        <translation>Reemplaça-ho tot</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="281"/>
        <source>Options:</source>
        <translation>Opcions:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="293"/>
        <source>For Regex searches, prefix your search with (?s).</source>
        <translation>Prefixa les cerques en mode expressió regular amb (?s).</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="299"/>
        <source>DotAll</source>
        <translation>Multilínia</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="306"/>
        <source>For Regex searches, prefix your search with (?U).</source>
        <translation>Prefixa les cerques en mode expressió regular amb (?U).</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="312"/>
        <source>Minimal Match</source>
        <translation>Coincidència mínima</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="319"/>
        <source>For Regex searches, tokenise/escape selection when opening Find.</source>
        <translation>A les cerques en mode expressió regular, separa les paraules i escapa
alguns caràcters de la selecció en obrir el diàleg de cerca.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="325"/>
        <source>Auto-Tokenise</source>
        <translation>Separa les paraules</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="332"/>
        <source>Search from current position to end of the 
current file or book, and then wrap to the
other end to continue searching.</source>
        <translation>Cerca des del punt d&apos;inserció fins al final
del fitxer o del llibre actuals i continua des del
principi fins al punt d&apos;inserció.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="337"/>
        <source>Wrap</source>
        <translation>Cerca circular</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="371"/>
        <source>Count all matches in Code View.</source>
        <translation>Compta totes les coincidències, a la vista de codi.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="377"/>
        <source>Count All</source>
        <translation>Compta-ho tot</translation>
    </message>
    <message>
        <location filename="../../Form_Files/FindReplace.ui" line="384"/>
        <source>Mode:</source>
        <translation>Mode:</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="179"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1435"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1436"/>
        <source>Current File</source>
        <translation>Fitxer actual</translation>
    </message>
    <message numerus="yes">
        <location filename="../../MainUI/FindReplace.cpp" line="334"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1258"/>
        <source>Matches found: %n</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="418"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1282"/>
        <source>No replacements made</source>
        <translation>No s&apos;ha fet cap reemplaçament</translation>
    </message>
    <message numerus="yes">
        <location filename="../../MainUI/FindReplace.cpp" line="420"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1284"/>
        <source>Replacements made: %n</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="621"/>
        <source>No matches found</source>
        <translation>No s&apos;ha trobat cap coincidència</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1136"/>
        <source>This tab cannot be searched</source>
        <translation>No es pot cercar en aquesta pestanya</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1168"/>
        <source>Unnamed search loaded</source>
        <translation>S&apos;ha carregat una selecció sense nom</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1171"/>
        <source>Loaded</source>
        <translation>Carregat</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1184"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1204"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1222"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1242"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1268"/>
        <source>No searches selected</source>
        <translation>No s&apos;ha seleccionat cap cerca</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1425"/>
        <source>What to search for</source>
        <translation>Cadena de cerca</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1426"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1427"/>
        <source>Normal</source>
        <translation>Normal</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1427"/>
        <source>Case in-sensitive search of exactly what you type.</source>
        <translation>La majúscula i la minúscula del mateix caràcter es consideren caràcters iguals.</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1428"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1429"/>
        <source>Case Sensitive</source>
        <translation>Distingeix entre majúscules i minúscules</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1429"/>
        <source>Case sensitive search of exactly what you type.</source>
        <translation>La majúscula i la minúscula del mateix caràcter es consideren caràcters diferents.</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1430"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1431"/>
        <source>Regex</source>
        <translation>Expressió regular</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1431"/>
        <source>Search for a pattern using Regular Expression syntax.</source>
        <translation>Cerca un patró usant la sintaxi de les expressions regulars.</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1434"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1446"/>
        <source>Where to search</source>
        <translation>Àmbit de la cerca</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1436"/>
        <source>Restrict the find or replace to the opened file.  Hold the Ctrl key down while clicking any search buttons to temporarily restrict the search to the Current File.</source>
        <translation>Limita la cerca o el reemplaçament al fitxer obert. Premeu la tecla de control en clicar sobre qualsevol botó de cerca per limitar temporalment la cerca al fitxer actual.</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1437"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1438"/>
        <source>All HTML Files</source>
        <translation>Tots els fitxers HTML</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1438"/>
        <source>Find or replace in all HTML files in Code View.</source>
        <translation>Cerca o reemplaça a tots els fitxers HTML, a la vista de codi.</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1439"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1440"/>
        <source>Selected HTML Files</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1440"/>
        <source>Restrict the find or replace to the HTML files selected in the Book Browser in Code View.</source>
        <translation>Limita la cerca o el reemplaçament als fitxers seleccionats del navegador del llibre, a la vista de codi.</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1442"/>
        <source>To restrict search to selected text, use Search&amp;rarr;Mark Selected Text.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1447"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1448"/>
        <source>Marked Text</source>
        <translation>Text marcat</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1448"/>
        <source>Restrict the find or replace to the text marked by Search&amp;rarr;Mark Selected Text.  Cleared if you use Undo, enter text, or change views or tabs.</source>
        <translation>Restringeix la cerca o el reemplaçament al text marcat per Cerca&amp;rarr;Marca el text seleccionat. S&apos;anul·la en desfer, introduir text o canviar de vista o de pestanya.</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1452"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1456"/>
        <source>Up</source>
        <translation>Amunt</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1453"/>
        <location filename="../../MainUI/FindReplace.cpp" line="1457"/>
        <source>Down</source>
        <translation>Avall</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1454"/>
        <source>Direction to search</source>
        <translation>Sentit de la cerca</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1456"/>
        <source>Search for the previous match from your current position.</source>
        <translation>Cerca la coincidència anterior des de la posició actual.</translation>
    </message>
    <message>
        <location filename="../../MainUI/FindReplace.cpp" line="1457"/>
        <source>Search for the next match from your current position.</source>
        <translation>Cerca la coincidència següent des de la posició actual.</translation>
    </message>
</context>
<context>
    <name>FindReplaceQLineEdit</name>
    <message>
        <location filename="../../Misc/FindReplaceQLineEdit.cpp" line="58"/>
        <source>Tokenise Selection</source>
        <translation>Separa les paraules de la selecció</translation>
    </message>
    <message>
        <location filename="../../Misc/FindReplaceQLineEdit.cpp" line="71"/>
        <source>Save Search</source>
        <translation>Desa la cerca</translation>
    </message>
</context>
<context>
    <name>FlowTab</name>
    <message>
        <location filename="../../Tabs/FlowTab.cpp" line="1162"/>
        <source>Print %1</source>
        <translation>Imprimeix %1</translation>
    </message>
</context>
<context>
    <name>GeneralSettingsWidget</name>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="14"/>
        <source>General Settings</source>
        <translation>Configuració general</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="20"/>
        <source>Choose which version of Epub to use
when creating new or empty Epubs in Sigil.</source>
        <translation>Trieu quina versió d&apos;EPUB voleu usar
en crear EPUBS nous o buids amb el Sigil.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="24"/>
        <source>Create New or Empty Epubs as:</source>
        <translation>Crea epubs nous o buits com a:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="30"/>
        <source>Epub Version 2.</source>
        <translation>Epub versió 2.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="33"/>
        <source>Version 2</source>
        <translation>Versió 2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="43"/>
        <source>Epub Version 3.</source>
        <translation>Epub versió 3.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="46"/>
        <source>Version 3</source>
        <translation>Versió 3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="59"/>
        <source>Choose when your HTML code is automatically 
mended.</source>
        <translation>Trieu quan voleu que es repari automàticament
el codi HTML.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="63"/>
        <source>Mend XHTML Source Code On:</source>
        <translation>Repara el codi font XHTML en </translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="69"/>
        <source>Mend when opening an Epub or HTML file, 
and when switching from Book View to Code View.</source>
        <translation>Repara en obrir un fitxer EPUB o HTML i
en canviar de vista de llibre a vista de codi.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="73"/>
        <source>Open</source>
        <translation>obrir</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="80"/>
        <source>Mend when saving an Epub.</source>
        <translation>Repara en desar l&apos;EPUB.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="83"/>
        <source>Save</source>
        <translation>desar</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="93"/>
        <source>Determine if Epubs are allowed to access non-multimedia remote resources.</source>
        <translation>Determina si els EPUB poden accedir a recusros remots no multimèdia.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="96"/>
        <source> Control Access by Epubs to non-multimedia remote resources.</source>
        <translation>Controla l&apos;accés dels EPUB als recursos remots no multimèdia.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="105"/>
        <source>Check to allow Epubs to access non-multimedia remote resources.</source>
        <translation>Marqueu per permetre als EPUB d&apos;accedir als recursos remots no multimèdia.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="108"/>
        <source>Epubs may access all remote resources types.</source>
        <translation>Els EPUB poden accedir a tota mena de recursos remots.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="127"/>
        <source>What CSS level to specify for W3C stylesheet validation tool (EPUB2)</source>
        <translation>Nivell del CSS establert per a l&apos;eina de validació del full d&apos;estils del W3C (EPUB2)</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="130"/>
        <source>EPUB2 W3C Stylesheet Validation Level:</source>
        <translation>Nivell de validació del full d&apos;estils del W3C per a l&apos;EPUB2:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="139"/>
        <source>W3C stylesheet validator will use CSS level 2 for EPUB2</source>
        <translation>S&apos;usarà el nivell 2 del CSS en la validació del full d&apos;estils del W3C per a l&apos;EPUB2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="142"/>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="199"/>
        <source>CSS Level 2</source>
        <translation>CSS nivell 2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="149"/>
        <source>W3C stylesheet validator will use CSS level 2.1 for EPUB2</source>
        <translation>S&apos;usarà el nivell 2.1 del CSS en la validació del full d&apos;estils del W3C per a l&apos;EPUB2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="152"/>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="209"/>
        <source>CSS Level 2.1</source>
        <translation>CSS nivell 2.1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="162"/>
        <source>W3C stylesheet validator will use CSS level 3 for EPUB2</source>
        <translation>S&apos;usarà el nivell 3 del CSS en la validació del full d&apos;estils del W3C per a l&apos;EPUB2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="165"/>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="222"/>
        <source>CSS Level 3</source>
        <translation>CSS nivell 3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="184"/>
        <source>What CSS Level to specify for W3C stylesheet validation tool (EPUB3)</source>
        <translation>Nivell del CSS establert per a l&apos;eina de validació del full d&apos;estils del W3C (EPUB3)</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="187"/>
        <source>EPUB3 W3C Stylesheet Validation Level:</source>
        <translation>Nivell de validació del full d&apos;estils del W3C per a l&apos;EPUB3:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="196"/>
        <source>W3C stylesheet validator will use CSS level 2 for EPUB3</source>
        <translation>S&apos;usarà el nivell 2 del CSS en la validació del full d&apos;estils del W3C per a l&apos;EPUB3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="206"/>
        <source>W3C stylesheet validator will use CSS level 2.1 for EPUB3</source>
        <translation>S&apos;usarà el nivell 2.1 del CSS en la validació del full d&apos;estils del W3C per a l&apos;EPUB3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="219"/>
        <source>W3C stylesheet validator will use CSS level 3 for EPUB3</source>
        <translation>S&apos;usarà el nivell 3 del CSS en la validació del full d&apos;estils del W3C per a l&apos;EPUB3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="235"/>
        <source>Number of clipboard history items to save between sessions (0 disables):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="247"/>
        <source>Use to limit (or disable) clipboard history saving between sessions</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="279"/>
        <source>Set Folder where temporary files should be created</source>
        <translation>Estableix la carpeta per als fitxers temporals</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="290"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PGeneralSettingsWidget.ui" line="297"/>
        <source>Browse</source>
        <translation>Navega</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/GeneralSettingsWidget.cpp" line="132"/>
        <source>Select Folder for Temporary Files</source>
        <translation>Selecciona la carpeta per als fitxers temporals</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/GeneralSettingsWidget.cpp" line="147"/>
        <source>Incorrect Folder for Temporary Files selected</source>
        <translation>S&apos;ha seleccionat una carpeta incorrecta per als fitxers temporals</translation>
    </message>
</context>
<context>
    <name>GuideItems</name>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="110"/>
        <source>Acknowledgements</source>
        <translation>Agraïments</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="110"/>
        <source>A passage containing acknowledgments to entities involved in the realization of the work.</source>
        <translation>Apartat que conté agraïments a les persones o entitats que han participat en la realització de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="111"/>
        <source>Bibliography</source>
        <translation>Bibliografia</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="111"/>
        <source>A list of works cited.</source>
        <translation>Llista de les paraules citades.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="112"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="112"/>
        <source>The start of the main text content of a publication.</source>
        <translation>Inici del text principal del contingut d&apos;una publicació.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="113"/>
        <source>Colophon</source>
        <translation>Colofó</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="113"/>
        <source>A brief description usually located at the end of a publication, describing production notes relevant to the edition.</source>
        <translation>Descripció breu, situada normalment al final de la publicació, que descriu les notes de producció rellevants per a l&apos;edició.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="114"/>
        <source>Copyright Page</source>
        <translation>Crèdits</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="114"/>
        <source>The copyright page of the work.</source>
        <translation>La pàgina de crèdits de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="115"/>
        <source>Cover</source>
        <translation>Coberta</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="115"/>
        <source>The publications cover(s), jacket information, etc.</source>
        <translation>La coberta (o cobertes) de la publicació, informació de la sobrecoberta, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="116"/>
        <source>Dedication</source>
        <translation>Dedicatòria</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="116"/>
        <source>An inscription addressed to one or several particular person(s).</source>
        <translation>Inscripció adreçada a una o més persones particulars.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="117"/>
        <source>Epigraph</source>
        <translation>Epígraf</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="117"/>
        <source>A quotation that is pertinent but not integral to the text.</source>
        <translation>Cita escaient però no essencial per al text.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="118"/>
        <source>Foreword</source>
        <translation>Prefaci de l&apos;autor</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="118"/>
        <source>An introductory section that precedes the work, typically not written by the work&apos;s author.</source>
        <translation>Secció introductòria que encapçala l&apos;obra; normalment és d&apos;un altre autor.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="119"/>
        <source>Glossary</source>
        <translation>Glossari</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="119"/>
        <source>An alphabetical list of terms in a particular domain of knowledge, with the definitions for those terms.</source>
        <translation>Llista alfabètica dels termes d&apos;una àrea de coneixement concreta amb les seves definicions.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="120"/>
        <source>Index</source>
        <translation>Índex</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="120"/>
        <source>A detailed list, usually arranged alphabetically, of the specific information in a publication.</source>
        <translation>Llista detallada, normalment en ordre alfabètic, de la informació específica d&apos;una publicació.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="121"/>
        <source>List of Illustrations</source>
        <translation>Llista d&apos;il·lustracions</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="121"/>
        <source>A listing of illustrations included in the work.</source>
        <translation>Llista de les il·lustracions incloses a l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="122"/>
        <source>List of Tables</source>
        <translation>Llista de taules</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="122"/>
        <source>A listing of tables included in the work.</source>
        <translation>Llista de les taules incloses a l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="123"/>
        <source>Notes</source>
        <translation>Notes</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="123"/>
        <source>A collection of notes. It can be used to identify footnotes, rear notes, marginal notes, inline notes, and similar when legacy naming conventions are not desired. Status: Deprecated - Replaced by: &apos;footnotes&apos;, &apos;rearnotes&apos;</source>
        <translation>Recull de notes. Es pot usar per identificar notes al peu, finals, marginals, en línia i similars quan no es vol usar les convencions de nomenclatura formals. Estat: Obsolet - Reemplaçat per: &apos;notes al peu&apos;, &apos;notes finals&apos;</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="124"/>
        <source>Preface</source>
        <translation>Prefaci</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="124"/>
        <source>An introductory section that precedes the work, typically written by the work&apos;s author.</source>
        <translation>Secció introductòria que encapçala l&apos;obra; normalment del mateix autor.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="125"/>
        <source>Title Page</source>
        <translation>Portada</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="125"/>
        <source>A page at the beginning of a book giving its title, authors, publisher and other publication information.</source>
        <translation>Pàgina del plec inicial del llibre amb el títol, l&apos;autor, l&apos;editor i altres informacions de la publicació.</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="126"/>
        <source>Table of Contents</source>
        <translation>Taula de continguts</translation>
    </message>
    <message>
        <location filename="../../Misc/GuideItems.cpp" line="126"/>
        <source>A table of contents which is a list of the headings or parts of the book or document, organized in the order in which they appear. Typically appearing in the work&apos;s frontmatter, or at the beginning of a section.</source>
        <translation>Taula de continguts. Llista dels apartats o seccions del llibre o del document organitzada per ordre d&apos;aparició. Usualment, es troba als preliminars de l&apos;obra o encapçalant una secció.</translation>
    </message>
</context>
<context>
    <name>HTMLFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsHTMLFilesWidget.ui" line="14"/>
        <source>HTML Files</source>
        <translation>Fitxers HTML</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsHTMLFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>Mostra només els noms de fitxers que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsHTMLFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="74"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="75"/>
        <source>File Size (KB)</source>
        <translation>Mida del fitxer (kB)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="76"/>
        <source>All Words</source>
        <translation>Totes les paraules</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="77"/>
        <source>Misspelled Words</source>
        <translation>Paraules mal escrites</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="78"/>
        <source>Images</source>
        <translation>Imatges</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="79"/>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="80"/>
        <source>Audio</source>
        <translation>Àudio</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="81"/>
        <source>Stylesheets</source>
        <translation>Fulls d&apos;estil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="82"/>
        <source>Well Formed</source>
        <translation>Ben formats</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="171"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="171"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message numerus="yes">
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="190"/>
        <source>%n file(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="331"/>
        <source>Save Report As Comma Separated File</source>
        <translation>Desa un informe com a fitxer de text separat per comes</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="344"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="344"/>
        <source>Cannot save report file.</source>
        <translation>No es pot desar el fitxer d&apos;informe.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/HTMLFilesWidget.cpp" line="368"/>
        <source>Delete From Book</source>
        <translation>Esborrar del llibre</translation>
    </message>
</context>
<context>
    <name>HeadingSelector</name>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="14"/>
        <source>Generate Table Of Contents</source>
        <translation>Genera la taula de continguts</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="52"/>
        <source>Change the name of the entry in the TOC.
The heading&apos;s title attribute will be updated in the document.</source>
        <translation>Canvia el nom de l&apos;entrada a la taula de continguts.
S&apos;actualitzarà l&apos;atribut títol de l&apos;encapçalament al document.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="56"/>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="975"/>
        <source>Rename</source>
        <translation>Canvia el nom</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="81"/>
        <source>Decrease the heading level of the selected entry by 1.
The heading's tag will be updated in the document.
You can also use the left arrow key.</source>
        <translation>Disminueix un nivell la capçalera de l&apos;entrada seleccionada.
S&apos;actualitzarà l&apos;etiqueta de l&apos;encapçalament al document.
També podeu fer servir la fletxa esquerra.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="96"/>
        <source>Increase the heading level of the selected entry by 1.
The heading's tag will be updated in the document.
You can also use the right arrow key.</source>
        <translation>Augmenta un nivell la capçalera de l&apos;entrada seleccionada.
S&apos;actualitzarà l&apos;etiqueta de l&apos;encapçalament al document.
També podeu fer servir la fletxa dreta.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="130"/>
        <source>Only display the items that will be added to the Table Of Contents.
Check or uncheck an entry to determine if it will be added to the TOC.</source>
        <translation>Mostra només els elements que s&apos;afegiran a la taula de continguts;
activeu o desactiveu les caselles de les entrades per indicar si s&apos;hi han d&apos;afegir o no.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="134"/>
        <source>Show TOC items only</source>
        <translation>Mostra només els elements de la taula de continguts</translation>
    </message>
    <message>
        <location filename="../../Form_Files/HeadingSelector.ui" line="153"/>
        <source>Quickly mark which headings are included in the TOC.
You can then check or uncheck individual headings in the list above.</source>
        <translation>Marca ràpidament quins encapçalaments s&apos;han d&apos;incloure a la taula de continguts;
podeu activar-les o desactivar-les individualment a la llista de dalt.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="602"/>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="618"/>
        <source>Level</source>
        <translation>Nivell</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="602"/>
        <source>Included</source>
        <translation>Inclòs</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="602"/>
        <source>Hidden</source>
        <translation>Ocult</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="617"/>
        <source>TOC Entry / Heading Title</source>
        <translation>Entrada de la taula de continguts / Títol de l&apos;encapçalament</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="619"/>
        <source>Include</source>
        <translation>Inclou</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="838"/>
        <source>Up to level</source>
        <translation>Fins al nivell</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="840"/>
        <source>&lt;Select headings to include in TOC&gt;</source>
        <translation>&lt;Selecciona els encapçalaments de la taula de continguts&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="843"/>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="904"/>
        <source>None</source>
        <translation>Cap</translation>
    </message>
    <message>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="849"/>
        <location filename="../../Dialogs/HeadingSelector.cpp" line="902"/>
        <source>All</source>
        <translation>Tot</translation>
    </message>
</context>
<context>
    <name>ImageFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsImageFilesWidget.ui" line="14"/>
        <source>Image Files</source>
        <translation>Fitxers d&apos;imatge</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsImageFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>Mostra només els noms de fitxers que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsImageFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsImageFilesWidget.ui" line="76"/>
        <source>Thumbnail size:</source>
        <translation>Mida de la miniatura:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="88"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="89"/>
        <source>File Size (KB)</source>
        <translation>Mida del fitxer (kB)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="90"/>
        <source>Times Used</source>
        <translation>Vegades que s&apos;utilitza</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="91"/>
        <source>Width</source>
        <translation>Amplada</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="92"/>
        <source>Height</source>
        <translation>Alçada</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="93"/>
        <source>Pixels</source>
        <translation>Píxels</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="94"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="97"/>
        <source>Image</source>
        <translation>Imatge</translation>
    </message>
    <message numerus="yes">
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="184"/>
        <source>%n file(s)</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="188"/>
        <source>KB</source>
        <translation>kB</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="332"/>
        <source>Save Report As Comma Separated File</source>
        <translation>Desa un informe com a fitxer de text separat per comes</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="345"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="345"/>
        <source>Cannot save report file.</source>
        <translation>No es pot desar el fitxer d&apos;informe.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/ImageFilesWidget.cpp" line="417"/>
        <source>Delete From Book</source>
        <translation>Esborra del llibre</translation>
    </message>
</context>
<context>
    <name>ImageTab</name>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="177"/>
        <source>shades</source>
        <translation>nivells</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="177"/>
        <source>colors</source>
        <translation>colors</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="178"/>
        <source>Grayscale</source>
        <translation>Escala de grisos</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="178"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="293"/>
        <location filename="../../Tabs/ImageTab.cpp" line="350"/>
        <location filename="../../Tabs/ImageTab.cpp" line="353"/>
        <source>Open With</source>
        <translation>Obrie amb</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="328"/>
        <source>Other Application</source>
        <translation>Una altra aplicació</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="351"/>
        <source>Save As</source>
        <translation>Anomena i desa</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="352"/>
        <source>Copy Image</source>
        <translation>Copia la imatge</translation>
    </message>
    <message>
        <location filename="../../Tabs/ImageTab.cpp" line="400"/>
        <source>Print %1</source>
        <translation>Imprimeix %1</translation>
    </message>
</context>
<context>
    <name>ImportEPUB</name>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="166"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="167"/>
        <source>This EPUB has HTML files that are not well formed. Sigil can attempt to automatically fix these files, although this can result in data loss.

Do you want to automatically fix the files?</source>
        <translation>L&apos;EPUB conté fitxers HTML mal formats. El Sigil pot provar de corregir automàticament aquests fitxers però pot ser que en el procés es perdin dades.

Voleu fer la correcció automàtica dels fitxers?</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="501"/>
        <source>Epub has missing or improperly specified OPF.</source>
        <translation>L’OPF de l’Epub és incorrecte o no s’ha trobat.</translation>
    </message>
</context>
<context>
    <name>IndexEditor</name>
    <message>
        <location filename="../../Form_Files/IndexEditor.ui" line="14"/>
        <location filename="../../Dialogs/IndexEditor.cpp" line="287"/>
        <source>Index Editor</source>
        <translation>Editor de l&apos;índex</translation>
    </message>
    <message>
        <location filename="../../Form_Files/IndexEditor.ui" line="22"/>
        <source>Filter:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/IndexEditor.ui" line="29"/>
        <source>List only the entries containing the text you enter.</source>
        <translation>Mostra només les entrades que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/IndexEditor.ui" line="55"/>
        <location filename="../../Dialogs/IndexEditor.cpp" line="421"/>
        <source>Add Entry</source>
        <translation>Afegeix una entrada</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="66"/>
        <source>Right click on an entry to see a context menu of actions.</source>
        <translation>Clicant una entrada amb el botó dret s&apos;obre un menú d&apos;accions contextual.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="67"/>
        <source>You can also right click in your document to add selected text to the Index.</source>
        <translation>També podeu clicar al document amb el botó dret per afegir el text seleccionat a l&apos;índex.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="69"/>
        <source>Text to Include</source>
        <translation>Text que s&apos;inclourà</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="69"/>
        <source>The pattern to match in your document, e.g. &quot;Gutenberg&quot;. This is a regex pattern so &quot;(?i)Gutenberg&quot; ignores case when matching.</source>
        <translation>El patró per cercar coincidències al document; per exemple, «Gutenberg». Tractant-se d&apos;una expressió regular, el patró «(?¡)Gutemberg» no té en compte la concordança de majúscules i minúscules.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="70"/>
        <source>Index Entries</source>
        <translation>Entrades de l&apos;índex</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="70"/>
        <source>The entry to create in the Index. Leave blank to use text as is, or enter text to display.  Create multi-level entries by using &apos;/&apos; after a level name, e.g. &quot;Books/Fantasy/Alice in Wonderland&quot; or &quot;Books/Fantasy/&quot;.</source>
        <translation>L&apos;entrada que s&apos;ha de crear a l&apos;índex. Deixeu-ho en blanc si voleu utilitzar el text tal com és o introduïu el text que vulgueu mostrar. Podeu crear entrades de nivells múltiples posant una «/» després d&apos;un nom de nivell; exemple: «Llibres/Fantasia/Alícia en terra de meravelles» o «Llibres/Fantasia/».</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="74"/>
        <source>Save</source>
        <translation>Desa</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="74"/>
        <source>Save your changes.</source>
        <translation>Desa els canvis.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="74"/>
        <source>If any other instances of Sigil are running they will be automatically updated with your changes.</source>
        <translation>Si s&apos;estan executant altres instàncies del Sigil, s&apos;hi actualitzaran els canvis automàticament.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="84"/>
        <source>Cannot save entries.</source>
        <translation>No es poden desar les entrades.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="126"/>
        <source>Index entries loaded from file.</source>
        <translation>S&apos;han carregat les entrades de l&apos;índex des d&apos;un fitxer.</translation>
    </message>
    <message numerus="yes">
        <location filename="../../Dialogs/IndexEditor.cpp" line="287"/>
        <source>Entries added: %n</source>
        <translation type="unfinished"><numerusform></numerusform><numerusform></numerusform></translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="293"/>
        <source>Index files: *.ini *.txt (*.ini *.txt)</source>
        <translation>Fitxers d&apos;índex: *.ini *.txt (*.ini *.txt)</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="295"/>
        <source>Load Entries From File</source>
        <translation>Carrega les entrades des d&apos;un fitxer</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="311"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="311"/>
        <source>Are you sure you want to reload all entries?  This will overwrite any unsaved changes.</source>
        <translation>Esteu segur que voleu tornar a carregar totes les entrades? Tots els canvis sense desar es sobreescriuran.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="329"/>
        <source>Save Entries to File</source>
        <translation>Desa les entrades a un fitxer</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="422"/>
        <source>Edit</source>
        <translation>Edita</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="423"/>
        <source>Cut</source>
        <translation>Retalla</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="424"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="425"/>
        <source>Paste</source>
        <translation>Enganxa</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="426"/>
        <source>Delete</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="427"/>
        <source>Autofill</source>
        <translation>Emplena automàticament</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="428"/>
        <source>Open</source>
        <translation>Obre</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="429"/>
        <source>Reload</source>
        <translation>Torna a carregar</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="430"/>
        <source>Save As</source>
        <translation>Anomena i desa</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="431"/>
        <source>Select All</source>
        <translation>Selecciona-ho tot</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="506"/>
        <source>Index entries saved.</source>
        <translation>S&apos;an desat les entrades de l&apos;índex.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="535"/>
        <source>Sigil: Index Editor</source>
        <translation>Sigil: Editor de l&apos;índex</translation>
    </message>
    <message>
        <location filename="../../Dialogs/IndexEditor.cpp" line="536"/>
        <source>The Index entries may have been modified.
Do you want to save your changes?</source>
        <translation>Les entrades de l&apos;índex es poden haver modificat.
Voleu desar els canvis?</translation>
    </message>
</context>
<context>
    <name>IndexEditorModel</name>
    <message>
        <location filename="../../MiscEditors/IndexEditorModel.cpp" line="61"/>
        <source>Text to Include</source>
        <translation>Text que s&apos;inclourà</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/IndexEditorModel.cpp" line="62"/>
        <source>Index Entries</source>
        <translation>Entrades de l&apos;índex</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/IndexEditorModel.cpp" line="347"/>
        <source>Unable to create file %1</source>
        <translation>No s&apos;ha pogut crear el fitxer %1</translation>
    </message>
</context>
<context>
    <name>KeyboardShortcutsWidget</name>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="14"/>
        <source>Keyboard Shortcuts</source>
        <translation>Dreceres de teclat</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="34"/>
        <source>List only the entries containing the text you enter.</source>
        <translation>Mostra només les entrades que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="37"/>
        <source>Filter: </source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="62"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="67"/>
        <source>Shortcut</source>
        <translation>Drecera</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="72"/>
        <source>Description</source>
        <translation>Descripció</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="82"/>
        <source>Reset all to default</source>
        <translation>Reinicia-totes les dreceres als seus valors predeterminats</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="85"/>
        <source>Reset All</source>
        <translation>Reinicia-ho tot</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="115"/>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="125"/>
        <source>Press the key combination you want to use.</source>
        <translation>Premeu la combinació de tecles que volgueu utilitzar.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="118"/>
        <source>Shortcut:</source>
        <translation>Drecera:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="141"/>
        <source>Assign this keyboard shortcut, overriding any conflicting usages.</source>
        <translation>Assigna la drecera i, si cal, sobreescriu altres usos en conflicte.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="144"/>
        <source>Assign</source>
        <translation>Assigna</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="160"/>
        <source>Remove this keyboard shortcut.</source>
        <translation>Eliminar aquesta drecera de teclat.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PKeyboardShortcutsWidget.ui" line="163"/>
        <source>Remove</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/KeyboardShortcutsWidget.cpp" line="343"/>
        <source>Conflicts with: &lt;b&gt;</source>
        <translation>Conflictes amb: &lt;b&gt;</translation>
    </message>
</context>
<context>
    <name>Landmarks</name>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="117"/>
        <source>Acknowledgments</source>
        <translation>Agraïments</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="117"/>
        <source>A passage containing acknowledgments to entities involved in the realization of the work.</source>
        <translation>Apartat que conté agraïments a les persones o entitats que han participat en la realització de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="118"/>
        <source>Afterword</source>
        <translation>Epíleg</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="118"/>
        <source>A closing statement from the author or a person of importance to the story, typically providing insight into how the story came to be written, its significance or related events that have transpired since its timeline.</source>
        <translation>Exposició final de l&apos;autor o d&apos;una persona important per a la història on, normalment, s&apos;explica com va ser que la història es va acabar escrivint, la seva rellevància o els fets relacionats que s&apos;han esdevingut des d&apos;aleshores.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="119"/>
        <source>Annotation</source>
        <translation>Nota d&apos;aclariment</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="119"/>
        <source>Explanatory information about passages in the work. Status: Deprecated</source>
        <translation>Explicació que aclareix algun episodi de l&apos;obra. Estat: Obsolet</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="120"/>
        <source>Appendix</source>
        <translation>Apèndix</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="120"/>
        <source>Supplemental information.</source>
        <translation>Informació suplementària.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="121"/>
        <source>Assessment</source>
        <translation>Avaluació</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="121"/>
        <source>A test, quiz, or other activity that helps measure a student&apos;s understanding of what is being taught.</source>
        <translation>Examen, prova o una altra activitat que permet mesurar el grau de comprensió d&apos;un estudiant sobre la lliçó.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="122"/>
        <source>Back Matter</source>
        <translation>Seccions posteriors</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="122"/>
        <source>Ancillary material occurring after the main content of a publication, such as indices, appendices, etc.</source>
        <translation>Material auxiliar que es troba després el contingut principal d&apos;una publicació, com ara índexs, annexos, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="123"/>
        <source>Bibliography</source>
        <translation>Bibliografia</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="123"/>
        <source>A list of works cited.</source>
        <translation>Llista de les paraules citades.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="124"/>
        <source>Body Matter</source>
        <translation>Cos de l&apos;obra</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="124"/>
        <source>The main content of a publication.</source>
        <translation>El contingut principal d&apos;una publicació.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="125"/>
        <source>Chapter</source>
        <translation>Capítol</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="125"/>
        <source>A major structural division of a piece of writing.</source>
        <translation>Divisió amb certa unitat de contingut d&apos;una obra escrita.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="126"/>
        <source>Colophon</source>
        <translation>Colofó</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="126"/>
        <source>A brief description usually located at the end of a publication, describing production notes relevant to the edition.</source>
        <translation>Descripció breu, situada normalment al final de la publicació, que descriu les notes de producció rellevants per a l&apos;edició.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="127"/>
        <source>Conclusion</source>
        <translation>Conclusió</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="127"/>
        <source>An ending section that typically wraps up the work.</source>
        <translation>Secció final que, normalment, clausura l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="128"/>
        <source>Contributors</source>
        <translation>Contribuïdors</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="128"/>
        <source>A list of contributors to the work.</source>
        <translation>Llista dels contribuïdors de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="129"/>
        <source>Copyright Page</source>
        <translation>Crèdits</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="129"/>
        <source>The copyright page of the work.</source>
        <translation>La pàgina de crèdits de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="130"/>
        <source>Cover</source>
        <translation>Coberta</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="130"/>
        <source>The publications cover(s), jacket information, etc.</source>
        <translation>La coberta (o cobertes) de la publicació, informació de la sobrecoberta, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="131"/>
        <source>Dedication</source>
        <translation>Dedicatòria</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="131"/>
        <source>An inscription addressed to one or several particular person(s).</source>
        <translation>Inscripció adreçada a una o més persones particulars.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="132"/>
        <source>Division</source>
        <translation>Títol</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="132"/>
        <source>A major structural division that may also appear as a substructure of a part (esp. in legislation).</source>
        <translation>Subdivisió d’un codi, d’un reglament, etc., que tracta d’una matèria determinada (especialment en legislació).</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="133"/>
        <source>Epigraph</source>
        <translation>Epígraf</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="133"/>
        <source>A quotation that is pertinent but not integral to the text.</source>
        <translation>Cita escaient però no essencial per al text.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="134"/>
        <source>Epilogue</source>
        <translation>Epíleg</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="134"/>
        <source>A concluding section that is typically written from a later point in time than the main story, although still part of the narrative.</source>
        <translation>Secció de clausura normalment situada més tard en el temps que la història principal encara que també pertany a la narració.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="135"/>
        <source>Errata</source>
        <translation>Fe d&apos;errades</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="135"/>
        <source>Publication errata, in printed works typically a loose sheet inserted by hand; sometimes a bound page that contains corrections for mistakes in the work.</source>
        <translation>Fe d&apos;errades de la publicació. En obres impreses, usualment és un full solt inserit a mà o, de vegades, enquadernat, amb les correccions de les errades de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="136"/>
        <source>Footnotes</source>
        <translation>Notes al peu</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="136"/>
        <source>A collection of notes appearing at the bottom of a page.</source>
        <translation>Grup de notes del peu d&apos;una pàgina.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="137"/>
        <source>Foreword</source>
        <translation>Prefaci de l&apos;autor</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="137"/>
        <source>An introductory section that precedes the work, typically not written by the work&apos;s author.</source>
        <translation>Secció introductòria que encapçala l&apos;obra; normalment és d&apos;un altre autor.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="138"/>
        <source>Front Matter</source>
        <translation>Preliminars</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="138"/>
        <source>Preliminary material to the main content of a publication, such as tables of contents, dedications, etc.</source>
        <translation>Material preliminar previ al cos de l&apos;obra, com ara taules de continguts, dedicatòries, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="139"/>
        <source>Glossary</source>
        <translation>Glossari</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="139"/>
        <source>An alphabetical list of terms in a particular domain of knowledge, with the definitions for those terms.</source>
        <translation>Llista alfabètica dels termes d&apos;una àrea de coneixement concreta amb les seves definicions.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="140"/>
        <source>Half Title Page</source>
        <translation>Portadella</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="140"/>
        <source>The half title page of the work which carries just the title itself.</source>
        <translation>Portadella de l&apos;obra amb el títol i prou.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="141"/>
        <source>Imprimatur</source>
        <translation>Imprimàtur</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="141"/>
        <source>A formal statement authorizing the publication of the work.</source>
        <translation>Llicència de l&apos;autoritat eclesiàstica per publicar l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="142"/>
        <source>Imprint</source>
        <translation>Peu d&apos;impremta</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="142"/>
        <source>Information relating to the publication or distribution of the work.</source>
        <translation>Dades relatives a la publicació o a la distribució de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="143"/>
        <source>Index</source>
        <translation>Índex</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="143"/>
        <source>A detailed list, usually arranged alphabetically, of the specific information in a publication.</source>
        <translation>Llista detallada, normalment en ordre alfabètic, de la informació específica d&apos;una publicació.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="144"/>
        <source>Introduction</source>
        <translation>Introducció</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="144"/>
        <source>A section in the beginning of the work, typically introducing the reader to the scope or nature of the work&apos;s content.</source>
        <translation>Secció dels preliminars en què, normalment, es presenta al lector el caràcter o l&apos;abast de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="145"/>
        <source>Landmarks</source>
        <translation>Fites</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="145"/>
        <source>A collection of references to well-known/recurring components within the publication</source>
        <translation>Recull de referències a episodis molt coneguts o recurrents d&apos;una publicació.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="146"/>
        <source>List of Audio Clips</source>
        <translation>Llista de fragments d&apos;àudio</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="146"/>
        <source>A listing of audio clips included in the work.</source>
        <translation>Llista dels fragments d&apos;àudio inclosos a l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="147"/>
        <source>List of Illustrations</source>
        <translation>Llista d&apos;il·lustracions</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="147"/>
        <source>A listing of illustrations included in the work.</source>
        <translation>Llista de les il·lustracions incloses a l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="148"/>
        <source>List of Tables</source>
        <translation>Llista de taules</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="148"/>
        <source>A listing of tables included in the work.</source>
        <translation>Llista de les taules incloses a l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="149"/>
        <source>List of Video Clips</source>
        <translation>Llista de fragments de vídeo</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="149"/>
        <source>A listing of video clips included in the work.</source>
        <translation>Llista dels fragments de vídeo inclosos a l&apos;obra</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="150"/>
        <source>Notice</source>
        <translation>Avís</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="150"/>
        <source>Information that requires special attention, and that must not be skipped or suppressed. Examples include: alert, warning, caution, danger, important.</source>
        <translation>Informació que demana una atenció especial i que no s&apos;ha d&apos;ignorar ni suprimir. Alguns exemples: alerta, avís, precaució, perill, important.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="151"/>
        <source>Other Credits</source>
        <translation>Altres crèdits</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="151"/>
        <source>Acknowledgments of previously published parts of the work, illustration credits, and permission to quote from copyrighted material.</source>
        <translation>Agraïments de fragments de l&apos;obra publicats anteriorment, crèdits de les il·lustracions i permís per citar obres amb drets d&apos;autor vigents.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="152"/>
        <source>Page List</source>
        <translation>Llista de pàgines</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="152"/>
        <source>A list of references to pagebreaks (start locations) from a print version of the ebook</source>
        <translation>Llista de referències a salt de pàgina (punts d&apos;inici) de la versió impresa d&apos;un llibre electrònic.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="153"/>
        <source>Part</source>
        <translation>Part</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="153"/>
        <source>A major structural division of a piece of writing, typically encapsulating a set of related chapters.</source>
        <translation>Divisió estructural d&apos;una obra escrita que, normalment, agrupa un conjunt de capítols relacionats entre sí.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="154"/>
        <source>Preamble</source>
        <translation>Preàmbul</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="154"/>
        <source>A section in the beginning of the work, typically containing introductory and/or explanatory prose regarding the scope or nature of the work&apos;s content</source>
        <translation>Secció dels preliminars que, normalment, conté un text introductori que tracta del caràcter o l&apos;abast de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="155"/>
        <source>Preface</source>
        <translation>Prefaci</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="155"/>
        <source>An introductory section that precedes the work, typically written by the work&apos;s author.</source>
        <translation>Secció introductòria que encapçala l&apos;obra; normalment del mateix autor.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="156"/>
        <source>Prologue</source>
        <translation>Pròleg</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="156"/>
        <source>An introductory section that sets the background to a story, typically part of the narrative.</source>
        <translation>Secció introductòria que estableix el rerefons d&apos;una història; normalment, és part de la narració.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="157"/>
        <source>Questions and Answers</source>
        <translation>Preguntes i respostes</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="157"/>
        <source>A question and answer section.</source>
        <translation>Secció de preguntes i respostes.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="158"/>
        <source>Rear Notes</source>
        <translation>Notes finals</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="158"/>
        <source>A collection of notes appearing at the rear (backmatter) of the work, or at the end of a section.</source>
        <translation>Recull de notes que figuren al final de tot (a la secció posterior) de l&apos;obra o al final d&apos;una secció qualsevol.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="159"/>
        <source>Revision History</source>
        <translation>Historial de revisions</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="159"/>
        <source>A record of changes made to a work.</source>
        <translation>Registre dels canvis fets a l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="160"/>
        <source>Subchapter</source>
        <translation>Subcapítol</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="160"/>
        <source>A major sub-division of a chapter.</source>
        <translation>Subdivisió major d&apos;un capítol.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="161"/>
        <source>Title Page</source>
        <translation>Portada</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="161"/>
        <source>A page at the beginning of a book giving its title, authors, publisher and other publication information.</source>
        <translation>Pàgina del plec inicial del llibre amb el títol, l&apos;autor, l&apos;editor i altres informacions de la publicació.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="162"/>
        <source>Table of Contents</source>
        <translation>Taula de continguts</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="162"/>
        <source>A table of contents which is a list of the headings or parts of the book or document, organized in the order in which they appear. Typically appearing in the work&apos;s frontmatter, or at the beginning of a section.</source>
        <translation>Taula de continguts. Llista dels apartats o seccions del llibre o del document organitzada per ordre d&apos;aparició. Usualment, es troba als preliminars de l&apos;obra o encapçalant una secció.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="163"/>
        <source>Volume</source>
        <translation>Volum</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="163"/>
        <source>A component of a collection.</source>
        <translation>Element d&apos;un recull.</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="164"/>
        <source>Warning</source>
        <translation>Avís</translation>
    </message>
    <message>
        <location filename="../../Misc/Landmarks.cpp" line="164"/>
        <source>A warning or caution about specific material. Status: Deprecated - Replaced by &apos;notice&apos;.</source>
        <translation>Avís o alerta sobre un material concret. Estat: obsolet - Reemplaçat per &apos;avís&apos;.</translation>
    </message>
</context>
<context>
    <name>Language</name>
    <message>
        <location filename="../../Misc/Language.cpp" line="85"/>
        <source>Abkhazian</source>
        <translation>Abkhaz</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="86"/>
        <source>Afar</source>
        <translation>Àfar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="87"/>
        <source>Afrikaans</source>
        <translation>Afrikaans</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="88"/>
        <source>Akan</source>
        <translation>Àkan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="89"/>
        <source>Albanian</source>
        <translation>Albanès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="90"/>
        <source>Amharic</source>
        <translation>Amhàric</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="91"/>
        <location filename="../../Misc/Language.cpp" line="92"/>
        <location filename="../../Misc/Language.cpp" line="93"/>
        <location filename="../../Misc/Language.cpp" line="94"/>
        <location filename="../../Misc/Language.cpp" line="95"/>
        <location filename="../../Misc/Language.cpp" line="96"/>
        <location filename="../../Misc/Language.cpp" line="97"/>
        <location filename="../../Misc/Language.cpp" line="98"/>
        <location filename="../../Misc/Language.cpp" line="99"/>
        <location filename="../../Misc/Language.cpp" line="100"/>
        <location filename="../../Misc/Language.cpp" line="101"/>
        <location filename="../../Misc/Language.cpp" line="102"/>
        <location filename="../../Misc/Language.cpp" line="103"/>
        <location filename="../../Misc/Language.cpp" line="104"/>
        <location filename="../../Misc/Language.cpp" line="105"/>
        <location filename="../../Misc/Language.cpp" line="106"/>
        <source>Arabic</source>
        <translation>Àrab</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="92"/>
        <source>Algeria</source>
        <translation>Algèria</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="93"/>
        <source>Bahrain</source>
        <translation>Bahrain</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="94"/>
        <source>Egypt</source>
        <translation>Egipte</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="95"/>
        <source>Iraq</source>
        <translation>Iraq</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="96"/>
        <source>Jordan</source>
        <translation>Jordània</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="97"/>
        <source>Kuwait</source>
        <translation>Kuwait</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="98"/>
        <source>Lebanon</source>
        <translation>Líban</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="99"/>
        <source>Libya</source>
        <translation>Líbia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="100"/>
        <source>Morocco</source>
        <translation>Marroc</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="101"/>
        <source>Oman</source>
        <translation>Oman</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="102"/>
        <source>Qatar</source>
        <translation>Qatar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="103"/>
        <source>Syria</source>
        <translation>República Àrab Siriana</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="104"/>
        <source>Tunisia</source>
        <translation>Tunísia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="105"/>
        <source>United Arab Emirates</source>
        <translation>Unió dels Emirats Àrabs</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="106"/>
        <source>Yemen</source>
        <translation>Iemen</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="107"/>
        <source>Aragonese</source>
        <translation>Aragonès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="108"/>
        <source>Armenian</source>
        <translation>Armeni</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="109"/>
        <source>Assamese</source>
        <translation>Assamès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="110"/>
        <source>Avaric</source>
        <translation>Àvar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="111"/>
        <source>Avestan</source>
        <translation>Avèstic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="112"/>
        <source>Aymara</source>
        <translation>Aimara</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="113"/>
        <location filename="../../Misc/Language.cpp" line="114"/>
        <source>Azerbaijani</source>
        <translation>Àzeri</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="114"/>
        <source>Azerbaijan</source>
        <translation>Azerbaitjan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="115"/>
        <source>Bambara</source>
        <translation>Bambara</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="116"/>
        <source>Bashkir</source>
        <translation>Baixkir</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="117"/>
        <source>Basque</source>
        <translation>Basc; èuscar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="118"/>
        <source>Belarusian</source>
        <translation>Bielorús</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="119"/>
        <source>Bengali</source>
        <translation>Bengalí</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="120"/>
        <source>Bihari</source>
        <translation>Bihari</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="121"/>
        <source>Bislama</source>
        <translation>Bislama</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="122"/>
        <source>Bosnian</source>
        <translation>Bosnià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="123"/>
        <source>Breton</source>
        <translation>Bretó</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="124"/>
        <source>Bulgarian</source>
        <translation>Búlgar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="125"/>
        <source>Burmese</source>
        <translation>Birmà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="126"/>
        <location filename="../../Misc/Language.cpp" line="127"/>
        <source>Catalan</source>
        <translation>Català</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="127"/>
        <location filename="../../Misc/Language.cpp" line="312"/>
        <source>Spain</source>
        <translation>Espanya</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="128"/>
        <source>Central Khmer</source>
        <translation>Khmer central</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="129"/>
        <source>Chamorro</source>
        <translation>Chamorro; chamoru</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="130"/>
        <source>Chechen</source>
        <translation>Txetxè</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="131"/>
        <location filename="../../Misc/Language.cpp" line="132"/>
        <location filename="../../Misc/Language.cpp" line="133"/>
        <location filename="../../Misc/Language.cpp" line="134"/>
        <location filename="../../Misc/Language.cpp" line="135"/>
        <location filename="../../Misc/Language.cpp" line="136"/>
        <source>Chinese</source>
        <translation>Xinès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="132"/>
        <source>China</source>
        <translation>Xina</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="133"/>
        <source>Hong Kong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="134"/>
        <source>Macau</source>
        <translation>Macau</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="135"/>
        <source>Singapore</source>
        <translation>Singapur</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="136"/>
        <source>Taiwan</source>
        <translation>Taiwan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="137"/>
        <source>Church Slavic</source>
        <translation>Eslau eclesiàstic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="138"/>
        <source>Chuvash</source>
        <translation>Txuvaix</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="139"/>
        <source>Cornish</source>
        <translation>Còrnic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="140"/>
        <source>Corsican</source>
        <translation>Cors</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="141"/>
        <source>Cree</source>
        <translation>Cree</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="142"/>
        <source>Croatian</source>
        <translation>Croat</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="143"/>
        <source>Czech</source>
        <translation>Txec</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="144"/>
        <location filename="../../Misc/Language.cpp" line="145"/>
        <source>Danish</source>
        <translation>Danès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="145"/>
        <source>Denmark</source>
        <translation>Dinamarca</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="146"/>
        <source>Dhivehi</source>
        <translation>Divehi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="147"/>
        <location filename="../../Misc/Language.cpp" line="148"/>
        <location filename="../../Misc/Language.cpp" line="149"/>
        <source>Dutch</source>
        <translation>Neerlandès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="148"/>
        <location filename="../../Misc/Language.cpp" line="171"/>
        <source>Belgium</source>
        <translation>Bèlgica</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="149"/>
        <source>Netherlands</source>
        <translation>Països Baixos</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="150"/>
        <source>Dzongkha</source>
        <translation>Bhutanès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="151"/>
        <location filename="../../Misc/Language.cpp" line="152"/>
        <location filename="../../Misc/Language.cpp" line="153"/>
        <location filename="../../Misc/Language.cpp" line="154"/>
        <location filename="../../Misc/Language.cpp" line="155"/>
        <location filename="../../Misc/Language.cpp" line="156"/>
        <location filename="../../Misc/Language.cpp" line="157"/>
        <location filename="../../Misc/Language.cpp" line="158"/>
        <location filename="../../Misc/Language.cpp" line="159"/>
        <location filename="../../Misc/Language.cpp" line="160"/>
        <location filename="../../Misc/Language.cpp" line="161"/>
        <location filename="../../Misc/Language.cpp" line="162"/>
        <location filename="../../Misc/Language.cpp" line="163"/>
        <source>English</source>
        <translation>Anglès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="152"/>
        <source>Australia</source>
        <translation>Austràlia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="153"/>
        <source>Belize</source>
        <translation>Belize</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="154"/>
        <location filename="../../Misc/Language.cpp" line="172"/>
        <source>Canada</source>
        <translation>Canadà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="155"/>
        <source>Caribbean</source>
        <translation>Carib</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="156"/>
        <source>Great Britain</source>
        <translation>Gran Bretanya</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="157"/>
        <source>India</source>
        <translation>Índia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="158"/>
        <location filename="../../Misc/Language.cpp" line="178"/>
        <source>Ireland</source>
        <translation>Illa d&apos;Irlanda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="159"/>
        <source>Jamaica</source>
        <translation>Jamaica</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="160"/>
        <source>Phillippines</source>
        <translation>Filipines</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="161"/>
        <source>Trinidad</source>
        <translation>Illa de Trinitat</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="162"/>
        <source>South Africa</source>
        <translation>Sudàfrica</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="163"/>
        <source>United States</source>
        <translation>Estats Units</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="164"/>
        <source>Esperanto</source>
        <translation>Esperanto</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="165"/>
        <source>Estonian</source>
        <translation>Estonià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="166"/>
        <source>Ewe</source>
        <translation>Ewe</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="167"/>
        <source>Faroese</source>
        <translation>Feroès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="168"/>
        <source>Fijian</source>
        <translation>Fijià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="169"/>
        <source>Finnish</source>
        <translation>Finès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="170"/>
        <location filename="../../Misc/Language.cpp" line="171"/>
        <location filename="../../Misc/Language.cpp" line="172"/>
        <location filename="../../Misc/Language.cpp" line="173"/>
        <location filename="../../Misc/Language.cpp" line="174"/>
        <location filename="../../Misc/Language.cpp" line="175"/>
        <source>French</source>
        <translation>Francès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="173"/>
        <source>France</source>
        <translation>França</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="174"/>
        <location filename="../../Misc/Language.cpp" line="186"/>
        <source>Luxembourg</source>
        <translation>Luxemburg</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="175"/>
        <location filename="../../Misc/Language.cpp" line="187"/>
        <location filename="../../Misc/Language.cpp" line="212"/>
        <source>Switzerland</source>
        <translation>Suïssa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="176"/>
        <source>Fulah</source>
        <translation>Ful</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="177"/>
        <location filename="../../Misc/Language.cpp" line="178"/>
        <source>Gaelic</source>
        <translation>Gaèlic irlandès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="177"/>
        <source>Scotland</source>
        <translation>Escòcia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="179"/>
        <source>Galician</source>
        <translation>Gallec</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="180"/>
        <source>Ganda</source>
        <translation>Ganda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="181"/>
        <source>Georgian</source>
        <translation>Georgià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="182"/>
        <location filename="../../Misc/Language.cpp" line="183"/>
        <location filename="../../Misc/Language.cpp" line="184"/>
        <location filename="../../Misc/Language.cpp" line="185"/>
        <location filename="../../Misc/Language.cpp" line="186"/>
        <location filename="../../Misc/Language.cpp" line="187"/>
        <source>German</source>
        <translation>Alemany</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="183"/>
        <source>Austria</source>
        <translation>Àustria</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="184"/>
        <source>Germany</source>
        <translation>Alemanya</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="185"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="188"/>
        <source>Greek, Modern</source>
        <translation>Grec demòtic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="189"/>
        <source>Greek</source>
        <translation>Grec</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="190"/>
        <source>Guarani</source>
        <translation>Guaraní</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="191"/>
        <source>Gujarati</source>
        <translation>Gujarati</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="192"/>
        <source>Haitian</source>
        <translation>Crioll haitià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="193"/>
        <source>Hausa</source>
        <translation>Hausa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="194"/>
        <source>Hebrew</source>
        <translation>Hebreu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="195"/>
        <source>Herero</source>
        <translation>Herero</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="196"/>
        <source>Hindi</source>
        <translation>Hindi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="197"/>
        <source>Hiri Motu</source>
        <translation>Hiri motu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="198"/>
        <location filename="../../Misc/Language.cpp" line="199"/>
        <source>Hungarian</source>
        <translation>Hongarès; magiar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="199"/>
        <source>Hungary</source>
        <translation>Hongria</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="200"/>
        <source>Icelandic</source>
        <translation>Islandès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="201"/>
        <source>Ido</source>
        <translation>Ido</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="202"/>
        <source>Igbo</source>
        <translation>Igbo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="203"/>
        <source>Indonesian</source>
        <translation>Indonesi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="204"/>
        <source>Indonesian - Indonesia</source>
        <translation>Indonesi - Indonèsia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="205"/>
        <source>Interlingua</source>
        <translation>Interlingua</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="206"/>
        <source>Interlingue</source>
        <translation>Interlingue</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="207"/>
        <source>Inuktitut</source>
        <translation>Inuktitut</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="208"/>
        <source>Inupiaq</source>
        <translation>Inupiak</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="209"/>
        <source>Irish</source>
        <translation>Irlandès; gaèlic irlandès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="210"/>
        <location filename="../../Misc/Language.cpp" line="211"/>
        <location filename="../../Misc/Language.cpp" line="212"/>
        <source>Italian</source>
        <translation>Italià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="211"/>
        <source>Italy</source>
        <translation>Itàlia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="213"/>
        <source>Japanese</source>
        <translation>Japonès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="214"/>
        <source>Javanese</source>
        <translation>Javanès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="215"/>
        <source>Kalaallisut</source>
        <translation>Grenlandès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="216"/>
        <source>Kannada</source>
        <translation>Kanarès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="217"/>
        <source>Kanuri</source>
        <translation>Kanuri</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="218"/>
        <source>Kashmiri</source>
        <translation>Caixmiri</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="219"/>
        <source>Kazakh</source>
        <translation>Kazakh</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="220"/>
        <source>Kikuyu</source>
        <translation>Kikuyu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="221"/>
        <source>Kinyarwanda</source>
        <translation>Kinyarwanda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="222"/>
        <source>Kirghiz</source>
        <translation>Kirguís</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="223"/>
        <source>Komi</source>
        <translation>República de Komi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="224"/>
        <source>Kongo</source>
        <translation>Kongo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="225"/>
        <source>Korean</source>
        <translation>Coreà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="226"/>
        <source>Kuanyama</source>
        <translation>Kwanyama</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="227"/>
        <source>Kurdish</source>
        <translation>Kurd</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="228"/>
        <source>Lao</source>
        <translation>Laosià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="229"/>
        <source>Latin</source>
        <translation>Llatí</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="230"/>
        <location filename="../../Misc/Language.cpp" line="231"/>
        <source>Latvian</source>
        <translation>Letó</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="231"/>
        <source>Latvia</source>
        <translation>Letònia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="232"/>
        <source>Limburgan</source>
        <translation>Limburgan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="233"/>
        <source>Lingala</source>
        <translation>Lingala</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="234"/>
        <source>Lithuanian</source>
        <translation>Lituà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="235"/>
        <source>Luba-Katanga</source>
        <translation>Luba-Katanga</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="236"/>
        <source>Luxembourgish</source>
        <translation>Luxemburguès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="237"/>
        <source>Macedonian</source>
        <translation>Macedoni</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="238"/>
        <source>Malagasy</source>
        <translation>Malgaix</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="239"/>
        <source>Malayalam</source>
        <translation>Malaiàlam</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="240"/>
        <location filename="../../Misc/Language.cpp" line="241"/>
        <location filename="../../Misc/Language.cpp" line="242"/>
        <source>Malay</source>
        <translation>Malai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="241"/>
        <source>Brunei</source>
        <translation>Brunei</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="242"/>
        <source>Malaysia</source>
        <translation>Malàisia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="243"/>
        <source>Maltese</source>
        <translation>Maltès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="244"/>
        <source>Manx</source>
        <translation>Gaèlic manx</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="245"/>
        <source>Maori</source>
        <translation>Maori</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="246"/>
        <source>Marathi</source>
        <translation>Marathi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="247"/>
        <source>Marshallese</source>
        <translation>Marshallès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="248"/>
        <source>Mongolian</source>
        <translation>Mongol</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="249"/>
        <source>Nauru</source>
        <translation>Nauruà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="250"/>
        <source>Navajo</source>
        <translation>Navaho</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="251"/>
        <location filename="../../Misc/Language.cpp" line="252"/>
        <source>Ndebele</source>
        <translation>Ndebele</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="251"/>
        <source>North</source>
        <translation>Nord</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="252"/>
        <source>South</source>
        <translation>Sud</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="253"/>
        <source>Ndonga</source>
        <translation>Ndonga</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="254"/>
        <source>Nepali</source>
        <translation>Nepalès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="255"/>
        <source>Northern, Sami</source>
        <translation>Sami septentrional</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="256"/>
        <location filename="../../Misc/Language.cpp" line="257"/>
        <location filename="../../Misc/Language.cpp" line="258"/>
        <source>Norwegian</source>
        <translation>Noruec</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="257"/>
        <source>Bokmal</source>
        <translation>Bokmål</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="258"/>
        <source>Nynorsk</source>
        <translation>Nynorsk</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="259"/>
        <source>Nyanja</source>
        <translation>Nyanja</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="260"/>
        <source>Occitan</source>
        <translation>Occità</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="261"/>
        <source>Ojibwa</source>
        <translation>Ojibwa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="262"/>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="263"/>
        <source>Oromo</source>
        <translation>Oromo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="264"/>
        <source>Ossetian</source>
        <translation>Osseta</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="265"/>
        <source>Pali</source>
        <translation>Pali</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="266"/>
        <source>Panjabi</source>
        <translation>Panjabi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="267"/>
        <source>Persian</source>
        <translation>Persa; farsi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="268"/>
        <source>Polish</source>
        <translation>Polonès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="269"/>
        <location filename="../../Misc/Language.cpp" line="270"/>
        <location filename="../../Misc/Language.cpp" line="271"/>
        <source>Portuguese</source>
        <translation>Portuguès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="270"/>
        <source>Brazil</source>
        <translation>Brasil</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="271"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="272"/>
        <source>Pushto</source>
        <translation>Paixtu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="273"/>
        <source>Quechua</source>
        <translation>Quítxua</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="274"/>
        <location filename="../../Misc/Language.cpp" line="275"/>
        <location filename="../../Misc/Language.cpp" line="276"/>
        <source>Romanian</source>
        <translation>Romanès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="275"/>
        <location filename="../../Misc/Language.cpp" line="280"/>
        <source>Moldova</source>
        <translation>República de Moldàvia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="276"/>
        <source>Romania</source>
        <translation>Romania</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="277"/>
        <source>Romansh</source>
        <translation>Romanx</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="278"/>
        <source>Rundi</source>
        <translation>Kirundi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="279"/>
        <location filename="../../Misc/Language.cpp" line="280"/>
        <source>Russian</source>
        <translation>Rus</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="281"/>
        <source>Samoan</source>
        <translation>Samoà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="282"/>
        <source>Sango</source>
        <translation>Sango</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="283"/>
        <source>Sanskrit</source>
        <translation>Sànscrit</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="284"/>
        <source>Sardinian</source>
        <translation>Sard</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="285"/>
        <location filename="../../Misc/Language.cpp" line="286"/>
        <source>Serbian</source>
        <translation>Serbi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="286"/>
        <source>Serbia</source>
        <translation>Sèrbia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="287"/>
        <source>Shona</source>
        <translation>Shona</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="288"/>
        <source>Sichuan Yi</source>
        <translation>Sichuan Yi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="289"/>
        <source>Sindhi</source>
        <translation>Sindhi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="290"/>
        <source>Sinhala</source>
        <translation>Singalès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="291"/>
        <source>Slovak</source>
        <translation>Eslovac</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="292"/>
        <source>Slovenian</source>
        <translation>Eslovè</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="293"/>
        <source>Somali</source>
        <translation>Somali</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="294"/>
        <source>Sotho, Southern</source>
        <translation>Sotho del sud</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="295"/>
        <location filename="../../Misc/Language.cpp" line="296"/>
        <location filename="../../Misc/Language.cpp" line="297"/>
        <location filename="../../Misc/Language.cpp" line="298"/>
        <location filename="../../Misc/Language.cpp" line="299"/>
        <location filename="../../Misc/Language.cpp" line="300"/>
        <location filename="../../Misc/Language.cpp" line="301"/>
        <location filename="../../Misc/Language.cpp" line="302"/>
        <location filename="../../Misc/Language.cpp" line="303"/>
        <location filename="../../Misc/Language.cpp" line="304"/>
        <location filename="../../Misc/Language.cpp" line="305"/>
        <location filename="../../Misc/Language.cpp" line="306"/>
        <location filename="../../Misc/Language.cpp" line="307"/>
        <location filename="../../Misc/Language.cpp" line="308"/>
        <location filename="../../Misc/Language.cpp" line="309"/>
        <location filename="../../Misc/Language.cpp" line="310"/>
        <location filename="../../Misc/Language.cpp" line="311"/>
        <location filename="../../Misc/Language.cpp" line="312"/>
        <location filename="../../Misc/Language.cpp" line="313"/>
        <location filename="../../Misc/Language.cpp" line="314"/>
        <source>Spanish</source>
        <translation>Espanyol</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="296"/>
        <source>Argentina</source>
        <translation>Argentina</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="297"/>
        <source>Bolivia</source>
        <translation>Bolívia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="298"/>
        <source>Chile</source>
        <translation>Xile</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="299"/>
        <source>Columbia</source>
        <translation>Colombia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="300"/>
        <source>Costa Rica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="301"/>
        <source>Dominican Republic</source>
        <translation>República Dominicana</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="302"/>
        <source>Ecuador</source>
        <translation>Equador</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="303"/>
        <source>El Salvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="304"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="305"/>
        <source>Honduras</source>
        <translation>Hondures</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="306"/>
        <source>Mexico</source>
        <translation>Mèxic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="307"/>
        <source>Nicaragua</source>
        <translation>Nicaragua</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="308"/>
        <source>Panama</source>
        <translation>Panamà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="309"/>
        <source>Paraguay</source>
        <translation>Paraguai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="310"/>
        <source>Peru</source>
        <translation>Perú</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="311"/>
        <source>Puerto Rico</source>
        <translation>Puerto Rico</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="313"/>
        <source>Uruguay</source>
        <translation>Uruguai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="314"/>
        <source>Venezuela</source>
        <translation>Veneçuela</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="315"/>
        <source>Sundanese</source>
        <translation>Sundanès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="316"/>
        <source>Swahili</source>
        <translation>Swahili</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="317"/>
        <source>Swati</source>
        <translation>Siswati</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="318"/>
        <location filename="../../Misc/Language.cpp" line="319"/>
        <location filename="../../Misc/Language.cpp" line="320"/>
        <source>Swedish</source>
        <translation>Suec</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="319"/>
        <source>Finland</source>
        <translation>Finlàndia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="320"/>
        <source>Sweden</source>
        <translation>Suècia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="321"/>
        <source>Tagalog</source>
        <translation>Tagal; tagàlog</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="322"/>
        <source>Tahitian</source>
        <translation>Tahitià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="323"/>
        <source>Tajik</source>
        <translation>Tadjik</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="324"/>
        <source>Tamil</source>
        <translation>Tàmil</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="325"/>
        <source>Tatar</source>
        <translation>Tàtar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="326"/>
        <source>Telugu</source>
        <translation>Telugu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="327"/>
        <source>Thai</source>
        <translation>Tailandès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="328"/>
        <source>Tibetan</source>
        <translation>Tibetà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="329"/>
        <source>Tigrinya</source>
        <translation>Tigrinya</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="330"/>
        <source>Tonga</source>
        <translation>Tongalès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="331"/>
        <source>Tsonga</source>
        <translation>Tsonga</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="332"/>
        <source>Tswana</source>
        <translation>Tswana</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="333"/>
        <location filename="../../Misc/Language.cpp" line="334"/>
        <source>Turkish</source>
        <translation>Turc</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="334"/>
        <source>Turkey</source>
        <translation>Turquia</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="335"/>
        <source>Turkmen</source>
        <translation>Turcman</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="336"/>
        <source>Twi</source>
        <translation>Twi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="337"/>
        <source>Uighur</source>
        <translation>Uigur</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="338"/>
        <location filename="../../Misc/Language.cpp" line="339"/>
        <source>Ukrainian</source>
        <translation>Ucraïnès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="339"/>
        <source>Ukraine</source>
        <translation>Ucraïna</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="340"/>
        <source>Urdu</source>
        <translation>Urdú</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="341"/>
        <location filename="../../Misc/Language.cpp" line="342"/>
        <source>Uzbek</source>
        <translation>Uzbek</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="342"/>
        <source>Uzbekistan</source>
        <translation>Uzbekistan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="343"/>
        <source>Venda</source>
        <translation>Venda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="344"/>
        <source>Vietnamese</source>
        <translation>Vietnamita</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="345"/>
        <source>Volapuk</source>
        <translation>Volapük</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="346"/>
        <source>Walloon</source>
        <translation>Való</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="347"/>
        <source>Welsh</source>
        <translation>Gal·lès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="348"/>
        <source>Western Frisian</source>
        <translation>Frisó occidental</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="349"/>
        <source>Wolof</source>
        <translation>Wòlof</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="350"/>
        <source>Xhosa</source>
        <translation>Xosa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="351"/>
        <source>Yiddish</source>
        <translation>Jiddisch</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="352"/>
        <source>Yoruba</source>
        <translation>Ioruba</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="353"/>
        <source>Zhuang</source>
        <translation>Zhuang</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="354"/>
        <source>Zulu</source>
        <translation>Zulu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="355"/>
        <source>Achinese</source>
        <translation>Axinès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="356"/>
        <source>Acoli</source>
        <translation>Acoli</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="357"/>
        <source>Adangme</source>
        <translation>Adangme</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="358"/>
        <source>Adygei, Adyghe</source>
        <translation>Adigué</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="359"/>
        <source>Afrihili</source>
        <translation>Afrihili</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="360"/>
        <source>Afro-Asiatic languages</source>
        <translation>Llengües afroasiàtiques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="361"/>
        <source>Ainu</source>
        <translation>Ainu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="362"/>
        <source>Akkadian</source>
        <translation>Accadi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="363"/>
        <source>Aleut</source>
        <translation>Aleutià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="364"/>
        <source>Algonquian languages</source>
        <translation>Llengües algonquines</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="365"/>
        <source>Altaic languages</source>
        <translation>Llengües altaiques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="366"/>
        <source>Angika</source>
        <translation>Angika</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="367"/>
        <source>Apache languages</source>
        <translation>Llengües apatxes</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="368"/>
        <source>Arapaho</source>
        <translation>Arapaho</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="369"/>
        <source>Arawak</source>
        <translation>Arauac; arawak</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="370"/>
        <source>Aromanian, Arumanian, Macedo-Romanian</source>
        <translation>Aromanès; macedoromanès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="371"/>
        <source>Artificial languages</source>
        <translation>Llengües artificials</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="372"/>
        <source>Asturian, Asturleonese, Bable, Leonese</source>
        <translation>Asturià; bable; lleonès; asturlleonès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="373"/>
        <source>Athapascan languages</source>
        <translation>Llengües atapascanes</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="374"/>
        <source>Australian languages</source>
        <translation>Llengües australianes</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="375"/>
        <source>Austronesian languages</source>
        <translation>Llengües austronèsiques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="376"/>
        <source>Awadhi</source>
        <translation>Awadhi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="377"/>
        <source>Balinese</source>
        <translation>Balinès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="378"/>
        <source>Baltic languages</source>
        <translation>Llengües bàltiques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="379"/>
        <source>Baluchi</source>
        <translation>Balutxí</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="380"/>
        <source>Bamileke languages</source>
        <translation>Llengües bamileké</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="381"/>
        <source>Banda languages</source>
        <translation>Llengües banda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="382"/>
        <source>Bantu languages</source>
        <translation>Llengües bantus</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="383"/>
        <source>Basa</source>
        <translation>Basa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="384"/>
        <source>Batak languages</source>
        <translation>Llengües bataks</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="385"/>
        <source>Bedawiyet, Beja</source>
        <translation>Beja; bedawiye</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="386"/>
        <source>Bemba</source>
        <translation>Bemba</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="387"/>
        <source>Berber languages</source>
        <translation>Llengües berbers</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="388"/>
        <source>Bhojpuri</source>
        <translation>Bhojpuri</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="389"/>
        <source>Bikol</source>
        <translation>Bikol</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="390"/>
        <source>Bilin, Blin</source>
        <translation>Bilin; blin</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="391"/>
        <source>Bini, Edo</source>
        <translation>Bini; edo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="392"/>
        <source>Bliss, Blissymbols, Blissymbolics</source>
        <translation>Blissymbols; blissymbolics; bliss</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="393"/>
        <source>Braj</source>
        <translation>Braj</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="394"/>
        <source>Buginese</source>
        <translation>Bugui</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="395"/>
        <source>Buriat</source>
        <translation>Buriats</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="396"/>
        <source>Caddo</source>
        <translation>Caddo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="397"/>
        <source>Caucasian languages</source>
        <translation>Llengües caucàsiques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="398"/>
        <source>Cebuano</source>
        <translation>Cebuano</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="399"/>
        <source>Celtic languages</source>
        <translation>Llengües cèltiques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="400"/>
        <source>Central American Indian languages</source>
        <translation>Llengües ameríndies d&apos;Amèrica Central</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="401"/>
        <source>Chagatai</source>
        <translation>Txagatai Khan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="402"/>
        <source>Chamic languages</source>
        <translation>Llengües txam</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="403"/>
        <source>Cherokee</source>
        <translation>Cherokee</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="404"/>
        <source>Cheyenne</source>
        <translation>Xeienne; cheyenne</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="405"/>
        <source>Chibcha</source>
        <translation>Chibcha</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="406"/>
        <source>Chinook jargon</source>
        <translation>Pidgin chinook</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="407"/>
        <source>Chipewyan, Dene Suline</source>
        <translation>Chipewyan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="408"/>
        <source>Choctaw</source>
        <translation>Choctaw</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="409"/>
        <source>Chuukese</source>
        <translation>Chuukese</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="410"/>
        <source>Classical Nepal Bhasa/Newari, Old Newari</source>
        <translation>Newari clàssic; newari antic; bhasa nepalès clàssic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="411"/>
        <source>Classical Syriac</source>
        <translation>Siríac clàssic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="412"/>
        <source>Coptic</source>
        <translation>Copte</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="413"/>
        <source>Creek</source>
        <translation>Creek</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="414"/>
        <source>Creoles and pidgins</source>
        <translation>Criolls i pidgins</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="415"/>
        <source>Creoles and pidgins- English based</source>
        <translation>Criolls i pidgins basats en l&apos;anglès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="416"/>
        <source>Creoles and pidgins- French-based</source>
        <translation>Criolls i pidgins basats en el francès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="417"/>
        <source>Creoles and pidgins- Portuguese-based</source>
        <translation>Criolls i pidgins basats en el portuguès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="418"/>
        <source>Crimean Tatar/Turkish</source>
        <translation>Tàtar de Crimea; turc de Crimea</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="419"/>
        <source>Cushitic languages</source>
        <translation>Llengües cuixítiques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="420"/>
        <source>Dakota</source>
        <translation>Dakota</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="421"/>
        <source>Dargwa</source>
        <translation>Darguà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="422"/>
        <source>Delaware</source>
        <translation>Delaware</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="423"/>
        <source>Dimili, Dimli, Zaza, Zazaki, Kirdki, Kirmanjki</source>
        <translation>Zaza; dimilki; kirmanjki; zazaki</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="424"/>
        <source>Dinka</source>
        <translation>Dinka</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="425"/>
        <source>Dogri</source>
        <translation>Dogri</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="426"/>
        <source>Dogrib</source>
        <translation>Dogrib</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="427"/>
        <source>Dravidian languages</source>
        <translation>Llengües dravídiques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="428"/>
        <source>Duala</source>
        <translation>Duala</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="429"/>
        <source>Dutch- Middle (ca.1050-1350)</source>
        <translation>Holandès mitjà (ca. 1050-1350)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="430"/>
        <source>Dyula</source>
        <translation>Dyula</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="431"/>
        <source>Eastern Frisian</source>
        <translation>Frisó oriental</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="432"/>
        <source>Efik</source>
        <translation>Efik</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="433"/>
        <source>Egyptian (Ancient)</source>
        <translation>Egipci (antic)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="434"/>
        <source>Ekajuk</source>
        <translation>Ekajuk</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="435"/>
        <source>Elamite</source>
        <translation>Llengua elamita</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="436"/>
        <source>English- Middle (1100-1500)</source>
        <translation>Anglès mitjà (1100-1500)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="437"/>
        <source>English- Old (ca.450-1100)</source>
        <translation>Anglès antic (ca.450-1100)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="438"/>
        <source>Erzya</source>
        <translation>Erzya</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="439"/>
        <source>Ewondo</source>
        <translation>Ewondo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="440"/>
        <source>Fang</source>
        <translation>Llengua fang</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="441"/>
        <source>Fanti</source>
        <translation>Fanti</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="442"/>
        <source>Filipino, Pilipino</source>
        <translation>Filipi; pilipino</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="443"/>
        <source>Finno-Ugrian languages</source>
        <translation>Llengües finoúgriques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="444"/>
        <source>Fon</source>
        <translation>Fon</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="445"/>
        <source>French- Middle (ca.1400-1600)</source>
        <translation>Francès mitjà (ca.1400-1600)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="446"/>
        <source>French- Old (842-ca.1400)</source>
        <translation>Francès antic (842-ca.1400)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="447"/>
        <source>Friulian</source>
        <translation>Friülès; friülà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="448"/>
        <source>Ga</source>
        <translation>Ga</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="449"/>
        <source>Galibi Carib</source>
        <translation>Carib</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="450"/>
        <source>Gayo</source>
        <translation>Gayo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="451"/>
        <source>Gbaya</source>
        <translation>Gbaya</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="452"/>
        <source>Geez</source>
        <translation>Gueez</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="453"/>
        <source>German- Middle High (ca.1050-1500)</source>
        <translation>Alt alemany mitjà (ca.1050-1500)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="454"/>
        <source>German- Old High (ca.750-1050)</source>
        <translation>Alt alemany antic (ca.750-1050)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="455"/>
        <source>Germanic languages</source>
        <translation>Llengües germàniques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="456"/>
        <source>Gilbertese</source>
        <translation>Gilbertès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="457"/>
        <source>Gondi</source>
        <translation>Gondi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="458"/>
        <source>Gorontalo</source>
        <translation>Gorontalo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="459"/>
        <source>Gothic</source>
        <translation>Gòtic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="460"/>
        <source>Grebo</source>
        <translation>Grebo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="461"/>
        <source>Greek- Ancient (to 1453)</source>
        <translation>Grec antic (fins al 1453)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="462"/>
        <source>Gwich&apos;in</source>
        <translation>Gwich&apos;in</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="463"/>
        <source>Haida</source>
        <translation>Haida</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="464"/>
        <source>Hawaiian</source>
        <translation>Hawaià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="465"/>
        <source>Hiligaynon</source>
        <translation>Hiligaynon</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="466"/>
        <source>Himachali, Western Pahari languages</source>
        <translation>Llengües himachalis; llengües paharis occidentals</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="467"/>
        <source>Hittite</source>
        <translation>Hitita</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="468"/>
        <source>Hmong, Mong</source>
        <translation>Hmong; mong</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="469"/>
        <source>Hupa</source>
        <translation>Hupa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="470"/>
        <source>Iban</source>
        <translation>Iban</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="471"/>
        <source>Ijo languages</source>
        <translation>Llengües ijo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="472"/>
        <source>Iloko</source>
        <translation>Ilocà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="473"/>
        <source>Inari Sami</source>
        <translation>Sami d&apos;Inari</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="474"/>
        <source>Indic languages</source>
        <translation>Llengües índiques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="475"/>
        <source>Indo-European languages</source>
        <translation>Llengües indoeuropees</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="476"/>
        <source>Ingush</source>
        <translation>Ingúix</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="477"/>
        <source>Iranian languages</source>
        <translation>Llengües iranianes</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="478"/>
        <source>Irish- Middle (900-1200)</source>
        <translation>Irlandès mitjà (900-1200)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="479"/>
        <source>Irish- Old (to 900)</source>
        <translation>Irlandès antic (fins al 900)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="480"/>
        <source>Iroquoian languages</source>
        <translation>Llengües iroqueses</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="481"/>
        <source>Jingpho, Kachin</source>
        <translation>Kachin; jingpho</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="482"/>
        <source>Judeo-Arabic</source>
        <translation>Judeoàrab</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="483"/>
        <source>Judeo-Persian</source>
        <translation>Judeopersa</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="484"/>
        <source>Kabardian</source>
        <translation>Kabardí</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="485"/>
        <source>Kabyle</source>
        <translation>Cabilenc</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="486"/>
        <source>Kalmyk, Oirat</source>
        <translation>Calmuc</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="487"/>
        <source>Kamba</source>
        <translation>Kamba</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="488"/>
        <source>Kapampangan, Pampanga</source>
        <translation>Pampanga; kapampangan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="489"/>
        <source>Kara-Kalpak</source>
        <translation>Karakalpak</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="490"/>
        <source>Karachay-Balkar</source>
        <translation>Karatxai-balkar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="491"/>
        <source>Karelian</source>
        <translation>Carelià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="492"/>
        <source>Karen languages</source>
        <translation>Llengües karenes</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="493"/>
        <source>Kashubian</source>
        <translation>Caixubi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="494"/>
        <source>Kawi</source>
        <translation>Kawi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="495"/>
        <source>Khasi</source>
        <translation>Khasi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="496"/>
        <source>Khoisan languages</source>
        <translation>Llengües khoisànides</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="497"/>
        <source>Khotanese, Sakan</source>
        <translation>Khotanès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="498"/>
        <source>Kimbundu</source>
        <translation>Kimbundu; mbundu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="499"/>
        <source>Klingon, tlhIngan-Hol</source>
        <translation>Klíngon; klingonès; tlhIngan Hol</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="500"/>
        <source>Konkani</source>
        <translation>Konkani</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="501"/>
        <source>Kosraean</source>
        <translation>Kosraeà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="502"/>
        <source>Kpelle</source>
        <translation>Kpelle</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="503"/>
        <source>Kru languages</source>
        <translation>Llengües Kru</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="504"/>
        <source>Kumyk</source>
        <translation>Kúmik</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="505"/>
        <source>Kurukh</source>
        <translation>Kurukh</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="506"/>
        <source>Kutenai</source>
        <translation>Kutenai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="507"/>
        <source>Ladino</source>
        <translation>Ladí</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="508"/>
        <source>Lahnda</source>
        <translation>Lahnda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="509"/>
        <source>Lamba</source>
        <translation>Lamba</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="510"/>
        <source>Land Dayak languages</source>
        <translation>Llengües daiaks</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="511"/>
        <source>Lezghian</source>
        <translation>Lesguià; lèsguic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="512"/>
        <source>Lojban</source>
        <translation>Lojban</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="513"/>
        <source>German-Low, Low Saxon</source>
        <translation>Baix alemany; baix saxó</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="514"/>
        <source>Lower Sorbian</source>
        <translation>Baix sòrab</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="515"/>
        <source>Lozi</source>
        <translation>Lozi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="516"/>
        <source>Luba-Lulua</source>
        <translation>Luba-lulua</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="517"/>
        <source>Luiseno</source>
        <translation>Luisenyo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="518"/>
        <source>Lule Sami</source>
        <translation>Sami de Lule</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="519"/>
        <source>Lunda</source>
        <translation>Lunda</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="520"/>
        <source>Luo (Kenya and Tanzania)</source>
        <translation>Luo (Kenya i Tanzània)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="521"/>
        <source>Lushai</source>
        <translation>Lushai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="522"/>
        <source>Madurese</source>
        <translation>Madurès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="523"/>
        <source>Magahi</source>
        <translation>Magahi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="524"/>
        <source>Maithili</source>
        <translation>Maithili</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="525"/>
        <source>Makasar</source>
        <translation>Makasar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="526"/>
        <source>Manchu</source>
        <translation>Mantxú</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="527"/>
        <source>Mandar</source>
        <translation>Mandar</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="528"/>
        <source>Mandingo</source>
        <translation>Manding</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="529"/>
        <source>Manipuri</source>
        <translation>Manipuri</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="530"/>
        <source>Manobo languages</source>
        <translation>Llengües manobo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="531"/>
        <source>Mapuche/Mapudungun</source>
        <translation>Mapudungun; maputxe</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="532"/>
        <source>Mari</source>
        <translation>Mari</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="533"/>
        <source>Marwari</source>
        <translation>Marwari</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="534"/>
        <source>Masai</source>
        <translation>Massai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="535"/>
        <source>Mayan languages</source>
        <translation>Llengües maies</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="536"/>
        <source>Mende</source>
        <translation>Mende</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="537"/>
        <source>Mi&apos;kmaq, Micmac</source>
        <translation>Mi&apos;kmaq; micmac</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="538"/>
        <source>Minangkabau</source>
        <translation>Minangkabau</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="539"/>
        <source>Mirandese</source>
        <translation>Mirandès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="540"/>
        <source>Mohawk</source>
        <translation>Mohawk</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="541"/>
        <source>Moksha</source>
        <translation>Moksha</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="542"/>
        <source>Mon-Khmer languages</source>
        <translation>Llengües mon-khmer</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="543"/>
        <source>Mongo</source>
        <translation>Mongo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="544"/>
        <source>Mossi</source>
        <translation>Mossi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="545"/>
        <source>Multiple languages</source>
        <translation>Diferents llengües</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="546"/>
        <source>Munda languages</source>
        <translation>Llengües mundes</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="547"/>
        <source>N&apos;Ko</source>
        <translation>Nko</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="548"/>
        <source>Nahuatl languages</source>
        <translation>Llengües nàhuatl</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="549"/>
        <source>Neapolitan</source>
        <translation>Napolità</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="550"/>
        <source>Nepal Bhasa/Newari</source>
        <translation>Newar; Bhasa Nepal</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="551"/>
        <source>Nias</source>
        <translation>Nias</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="552"/>
        <source>Niger-Kordofanian languages</source>
        <translation>Llengües nigerokordofanianes</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="553"/>
        <source>Nilo-Saharan languages</source>
        <translation>Llengües nilosaharianes</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="554"/>
        <source>Niuean</source>
        <translation>Niueà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="555"/>
        <source>No linguistic content/Not applicable</source>
        <translation>Sense contingut lingüístic / No aplicable</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="556"/>
        <source>Nogai</source>
        <translation>Nogai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="557"/>
        <source>Norse- Old</source>
        <translation>Nòrdic antic</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="558"/>
        <source>North American Indian languages</source>
        <translation>Llengües ameríndies d&apos;Amèrica del Nord</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="559"/>
        <source>Northern Frisian</source>
        <translation>Frisó septentrional</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="560"/>
        <source>Northern Sotho, Sepedi, Pedi</source>
        <translation>Pedi; sepedi; sotho septrentional</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="561"/>
        <source>Nubian languages</source>
        <translation>Llengües nubianes</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="562"/>
        <source>Nyamwezi</source>
        <translation>Nyamwezi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="563"/>
        <source>Nyankole</source>
        <translation>Nyankole</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="564"/>
        <source>Nyoro</source>
        <translation>Nyoro</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="565"/>
        <source>Nzima</source>
        <translation>Nzema; Nzima; Appolo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="566"/>
        <source>Occitan/Provencal- Old (to 1500)</source>
        <translation>Provençal antic (fins al 1500); occità antic (fins al 1500)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="567"/>
        <source>Official/Imperial Aramaic (700-300 BCE)</source>
        <translation>Aramaic oficial (700-300 a.C.); aramaic imperial (700-300 a.C.)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="568"/>
        <source>Osage</source>
        <translation>Osage</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="569"/>
        <source>Otomian languages</source>
        <translation>Llengües otomianes</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="570"/>
        <source>Pahlavi</source>
        <translation>Pahlavi</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="571"/>
        <source>Palauan</source>
        <translation>Palauà; palauès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="572"/>
        <source>Pangasinan</source>
        <translation>Pangasinan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="573"/>
        <source>Papiamento</source>
        <translation>Papiamento</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="574"/>
        <source>Papuan languages</source>
        <translation>Llengües papús</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="575"/>
        <source>Persian- Old (ca.600-400 B.C.)</source>
        <translation>Persa antic (ca. 600-400 AC)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="576"/>
        <source>Philippine languages</source>
        <translation>Llengües filipines</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="577"/>
        <source>Phoenician</source>
        <translation>Fenici</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="578"/>
        <source>Pohnpeian</source>
        <translation>Ponapeà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="579"/>
        <source>Prakrit languages</source>
        <translation>Llengües pràcrits</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="580"/>
        <source>Rajasthani</source>
        <translation>Rajasthani</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="581"/>
        <source>Rapanui</source>
        <translation>Rapanui</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="582"/>
        <source>Rarotongan, Cook Islands Maori</source>
        <translation>Rarotongan; maori de les Illes Cook</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="583"/>
        <source>Reserved for local use</source>
        <translation>Reservat per a ús local</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="584"/>
        <source>Romance languages</source>
        <translation>Llengües romàniques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="585"/>
        <source>Romany</source>
        <translation>Romaní</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="586"/>
        <source>Salishan languages</source>
        <translation>Llengües salish</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="587"/>
        <source>Samaritan Aramaic</source>
        <translation>Arameu samarità</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="588"/>
        <source>Sami languages</source>
        <translation>Llengües sami</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="589"/>
        <source>Sandawe</source>
        <translation>Sandawe</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="590"/>
        <source>Santali</source>
        <translation>Santali</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="591"/>
        <source>Sasak</source>
        <translation>Sasak</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="592"/>
        <source>Scots</source>
        <translation>Escocès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="593"/>
        <source>Selkup</source>
        <translation>Selkup</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="594"/>
        <source>Semitic languages</source>
        <translation>Llengües semítiques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="595"/>
        <source>Serer</source>
        <translation>Serer</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="596"/>
        <source>Shan</source>
        <translation>Shan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="597"/>
        <source>Sicilian</source>
        <translation>Sicilià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="598"/>
        <source>Sidamo</source>
        <translation>Sidamo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="599"/>
        <source>Sign Languages</source>
        <translation>Llengües de signes</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="600"/>
        <source>Siksika</source>
        <translation>Siksika; peus negres</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="601"/>
        <source>Sino-Tibetan languages</source>
        <translation>Llengües sinotibetanes</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="602"/>
        <source>Siouan languages</source>
        <translation>Llengües siux</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="603"/>
        <source>Skolt Sami</source>
        <translation>Sami skolt</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="604"/>
        <source>Slave (Athapascan)</source>
        <translation>Slave (atapascà)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="605"/>
        <source>Slavic languages</source>
        <translation>Llengües eslàviques</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="606"/>
        <source>Sogdian</source>
        <translation>Sogdià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="607"/>
        <source>Songhai languages</source>
        <translation>Llengües songhai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="608"/>
        <source>Soninke</source>
        <translation>Soninke</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="609"/>
        <source>Sorbian languages</source>
        <translation>Llengües sòrabes</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="610"/>
        <source>South American Indian languages</source>
        <translation>Llengües ameríndies d&apos;Amèrica del Sud</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="611"/>
        <source>Southern Altai</source>
        <translation>Altaic meridional</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="612"/>
        <source>Southern Sami</source>
        <translation>Sami meridional</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="613"/>
        <source>Sranan Tongo</source>
        <translation>Sranan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="614"/>
        <source>Sukuma</source>
        <translation>Sukuma</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="615"/>
        <source>Sumerian</source>
        <translation>Sumeri</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="616"/>
        <source>Susu</source>
        <translation>Susu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="617"/>
        <source>Alsatian, Swiss German, Alemannic</source>
        <translation>Alemany suís; alamànic; alsacià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="618"/>
        <source>Syriac</source>
        <translation>Siríac</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="619"/>
        <source>Tai languages</source>
        <translation>Llengües tais</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="620"/>
        <source>Tamashek</source>
        <translation>Tamahaq</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="621"/>
        <source>Tereno</source>
        <translation>Tereno; terêna</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="622"/>
        <source>Tetum</source>
        <translation>Tetum; tetun</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="623"/>
        <source>Tigre</source>
        <translation>Tigre; tigré</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="624"/>
        <source>Timne</source>
        <translation>Timne; themne</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="625"/>
        <source>Tiv</source>
        <translation>Tiv</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="626"/>
        <source>Tlingit</source>
        <translation>Tlingit</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="627"/>
        <source>Tok Pisin</source>
        <translation>Tok pisin</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="628"/>
        <source>Tokelau</source>
        <translation>Tokelauès</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="629"/>
        <source>Tonga (Nyasa)</source>
        <translation>Tonga (Nyasa)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="630"/>
        <source>Tsimshian</source>
        <translation>Tsimshian</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="631"/>
        <source>Tumbuka</source>
        <translation>Tumbuka</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="632"/>
        <source>Tupi languages</source>
        <translation>Llengües tupís</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="633"/>
        <source>Turkish- Ottoman (1500-1928)</source>
        <translation>Turc otomà (1500-1928)</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="634"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="635"/>
        <source>Tuvinian</source>
        <translation>Tuvinià</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="636"/>
        <source>Udmurt</source>
        <translation>Udmurt</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="637"/>
        <source>Ugaritic</source>
        <translation>Ugarític</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="638"/>
        <source>Umbundu</source>
        <translation>Umbundu</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="639"/>
        <source>Uncoded languages</source>
        <translation>Llengües sense codificació</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="640"/>
        <source>Undetermined</source>
        <translation>Indeterminat</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="641"/>
        <source>Upper Sorbian</source>
        <translation>Alt sòrab</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="642"/>
        <source>Vai</source>
        <translation>Vai</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="643"/>
        <source>Votic</source>
        <translation>Votic; vod</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="644"/>
        <source>Wakashan languages</source>
        <translation>Llengües wakashan</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="645"/>
        <source>Waray</source>
        <translation>Waray</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="646"/>
        <source>Washo</source>
        <translation>Washo</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="647"/>
        <source>Wolaitta, Wolaytta</source>
        <translation>Walamo, wolaytta</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="648"/>
        <source>Yakut</source>
        <translation>Iacut</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="649"/>
        <source>Yao</source>
        <translation>Yao</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="650"/>
        <source>Yapese</source>
        <translation>Yapeà; yapà</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="651"/>
        <source>Yupik languages</source>
        <translation>Llengües yupik</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="652"/>
        <source>Zande languages</source>
        <translation>Llengües zande</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="653"/>
        <source>Zapotec</source>
        <translation>Zapoteca</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="654"/>
        <source>Zenaga</source>
        <translation>Zenaga</translation>
    </message>
    <message>
        <location filename="../../Misc/Language.cpp" line="655"/>
        <source>Zuni</source>
        <translation>Zuni</translation>
    </message>
</context>
<context>
    <name>LanguageWidget</name>
    <message>
        <location filename="../../Form_Files/PLanguageWidget.ui" line="14"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PLanguageWidget.ui" line="36"/>
        <source>You must restart Sigil after changing the User Interface language.

If a translation for specific word or phrase is not available it will be displayed in English.

Use Preferences-&gt;Spellcheck Dictionaries to set the Spellcheck dictionary.</source>
        <translation>Heu de reinicar el Sigil després de canviar l&apos;idioma de la interfície d&apos;usuari.

Si no està disponible la traducció d&apos;una paraula o frase concreta, es mostrarà en anglès.

Establiu el diccionari de comprovació ortogràfica a l&apos;apartat corresponent de les preferències.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PLanguageWidget.ui" line="43"/>
        <source>User Interface Language:</source>
        <translation>Idioma de la interfície d&apos;usuari:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PLanguageWidget.ui" line="53"/>
        <source>Set the default language used by the Metadata Editor for new books.</source>
        <translation>Estableix l&apos;idioma predeterminat de l&apos;editor de metadades per als llibres nous.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PLanguageWidget.ui" line="56"/>
        <source>Default Language For Metadata:</source>
        <translation>Idioma predeterminat de les metadades:</translation>
    </message>
</context>
<context>
    <name>LinkStylesheets</name>
    <message>
        <location filename="../../Form_Files/LinkStylesheets.ui" line="14"/>
        <source>Link StyleSheets</source>
        <translation>Enllaça els fulls d&apos;estil</translation>
    </message>
    <message>
        <location filename="../../Form_Files/LinkStylesheets.ui" line="43"/>
        <source>Move the selected stylesheets up in priority.

Stylesheets that are listed first take precedence over later stylesheets.</source>
        <translation>Mou els fulls d&apos;estil seleccionats cap amunt.

La llista estableix els fulls d&apos;estil amb prioritat decreixent.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/LinkStylesheets.ui" line="48"/>
        <source>Up</source>
        <translation>Amunt</translation>
    </message>
    <message>
        <location filename="../../Form_Files/LinkStylesheets.ui" line="58"/>
        <source>Move the selected stylesheets down in priority.</source>
        <translation>Mou els fulls d&apos;estil seleccionats cap avall.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/LinkStylesheets.ui" line="61"/>
        <source>Down</source>
        <translation>Avall</translation>
    </message>
    <message>
        <location filename="../../Dialogs/LinkStylesheets.cpp" line="60"/>
        <source>Include</source>
        <translation>Inclou</translation>
    </message>
    <message>
        <location filename="../../Dialogs/LinkStylesheets.cpp" line="61"/>
        <source>Stylesheet</source>
        <translation>Full d&apos;estil</translation>
    </message>
</context>
<context>
    <name>LinksWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsLinksWidget.ui" line="14"/>
        <source>Links</source>
        <translation>Enllaços</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsLinksWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>Mostra només els noms de fitxer que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsLinksWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="71"/>
        <source>File</source>
        <translation>Fitxer</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="72"/>
        <source>Line</source>
        <translation>Línia</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="73"/>
        <source>ID</source>
        <translation>Identificador</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="74"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="75"/>
        <source>Target File</source>
        <translation>Fitxer objectiu</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="76"/>
        <source>Target ID</source>
        <translation>Identificador objectiu</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="77"/>
        <source>Target Exists?</source>
        <translation>Existeix l&apos;objectiu?</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="78"/>
        <source>Target Text</source>
        <translation>Text objectiu</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="79"/>
        <source>Target&apos;s Target File</source>
        <translation>Objectiu del fitxer objectiu</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="80"/>
        <source>Target&apos;s Target ID</source>
        <translation>Objectiu de l&apos;identificador objectiu</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="81"/>
        <source>Match?</source>
        <translation>Hi ha coincidència?</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="87"/>
        <source>Report shows all source and target links using the anchor tag &quot;a&quot;.</source>
        <translation>L&apos;informe mostra tots els origens i les destinacions dels enllaços amb l&apos;etiqueta d&apos;àncora «a».</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="156"/>
        <source>n/a</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="159"/>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="227"/>
        <source>no</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="166"/>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="229"/>
        <source>yes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="343"/>
        <source>Save Report As Comma Separated File</source>
        <translation>Desa l&apos;informe com a fitxer de text separat per comes</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="356"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/LinksWidget.cpp" line="356"/>
        <source>Cannot save report file.</source>
        <translation>No es pot desar el fitxer d&apos;informe.</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../Form_Files/main.ui" line="14"/>
        <source>untitled.epub[*] - Sigil</source>
        <translation>sense_titol.epub[*] - Sigil</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="58"/>
        <source>&amp;File</source>
        <translation>&amp;Fitxer</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="62"/>
        <source>A&amp;dd</source>
        <translation>A&amp;fegeix</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="88"/>
        <source>&amp;Edit</source>
        <translation>&amp;Edita</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="92"/>
        <source>C&amp;hange Case</source>
        <translation>&amp;Majúscules i minúscules</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="117"/>
        <source>&amp;Insert</source>
        <translation>&amp;Insereix</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="121"/>
        <source>Cli&amp;p</source>
        <translation>&amp;Retall</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="158"/>
        <source>&amp;Help</source>
        <translation>&amp;Ajuda</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="168"/>
        <source>For&amp;mat</source>
        <translation>For&amp;mata</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="172"/>
        <source>&amp;Heading</source>
        <translation>&amp;Encapçalament</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="213"/>
        <source>&amp;View</source>
        <translation>&amp;Visualitza</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="217"/>
        <source>&amp;Toolbars</source>
        <translation>&amp;Barres d&apos;eines</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="232"/>
        <source>&amp;Search</source>
        <translation>&amp;Cerca</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="236"/>
        <source>Current Fil&amp;e</source>
        <translation>Fitx&amp;er actual</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="268"/>
        <source>&amp;Window</source>
        <translation>&amp;Finestra</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="280"/>
        <source>&amp;Tools</source>
        <translation>&amp;Eines</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="284"/>
        <source>&amp;Table Of Contents</source>
        <translation>&amp;Taula de continguts</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="292"/>
        <source>Spe&amp;llcheck</source>
        <translation>Corrector &amp;ortogràfic</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="306"/>
        <source>&amp;Index</source>
        <translation>Índe&amp;x</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="317"/>
        <source>Re&amp;format HTML</source>
        <translation>Re&amp;formata l&apos;HTML</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="324"/>
        <source>Epub&amp;3 Tools</source>
        <translation>Eines EPUB&amp;3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="349"/>
        <source>Plugins</source>
        <translation>Connectors</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="367"/>
        <location filename="../../MainUI/MainWindow.cpp" line="598"/>
        <source>File</source>
        <translation>Fitxer</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="382"/>
        <location filename="../../MainUI/MainWindow.cpp" line="337"/>
        <source>Edit</source>
        <translation>Edita</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="401"/>
        <source>View</source>
        <translation>Visualitza</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="414"/>
        <source>Insert</source>
        <translation>Insereix</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="431"/>
        <source>Back</source>
        <translation>Vés enrere</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="443"/>
        <source>Donate</source>
        <translation>Feu una donació</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="455"/>
        <source>Tools</source>
        <translation>Eines</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="477"/>
        <source>Heading</source>
        <translation>Encapçalament</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="495"/>
        <source>Format</source>
        <translation>Formata</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="512"/>
        <source>Align</source>
        <translation>Alinea</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="527"/>
        <source>List</source>
        <translation>Llista</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="540"/>
        <source>Indent</source>
        <translation>Sagna</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="553"/>
        <source>Change Case</source>
        <translation>Majúscules i minúscules</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="568"/>
        <source>Text Direction</source>
        <translation>Sentit del text</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="582"/>
        <source>Clip Bar</source>
        <translation>Barra de retalls</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="617"/>
        <source>&amp;New</source>
        <translation>&amp;Nou</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="620"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;New&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Create a new book.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Nou&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Crea un llibre nou.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="625"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="634"/>
        <source>&amp;Save</source>
        <translation>&amp;Desa</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="637"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Save&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Save the current book.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Desa&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Desa el llibre actual.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="642"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="647"/>
        <source>Save &amp;As...</source>
        <translation>&amp;Anomena i desa...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="650"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Save As&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Save the current book with a different filename.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Anomena i desa&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Desar el llibre actual amb un altre nom.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="655"/>
        <source>Ctrl+Shift+S</source>
        <translation>Ctrl+Maj+S</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="660"/>
        <source>Save A &amp;Copy...</source>
        <translation>Desa una &amp;copia...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="663"/>
        <source>Save a copy of your book to another file name.</source>
        <translation>Desa una còpia del llibre amb un altre nom.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="672"/>
        <source>Cu&amp;t</source>
        <translation>Re&amp;talla</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="675"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Cut&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Cuts the selected text from the document and puts it on the clipboard.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Talla&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Talla el text seleccionat al document i el desa al porta-retalls.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="686"/>
        <source>&amp;Paste</source>
        <translation>&amp;Enganxa</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="689"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Paste&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Pastes the content from the clipboard into the book.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Enganxa&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Enganxa el contingut del porta-retalls al llibre.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="696"/>
        <source>&amp;Closing Tag</source>
        <translation>Etiqueta de &amp;tancament</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="699"/>
        <source>Insert a closing tag in Code View.</source>
        <translation>Insereix una etiqueta de tancament en la vista de codi.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="702"/>
        <source>Ctrl+.</source>
        <translation>Ctrl+.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="711"/>
        <source>&amp;Undo</source>
        <translation>&amp;Desfés</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="714"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Undo&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Reverts the changes of the previous operation.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Desfés&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Desfà els canvis de l&apos;operació anterior.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="719"/>
        <source>Ctrl+Z</source>
        <translation>Ctrl+Z</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="728"/>
        <source>&amp;Redo</source>
        <translation>&amp;Refés</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="731"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Redo&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Restores the changes reverted by the previous Undo action.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Refés&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Restaura els canvis desfets per l&apos;acció de desfer anterior.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="736"/>
        <source>Ctrl+Y</source>
        <translation>Ctrl+Y</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="745"/>
        <source>&amp;Copy</source>
        <translation>&amp;Copia</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="748"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Copy&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Copies the selected text and puts it on the clipboard.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Copia&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Copia el text seleccionat i el desa al porta-retalls.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="762"/>
        <source>Align &amp;Left</source>
        <translation>Alinea a l&apos;es&amp;querra</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="765"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Align Left&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Align the paragraph to the left.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Alinea a l&apos;esquerra&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Alinea el paràgraf a l&apos;esquerra.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="779"/>
        <source>Align &amp;Right</source>
        <translation>Alinea a la &amp;dreta</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="782"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Align Right&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Align the paragraph to the right.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Alinea a la dreta&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Alinea el paràgraf a la dreta.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="796"/>
        <source>&amp;Center</source>
        <translation>&amp;Centra</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="799"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Center&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Center the paragraph.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Centra&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Centra el paràgraf.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="804"/>
        <source>Ctrl+E</source>
        <translation>Ctrl+E</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="816"/>
        <source>&amp;Justify</source>
        <translation>&amp;Justifica</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="819"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Justify&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Align the paragraph to both the left and right margins.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Justifica&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Alinea el paragraf a la dreta i a lèsquerra.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="824"/>
        <source>Ctrl+J</source>
        <translation>Ctrl+J</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="836"/>
        <source>&amp;Bold</source>
        <translation>&amp;Negreta</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="839"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Bold&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Make the selected text bold.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Negreta&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Posa en negreta el text seleccionat.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="844"/>
        <source>Ctrl+B</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="856"/>
        <source>&amp;Italic</source>
        <translation>&amp;Cursiva</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="859"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Italic&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Make the selected text italic.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Cursiva&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Posa en cursiva el text seleccionat.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="864"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+I</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="873"/>
        <source>&amp;Open...</source>
        <translation>&amp;Obre...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="876"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Open&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Open a book from disk.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Obre&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Obre un llibre.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="881"/>
        <source>Ctrl+O</source>
        <translation>Ctrl+O</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="893"/>
        <source>&amp;Underline</source>
        <translation>&amp;Subratlla</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="896"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Underline&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Underline the selected text.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Subratlla&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Subratlla el text seleccionat.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="901"/>
        <source>Ctrl+U</source>
        <translation>Ctrl+U</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="910"/>
        <source>&amp;Quit</source>
        <translation>&amp;Surt</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="913"/>
        <source>Exit</source>
        <translation>Surt</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="916"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="925"/>
        <source>&amp;About...</source>
        <translation>&amp;Quant al Sigil...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="928"/>
        <source>Show information about Sigil.</source>
        <translation>Mostra informació quant al Sigil.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="933"/>
        <source>Add &amp;Cover...</source>
        <translation>Afegeix una &amp;coberta...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="936"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Add Cover&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Add a cover.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Afegeix una coberta&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Afegeix una coberta.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="947"/>
        <source>&amp;Metadata Editor...</source>
        <translation>Editor de &amp;metadades...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="950"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Metadata Editor&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Edit and display information about your book including the author and title.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Editor de metadades&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Mostra i permet editar la informació del llibre, incloent-ne l&apos;autor i el títol.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="955"/>
        <source>F8</source>
        <translation>F8</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="964"/>
        <source>&amp;Generate Table Of Contents...</source>
        <translation>&amp;Genera la taula de continguts...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="967"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Generate Table of Contents&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Generate a new Table of Contents from headings in your book.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Genera la taula de continguts&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Genera una taula de continguts nova a partir dels encapçalaments del llibre.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="972"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="977"/>
        <source>&amp;Edit Table Of Contents...</source>
        <translation>&amp;Edita la taula de continguts...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="980"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Edit Table of Contents&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Directly edit the existing Table of Contents.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Edita la taula de continguts&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Edita directament la taula de continguts actual.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="994"/>
        <source>&amp;Book View</source>
        <translation>Vista de &amp;llibre</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="997"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Book View&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Edit and display the files in your book as they will appear to readers.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Vista de llibre&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Edita i mostra els fitxers del llibre tal i com es veuran als aparells lectors.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1011"/>
        <source>&amp;Code View</source>
        <translation>Vista de &amp;codi</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1014"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Code View&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Edit and display the actual contents of the files in your book, including the formatting codes that control how your book will appear to readers.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Vista de codi&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Edita i mostra el contingut real dels fitxers del llibre, incloent els codis de format que controlen com es veurà el llibre en els aparells lectors.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1021"/>
        <source>&amp;Toggle View State</source>
        <translation>Commu&amp;ta el tipus de vista</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1024"/>
        <source>Toggle Book View to Code View or Code View to Book View</source>
        <translation>Commuta entre la vista de llibre i la vista de codi</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1027"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1036"/>
        <source>&amp;Split At Cursor</source>
        <translation>&amp;Divideix al cursor</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1039"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Split At Cursor&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Split the current file into two files using your cursor location as the dividing point.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Divideix al cursor&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Divideix el fitxer actual en dos fitxers. La posició del cursor és el punt de divisió.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1044"/>
        <source>Ctrl+Return</source>
        <translation>Ctrl+Retorn</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1053"/>
        <source>&amp;File...</source>
        <translation>&amp;Fitxer...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1056"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Insert File&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Select image, video or audio files from your book to insert into the text.&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;You can add files to your book by using the menu File - Add - Existing Files.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Insereix un fitxer&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Selecciona fitxers d&apos;imatge, vídeo o àudio del llibre per inserir-los al text.&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Podeu afegir fitxers al llibre amb l&apos;ordre «Afegeix» i «fitxers» del menú «Fitxer».&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1063"/>
        <source>Ctrl+Shift+I</source>
        <translation>Ctrl+Maj+I</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1072"/>
        <source>&amp;Special Character...</source>
        <translation>Caràcter &amp;especial...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1075"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Insert Special Character&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Select a character to insert into your text.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Insereix un caràcter especial&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Selecciona un caràcter per inserir-lo al text.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1086"/>
        <source>I&amp;D...</source>
        <translation>I&amp;dentificador...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1089"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Insert ID&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Insert or edit an anchor with an ID name to use as a link target.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Insereix un identificador&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Insereix o edita una àncora amb un nom identificador per a utilitzar-la com a objectiu d&apos;un enllaç.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1100"/>
        <source>&amp;Link...</source>
        <translation>&amp;Enllaç...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1103"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Insert Link&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Insert or edit an anchor with a hyperlink to a target.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Insereix enllaç&lt;/b&gt;&lt;/p&gt;⏎ ⏎ &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Insereix o edita un text com a hipervincle.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1117"/>
        <source>&amp;Numbered List</source>
        <translation>&amp;Llista numerada</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1120"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Numbering&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Create a numbered list.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Llista numerada&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Crea una llista numerada.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1134"/>
        <source>Bulle&amp;ted List</source>
        <translation>Llis&amp;ta de pics</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1137"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Bullets&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Create a bulleted list.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Llista de pics&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Crea una llista de pics.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1142"/>
        <source>Ctrl+Shift+L</source>
        <translation>Ctrl+Maj+L</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1154"/>
        <source>Stri&amp;kethrough</source>
        <translation>Barra&amp;t</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1157"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Strikethrough&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Draw a line through the selected text.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Text barrat&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Barra el text seleccionat.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1171"/>
        <source>&amp;Subscript</source>
        <translation>&amp;Subíndex</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1174"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Subscript&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set the selected text slightly smaller and below the normal line.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Subíndex&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Estableix el text seleccionat com a subíndex.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1188"/>
        <source>Su&amp;perscript</source>
        <translation>Su&amp;períndex</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1191"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Superscript&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set the selected text slightly smaller and above the normal line.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Superíndex&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Estableix el text seleccionat com a superíndex.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1202"/>
        <source>&amp;Print...</source>
        <translation>Im&amp;primeix...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1205"/>
        <source>Print</source>
        <translation>Imprimeix</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1208"/>
        <source>Ctrl+P</source>
        <translation>Ctrl+P</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1217"/>
        <source>Print Pre&amp;view...</source>
        <translation>Pre&amp;visualització de la impressió...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1220"/>
        <source>Print Preview</source>
        <translation>Previsualització de la impressió</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1225"/>
        <location filename="../../Form_Files/main.ui" line="1228"/>
        <source>Close</source>
        <translation>Tanca</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1231"/>
        <source>Ctrl+Shift+W</source>
        <translation>Ctrl+Maj+W</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1240"/>
        <source>Zoom &amp;In</source>
        <translation>&amp;Amplia</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1243"/>
        <source>Zoom In</source>
        <translation>Apropa</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1246"/>
        <source>Ctrl+=</source>
        <translation>Ctrl+=</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1255"/>
        <source>Zoom &amp;Out</source>
        <translation>&amp;Redueix</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1258"/>
        <source>Zoom Out</source>
        <translation>Redueix</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1261"/>
        <source>Ctrl+-</source>
        <translation>Ctrl+-</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1266"/>
        <source>Sho&amp;w Tag</source>
        <translation>&amp;Mostra l&apos;etiqueta</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1269"/>
        <source>Show the enclosing tag HTML for the cursor position in Book View.</source>
        <translation>Mostra l&apos;etiqueta HTML on es troba inclòs el cursor, a la vista de llibre.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1272"/>
        <source>Ctrl+Alt+T</source>
        <translation>Ctrl+Alt+T</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1281"/>
        <source>&amp;Find &amp;&amp; Replace...</source>
        <translation>&amp;Cerca i reemplaça...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1284"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Find &amp;amp; Replace&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Find and replace text in the document.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Cerca i reemplaça&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Cerca i reemplaça text dins del document.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1289"/>
        <source>Ctrl+F</source>
        <translation>Ctrl+F</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1298"/>
        <source>Incre&amp;ase Indent</source>
        <translation>Au&amp;gmenta el sagnat</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1301"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Increase Indent&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Increase the indent level of the paragraph.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Augmenta el sagnat&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Augmenta el nivell de sagnat del paràgraf.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1306"/>
        <source>Ctrl+Alt+M</source>
        <translation>Ctrl+Alt+M</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1315"/>
        <source>&amp;Decrease Indent</source>
        <translation>Re&amp;dueix el sagnat</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1318"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Decrease Indent&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Decrease the indent level of the paragraph.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Redueix el sagnat&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Redueix el nivell de sagnat del paràgraf.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1323"/>
        <location filename="../../Form_Files/main.ui" line="1734"/>
        <source>Ctrl+Shift+M</source>
        <translation>Ctrl+Maj+M</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1332"/>
        <source>Te&amp;xt Direction LTR</source>
        <translation>Te&amp;xt d&apos;esquerra a dreta</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1335"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Left-to-Right&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set paragraph direction left to right.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;D&apos;esquerra a dreta&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Estableix el sentit del paràgraf d&apos;esquerra a dreta.&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1348"/>
        <source>T&amp;ext Direction RTL</source>
        <translation>T&amp;ext de dreta a esquerra</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1351"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Right-to-Left&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set paragraph direction right to left.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;De dreta a esquerra&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Estableix el sentit del paràgraf de dreta a esquerra.&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1364"/>
        <source>Text Directi&amp;on Default</source>
        <translation>Sentit del text &amp;predeterminat</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1367"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Default&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set paragraph direction to inherit from default.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Predeterminat&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Estableix el sentit de paràgraf a partir del valor predeterminat.&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1376"/>
        <source>Remove &amp;Formatting</source>
        <translation>Elimina el &amp;formatat</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1379"/>
        <source>Ctrl+Space</source>
        <translation>Ctrl+Espai</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1388"/>
        <source>&amp;Lowercase</source>
        <translation>Caixa &amp;baixa</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1391"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Lowercase&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set selected text to lowercase.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;caixa baixa&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Posa tot el text seleccionat en minúscules.&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1398"/>
        <source>Alt+L</source>
        <translation>Alt+L</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1407"/>
        <source>&amp;Uppercase</source>
        <translation>Caixa &amp;alta</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1410"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Uppercase&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Set selected text to uppercase.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;CAIXA ALTA&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Posa tot el text seleccionat en majúscules.&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1417"/>
        <source>Alt+U</source>
        <translation>Alt+U</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1426"/>
        <source>&amp;Titlecase</source>
        <translation>Majúscules &amp;posicionals</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1429"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Titlecase&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Capitalize the first letter of each word selected.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Majúscules Posicionals&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Posa en majúscula la primera lletra de cada paraula.&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1442"/>
        <source>&amp;Capitalize</source>
        <translation>Majúscula &amp;inicial</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1445"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Capitalize&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Capitalize only the first word of the selected text.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Majúscula inicial&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Posa en majúscula només la primera lletra del text seleccionat.&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1454"/>
        <source>Sigil Website...</source>
        <translation>Lloc web del Sigil...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1459"/>
        <source>&amp;Next Tab</source>
        <translation>Pestanya &amp;següent</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1462"/>
        <source>Ctrl+PgUp</source>
        <translation>Ctrl+Re Pàg</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1467"/>
        <source>&amp;Previous Tab</source>
        <translation>Pestanya &amp;anterior</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1470"/>
        <source>Ctrl+PgDown</source>
        <translation>Ctrl+Av Pàg</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1475"/>
        <source>&amp;Close Tab</source>
        <translation>&amp;Tanca la pestanya</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1478"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1483"/>
        <source>Split At &amp;Markers</source>
        <translation>Divideix als &amp;marcadors</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1486"/>
        <source>Split At Sigil split file markers</source>
        <translation>Divideix als marcadors de divisió de fitxers del Sigil</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1489"/>
        <source>F6</source>
        <translation>F6</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1494"/>
        <source>Split &amp;Marker</source>
        <translation>&amp;Marcador de divisió</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1497"/>
        <source>Insert Sigil split file marker</source>
        <translation>Insereix un marcador de divisió de fitxer del Sigil</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1500"/>
        <source>Ctrl+Shift+Return</source>
        <translation>Ctrl+Maj+Retorn</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1505"/>
        <source>User &amp;Guide...</source>
        <translation>&amp;Manual d&apos;usuari...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1508"/>
        <source>User Guide</source>
        <translation>Manual d&apos;usuari</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1511"/>
        <source>F1</source>
        <translation>F1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1516"/>
        <source>&amp;Frequently Asked Questions...</source>
        <translation>&amp;Preguntes més freqüents...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1519"/>
        <source>Frequently Asked Questions</source>
        <translation>Preguntes més freqüents</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1524"/>
        <source>&amp;Tutorials...</source>
        <translation>&amp;Programes d&apos;aprenentatge...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1527"/>
        <source>Tutorials</source>
        <translation>Programes d&apos;aprenentatge</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1532"/>
        <source>Well-Formed Check &amp;EPUB</source>
        <translation>Comprovació d&apos;&amp;EPUB ben format</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1535"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Well-Formed Check EPUB&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Verify your document complies with minimum needed to be successfully parsed. This does not indicate compliance with the relevant epub standards.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;La Comprovació d&apos;EPUB ben format&lt;/span&gt;&lt;/p&gt;&lt;p&gt; verifica que el document compleixi amb els requisits mínims per ser analitzat amb èxit; això no garanteix el compliment dels estàndards EPUB més rellevants.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1538"/>
        <source>F7</source>
        <translation>F7</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1543"/>
        <source>Validate Stylesheets With &amp;W3C</source>
        <translation>Valida els fulls d&apos;estil amb el &amp;W3C</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1546"/>
        <source>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Validate Stylesheets with W3C&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Verify your CSS stylesheets comply with W3C standards using the online W3C CSS Validation Service.&lt;/p&gt;
    </source>
        <translation>
     &lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Valida els fulls d&apos;estils amb el W3C&lt;/b&gt;&lt;/p&gt;

     &lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Verifica si els fulls d&apos;estil compleixen els estàndards del W3C usant el servei de validació de CSS en línia del W3C.&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1559"/>
        <source>&amp;Spellcheck...</source>
        <translation>Corrector &amp;ortogràfic...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1562"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Spellcheck&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Find all misspelled words and allow you to add them to a dictionary or ignore them.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Corrector ortogràfic&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Cerca les paraules que no són al diccionari ortogràfic i permet d&apos;afegir-les-hi o ignorar-les.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1567"/>
        <source>Alt+Q</source>
        <translation>Alt+Q</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1575"/>
        <source>&amp;Highlight Misspelled Words</source>
        <translation>&amp;Ressalta les paraules incorrectes</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1578"/>
        <source>Enable or disable highlighting of misspelled words in Code View.</source>
        <translation>Activa/desactiva el realçat d&apos;errors ortogràfics a la vista de codi.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1583"/>
        <source>&amp;Next Misspelled Word</source>
        <translation>Paraula incorrecta &amp;següent</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1586"/>
        <source>Find the next misspelled word in the book.</source>
        <translation>Cerca la paraula incorrecta següent del llibre.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1589"/>
        <source>F4</source>
        <translation>F4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1594"/>
        <source>&amp;Add Misspelled Word</source>
        <translation>&amp;Afegeix al diccionari</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1597"/>
        <source>Add the current misspelled word under the caret to the default user dictionary.</source>
        <translation>Afegeix la paraula incorrecta en curs al diccionari predeterminat de l&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1602"/>
        <source>&amp;Ignore Misspelled Word</source>
        <translation>&amp;Ignora la paraula incorrecta</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1605"/>
        <source>Ignore the current misspelled word under the caret until Sigil is restarted.</source>
        <translation>Ignora la paraula incorrecta actual del punt d&apos;inserció fins que el Sigil es reinicïi.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1610"/>
        <source>&amp;Clear Ignored Words</source>
        <translation>&amp;Elimina les paraules ignorades</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1613"/>
        <source>Clear currently ignored words from Spellcheck without having to restart Sigil.</source>
        <translation>Neteja les paraules ignorades actualment per la correcció ortogràfica sense haver de reiniciar el Sigil.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1618"/>
        <source>&amp;Index Editor...</source>
        <translation>Editor d&amp;índexs...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1621"/>
        <source>Ctrl+Alt+I</source>
        <translation>Ctrl+Alt+I</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1626"/>
        <source>&amp;Delete Unused Media Files...</source>
        <translation>&amp;Esborra els fitxers multimèdia no usats...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1631"/>
        <source>Delete &amp;Unused Stylesheet Classes...</source>
        <translation>&amp;Esborra les classes no usades dels fulls d&apos;estils...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1636"/>
        <source>&amp;Reports...</source>
        <translation>In&amp;formes...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1639"/>
        <source>Ctrl+Shift+R</source>
        <translation>Ctrl+Maj+R</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1648"/>
        <source>&amp;Donate...</source>
        <translation>Feu una &amp;donació...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1651"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Donate&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Donate to support Sigil.&lt;/p&gt;
</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Feu una donació&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Col·laboreu amb diners amb el desenvolupament del Sigil.&lt;/p&gt;
</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1659"/>
        <source>Close &amp;Other Tabs</source>
        <translation>&amp;Tanca les altres pestanyes</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1662"/>
        <source>Ctrl+Alt+W</source>
        <translation>Ctrl+Alt+W</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1667"/>
        <source>Go To &amp;Line...</source>
        <translation>Vés a la &amp;línia...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1670"/>
        <source>Ctrl+/</source>
        <translation>Ctrl+/</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1675"/>
        <source>Find &amp;Next</source>
        <translation>Cerca el &amp;següent</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1678"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1683"/>
        <source>Find &amp;Previous</source>
        <translation>Cerca l&apos;&amp;anterior</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1686"/>
        <source>Ctrl+Shift+G</source>
        <translation>Ctrl+Shift+G</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1691"/>
        <source>Replace</source>
        <translation>Reemplaça</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1694"/>
        <source>Ctrl+R</source>
        <translation>Ctrl+R</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1699"/>
        <source>&amp;Replace/Find Next</source>
        <translation>&amp;Reemplaça i cerca el següent</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1702"/>
        <source>Ctrl+]</source>
        <translation>Ctrl+]</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1707"/>
        <source>R&amp;eplace/Find Previous</source>
        <translation>R&amp;eemplaça i cerca l&apos;anterior</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1710"/>
        <source>Ctrl+[</source>
        <translation>Ctrl+[</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1715"/>
        <source>Replace &amp;All</source>
        <translation>Reemplaça-ho &amp;tot</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1718"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1723"/>
        <source>&amp;Count All</source>
        <translation>&amp;Compta-ho tot</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1726"/>
        <source>Alt+C</source>
        <translation>Alt+C</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1731"/>
        <source>Mar&amp;k Selected Text</source>
        <translation>Mar&amp;ca el text seleccionat</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1739"/>
        <source>Find &amp;Next In File</source>
        <translation>Cerca el &amp;següent del fitxer</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1744"/>
        <source>&amp;Replace Next In File</source>
        <translation>&amp;Reemplaça el següent del fitxer</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1749"/>
        <source>Replace &amp;All In File</source>
        <translation>Reemplaça-ho &amp;tot al fitxer</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1754"/>
        <source>&amp;Count All In File</source>
        <translation>&amp;Compta-ho tot al fitxer</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1759"/>
        <source>&amp;Saved Searches...</source>
        <translation>&amp;Cerques desades...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1762"/>
        <source>Ctrl+Alt+F</source>
        <translation>Ctrl+Alt+F</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1767"/>
        <source>&amp;Clip Editor...</source>
        <translation>Editor de &amp;retalls...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1770"/>
        <source>Open the Clip Editor.</source>
        <translation>Obre l&apos;editor de retalls.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1773"/>
        <source>Ctrl+Alt+C</source>
        <translation>Ctrl+Alt+C</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1778"/>
        <source>Clip &amp;1</source>
        <translation>Retall &amp;1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1781"/>
        <source>Insert Clip 1</source>
        <translation>Insereix el retall 1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1784"/>
        <source>Ctrl+Alt+1</source>
        <translation>Ctrl+Alt+1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1789"/>
        <source>Clip &amp;2</source>
        <translation>Retall &amp;2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1792"/>
        <source>Insert Clip 2</source>
        <translation>Insereix el retall 2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1795"/>
        <source>Ctrl+Alt+2</source>
        <translation>Ctrl+Alt+2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1800"/>
        <source>Clip &amp;3</source>
        <translation>Retall &amp;3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1803"/>
        <source>Insert Clip 3</source>
        <translation>Insereix el retall 3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1806"/>
        <source>Ctrl+Alt+3</source>
        <translation>Ctrl+Alt+3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1811"/>
        <source>Clip &amp;4</source>
        <translation>Retall &amp;4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1814"/>
        <source>Insert Clip 4</source>
        <translation>Insereix el retall 4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1817"/>
        <source>Ctrl+Alt+4</source>
        <translation>Ctrl+Alt+4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1822"/>
        <source>Clip &amp;5</source>
        <translation>Retall &amp;5</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1825"/>
        <source>Insert Clip 5</source>
        <translation>Insereix el retall 5</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1828"/>
        <source>Ctrl+Alt+5</source>
        <translation>Ctrl+Alt+5</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1833"/>
        <source>Clip &amp;6</source>
        <translation>Retall &amp;6</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1836"/>
        <source>Insert Clip 6</source>
        <translation>Insereix el retall 6</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1839"/>
        <source>Ctrl+Alt+6</source>
        <translation>Ctrl+Alt+6</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1844"/>
        <source>Clip &amp;7</source>
        <translation>Retall &amp;7</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1847"/>
        <source>Insert Clip 7</source>
        <translation>Insereix el retall 7</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1850"/>
        <source>Ctrl+Alt+7</source>
        <translation>Ctrl+Alt+7</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1855"/>
        <source>Clip &amp;8</source>
        <translation>Retall &amp;8</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1858"/>
        <source>Insert Clip 8</source>
        <translation>Insereix el retall 8</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1861"/>
        <source>Ctrl+Alt+8</source>
        <translation>Ctrl+Alt+8</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1866"/>
        <source>Clip &amp;9</source>
        <translation>Retall &amp;9</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1869"/>
        <source>Insert Clip 9</source>
        <translation>Insereix el retall 9</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1872"/>
        <source>Ctrl+Alt+9</source>
        <translation>Ctrl+Alt+9</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1877"/>
        <source>Clip 1&amp;0</source>
        <translation>Retall 1&amp;0</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1880"/>
        <source>Insert Clip 10</source>
        <translation>Insereix el retall 10</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1883"/>
        <source>Ctrl+Alt+0</source>
        <translation>Ctrl+Alt+0</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1888"/>
        <source>Clip 11</source>
        <translation>Retall 11</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1891"/>
        <source>Insert Clip 11</source>
        <translation>Insereix el retall 11</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1896"/>
        <source>Clip 12</source>
        <translation>Retall 12</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1899"/>
        <source>Insert Clip 12</source>
        <translation>Insereix el retall 12</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1904"/>
        <source>Clip 13</source>
        <translation>Retall 13</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1907"/>
        <source>Insert Clip 13</source>
        <translation>Insereix el retall 13</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1912"/>
        <source>Clip 14</source>
        <translation>Retall 14</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1915"/>
        <source>Insert Clip 14</source>
        <translation>Insereix el retall 14</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1920"/>
        <source>Clip 15</source>
        <translation>Retall 15</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1923"/>
        <source>Insert Clip 15</source>
        <translation>Insereix el retall 15</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1928"/>
        <source>Clip 16</source>
        <translation>Retall 16</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1931"/>
        <source>Insert Clip 16</source>
        <translation>Insereix el retall 16</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1936"/>
        <source>Clip 17</source>
        <translation>Retall 17</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1939"/>
        <source>Insert Clip 17</source>
        <translation>Insereix el retall 17</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1944"/>
        <source>Clip 18</source>
        <translation>Retall 18</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1947"/>
        <source>Insert Clip 18</source>
        <translation>Insereix el retall 18</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1952"/>
        <source>Clip 19</source>
        <translation>Retall 19</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1955"/>
        <source>Insert Clip 19</source>
        <translation>Insereix el retall 19</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1960"/>
        <source>Clip 20</source>
        <translation>Retall 20</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1963"/>
        <source>Insert Clip 20</source>
        <translation>Insereix el retall 20</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1968"/>
        <source>&amp;Preferences...</source>
        <translation>&amp;Preferències...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1971"/>
        <source>F5</source>
        <translation>F5</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1976"/>
        <source>&amp;Zoom Reset</source>
        <translation>Reinicia el &amp;zoom</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1979"/>
        <source>Zoom Reset</source>
        <translation>Reinicia el zoom</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1982"/>
        <source>Ctrl+0</source>
        <translation>Ctrl+0</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1994"/>
        <source>Heading &amp;1</source>
        <translation>Encapçalament &amp;1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="1997"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Heading 1&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a level 1 heading.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Encapçalament 1&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Formata el paràgraf com a encapçalament de nivell 1.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2002"/>
        <source>Ctrl+1</source>
        <translation>Ctrl+1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2014"/>
        <source>Heading &amp;2</source>
        <translation>Encapçalament &amp;2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2017"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Heading 2&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a level 2 heading.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Encapçalament 2&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Formata el paràgraf com a encapçalament de nivell 2.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2022"/>
        <source>Ctrl+2</source>
        <translation>Ctrl+2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2034"/>
        <source>Heading &amp;3</source>
        <translation>Encapçalament &amp;3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2037"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Heading 3&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a level 3 heading.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Encapçalament 3&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Formata el paràgraf com a encapçalament de nivell 3.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2042"/>
        <source>Ctrl+3</source>
        <translation>Ctrl+3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2054"/>
        <source>Heading &amp;4</source>
        <translation>Encapçalament &amp;4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2057"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Heading 4&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a level 4 heading.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Encapçalament 4&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Formata el paràgraf com a encapçalament de nivell 4.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2062"/>
        <source>Ctrl+4</source>
        <translation>Ctrl+4</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2074"/>
        <source>Heading &amp;5</source>
        <translation>Encapçalament &amp;5</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2077"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Heading 5&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a level 5 heading.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Encapçalament 5&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Formata el paràgraf com a encapçalament de nivell 5.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2082"/>
        <source>Ctrl+5</source>
        <translation>Ctrl+5</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2094"/>
        <source>Heading &amp;6</source>
        <translation>Encapçalament &amp;6</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2097"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Heading 6&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a level 6 heading.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Encapçalament 6&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Formata el paràgraf com a encapçalament de nivell 6.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2102"/>
        <source>Ctrl+6</source>
        <translation>Ctrl+6</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2114"/>
        <source>&amp;Normal</source>
        <translation>&amp;Normal</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2117"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Paragraph&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Format paragraph as a normal paragraph.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Paràgraf&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Formata el paràgraf com a paràgraf normal.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2122"/>
        <source>Ctrl+7</source>
        <translation>Ctrl+7</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2130"/>
        <source>&amp;Preserve Existing Attributes</source>
        <translation>&amp;Conserva els atributs que tingui</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2133"/>
        <source>When applying this style, preserve any existing attributes on the tag</source>
        <translation>Conserva els atributs de l&apos;etiqueta en aplicar aquest estil</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2138"/>
        <source>Blank HTML File</source>
        <translation>Fitxer HTML en blanc</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2141"/>
        <source>Add a new blank HTML file to the book.</source>
        <translation>Afegeix un fitxer HTML en blanc al llibre.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2150"/>
        <source>Existing Files...</source>
        <translation>Fitxers...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2153"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Add Existing Files&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Add files from your computer to the book.&lt;/p&gt;</source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Afegeix fitxers&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Afegeix altres fitxers de l&apos;ordinador al llibre.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2160"/>
        <source>Blank Stylesheet</source>
        <translation>Full d&apos;estil en blanc</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2163"/>
        <source>Add a new blank stylesheet to the book.</source>
        <translation>Afegeix un full d&apos;estil en blanc nou al llibre.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2168"/>
        <source>Blank SVG Image</source>
        <translation>Imatge SVG en blanc</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2171"/>
        <source>Add a new blank svg image file to the book.</source>
        <translation>Afegir un fitxer nou d&apos;imatge SVG en blanc al llibre.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2176"/>
        <source>Pre&amp;vious File</source>
        <translation>Fitxer &amp;anterior</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2179"/>
        <source>Open previous file of the same type.</source>
        <translation>Obre el fitxer anterior del mateix tipus.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2182"/>
        <source>Alt+PgUp</source>
        <translation>Alt+Re Pàg</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2187"/>
        <source>Next &amp;File</source>
        <translation>&amp;Fitxer següent</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2190"/>
        <source>Open next file of the same type.</source>
        <translation>Obre el fitxer següent del mateix tipus.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2193"/>
        <source>Alt+PgDown</source>
        <translation>Alt+Av Pàg</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2198"/>
        <source>&amp;Add To Index Editor</source>
        <translation>&amp;Afegeix a l&apos;editor de l&apos;índex</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2201"/>
        <source>Add the selected text to the Index Editor.</source>
        <translation>Afegeix el text seleccionat a l&apos;editor de l&apos;índex.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2206"/>
        <source>&amp;Mark For Index</source>
        <translation>&amp;Marca per a incloure a l&apos;índex</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2209"/>
        <source>Mark the selected text for inclusion in the Index.</source>
        <translation>Marca el text seleccionat per incloure&apos;l a l&apos;índex.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2212"/>
        <source>Ctrl+Shift+X</source>
        <translation>Ctrl+Maj+X</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2217"/>
        <source>&amp;Create Index</source>
        <translation>&amp;Crea l&apos;índex</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2220"/>
        <source>Generate a new Index HTML file.</source>
        <translation>Genera un fitxer HTML d&apos;índex nou.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2225"/>
        <source>&amp;Create HTML Table Of Contents</source>
        <translation>&amp;Crea la taula de continguts HTML</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2228"/>
        <source>Create a new HTML file using the current TOC.</source>
        <translation>Crea un fitxer HTML nou a partir de la taula de continguts actual.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2233"/>
        <source>Book&amp;mark Location</source>
        <translation>&amp;Ubicació de les adreces d&apos;interès</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2236"/>
        <source>Ctrl+Alt+B</source>
        <translation>Ctrl+Alt+B</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2241"/>
        <source>&amp;Go To Link Or Style</source>
        <translation>&amp;Vés a l&apos;enllaç o a l&apos;estil</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2244"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2253"/>
        <source>&amp;Back</source>
        <translation>&amp;Enrere</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2256"/>
        <source>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Back&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Go back to where you last went to a link or style, or bookmarked your location.&lt;/p&gt;
    </source>
        <translation>&lt;p style=&quot;padding-top: 0.5em;&quot; &gt;&lt;b&gt;Enrere&lt;/b&gt;&lt;/p&gt;

&lt;p style=&quot;margin-left: 0.5em;&quot;&gt;Vés enrere fins al lloc de destí del darrer enllaç, estil o ubicació dels preferits.&lt;/p&gt;
    </translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2262"/>
        <source>Ctrl+\</source>
        <translation>Ctrl+\</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2267"/>
        <source>Edit/Paste From Clipboard &amp;History...</source>
        <translation>Edita/Enganxa des de l&apos;&amp;historial del porta-retalls</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2270"/>
        <source>Ctrl+Alt+V</source>
        <translation>Ctrl+Alt+V</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2275"/>
        <source>&amp;Delete Line</source>
        <translation>&amp;Esborra la línia</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2278"/>
        <source>Ctrl+D</source>
        <translation>Ctrl+D</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2283"/>
        <source>Manage Plugins</source>
        <translation>Gestiona els connectors</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2292"/>
        <source>Run Plugin 1</source>
        <translation>Executa el connector 1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2301"/>
        <source>Run Plugin 2</source>
        <translation>Executa el connector 2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2310"/>
        <source>Run Plugin 3</source>
        <translation>Executa el connector 3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2319"/>
        <source>Run Plugin 4</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2328"/>
        <source>Run Plugin 5</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2333"/>
        <source>Mend and &amp;Prettify All HTML Files</source>
        <translation>Repara i &amp;poleix tots els fitxers HTML</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2338"/>
        <source>&amp;Mend All HTML Files</source>
        <translation>Repara tots els fitxers HT&amp;ML</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2343"/>
        <source>&amp;Update Manifest Properties</source>
        <translation>Act&amp;ualitza les propietats del manifest</translation>
    </message>
    <message>
        <location filename="../../Form_Files/main.ui" line="2348"/>
        <source>Generate NC&amp;X from Nav</source>
        <translation>Genera l&apos;NC&amp;X a partir del NAV</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="325"/>
        <source>Input</source>
        <translation>Entrada</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="331"/>
        <source>Output</source>
        <translation>Sortida</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="343"/>
        <source>Validation</source>
        <translation>Validació</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="489"/>
        <source>Navigation cancelled as location no longer exists.</source>
        <translation>S&apos;ha cancel·lat la navegació ja que el lloc ja no existeix.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="505"/>
        <source>Location bookmarked.</source>
        <translation>S&apos;ha desat l&apos;adreça d&apos;interès.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="552"/>
        <location filename="../../MainUI/MainWindow.cpp" line="784"/>
        <location filename="../../MainUI/MainWindow.cpp" line="992"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1138"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1520"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1607"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1662"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1670"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1687"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1699"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1802"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1810"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1824"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1829"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1842"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1850"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1861"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1866"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1878"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1888"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1893"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2124"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2131"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2145"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2150"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2174"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2206"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3509"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3515"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3521"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3563"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3569"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3575"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3732"/>
        <location filename="../../MainUI/MainWindow.cpp" line="3939"/>
        <location filename="../../MainUI/MainWindow.cpp" line="4139"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="552"/>
        <source>Are you sure you want to open this external link?

%1</source>
        <translation>Esteu segur que voleu obrir aquest enllaç extern?

%1</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="598"/>
        <source>was updated</source>
        <translation>s&apos;ha actualitzat</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="605"/>
        <source>Warning</source>
        <translation>Avís</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="605"/>
        <source>The file was NOT well formed and may be corrupted.</source>
        <translation>El fitxer no és ben format i pot ser corrupte.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="633"/>
        <source>Opening this EPUB generated warnings.</source>
        <translation>Alertes generades en l&apos;obertura de l&apos;EPUB.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="635"/>
        <source>Select Show Details for more information.</source>
        <translation>Seleccioneu «Mostra&apos;n els detalls» per obtenir-ne més informació.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="675"/>
        <source>Sigil is closing...</source>
        <translation>El Sigil s&apos;està tancant...</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="725"/>
        <source>New file created.</source>
        <translation>S&apos;ha creat un fitxer nou.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="746"/>
        <source>Open File</source>
        <translation>Obre el fitxer</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="783"/>
        <source>This file no longer exists. Click OK to remove it from the menu.
%1</source>
        <translation>El fitxer ja no existeix. Feu clic a «D&apos;acord» per esborrar-lo del menú.
%1</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="853"/>
        <source>Save File</source>
        <translation>Desa el fitxer</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="907"/>
        <source>Save a Copy</source>
        <translation>Desa una còpia</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="969"/>
        <source>Go To Line</source>
        <translation>Vés a la línia</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="969"/>
        <source>Line #</source>
        <translation>Linia número</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="992"/>
        <source>Image does not exist: </source>
        <translation>La imatge no existeix:</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1054"/>
        <source>or</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1062"/>
        <source>No CSS styles named</source>
        <translation>No hi ha cap estil CSS anomenat</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1062"/>
        <source>found, or stylesheet not linked.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1134"/>
        <source>&lt;html&gt;&lt;p&gt;The href &lt;b&gt;%1&lt;/b&gt; found in &lt;b&gt;%2&lt;/b&gt; does not exist (and there may be more). Splitting or merging under these conditions can result in broken links.&lt;/p&gt;&lt;p&gt;Do you still wish to continue?&lt;/p&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;p&gt;L&apos;href &lt;b&gt;%1&lt;/b&gt; trobat en &lt;b&gt;%2&lt;/b&gt; no existeix (hi poden haver-hi més). La divisió o fusió sota aquestes condicions pot donar lloc a enllaços trencats.&lt;/p&gt;&lt;p&gt;Encara voleu continuar?&lt;/p&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1156"/>
        <source>Add Cover</source>
        <translation>Afegeix una coberta</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1248"/>
        <source>Unexpected error. Only image files can be used for the cover.</source>
        <translation>Hi ha hagut un error. Per a la coberta, només es poden fer servir fitxers d&apos;imatge.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1265"/>
        <source>Cover added.</source>
        <translation>S&apos;ha afegit la coberta.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1274"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1291"/>
        <source>Not Available for epub2.</source>
        <translation>No disponible per a l&apos;EPUB2.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1282"/>
        <source>OPF Manifest Properties Updated.</source>
        <translation>S&apos;han actualitzat les propietats del manifest OPF.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1308"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1362"/>
        <source>NCX generation failed.</source>
        <translation>La generació de l&apos;NCX ha fallat.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1357"/>
        <source>NCX generated.</source>
        <translation>S&apos;ha general l&apos;NCX.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1510"/>
        <source>Styles deleted.</source>
        <translation>S&apos;han esborrat els estils.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1520"/>
        <source>Reports cancelled due to XML not well formed.</source>
        <translation>S&apos;han cancel·lat els informes ja que l&apos;XML és mal format.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1607"/>
        <source>Delete Unused Media Files cancelled due to XML not well formed.</source>
        <translation>S&apos;ha cancel·lat la supressió de fitxers multimèdia sense utilitzar ja que l&apos;XML és mal format.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1660"/>
        <source>Unused media files deleted.</source>
        <translation>S&apos;han suprimit els fitxers multimèdia no utilitzats.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1662"/>
        <source>There are no unused image, video or audio files to delete.</source>
        <translation>No hi ha cap imatge, vídeo o fitxer d&apos;àudio sense utilitzar.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1670"/>
        <source>Delete Unused Styles cancelled due to XML not well formed.</source>
        <translation>Esborra els fulls d&apos;estil sense utilitzar cancel·lats per tenir l&apos;XML mal format.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1687"/>
        <source>There are no unused stylesheet classes to delete.</source>
        <translation>Als fulls d&apos;estil, no hi ha cap classe sense utilitzar per esborrar.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1699"/>
        <source>You cannot insert a file at this position.</source>
        <translation>No es pot inserir un fitxer en aquesta posició.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1706"/>
        <source>Insert File</source>
        <translation>Insereix un fitxer</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1751"/>
        <source>The file &quot;%1&quot; does not exist.</source>
        <translation>El fitxer «%1» no existeix.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1802"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1829"/>
        <source>You cannot insert an id at this position.</source>
        <translation>No es pot inserir un identificador en aquesta posició.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1810"/>
        <source>You must select text before inserting a new id.</source>
        <translation>Heu de seleccionar algun text abans d&apos;inserir un identificador nou.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1824"/>
        <source>ID is invalid - must start with a letter, followed by letter number _ : - or .</source>
        <translation>L&apos;identificador no és vàlid; ha de començar amb una lletra seguida de lletre, números _ : o .</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1842"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1866"/>
        <source>You cannot insert a link at this position.</source>
        <translation>No es pot inserir un enllaç en aquesta posició</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1850"/>
        <source>You must select text before inserting a new link.</source>
        <translation>Heu de seleccionar algun text abans d&apos;inserir un enllaç nou.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1861"/>
        <source>Link is invalid - cannot contain &apos;&lt;&apos; or &apos;&gt;&apos;</source>
        <translation>L&apos;enllaç no és correcte; no ha de tenir «&lt;» ni «&gt;»</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1878"/>
        <source>You cannot mark an index at this position or without selecting text.</source>
        <translation>No es pot marcar un índex en aquesta posició o sense seleccionar text.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1888"/>
        <source>Entry is invalid - cannot contain &apos;&lt;&apos; or &apos;&gt;&apos;</source>
        <translation>L&apos;entrada no és correcta; no ha de tenir «&lt;» ni «&gt;»</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1893"/>
        <source>You cannot mark an index at this position.</source>
        <translation>No es pot marcar un índex en aquesta posició.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1947"/>
        <location filename="../../MainUI/MainWindow.cpp" line="1958"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2077"/>
        <source>Select the destination to paste into first.</source>
        <translation>Seleccioneu una destinació per enganxar-hi a dins.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="1966"/>
        <source>Pasted clip entry %1.</source>
        <translation>S&apos;ha enganxat l&apos;entrada de retall %1.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2124"/>
        <source>One resource selected and there is no previous resource to merge into.</source>
        <translation>Hi ha un recurs seleccionat i cap recurs previ per combinar-lo dins seu.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2131"/>
        <source>Are you sure you want to merge the selected files?
This action cannot be reversed.</source>
        <translation>Esteu segur que voleu combinar els fitxers seleccionats?
Aquesta acció no es pot desfer.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2145"/>
        <source>Merge cancelled: %1, XML not well formed.</source>
        <translation>S&apos;ha cancel·lat la combinació %1 ja que l&apos;XML no és ben format.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2150"/>
        <source>Merge cancelled due to XML not well formed.</source>
        <translation>S&apos;ha cancel·lat la combinació ja que l&apos;XML no és ben format.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2174"/>
        <source>Cannot merge file %1</source>
        <translation>No es pot combinar el fitxer %1</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2188"/>
        <source>Merge completed. You may need to regenerate or edit your Table Of Contents.</source>
        <translation>S&apos;ha completat la combinació. Si cal, editeu o tornau a generar la taula de continguts.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2206"/>
        <source>Link Stylesheets cancelled: %1, XML not well formed.</source>
        <translation>S&apos;ha cancel·lat l&apos;enllaç amb el full d&apos;estil %1 ja que l&apos;XML no és ben format.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2351"/>
        <source>Word updated.</source>
        <translation>S&apos;ha actualitzat la paraula.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2433"/>
        <source>File(s) deleted.</source>
        <translation>S&apos;han esborrat els fitxers.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2444"/>
        <source>Edit Table of Contents cancelled.</source>
        <translation>S&apos;ha cancel·lat l&apos;edició de la taula de continguts.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2449"/>
        <source>Table Of Contents edited.</source>
        <translation>S&apos;ha editat la taula de contonguts.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2467"/>
        <source>Generate TOC cancelled.</source>
        <translation>S&apos;ha cancel·lat la generació de la taula de continguts.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2491"/>
        <source>Table Of Contents generated.</source>
        <translation>S&apos;ha generat la taula de continguts.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2493"/>
        <source>No Table Of Contents changes were necessary.</source>
        <translation>No cal fer canvis a la taula de continguts.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2629"/>
        <source>Text selection marked.</source>
        <translation>S&apos;ha marcat el text seleccionat.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2631"/>
        <location filename="../../MainUI/MainWindow.cpp" line="2649"/>
        <source>Text selection unmarked.</source>
        <translation>S&apos;ha desmarcat el text seleccionat.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2737"/>
        <source>Metadata Editor cancelled.</source>
        <translation>S&apos;ha cancel·lat l&apos;editor de metadades.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2740"/>
        <source>Metadata edited.</source>
        <translation>S&apos;han editat les metadades.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2828"/>
        <source>RunPlugin1</source>
        <translation>RunPlugin1</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2829"/>
        <source>RunPlugin2</source>
        <translation>RunPlugin2</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2830"/>
        <source>RunPlugin3</source>
        <translation>RunPlugin3</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2831"/>
        <source>RunPlugin4</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2832"/>
        <source>RunPlugin5</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="2863"/>
        <source>This EPUB does not contain any CSS stylesheets to validate.</source>
        <translation>Aquest EPUB no conté cap full d&apos;estil CSS per validar.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3410"/>
        <source>Line: %1, Col: %2</source>
        <translation>Línia %1 - Columna %2</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3509"/>
        <source>File cannot be split at this position.</source>
        <translation>El fitxer no es pot dividir en aquesta posició.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3515"/>
        <source>Cannot split since it may not be an HTML file.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3521"/>
        <source>The Nav file cannot be split.</source>
        <translation>El fitxer NAV no es pot dividir.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3538"/>
        <source>Split completed.</source>
        <translation>S&apos;ha completat la divisió.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3563"/>
        <source>Cannot split since at least one file is not an HTML file.</source>
        <translation>No es po dividir ja que un dels fitxers, com a mínim, no és HTML.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3569"/>
        <source>Cannot split: %1 XML is not well formed</source>
        <translation>No es pot dividir %1 ja que l&apos;XML no és ben format</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3575"/>
        <source>Cannot split since at least one file may not be an HTML file.</source>
        <translation>No es pot dividir ja que un dels fitxers, com a mínim, potser no és HTML.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3608"/>
        <source>Split completed. You may need to update the Table of Contents.</source>
        <translation>S&apos;ha completat la divisió. Si cal, actualitzau la taula de continguts.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3617"/>
        <source>No split file markers found. Use Insert-&gt;Split Marker.</source>
        <translation>No s&apos;ha trobat cap marcador de divisió de fitxer.
Utilizeu l&apos;ordre «Marcador de divisió» del menú «Insereix».</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3733"/>
        <source>The document has been modified.
Do you want to save your changes?</source>
        <translation>El document s&apos;ha modificat.
Voleu desar-ne els canvis?</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3813"/>
        <source>No importer for file type: %1</source>
        <translation>No es poden importar els fitxers de tipus %1</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3820"/>
        <source>The following file was not loaded due to invalid content or not well formed XML:

%1 (line %2: %3)

Try setting the Clean Source preference to Mend XHTML Source Code on Open and reloading the file.</source>
        <translation>El fitxer següent no s&apos;ha carregat ja que el seu contingut no és correcte o l&apos;XML no és ben format:

%1 (línia %2: %3)

Proveu de canviar les preferències de netedat del codi triant l&apos;opció «Repara el codi font XHTML en obrir» i torneu a carregat el fitxer.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3825"/>
        <source>Loading file...</source>
        <translation>S&apos;està carregant el fitxer...</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3839"/>
        <source>File loaded.</source>
        <translation>S&apos;ha carregat el fitxer.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3866"/>
        <source>The creator of this file has encrypted it with DRM. Sigil cannot open such files.</source>
        <translation>El creador d&apos;aquest fitxer l&apos;ha encriptat amb DRM. El Sigil no pot obrir aquests fitxers.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3873"/>
        <source>Cannot load EPUB: %1</source>
        <translation>No es pot carregar l&apos;EPUB %1</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3877"/>
        <source>Cannot load file %1: %2</source>
        <translation>No es pot carregar el fitxer %1: %2</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3906"/>
        <source>Saving EPUB...</source>
        <translation>S&apos;està desant l&apos;EPUB...</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3915"/>
        <source>Sigil cannot save files of type &quot;%1&quot;.
Please choose a different format.</source>
        <translation>El Sigil no pot desar fitxers del tipus «%1».
Trieu un altre format.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3940"/>
        <source>This EPUB has HTML files that are not well formed and your current Clean Source preferences are set to automatically mend on Save. Saving a file that is not well formed will cause it to be automatically fixed, which very rarely may result in data loss.

Do you want to automatically mend the files before saving?</source>
        <translation>L&apos;EPUB conté fitxers HTML mal formats i a les preferències de netedat del codi està activada l&apos;opció de reparació automàtica en desar. Per tant, si el deseu, el fitxer es corregirà automàticament i, encara que no és gens freqüent, pot ser que en el procés es perdin dades.

Voleu reparar automàticament el fitxer abans de desar-lo?</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3971"/>
        <source>EPUB saved, but not all HTML files are well formed.</source>
        <translation>S&apos;ha desat l&apos;EPUB, però no tots els fitxers HTML són ben formats.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3973"/>
        <source>EPUB saved.</source>
        <translation>S&apos;ha desat l&apos;EPUB.</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="3979"/>
        <source>Cannot save file %1: %2</source>
        <translation>No es pot desar el fitxer %1: %2</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4114"/>
        <source>EPUB files (*.epub)</source>
        <translation>Fitxers EPUB (*.epub)</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4115"/>
        <location filename="../../MainUI/MainWindow.cpp" line="4116"/>
        <location filename="../../MainUI/MainWindow.cpp" line="4117"/>
        <source>HTML files (*.htm *.html *.xhtml)</source>
        <translation>Fitxers HTML  (*.htm *.html *.xhtml)</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4118"/>
        <source>Text files (*.txt)</source>
        <translation>Fitxers de text (*.txt)</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4119"/>
        <source>All files (*.*)</source>
        <translation>Tots els fitxers (*.*)</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4127"/>
        <source>EPUB file (*.epub)</source>
        <translation>Fitxer EPUB (*.epub)</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4139"/>
        <source>%1[*] - epub%2 - %3</source>
        <translation>%1[*] - EPUB%2 - %3</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4210"/>
        <source>Preserve existing heading attributes is now:</source>
        <translation>Conservació d&apos;atributs d&apos;encapçalament:</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4211"/>
        <source>ON</source>
        <translation>Actiu</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4211"/>
        <source>OFF</source>
        <translation>Inactiu</translation>
    </message>
    <message>
        <location filename="../../MainUI/MainWindow.cpp" line="4236"/>
        <source>&amp;%1 %2</source>
        <translation>&amp;%1 %2</translation>
    </message>
</context>
<context>
    <name>MarcRelators</name>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="111"/>
        <source>Abridger</source>
        <translation>Abreujador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="111"/>
        <source>A person, family, or organization contributing to a resource by shortening or condensing the original work but leaving the nature and content of the original work substantially unchanged. For substantial modifications that result in the creation of a new work, see Author.</source>
        <translation>Persona, família o organització que contribueix a un recurs escurçant o condensant l&apos;obra original sense canviar-ne de manera substancial la natura ni el contingut. Per a modificacions substancials de les quals en resulta la creació d&apos;una obra nova, vegeu «Autor».</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="112"/>
        <source>Actor</source>
        <translation>Actor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="112"/>
        <source>Use for a person or organization who principally exhibits acting skills in a musical or dramatic presentation or entertainment.</source>
        <translation>Persona o organització que principalment mostra habilitats per actuar en una obra musical, dramàtica o d&apos;entreteniment.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="113"/>
        <source>Adapter</source>
        <translation>Adaptador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="113"/>
        <source>Use for a person or organization who 1) reworks a musical composition, usually for a different medium, or 2) rewrites novels or stories for motion pictures or other audiovisual medium.</source>
        <translation>Persona o organització que:
1) refà una composició musical, noemalment per a un mitjà diferent, o
2) reescriu novel·les o escrits per al cinema o altres mitjans audiovisuals.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="114"/>
        <source>Analyst</source>
        <translation>Analista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="114"/>
        <source>Use for a person or organization that reviews, examines and interprets data or information in a specific area.</source>
        <translation>Persona o organització que revisa, examina i interpreta dades o informació en una àrea específica.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="115"/>
        <source>Animator</source>
        <translation>Animador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="115"/>
        <source>Use for a person or organization who draws the two-dimensional figures, manipulates the three dimensional objects and/or also programs the computer to move objects and images for the purpose of animated film processing. Animation cameras, stands, celluloid screens, transparencies and inks are some of the tools of the animator.</source>
        <translation>Persona o organització que dibuixa les imatges planes, manipula els objectes en tres dimensions o programa els ordinadors per fer moure objectes i imatges per tal de crear pel·lícules d&apos;animació. L&apos;animador fa servir eines com ara càmeres d&apos;animació, suports, pantalles de cel·luloide i tintes.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="116"/>
        <source>Annotator</source>
        <translation>Anotador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="116"/>
        <source>Use for a person who writes manuscript annotations on a printed item.</source>
        <translation>Persona que escriu notes manuscrites en un document imprès.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="117"/>
        <source>Appellant</source>
        <translation>Apel·lant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="117"/>
        <source>A person or organization who appeals a lower court&apos;s decision.</source>
        <translation>Persona o organització que apel·la una decisió d&apos;un jutjat ordinari.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="118"/>
        <source>Appellee</source>
        <translation>Apel·lat</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="118"/>
        <source>A person or organization against whom an appeal is taken.</source>
        <translation>Persona o organització contra la qual s&apos;ha admès una apel·lació.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="119"/>
        <source>Applicant</source>
        <translation>Sol·licitant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="119"/>
        <source>Use for a person or organization responsible for the submission of an application or who is named as eligible for the results of the processing of the application (e.g., bestowing of rights, reward, title, position).</source>
        <translation>Persona o organització responsable de la presentació d&apos;una sol·licitud o que es designada com a titular per rebre el resultat de la sol·licitud (per exemple, concessió de drets, remuneració, títol o càrrec).</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="120"/>
        <source>Architect</source>
        <translation>Arquitecte</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="120"/>
        <source>Use for a person or organization who designs structures or oversees their construction.</source>
        <translation>Persona o organització que dissenya estructures o en supervisa la construcció.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="121"/>
        <source>Arranger</source>
        <translation>Arranjador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="121"/>
        <source>Use for a person or organization who transcribes a musical composition, usually for a different medium from that of the original; in an arrangement the musical substance remains essentially unchanged.</source>
        <translation>Músic que adapta composicions musicals a instruments i veus diferents dels originals.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="122"/>
        <source>Art copyist</source>
        <translation>Copista d&apos;art</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="122"/>
        <source>Use for a person (e.g., a painter or sculptor) who makes copies of works of visual art.</source>
        <translation>Persona (p. ex. un pintor o un escultor) que fa còpies d&apos;obres d&apos;art.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="123"/>
        <source>Art director</source>
        <translation>Director d&apos;art</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="123"/>
        <source>A person contributing to a motion picture or television production by overseeing the artists and craftspeople who build the sets.</source>
        <translation>Persona que supervisa la feina dels artistes i dels artesans que construeixen els escenaris d&apos;una pel·lícula o d&apos;una producció de televisió.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="124"/>
        <source>Artist</source>
        <translation>Artista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="124"/>
        <source>Use for a person (e.g., a painter) or organization who conceives, and perhaps also implements, an original graphic design or work of art, if specific codes (e.g., [egr], [etr]) are not desired. For book illustrators, prefer Illustrator [ill]. </source>
        <translation>Persona o organització que concep i, potser, també du a terme un disseny gràfic original o una obra d&apos;art, si no es volen fer servir altres codis més concrets (com [egr] o [etr]). Per a il·lustradors de llibres, utilitzeu preferentment «il·lustrador» [ill].</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="125"/>
        <source>Artistic director</source>
        <translation>Director artístic</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="125"/>
        <source>Use for a person responsible for controlling the development of the artistic style of an entire production, including the choice of works to be presented and selection of senior production staff.</source>
        <translation>Persona responsable de controlar el desenvolupament de l&apos;estil artístic d&apos;una producció sencera; incloent-ne la tria de les obres que s&apos;hi presenten i la selecció del personal principal de la producció.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="126"/>
        <source>Assignee</source>
        <translation>Cessionari</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="126"/>
        <source>Use for a person or organization to whom a license for printing or publishing has been transferred.</source>
        <translation>Persona o organització a favor de la qual ha estat atorgada la llicència d&apos;impressió o publicació.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="127"/>
        <source>Associated name</source>
        <translation>Nom associat</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="127"/>
        <source>Use for a person or organization associated with or found in an item or collection, which cannot be determined to be that of a Former owner [fmo] or other designated relator indicative of provenance.</source>
        <translation>Persona o organització associada o que es troba en un objecte o col·lecció, la qual no es pot determinar si es un propietari anterior [fmo] o altre indicador de relació que n&apos;indiqui l&apos;origen.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="128"/>
        <source>Attributed name</source>
        <translation>Nom atribuït</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="128"/>
        <source>Use for an author, artist, etc., relating him/her to a work for which there is or once was substantial authority for designating that person as author, creator, etc. of the work. </source>
        <translation>Autor, artista, etc. relacionat amb una obra amb la qual hi ha, o hi va haver, constància en ferm de ser-ne l&apos;autor, el creador, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="129"/>
        <source>Auctioneer</source>
        <translation>Subhastador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="129"/>
        <source>Use for a person or organization in charge of the estimation and public auctioning of goods, particularly books, artistic works, etc.</source>
        <translation>Persona o organització encarregada de la valoració i la subhasta pública de bens, especialment de llibres, obres d&apos;art, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="130"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="130"/>
        <source>Use for a person or organization chiefly responsible for the intellectual or artistic content of a work, usually printed text. This term may also be used when more than one person or body bears such responsibility. </source>
        <translation>Persona o organització que és la principal responsable del contingut intel·lectual o artístic de l&apos;obra, generalment un text imprès. Aquest terme també es pot fer servir quan la responsabilitat correspon a més d&apos;una persona o organització.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="131"/>
        <source>Author in quotations or text extracts</source>
        <translation>Autor de cites o extractes textuals</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="131"/>
        <source>Use for a person or organization whose work is largely quoted or extracted in works to which he or she did not contribute directly. Such quotations are found particularly in exhibition catalogs, collections of photographs, etc.</source>
        <translation>Persona o organització l&apos;obra del qual ha estat ampliament citada o extractada en obres en les que no ha contribuït directament. Aquestes cites es troben sobretot en catàlegs d&apos;exposicions, col·leccions de fotografies, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="132"/>
        <source>Author of afterword, colophon, etc.</source>
        <translation>Autor de l&apos;epíleg, colofó​​, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="132"/>
        <source>Use for a person or organization responsible for an afterword, postface, colophon, etc. but who is not the chief author of a work.</source>
        <translation>Persona o organització responsable de l&apos;epíleg, nota final, colofó, etc., però que no és l&apos;autor principal de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="133"/>
        <source>Author of dialog</source>
        <translation>Autor del diàleg</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="133"/>
        <source>Use for a person or organization responsible for the dialog or spoken commentary for a screenplay or sound recording.</source>
        <translation>Persona o organització responsable del diàleg o del comentari parlat d&apos;un guió o d&apos;un enregistrament de so.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="134"/>
        <source>Author of introduction, etc.</source>
        <translation>Autor de la introducció, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="134"/>
        <source>Use for a person or organization responsible for an introduction, preface, foreword, or other critical introductory matter, but who is not the chief author.</source>
        <translation>Persona o organització responsable de la introducció, prefaci, pròleg, o altres tipus de material crític introductori, però que no és l&apos;autor principal.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="135"/>
        <source>Author of screenplay, etc.</source>
        <translation>Guionista, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="135"/>
        <source>Use for a person or organization responsible for a motion picture screenplay, dialog, spoken commentary, etc.</source>
        <translation>Persona o organització responsable del guió d&apos;una pel·lícula, diàleg, comentari parlat, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="136"/>
        <source>Autographer</source>
        <translation>Autor d&apos;un autògraf</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="136"/>
        <source>A person whose manuscript signature appears on an item.</source>
        <translation>Persona, la signatura manuscrita de la qual, figura en un ítem.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="137"/>
        <source>Bibliographic antecedent</source>
        <translation>Antecedent bibliogràfic</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="137"/>
        <source>Use for a person or organization responsible for a work upon which the work represented by the catalog record is based. This may be appropriate for adaptations, sequels, continuations, indexes, etc.</source>
        <translation>Persona o organització responsable d&apos;una obra en la qual es basa l&apos;obra descrita. Pot ser adequat per adaptacions, seqüeles, continuacions, índexs, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="138"/>
        <source>Binder</source>
        <translation>Enquadernador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="138"/>
        <source>Use for a person or organization responsible for the binding of printed or manuscript materials.</source>
        <translation>Persona o organització responsable de l&apos;enquadernació de materials impresos o manuscrits.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="139"/>
        <source>Binding designer</source>
        <translation>Dissenyador de l&apos;enquadernació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="139"/>
        <source>Use for a person or organization responsible for the binding design of a book, including the type of binding, the type of materials used, and any decorative aspects of the binding. </source>
        <translation>Persona o organització responsable del disseny del relligat d&apos;un llibre, incloent-ne en tipus d&apos;enquadernació, els materials utilitzats i qualsevol aspecte decoratiu del relligat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="140"/>
        <source>Blurb writer</source>
        <translation>Redactor del prospecte</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="140"/>
        <source>A person or organization responsible for writing a commendation or testimonial for a work, which appears on or within the publication itself, frequently on the back or dust jacket of print publications or on advertising material for all media.</source>
        <translation>Persona o organització encarregada de redactar la recomanació o el comentari d&apos;una obra que figura dins la mateixa publicació, normalment a la part del darrere de la coberta o de la sobrecoberta en les publicacions impreses o al material publicitari de qualsevol medi.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="141"/>
        <source>Book designer</source>
        <translation>Dissenyador del llibre</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="141"/>
        <source>Use for a person or organization responsible for the entire graphic design of a book, including arrangement of type and illustration, choice of materials, and process used. </source>
        <translation>Persona o organització responsable del disseny gràfic complet d&apos;un llibre, incloent-ne la maquetació del text i de les il·lustracions, la tria dels materials i el procés utilitzat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="142"/>
        <source>Book producer</source>
        <translation>Productor del llibre</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="142"/>
        <source>Use for a person or organization responsible for the production of books and other print media, if specific codes (e.g., [bkd], [egr], [tyd], [prt]) are not desired. </source>
        <translation>Persona o organització responsable de la producció de llibres i d&apos;altres mitjans impresos, si no es volen utilitzar altres codis més concrets (per exemple, [bkd], [egr], [tyd], [prt]).</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="143"/>
        <source>Bookjacket designer</source>
        <translation>Dissenyador de la sobrecoberta</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="143"/>
        <source>Use for a person or organization responsible for the design of flexible covers designed for or published with a book, including the type of materials used, and any decorative aspects of the bookjacket. </source>
        <translation>Persona o organització responsable del disseny de les cobertes flexibles d&apos;un llibre, incloent-ne els tipus de materials utilitzats i qualsevol aspecte decoratiu de la sobrecoberta.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="144"/>
        <source>Bookplate designer</source>
        <translation>Dissenyador de l&apos;ex-libris</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="144"/>
        <source>Use for a person or organization responsible for the design of a book owner&apos;s identification label that is most commonly pasted to the inside front cover of a book. </source>
        <translation>Persona o organització responsable del disseny de l&apos;etiqueta que identifica el propietari d&apos;un llibre, que generalment s&apos;enganxa a l&apos;interior de la coberta frontal.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="145"/>
        <source>Bookseller</source>
        <translation>Llibreter</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="145"/>
        <source>Use for a person or organization who makes books and other bibliographic materials available for purchase. Interest in the materials is primarily lucrative.</source>
        <translation>Persona o organització que ven llibres i altres materials bibliogràfics, principalment, amb afany de lucre.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="146"/>
        <source>Braille embosser</source>
        <translation>Impressor braille</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="146"/>
        <source>A person, family, or organization involved in manufacturing a resource by embossing Braille cells using a stylus, special embossing printer, or other device.</source>
        <translation>Persona, família  o organització que es dedica a fer un recurs gofrant cel·les braille amb punxons, impressores especials o altres dispositius.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="147"/>
        <source>Broadcaster</source>
        <translation>Locutor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="147"/>
        <source>A person, family, or organization involved in broadcasting a resource to an audience via radio, television, webcast, etc.</source>
        <translation>Persona, família o organització que es dedica a fer la locució d&apos;un recurs per a una audiència de ràdio, televisió, web, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="148"/>
        <source>Calligrapher</source>
        <translation>Cal·lígraf</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="148"/>
        <source>Use for a person or organization who writes in an artistic hand, usually as a copyist and or engrosser.</source>
        <translation>Persona o organització que escriu a mà de manera artística, normalment com a copista o cal·lígraf.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="149"/>
        <source>Cartographer</source>
        <translation>Cartògraf</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="149"/>
        <source>Use for a person or organization responsible for the creation of maps and other cartographic materials.</source>
        <translation>Persona o organització responsable de la creació de mapes i altres materials cartogràfics.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="150"/>
        <source>Caster</source>
        <translation>Fonedor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="150"/>
        <source>A person, family, or organization involved in manufacturing a resource by pouring a liquid or molten substance into a mold and leaving it to solidify to take the shape of the mold.</source>
        <translation>Persona, família o organització que es dedica a la manufactura d&apos;un recurs abocant líquid o matèria fosa en un motlle i deixant que se solidifiqui</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="151"/>
        <source>Censor</source>
        <translation>Censor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="151"/>
        <source>Use for a censor, bowdlerizer, expurgator, etc., official or private. </source>
        <translation>Censor, expurgador, mutilador, etc. oficial o privat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="152"/>
        <source>Choreographer</source>
        <translation>Coreògraf</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="152"/>
        <source>Use for a person or organization who composes or arranges dances or other movements (e.g., &quot;master of swords&quot;) for a musical or dramatic presentation or entertainment.</source>
        <translation>Persona o organització que compon o arranja danses o altres moviments (per exemple, «mestre d&apos;espases») per a un musical, representació dramàtica o espectacle d&apos;entreteniment.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="153"/>
        <source>Cinematographer</source>
        <translation>Director de fotografia</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="153"/>
        <source>Use for a person or organization who is in charge of the images captured for a motion picture film. The cinematographer works under the supervision of a director, and may also be referred to as director of photography. Do not confuse with videographer.</source>
        <translation>Persona o organització encarregada de les imatges rodades per a una pel·lícula. Treballa sota la supervisió d&apos;un director. No s&apos;ha de confondre amb l&apos;operador de càmera o cameràman.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="154"/>
        <source>Client</source>
        <translation>Client</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="154"/>
        <source>Use for a person or organization for whom another person or organization is acting.</source>
        <translation>Persona o organització per a la que una altra persona o organització actua.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="155"/>
        <source>Collection registrar</source>
        <translation>Registrador de la col·lecció</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="155"/>
        <source>A curator who lists or inventories the items in an aggregate work such as a collection of items or works.</source>
        <translation>Curador que fa la llista o l&apos;inventari dels ítems en una obra d&apos;agregació, com ara una col·lecció d&apos;ítems o obres.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="156"/>
        <source>Collector</source>
        <translation>Col·leccionista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="156"/>
        <source>Use for a person or organization who has brought together material from various sources that has been arranged, described, and cataloged as a collection. A collector is neither the creator of the material nor a person to whom manuscripts in the collection may have been addressed.</source>
        <translation>Persona o organització que ha compilat material de diverses fonts que ha estat ordenat, descrit i catalogat com a col·lecció. Un col·leccionista no és ni el creador del material ni la persona a la qual els manuscrits d&apos;una col·lecció s&apos;hi poden haver adreçat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="157"/>
        <source>Collotyper</source>
        <translation>Fototipista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="157"/>
        <source>Use for a person or organization responsible for the production of photographic prints from film or other colloid that has ink-receptive and ink-repellent surfaces.</source>
        <translation>Persona o organització responsable de la producció d&apos;impressions fotogràfiques a partir d&apos;una pel·licula o d&apos;un altre col·loide que tingui superfícies receptores o repel·lents a la tinta.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="158"/>
        <source>Colorist</source>
        <translation>Colorista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="158"/>
        <source>A person or organization responsible for applying color to drawings, prints, photographs, maps, moving images, etc.</source>
        <translation>Persona o organització responsable d&apos;acolorir dibuixos, impresos, fotografies, mapes, imatges en moviment, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="159"/>
        <source>Commentator</source>
        <translation>Comentarista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="159"/>
        <source>Use for a person or organization who provides interpretation, analysis, or a discussion of the subject matter on a recording, motion picture, or other audiovisual medium.</source>
        <translation>Persona o organització que proporciona una interpretació, anàlisi o discussió del tema en un enregistrament, gravació de vídeo, o qualsevol altre mitjà audiovisual.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="160"/>
        <source>Commentator for written text</source>
        <translation>Comentarista pel text escrit</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="160"/>
        <source>Use for a person or organization responsible for the commentary or explanatory notes about a text. For the writer of manuscript annotations in a printed book, use Annotator [ann].</source>
        <translation>Persona o organització responsable dels comentaris o de les notes explicatives d&apos;un text. Per a l&apos;autor de les notes manuscrites d&apos;un llibre imprès, feu servir Anotador [ann].</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="161"/>
        <source>Compiler</source>
        <translation>Compilador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="161"/>
        <source>Use for a person or organization who produces a work or publication by selecting and putting together material from the works of various persons or bodies.</source>
        <translation>Persona o organització que produeix una obra o una publicació seleccionant i compilant material a partir d&apos;obres de diverses persones o entitats.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="162"/>
        <source>Complainant</source>
        <translation>Querellant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="162"/>
        <source>Use for the party who applies to the courts for redress, usually in an equity proceeding.</source>
        <translation>Part que recorre als tribunals per a una reparació, normalment en un procés d&apos;equitat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="163"/>
        <source>Complainant-appellant</source>
        <translation>Querellant apel·lant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="163"/>
        <source>Use for a complainant who takes an appeal from one court or jurisdiction to another to reverse the judgment, usually in an equity proceeding.</source>
        <translation>Querellant que presenta una apel·lació en un altre tribunal o jurisdicció per tal de revocar una sentència, normalment en un procés d&apos;equitat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="164"/>
        <source>Complainant-appellee</source>
        <translation>Querellant apel·lat</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="164"/>
        <source>Use for a complainant against whom an appeal is taken from one court or jurisdiction to another to reverse the judgment, usually in an equity proceeding.</source>
        <translation>Querellant contra el qual es presenta una apel·lació en un altre tribunal o jurisdicció per tal de revocar una sentència, normalment en un procés d&apos;equitat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="165"/>
        <source>Composer</source>
        <translation>Compositor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="165"/>
        <source>Use for a person or organization who creates a musical work, usually a piece of music in manuscript or printed form.</source>
        <translation>Persona o organització que crea una obra musical, noemalment una peça de música en forma manuscrita o impresa.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="166"/>
        <source>Compositor</source>
        <translation>Caixista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="166"/>
        <source>Use for a person or organization responsible for the creation of metal slug, or molds made of other materials, used to produce the text and images in printed matter. </source>
        <translation>Persona o organització responsable de la creació dels motlles de metall o d&apos;altres materials utilitzats per obtenir text i imatges en un imprès.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="167"/>
        <source>Conceptor</source>
        <translation>Autor de la idea</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="167"/>
        <source>Use for a person or organization responsible for the original idea on which a work is based, this includes the scientific author of an audio-visual item and the conceptor of an advertisement.</source>
        <translation>Persona o organització responsable de la idea original en la qual es basa l&apos;obra, incloent-ne l&apos;autor científic d&apos;un element audiovisual i l&apos;autor d ela idea d&apos;un anunci.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="168"/>
        <source>Conductor</source>
        <translation>Director d&apos;orquestra</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="168"/>
        <source>Use for a person who directs a performing group (orchestra, chorus, opera, etc.) in a musical or dramatic presentation or entertainment.</source>
        <translation>Persona que dirigeix un grup d&apos;intèrprets (orquestra, cor, òpera, etc.) en una representació musical, dramàtica o espectacle d&apos;entreteniment.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="169"/>
        <source>Conservator</source>
        <translation>Conservador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="169"/>
        <source>A person or organization responsible for documenting, preserving, or treating printed or manuscript material, works of art, artifacts, or other media.</source>
        <translation>Persona o organització responsable de documentar, preservar o tractar materials impresos o manuscrits, obres d&apos;art, artefactes o altres medis.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="170"/>
        <source>Consultant</source>
        <translation>Consultor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="170"/>
        <source>Use for a person or organization relevant to a resource, who is called upon for professional advice or services in a specialized field of knowledge or training.</source>
        <translation>Persona o organització competent en la matèria a qui es demana consell professional o serveis en un camp especialitzat de coneixement o d&apos;habilitats.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="171"/>
        <source>Consultant to a project</source>
        <translation>Consultor d&apos;un projecte</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="171"/>
        <source>Use for a person or organization relevant to a resource, who is engaged specifically to provide an intellectual overview of a strategic or operational task and by analysis, specification, or instruction, to create or propose a cost-effective course of action or solution.</source>
        <translation>Persona o organització competent en la matèria a qui es contracta específicament per a supervisar intel·lectualment una tasca estratègica o operativa i per a crear o proposar-ne una solució o un pla d&apos;acció eficient mitjançant l&apos;anàlisi, l&apos;especificació o la indicació.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="172"/>
        <source>Contestant</source>
        <translation>Impugnador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="172"/>
        <source>Use for the party who opposes, resists, or disputes, in a court of law, a claim, decision, result, etc.</source>
        <translation>Part que s&apos;oposa, rebutja o impugna, en un tribunal, una reclamació, decisió, resultat, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="173"/>
        <source>Contestant-appellant</source>
        <translation>Impugnador apel·lant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="173"/>
        <source>Use for a contestant who takes an appeal from one court of law or jurisdiction to another to reverse the judgment.</source>
        <translation>Impugnador que presenta una apel·lació en un altre tribunal o jurisdicció per tal de revocar una sentència.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="174"/>
        <source>Contestant-appellee</source>
        <translation>Impugnador apel·lat</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="174"/>
        <source>Use for a contestant against whom an appeal is taken from one court of law or jurisdiction to another to reverse the judgment.</source>
        <translation>Impugnador en contra del qual es presenta una apel·lació en un altre tribunal o jurisdicció per tal de revocar una sentència.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="175"/>
        <source>Contestee</source>
        <translation>Impugnat</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="175"/>
        <source>Use for the party defending a claim, decision, result, etc. being opposed, resisted, or disputed in a court of law.</source>
        <translation>Part que defensa una reclamació, decisió, resultat, etc. que ha estat rebutjada o impugnada en un tribunal.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="176"/>
        <source>Contestee-appellant</source>
        <translation>Impugnat apel·lant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="176"/>
        <source>Use for a contestee who takes an appeal from one court or jurisdiction to another to reverse the judgment.</source>
        <translation>Impugnat que presenta una apel·lació en un altre tribunal o jurisdicció per tal de revocar una sentència.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="177"/>
        <source>Contestee-appellee</source>
        <translation>Impugnat apel·lant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="177"/>
        <source>Use for a contestee against whom an appeal is taken from one court or jurisdiction to another to reverse the judgment.</source>
        <translation>Impugnat en contra del qual es presenta una apel·lació en un altre tribunal o jurisdicció per tal de revocar una sentència.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="178"/>
        <source>Contractor</source>
        <translation>Contractista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="178"/>
        <source>Use for a person or organization relevant to a resource, who enters into a contract with another person or organization to perform a specific task.</source>
        <translation>Persona o organització competent en la matèria que estableix un contracte amb una altra persona o organització per dur a terme una tasca concreta.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="179"/>
        <source>Contributor</source>
        <translation>Contribuïdor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="179"/>
        <source>Use for a person or organization one whose work has been contributed to a larger work, such as an anthology, serial publication, or other compilation of individual works. Do not use if the sole function in relation to a work is as author, editor, compiler or translator.</source>
        <translation>Persona o organització l&apos;obra de la qual contribueix a una obra més gran, com ara un antologia, publicació en sèrie, o altre tipus de recopilació d&apos;obres individuals. No s&apos;ha de fer servir aquest element si l&apos;única funció en relació amb l&apos;obra és la d&apos;autor, editor, compilador o traductor.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="180"/>
        <source>Copyright claimant</source>
        <translation>Sol·licitant del copyright</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="180"/>
        <source>Use for a person or organization listed as a copyright owner at the time of registration. Copyright can be granted or later transferred to another person or organization, at which time the claimant becomes the copyright holder.</source>
        <translation>Persona o organització que s&apos;inscriu com a propietària del copyright en el moment del registre. El copyright pot concesir-se o ser transferit després a una altra persona o organització i, aleshores, el sol·licitant es converteix en el titular del copyright.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="181"/>
        <source>Copyright holder</source>
        <translation>Titular del copyright</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="181"/>
        <source>Use for a person or organization to whom copy and legal rights have been granted or transferred for the intellectual content of a work. The copyright holder, although not necessarily the creator of the work, usually has the exclusive right to benefit financially from the sale and use of the work to which the associated copyright protection applies.</source>
        <translation>Persona o organització a qui es concedeixen o es transfereixen els drets legals i de còpia pel que fa al contingut intel·lectual d&apos;una obra. El titular del copyright, encara que no sigui necessàriament el creador de l&apos;obra, normalment té els drets exclusius per a rebre beneficis econòmics provinents de la venda i l&apos;ús de l&apos;obra afectada per la protecció del copyright.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="182"/>
        <source>Corrector</source>
        <translation>Corrector</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="182"/>
        <source>Use for a person or organization who is a corrector of manuscripts, such as the scriptorium official who corrected the work of a scribe. For printed matter, use Proofreader.</source>
        <translation>Persona o organització que corregeix manuscrits, com ara l&apos;encarregat oficial de corregir el treballs dels escrivents en un scriptòrium. Per a materials impresos, feu servir Corrector de proves.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="183"/>
        <source>Correspondent</source>
        <translation>Corresponsal</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="183"/>
        <source>Use for a person or organization who was either the writer or recipient of a letter or other communication.</source>
        <translation>Persona o organització que ha estat el remitent o el destinatari d&apos;una carta o d&apos;un altra mena de comunicació.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="184"/>
        <source>Costume designer</source>
        <translation>Dissenyador de vestuari</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="184"/>
        <source>Use for a person or organization who designs or makes costumes, fixes hair, etc., for a musical or dramatic presentation or entertainment.</source>
        <translation>Persona o organització que dissenya o fa vestits, s&apos;encarrega dels pentinats, etc. en una representació musical o dramàtica o en un espectacle d&apos;entreteniment.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="185"/>
        <source>Court governed</source>
        <translation>Jutjat regit</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="185"/>
        <source>A court governed by court rules, regardless of their official nature (e.g., laws, administrative regulations.)</source>
        <translation>Jutjat regit per nomes jurídiques, independentment del seu caràcter oficial (per exemple, lleis, normes administratives.)</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="186"/>
        <source>Court reporter</source>
        <translation>Reporter dels jutjats</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="186"/>
        <source>A person, family, or organization contributing to a resource by preparing a court&apos;s opinions for publication.</source>
        <translation>Persona, família o organització que contribueix a un recurs redactant opinions dels jutjats per ser publicades.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="187"/>
        <source>Cover designer</source>
        <translation>Dissenyador de la coberta</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="187"/>
        <source>Use for a person or organization responsible for the graphic design of a book cover, album cover, slipcase, box, container, etc. For a person or organization responsible for the graphic design of an entire book, use Book designer; for book jackets, use Bookjacket designer.</source>
        <translation>Persona o organització responsable del disseny gràfic de la coberta d&apos;un llibre o d&apos;un àlbum, o de l&apos;estoig, la capsa, el contenidor, etc. Per a la persona o orgnaització responsable del disseny gràfic del llibre sencer, feu servir Dissenyador del llibre; per a la sobrecoberta, Dissenyador de la sobrecoberta.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="188"/>
        <source>Creator</source>
        <translation>Creador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="188"/>
        <source>Use for a person or organization responsible for the intellectual or artistic content of a work.</source>
        <translation>Persona o organització responsable del contingut intel·lectual o artístic d&apos;una obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="189"/>
        <source>Curator of an exhibition</source>
        <translation>Comissari de l&apos;exposició</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="189"/>
        <source>Use for a person or organization responsible for conceiving and organizing an exhibition.</source>
        <translation>Persona o organització responsable de la concepció i l&apos;organització d&apos;una exposició.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="190"/>
        <source>Dancer</source>
        <translation>Ballarí o ballarina</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="190"/>
        <source>Use for a person or organization who principally exhibits dancing skills in a musical or dramatic presentation or entertainment.</source>
        <translation>Persona o organització que presenta principalment habilitats de ball en una representació musical o dramàtica o d&apos;entreteniment.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="191"/>
        <source>Data contributor</source>
        <translation>Contribuïdor de dades</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="191"/>
        <source>Use for a person or organization that submits data for inclusion in a database or other collection of data.</source>
        <translation>Persona o organització que proporciona dades per incloure-les en una base de dades o una altra col·lecció de dades.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="192"/>
        <source>Data manager</source>
        <translation>Gestor de dades</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="192"/>
        <source>Use for a person or organization responsible for managing databases or other data sources.</source>
        <translation>Persona o organització responsable de la gestió de bases de dades o altres fonts de dades.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="193"/>
        <source>Dedicatee</source>
        <translation>A qui es dedica</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="193"/>
        <source>Use for a person or organization to whom a book, manuscript, etc., is dedicated (not the recipient of a gift).</source>
        <translation>Persona o organització al qui se li dedica un llibre, manuscrit, etc. (no el destinatari d&apos;un obsequi).</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="194"/>
        <source>Dedicator</source>
        <translation>Qui dedica</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="194"/>
        <source>Use for the author of a dedication, which may be a formal statement or in epistolary or verse form.</source>
        <translation>Autor d&apos;una dedicatòria, que pot ser redactada de manera formal, epistolar o en vers.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="195"/>
        <source>Defendant</source>
        <translation>Demandat</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="195"/>
        <source>Use for the party defending or denying allegations made in a suit and against whom relief or recovery is sought in the courts, usually in a legal action.</source>
        <translation>Part que nega o es defensa de les al·legacions que es fan en contra d&apos;ella en un plet i a qui es demana reparació o compensació, normalment en una acció legal.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="196"/>
        <source>Defendant-appellant</source>
        <translation>Demandat apel·lant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="196"/>
        <source>Use for a defendant who takes an appeal from one court or jurisdiction to another to reverse the judgment, usually in a legal action.</source>
        <translation>Demandat que presenta una apel·lació en un altre tribunal o jurisdicció per tal de revocar una sentència, normalment en una acció legal.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="197"/>
        <source>Defendant-appellee</source>
        <translation>Demandat apel·lat</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="197"/>
        <source>Use for a defendant against whom an appeal is taken from one court or jurisdiction to another to reverse the judgment, usually in a legal action.</source>
        <translation>Demandat en contra del qual es presenta una apel·lació en un altre tribunal o jurisdicció per tal de revocar una sentència, normalment e una acció legal.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="198"/>
        <source>Degree grantor</source>
        <translation>Otorgant del títol</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="198"/>
        <source>Use for the organization granting a degree for which the thesis or dissertation described was presented.</source>
        <translation>Organització que otorga un títol o grau per al qual es presenta una tesi.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="199"/>
        <source>Delineator</source>
        <translation>Delineant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="199"/>
        <source>Use for a person or organization executing technical drawings from others&apos; designs.</source>
        <translation>Persona o organització que executa els dibuixos tècnics a partir dels dissenys d&apos;altres.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="200"/>
        <source>Depicted</source>
        <translation>Representat</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="200"/>
        <source>Use for an entity depicted or portrayed in a work, particularly in a work of art.</source>
        <translation>Entitat representada en una obra, especialment en obres d&apos;art.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="201"/>
        <source>Depositor</source>
        <translation>Dipositant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="201"/>
        <source>Use for a person or organization placing material in the physical custody of a library or repository without transferring the legal title.</source>
        <translation>Persona o organització que diposita materials sota la custòdia d&apos;una biblioteca o arxiu sense transferir els drets de propietat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="202"/>
        <source>Designer</source>
        <translation>Dissenyador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="202"/>
        <source>Use for a person or organization responsible for the design if more specific codes (e.g., [bkd], [tyd]) are not desired.</source>
        <translation>Persona o organització responsable del disseny si no es volen fer servir altres codis més concrets, com ara [bkd] o [tyd].</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="203"/>
        <source>Director</source>
        <translation>Director</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="203"/>
        <source>Use for a person or organization who is responsible for the general management of a work or who supervises the production of a performance for stage, screen, or sound recording.</source>
        <translation>Persona o organització responsable de la gestió general d&apos;una obra o que supervisa la producció d&apos;una representació, pel·lícula o enregistrament de so.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="204"/>
        <source>Dissertant</source>
        <translation>Aspirant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="204"/>
        <source>Use for a person who presents a thesis for a university or higher-level educational degree.</source>
        <translation>Persona que defensa una tesi per assolir un grau universitari o d&apos;educació superior.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="205"/>
        <source>Distribution place</source>
        <translation>Lloc de distribució</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="205"/>
        <source>A place from which a resource, e.g., a serial, is distributed.</source>
        <translation>Llos des del qual un recurs, per exemple una sèrie, es distribueix.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="206"/>
        <source>Distributor</source>
        <translation>Distribuïdor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="206"/>
        <source>Use for a person or organization that has exclusive or shared marketing rights for an item.</source>
        <translation>Persona o organització que té drets exclusius o compartits per comercialitzar un objecte.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="207"/>
        <source>Donor</source>
        <translation>Donant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="207"/>
        <source>Use for a person or organization who is the donor of a book, manuscript, etc., to its present owner. Donors to previous owners are designated as Former owner [fmo] or Inscriber [ins].</source>
        <translation>Persona o organització que dóna un llibre, un manuscrit, etc. al seu propietari actual. Els donants als propietaris anteriors s&apos;anomenen «Propietari anterior» [fmo] o  Inscriptor [ins].</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="208"/>
        <source>Draftsman</source>
        <translation>Dibuixant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="208"/>
        <source>Use for a person or organization who prepares artistic or technical drawings. </source>
        <translation>Persona o organització que prepara dibuixos tècnics o artístics.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="209"/>
        <source>Dubious author</source>
        <translation>Autor dubtós</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="209"/>
        <source>Use for a person or organization to which authorship has been dubiously or incorrectly ascribed.</source>
        <translation>Persona o organització a qui s&apos;atribueix una autoria dubtosa o incorrecta.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="210"/>
        <source>Editor</source>
        <translation>Editor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="210"/>
        <source>Use for a person or organization who prepares for publication a work not primarily his/her own, such as by elucidating text, adding introductory or other critical matter, or technically directing an editorial staff.</source>
        <translation>Persona o organització que prepara una obra en principi aliena per a ser publicada, interpretant o aclarint el text, afegint-ne una introducció o altre contingut introductori o dirigint tècnicament el personal d&apos;una editorial.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="211"/>
        <source>Editor of compilation</source>
        <translation>Editor de la compilació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="211"/>
        <source>A person, family, or organization contributing to a collective or aggregate work by selecting and putting together works, or parts of works, by one or more creators. For compilations of data, information, etc., that result in new works, see compiler.</source>
        <translation>Persona, família o organització que contribueix a una obra col·lectiva o d&apos;agregació seleccionant i compilant obres, o part d&apos;obres, d&apos;un o més creadors. Per indicar una compilació de dades o d&apos;informació de la qual resulta una obra nova, vegeu «Compilador».</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="212"/>
        <source>Editor of moving image work</source>
        <translation>Editor d&apos;obres cinematogràfiques</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="212"/>
        <source>A person, family, or organization responsible for assembling, arranging, and trimming film, video, or other moving image formats, including both visual and audio aspects.</source>
        <translation>Persona, família o organització responsable de l&apos;assemblatge, l&apos;arranjament i el muntatge de pel·lícules, vídeos o altres formats cinematogràfics, incloent tant els aspectes visuals com els d&apos;àudio.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="213"/>
        <source>Electrician</source>
        <translation>Electricista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="213"/>
        <source>Use for a person responsible for setting up a lighting rig and focusing the lights for a production, and running the lighting at a performance.</source>
        <translation>Persona responsable d&apos;instal·lar un equip d&apos;il·luminació i d&apos;enfocar els llums d&apos;una producció i de controlar la il·luminació d&apos;una representació.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="214"/>
        <source>Electrotyper</source>
        <translation>Electrotipista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="214"/>
        <source>Use for a person or organization who creates a duplicate printing surface by pressure molding and electrodepositing of metal that is then backed up with lead for printing.</source>
        <translation>Persona o organització que crea una planxa d&apos;impressió per mitjà de procediments electroquímics.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="215"/>
        <source>Engineer</source>
        <translation>Enginyer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="215"/>
        <source>Use for a person or organization that is responsible for technical planning and design, particularly with construction.</source>
        <translation>Persona o organització responsable de la planificació i del disseny tècnic, especialment en la construcció.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="216"/>
        <source>Engraver</source>
        <translation>Gravador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="216"/>
        <source>Use for a person or organization who cuts letters, figures, etc. on a surface, such as a wooden or metal plate, for printing.</source>
        <translation>Persona o organització que talla les lletres, figures, etc, sobre una superfície, com ara una placa de fusta o de metall, per a la impressió.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="217"/>
        <source>Etcher</source>
        <translation>Gravador d&apos;aiguaforts</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="217"/>
        <source>Use for a person or organization who produces text or images for printing by subjecting metal, glass, or some other surface to acid or the corrosive action of some other substance.</source>
        <translation>Persona o organització que prepara textos o imatges per ser impresos atacant amb àcid, o altra substància corrosiva, metall, fusta o una altra superfície.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="218"/>
        <source>Event place</source>
        <translation>Lloc de l&apos;esdeveniment</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="218"/>
        <source>A place where an event such as a conference or a concert took place.</source>
        <translation>Lloc on s&apos;esdevé un fet, com ara una conferència o un concert.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="219"/>
        <source>Expert</source>
        <translation>Expert</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="219"/>
        <source>Use for a person or organization in charge of the description and appraisal of the value of goods, particularly rare items, works of art, etc. </source>
        <translation>Persona o organització encarregada de la descripció i taxació de bens, especialment objectes rars, obres d&apos;art, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="220"/>
        <source>Facsimilist</source>
        <translation>Autor de facsímils</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="220"/>
        <source>Use for a person or organization that executed the facsimile.</source>
        <translation>Persona o organització autora del facsímil.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="221"/>
        <source>Field director</source>
        <translation>Director de camp</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="221"/>
        <source>Use for a person or organization that manages or supervises the work done to collect raw data or do research in an actual setting or environment (typically applies to the natural and social sciences).</source>
        <translation>Persona o organització que gestiona o supervisa la feina feta per tal de recollir dades o fer recerca en un entorn o localització real (generalment s&apos;aplica a les ciències naturals i socials).</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="222"/>
        <source>Film director</source>
        <translation>Director de la pel·lícula</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="222"/>
        <source>A director responsible for the general management and supervision of a filmed performance.</source>
        <translation>Director responsable de la gestió general i de la supervisió de la filmació d&apos;una representació.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="223"/>
        <source>Film distributor</source>
        <translation>Distribuïdor de la pel·lícula</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="223"/>
        <source>A person, family, or organization involved in distributing a moving image resource to theatres or other distribution channels.</source>
        <translation>Persona, família o organització dedicada a la distribució de recursos cinematogràfics a les sales d&apos;exhibició o altres canals de distribució.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="224"/>
        <source>Film editor</source>
        <translation>Muntador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="224"/>
        <source>Use for a person or organization who is an editor of a motion picture film. This term is used regardless of the medium upon which the motion picture is produced or manufactured (e.g., acetate film, video tape). </source>
        <translation>Persona o organització que fa el muntatge d&apos;una pel·lícula de cinema.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="225"/>
        <source>Film producer</source>
        <translation>Productor de la pel·lícula</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="225"/>
        <source>A producer responsible for most of the business aspects of a film.</source>
        <translation>Productor responsable de la majoria dels temes econòmics d&apos;una pel·lícula.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="226"/>
        <source>Filmmaker</source>
        <translation>Cineasta</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="226"/>
        <source>A person, family or organization responsible for creating an independent or personal film. A filmmaker is individually responsible for the conception and execution of all aspects of the film.</source>
        <translation>Persona, família o organització responsable de la creació d&apos;una pel·lícula independent o personal. El cineasta és el responsable individual de la concepció i l&apos;execució de tots els aspectes de la pel·lícula.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="227"/>
        <source>First party</source>
        <translation>Primera part</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="227"/>
        <source>Use for a person or organization who is identified as the only party or the party of the first part. In the case of transfer of right, this is the assignor, transferor, licensor, grantor, etc. Multiple parties can be named jointly as the first party.</source>
        <translation>Persona o organització que s&apos;identifica com a part única o com a primera part. En cas d&apos;un traspàs de drets, és qui els cedeix. La primera part pot designar diverses parts alhora.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="228"/>
        <source>Forger</source>
        <translation>Falsificador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="228"/>
        <source>Use for a person or organization who makes or imitates something of value or importance, especially with the intent to defraud. </source>
        <translation>Persona o organització que fa o imita alguna cosa de valor o d&apos;importància, especialment amb la intenció d&apos;estafar.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="229"/>
        <source>Former owner</source>
        <translation>Propietari anterior</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="229"/>
        <source>Use for a person or organization who owned an item at any time in the past. Includes those to whom the material was once presented. A person or organization giving the item to the present owner is designated as Donor [dnr].</source>
        <translation>Persona o organització que va ser propietària d&apos;un objecte en algun moment passat. Inclou aquells a qui el material els va ser regalat. Qui dona l&apos;objecte al propietari actual s&apos;anomena «Donant» [dnr].</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="230"/>
        <source>Funder</source>
        <translation>Financer</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="230"/>
        <source>Use for a person or organization that furnished financial support for the production of the work.</source>
        <translation>Persona o organització  que dona suport econòmic a la producció de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="231"/>
        <source>Geographic information specialist</source>
        <translation>Especialista d&apos;informació geogràfica</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="231"/>
        <source>Use for a person responsible for geographic information system (GIS) development and integration with global positioning system data.</source>
        <translation>Persona responsable del desenvolupament de sistemes d&apos;informació geogràfica (GIS) i de la seva integració amb dades de sistemes de posicionament global.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="232"/>
        <source>Honoree</source>
        <translation>Homenatjat</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="232"/>
        <source>Use for a person or organization in memory or honor of whom a book, manuscript, etc. is donated. </source>
        <translation>Persona o organització en memòria o honor del qual es dóna un llibre, manuscrit, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="233"/>
        <source>Host</source>
        <translation>Presentador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="233"/>
        <source>Use for a person who is invited or regularly leads a program (often broadcast) that includes other guests, performers, etc. (e.g., talk show host).</source>
        <translation>Persona invitada o que sovint presenta un programa (normalment retransmès) que inclou altres convidats, intèrprets, etc. (per exemple, un presentador de programes d&apos;entrevistes).</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="234"/>
        <source>Host institution</source>
        <translation>Institució hoste</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="234"/>
        <source>An organization hosting the event, exhibit, conference, etc., which gave rise to a resource, but having little or no responsibility for the content of the resource.</source>
        <translation>Organització encarregada d&apos;acollir l&apos;esdeveniment, l&apos;exposició, la conferència, etc. que origina el recurs però amb una responsabilitat minsa o nul·la sobre el seu contingut.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="235"/>
        <source>Illuminator</source>
        <translation>Il·luminador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="235"/>
        <source>Use for a person or organization responsible for the decoration of a work (especially manuscript material) with precious metals or color, usually with elaborate designs and motifs.</source>
        <translation>Persona o organització responsable de la decoració d&apos;una obra (especialment manuscrits) amb metalls preciosos o colors, generalment amb motius i dissenys molt elaborats.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="236"/>
        <source>Illustrator</source>
        <translation>Il·lustrador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="236"/>
        <source>Use for a person or organization who conceives, and perhaps also implements, a design or illustration, usually to accompany a written text.</source>
        <translation>Persona o organització que idea i, potser també fa, un disseny o una il·lustració, normalment per tal d&apos;acompanyar un text escrit.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="237"/>
        <source>Inscriber</source>
        <translation>Inscriptor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="237"/>
        <source>Use for a person who has written a statement of dedication or gift.</source>
        <translation>Utilitzat per la persona que ha escrit la dedicatòria.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="238"/>
        <source>Instrumentalist</source>
        <translation>Instrumentista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="238"/>
        <source>Use for a person or organization who principally plays an instrument in a musical or dramatic presentation or entertainment.</source>
        <translation>Persona o organització que principalment toca un intrument en una obra musical, dramàtica o d&apos;entreteniment.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="239"/>
        <source>Interviewee</source>
        <translation>Entrevistat</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="239"/>
        <source>Use for a person or organization who is interviewed at a consultation or meeting, usually by a reporter, pollster, or some other information gathering agent.</source>
        <translation>Persona o organització que es entrevistada en una consulta o reunió, generalment per un reporter, enquestador o qualsevol altre agent recol·lector d&apos;informació.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="240"/>
        <source>Interviewer</source>
        <translation>Entrevistador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="240"/>
        <source>Use for a person or organization who acts as a reporter, pollster, or other information gathering agent in a consultation or meeting involving one or more individuals.</source>
        <translation>Persona o organització que actua com a reporter, enquestador o qualsevol altre agent recol·lector d&apos;informació en una consulta o reunió amb un o més individus.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="241"/>
        <source>Inventor</source>
        <translation>Inventor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="241"/>
        <source>Use for a person or organization who first produces a particular useful item, or develops a new process for obtaining a known item or result.</source>
        <translation>Persona o organització que crea per primera vegada un objecte d&apos;una utilitat concreta, o desenvolupa un procés nou per obtenir un objecte o un resultat conegut.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="242"/>
        <source>Issuing body</source>
        <translation>Ens emissor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="242"/>
        <source>A person, family or organization issuing a work, such as an official organ of the body.</source>
        <translation>Persona, família o organització que lliura l&apos;obra, com a òrgan oficial de l&apos;ens.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="243"/>
        <source>Judge</source>
        <translation>Jutge</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="243"/>
        <source>A person who hears and decides on legal matters in court.</source>
        <translation>Persona que escolta i decideix sobre temes legals en un jutjat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="244"/>
        <source>Jurisdiction governed</source>
        <translation>Jurisdicció regida</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="244"/>
        <source>A jurisdiction governed by a law, regulation, etc., that was enacted by another jurisdiction.</source>
        <translation>Jurisdicció regida per una llei, reglament, etc., promulgada per una altra jurisdicció.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="245"/>
        <source>Laboratory</source>
        <translation>Laboratori</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="245"/>
        <source>Use for an institution that provides scientific analyses of material samples.</source>
        <translation>Institució que proporciona les anàlisis científiques de les mostres de materials.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="246"/>
        <source>Laboratory director</source>
        <translation>Director de laboratori</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="246"/>
        <source>Use for a person or organization that manages or supervises work done in a controlled setting or environment. </source>
        <translation>Persona o organització que administra o supervisa el treball realitzat en un entorn controlat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="247"/>
        <source>Landscape architect</source>
        <translation>Arquitecte de paisatge</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="247"/>
        <source>Use for a person or organization whose work involves coordinating the arrangement of existing and proposed land features and structures.</source>
        <translation>Persona o organització el treball de la qual inclou coordinar la distribució de les estructures i les característiques existents i proposades del terreny.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="248"/>
        <source>Lead</source>
        <translation>Cap</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="248"/>
        <source>Use to indicate that a person or organization takes primary responsibility for a particular activity or endeavor. Use with another relator term or code to show the greater importance this person or organization has regarding that particular role. If more than one relator is assigned to a heading, use the Lead relator only if it applies to all the relators.</source>
        <translation>Persona o organització que té una responsabilitat principal en una activitat o tasca concreta. S&apos;utilitza amb un altre codi o terme de relació per indicar que, en aquesta funció en particular, la persona o organització tenen una importància més gran. Si hi ha una o més persones o organitzacions en l&apos;element, s&apos;ha d&apos;utilitzar «Cap» només si s&apos;ha d&apos;aplicar a totes.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="249"/>
        <source>Lender</source>
        <translation>Prestador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="249"/>
        <source>Use for a person or organization permitting the temporary use of a book, manuscript, etc., such as for photocopying or microfilming.</source>
        <translation>Persona o organització que permet l&apos;ús temporal d&apos;un llibre, manuscrit, etc., per exemple per fotocopiar o microfilmar.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="250"/>
        <source>Libelant</source>
        <translation>Demandant per difamació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="250"/>
        <source>Use for the party who files a libel in an ecclesiastical or admiralty case.</source>
        <translation>Part que interposa una demanda per difamació en un tribunal eclesiàstic o militar.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="251"/>
        <source>Libelant-appellant</source>
        <translation>Demandant apel·lant per difamació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="251"/>
        <source>Use for a libelant who takes an appeal from one ecclesiastical court or admiralty to another to reverse the judgment.</source>
        <translation>Demandant per difamació que presenta una apel·lació en un altre tibunal eclesiàstic o militar per tal de revocar una sentència.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="252"/>
        <source>Libelant-appellee</source>
        <translation>Demandant apel·lat per difamació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="252"/>
        <source>Use for a libelant against whom an appeal is taken from one ecclesiastical court or admiralty to another to reverse the judgment.</source>
        <translation>Demandant per difamació en contra del qual es presenta una apel·lació en un altre tribunal eclesiàstic o militar per tal de revocar una sentència.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="253"/>
        <source>Libelee</source>
        <translation>Demandat per difamació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="253"/>
        <source>Use for a party against whom a libel has been filed in an ecclesiastical court or admiralty.</source>
        <translation>Part en contra de la qual s&apos;interposa una demanda per difamació en un tribunal eclesiàstic o militar.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="254"/>
        <source>Libelee-appellant</source>
        <translation>Demandat apel·lant per difamació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="254"/>
        <source>Use for a libelee who takes an appeal from one ecclesiastical court or admiralty to another to reverse the judgment.</source>
        <translation>Demandat per difamació que presenta una apel·lació en un altre tribunal eclesiàstic o militar per tal de revocar una sentència.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="255"/>
        <source>Libelee-appellee</source>
        <translation>Demandat apel·lat per difamació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="255"/>
        <source>Use for a libelee against whom an appeal is taken from one ecclesiastical court or admiralty to another to reverse the judgment.</source>
        <translation>Demandat per difamació en contra del qual es presenta una apel·lació en un altre tribunal eclesiàstic o militar per tal de revocar una sentència.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="256"/>
        <source>Librettist</source>
        <translation>Llibretista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="256"/>
        <source>Use for a person or organization who is a writer of the text of an opera, oratorio, etc.</source>
        <translation>Persona o organització que escriu el text d&apos;una òpera, oratori, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="257"/>
        <source>Licensee</source>
        <translation>Concessionari de la llicència</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="257"/>
        <source>Use for a person or organization who is an original recipient of the right to print or publish.</source>
        <translation>Persona o organització que es el receptor original del dret d&apos;impressió o publicació.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="258"/>
        <source>Licensor</source>
        <translation>Atorgant de la llicència</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="258"/>
        <source>Use for person or organization who is a signer of the license, imprimatur, etc. </source>
        <translation>Persona o organització que signa la llicència, imprimàtur, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="259"/>
        <source>Lighting designer</source>
        <translation>Dissenyador d&apos;il·luminació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="259"/>
        <source>Use for a person or organization who designs the lighting scheme for a theatrical presentation, entertainment, motion picture, etc.</source>
        <translation>Persona o organització que dissenya el pla d&apos;il·luminació d&apos;una representació teatral, espectacle, pel·lícula, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="260"/>
        <source>Lithographer</source>
        <translation>Litògraf</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="260"/>
        <source>Use for a person or organization who prepares the stone or plate for lithographic printing, including a graphic artist creating a design directly on the surface from which printing will be done.</source>
        <translation>Persona o organització que prepara la pedra o la planxa per a la impressió litogràfica, incloent els artistes gràfics que creen un disseny directament sobre la superfície amb la qual es farà la impressió.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="261"/>
        <source>Lyricist</source>
        <translation>Lletrista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="261"/>
        <source>Use for a person or organization who is the a writer of the text of a song.</source>
        <translation>Persona o organització autora del text d&apos;una cançó.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="262"/>
        <source>Manufacture place</source>
        <translation>Lloc de fabricació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="262"/>
        <source>The place of manufacture (e.g., printing, duplicating, casting, etc.) of a resource in a published form.</source>
        <translation>Lloc on s&apos;ha fet el recurs (per exemple, impressió, duplicat, emissió, etc.) de manera pública.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="263"/>
        <source>Manufacturer</source>
        <translation>Fabricant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="263"/>
        <source>Use for a person or organization that makes an artifactual work (an object made or modified by one or more persons). Examples of artifactual works include vases, cannons or pieces of furniture.</source>
        <translation>Persona o organització que fa un treball manufacturat (un objecte fet o modificat per una o més persones). Exemples de treballs manufacturats: gerros, canons o mobles.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="264"/>
        <source>Marbler</source>
        <translation>Marbrista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="264"/>
        <source>The entity responsible for marbling paper, cloth, leather, etc. used in construction of a resource.</source>
        <translation>Entitat responsable de marbrar paper, roba, pell, etc. usada en la construcció d&apos;un recurs.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="265"/>
        <source>Markup editor</source>
        <translation>Editor de marcatge</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="265"/>
        <source>Use for a person or organization performing the coding of SGML, HTML, or XML markup of metadata, text, etc.</source>
        <translation>Persona o organització que codifica en SGML, HTML o fa el marcatge en XML de metadades, text, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="266"/>
        <source>Medium</source>
        <translation>Mèdium</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="266"/>
        <source>A person held to be a channel of communication between the earthly world and a different world.</source>
        <translation>Persona a la qual s&apos;atribueix la capacitat de comunicar-se amb el més enllà, fent d&apos;intermediari entre els esperits i el món terrenal.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="267"/>
        <source>Metadata contact</source>
        <translation>Contacte per a metadades</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="267"/>
        <source>Use for a person or organization primarily responsible for compiling and maintaining the original description of a metadata set (e.g., geospatial metadata set).</source>
        <translation>Persona o organització responsable principalment de compilar i mantenir la descripcions originals d&apos;un conjunt de metadades (per exemple, un conjunt de metadades geogràfiques espacials).</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="268"/>
        <source>Metal-engraver</source>
        <translation>Gravador de metall</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="268"/>
        <source>Use for a person or organization responsible for decorations, illustrations, letters, etc. cut on a metal surface for printing or decoration.</source>
        <translation>Persona o organització responsable de la decoració, les il·lustracions, les lletres, etc. gravades en una superfície de metall per tal d&apos;imprimir o decaorar.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="269"/>
        <source>Minute taker</source>
        <translation>Secretari de la reunió</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="269"/>
        <source>A person, family, or organization responsible for recording the minutes of a meeting.</source>
        <translation>Persona, família o organització encarregada d&apos;estendre l&apos;acta d&apos;una reunió.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="270"/>
        <source>Moderator</source>
        <translation>Moderador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="270"/>
        <source>Use for a person who leads a program (often broadcast) where topics are discussed, usually with participation of experts in fields related to the discussion.</source>
        <translation>Persona que presenta un programa (normalment retransmès) on es tracten temes, generalment amb la participació d&apos;experts en la matèria que es debat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="271"/>
        <source>Monitor</source>
        <translation>Supervisor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="271"/>
        <source>Use for a person or organization that supervises compliance with the contract and is responsible for the report and controls its distribution. Sometimes referred to as the grantee, or controlling agency.</source>
        <translation>Persona o organització que supervisa el compliment d&apos;un contracte i que es responsable de l&apos;informe i en controla la distribució. També se&apos;n pot dir agència de control.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="272"/>
        <source>Music copyist</source>
        <translation>Copista de música</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="272"/>
        <source>Use for a person who transcribes or copies musical notation</source>
        <translation>Persona que transcriu o copia notacions musicals</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="273"/>
        <source>Musical director</source>
        <translation>Director musical</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="273"/>
        <source>Use for a person responsible for basic music decisions about a production, including coordinating the work of the composer, the sound editor, and sound mixers, selecting musicians, and organizing and/or conducting sound for rehearsals and performances.</source>
        <translation>Persona responsable de decisions musicals bàsiques sobre una producció, incloent-ne la coordinació del treball del compositor i  l&apos;editor de so i els mescladors, la selecció de músics i l&apos;organització o la direcció del so als assajos i les representacions.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="274"/>
        <source>Musician</source>
        <translation>Músic</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="274"/>
        <source>Use for a person or organization who performs music or contributes to the musical content of a work when it is not possible or desirable to identify the function more precisely.</source>
        <translation>Persona o organització que interpreta música o contribueix al context musical d&apos;una obra quan no és possible o no es vol identificar la funció d&apos;una forma més precisa.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="275"/>
        <source>Narrator</source>
        <translation>Narrador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="275"/>
        <source>Use for a person who is a speaker relating the particulars of an act, occurrence, or course of events.</source>
        <translation>Persona que narra els detall d&apos;una acció, un succés o una cadena d&apos;esdeveniments.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="276"/>
        <source>Onscreen presenter</source>
        <translation>Presentador de l&apos;audiovisual</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="276"/>
        <source>A performer contributing to an expression of a work by appearing on screen in nonfiction moving image materials or introductions to fiction moving image materials to provide contextual or background information. Use when another term (e.g., Narrator, Host) is either not applicable or not desired.</source>
        <translation>Intèrpret que col·labora amb el contingut de l&apos;obra cinematogràfica apareixent en pantalla per tal d&apos;explicar el context o d&apos;oferir informació general, tant en obres de ficció com de no ficció. Es pot usar quan altres termes (com ara «Narrador» o «Presentador») no es poden o no es volen fer servir.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="277"/>
        <source>Opponent</source>
        <translation>Oponent</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="277"/>
        <source>Use for a person or organization responsible for opposing a thesis or dissertation.</source>
        <translation>Persona o organització responsable d&apos;oposar una tesi o una memòria.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="278"/>
        <source>Organizer of meeting</source>
        <translation>Organitzador de la reunió</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="278"/>
        <source>Use for a person or organization responsible for organizing a meeting for which an item is the report or proceedings.</source>
        <translation>Persona o organització responsable d&apos;organitzar una reunió amb el propòsit d&apos;informar o planificar.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="279"/>
        <source>Originator</source>
        <translation>Autor original</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="279"/>
        <source>Use for a person or organization performing the work, i.e., the name of a person or organization associated with the intellectual content of the work. This category does not include the publisher or personal affiliation, or sponsor except where it is also the corporate author.</source>
        <translation>Persona o organització que executa l&apos;obra, és a dir, el nom de la persona o l&apos;organització associada amb el contingut intel·lectual d&apos;una obra. Aquesta categoria no inclou l&apos;editorial o el seu personal ni el patrocinador, si no és que també en són els autors materials.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="280"/>
        <source>Other</source>
        <translation>Altres</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="280"/>
        <source>Use for relator codes from other lists which have no equivalent in the MARC list or for terms which have not been assigned a code.</source>
        <translation>Codis de relació d&apos;altres llistes que no tenen equivalent a la llista MARC o per a termes que no hi ténen un codi assignat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="281"/>
        <source>Owner</source>
        <translation>Propietari</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="281"/>
        <source>Use for a person or organization that currently owns an item or collection.</source>
        <translation>Persona o organització que actualment és la propietària d&apos;un objecte o d&apos;una col·lecció.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="282"/>
        <source>Panelist</source>
        <translation>Ponent</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="282"/>
        <source> performer contributing to a resource by participating in a program (often broadcast) where topics are discussed, usually with participation of experts in fields related to the discussion.</source>
        <translation>Persona que contribueix amb un recurs participant en un programa (normalment retransmès) on es tracten temes, generalment amb la participació d&apos;experts en la matèria que es debat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="283"/>
        <source>Papermaker</source>
        <translation>Fabricant del paper</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="283"/>
        <source>Use for a person or organization responsible for the production of paper, usually from wood, cloth, or other fibrous material.</source>
        <translation>Persona o organització que fabrica paper, normalment a partir de fusta, roba o altres materials fibrosos.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="284"/>
        <source>Patent applicant</source>
        <translation>Sol·licitant de la patent</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="284"/>
        <source>Use for a person or organization that applied for a patent.</source>
        <translation>Persona o organització que va sol·licitar la patent.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="285"/>
        <source>Patent holder</source>
        <translation>Titular de la patent</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="285"/>
        <source>Use for a person or organization that was granted the patent referred to by the item. </source>
        <translation>Persona o organització a la que es va concedir la patent a la que es refereix l&apos;article.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="286"/>
        <source>Patron</source>
        <translation>Patró</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="286"/>
        <source>Use for a person or organization responsible for commissioning a work. Usually a patron uses his or her means or influence to support the work of artists, writers, etc. This includes those who commission and pay for individual works.</source>
        <translation>Persona o organització responsable de l&apos;encàrrec d&apos;una obra.Normalment, un patró dona suport al treball dels artistes, escriptors, etc. mitjançant els seus medis o la seva influència. S&apos;inclou els que encarreguen i paguen obres individuals.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="287"/>
        <source>Performer</source>
        <translation>Intèrpret</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="287"/>
        <source>Use for a person or organization who exhibits musical or acting skills in a musical or dramatic presentation or entertainment, if specific codes for those functions ([act], [dnc], [itr], [voc], etc.) are not used. If specific codes are used, [prf] is used for a person whose principal skill is not known or specified.</source>
        <translation>Persona o organització que mostren habilitats musicals o d&apos;actuació en una representació dramàtica, musical o d&apos;entreteniment, si no s&apos;utilitzen altres codis més concrets ([act], [dnc], [itr], [voc], etc.) per indicar aquestes funcions. Si s&apos;utilitzen codis concrets, aleshores «Intèrpret» [prf] es fa servir per algú de qui no es coneix o no s&apos;indica la seva habilitat principal.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="288"/>
        <source>Permitting agency</source>
        <translation>Autoritat permitent</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="288"/>
        <source>Use for an authority (usually a government agency) that issues permits under which work is accomplished.</source>
        <translation>Autoritat (normalment un departament del govern) que atorga el permís per fer l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="289"/>
        <source>Photographer</source>
        <translation>Fotògraf</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="289"/>
        <source>Use for a person or organization responsible for taking photographs, whether they are used in their original form or as reproductions.</source>
        <translation>Persona o organització responsable de fer fotografies per tal de ser utilitzades en la seva forma original o com a reproduccions.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="290"/>
        <source>Plaintiff</source>
        <translation>Demandant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="290"/>
        <source>Use for the party who complains or sues in court in a personal action, usually in a legal proceeding.</source>
        <translation>Part que denuncia o demanda en un tribunal com a acció personal, normalment en un procés legal.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="291"/>
        <source>Plaintiff-appellant</source>
        <translation>Demandant apel·lant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="291"/>
        <source>Use for a plaintiff who takes an appeal from one court or jurisdiction to another to reverse the judgment, usually in a legal proceeding.</source>
        <translation>Demandant que presenta una apel·lació a un altre tribunal o jurisdicció perl tal de revocar una sentència, normalment en un procés legal.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="292"/>
        <source>Plaintiff-appellee</source>
        <translation>Demandant apel·lat</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="292"/>
        <source>Use for a plaintiff against whom an appeal is taken from one court or jurisdiction to another to reverse the judgment, usually in a legal proceeding.</source>
        <translation>Demandant en contra del qual es presenta una apel·lació a un altre tribunal o jurisdicció perl tal de revocar una sentència, normalment en un procés legal.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="293"/>
        <source>Platemaker</source>
        <translation>Productor de planxes</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="293"/>
        <source>Use for a person or organization responsible for the production of plates, usually for the production of printed images and/or text.</source>
        <translation>Persona o organització responsable de fabricar les planxes que, normalment, s&apos;utilitzen per la impressió d&apos;imatges o text.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="294"/>
        <source>Praeses</source>
        <translation>President</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="294"/>
        <source>A person who is the faculty moderator of an academic disputation, normally proposing a thesis and participating in the ensuing disputation.</source>
        <translation>Moderador reconegut d&apos;un debat acadèmic en el qual, normalment, hi proposa una tesi i participa en la discussió resultant.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="295"/>
        <source>Presenter</source>
        <translation>Presentador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="295"/>
        <source>A person or organization mentioned in an &apos;X presents&apos; credit for moving image materials and who is associated with production, finance, or distribution in some way. A vanity credit; in early years, normally the head of a studio.</source>
        <translation>Persona o organització que als crèdits dels materials cinematogràfics apareix com a «tal presenta» i que hi està relacionat d&apos;alguna manera amb la producció, el finançament o la distribució. Un crèdit laudatori; abans era, normalment, la capçalera dels estudis de producció.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="296"/>
        <source>Printer</source>
        <translation>Impressor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="296"/>
        <source>Use for a person or organization who prints texts, whether from type or plates.</source>
        <translation>Persona o organització que imprimeix textos amb motlles tipogràfics o planxes d&apos;impressió.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="297"/>
        <source>Printer of plates</source>
        <translation>Impressor de planxes</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="297"/>
        <source>Use for a person or organization who prints illustrations from plates. </source>
        <translation>Persona o organització que imprimeix il·lustracions amb planxes d&apos;impressió.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="298"/>
        <source>Printmaker</source>
        <translation>Impremter</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="298"/>
        <source>Use for a person or organization who makes a relief, intaglio, or planographic printing surface.</source>
        <translation>Persona o organització que prepara les formes impressores en relleu, rotogravat o planografia.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="299"/>
        <source>Process contact</source>
        <translation>Contacte de processament</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="299"/>
        <source>Use for a person or organization primarily responsible for performing or initiating a process, such as is done with the collection of metadata sets.</source>
        <translation>Persona o organització responsable principalment de dur a terme o iniciar un procés, com ara la compilació de conjunts de metadades.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="300"/>
        <source>Producer</source>
        <translation>Productor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="300"/>
        <source>Use for a person or organization responsible for the making of a motion picture, including business aspects, management of the productions, and the commercial success of the work.</source>
        <translation>Persona o organització responsable de fer una pel·lícula incloent-ne els aspectes financers, la gestió de la producció i l&apos;èxit comercial de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="301"/>
        <source>Production company</source>
        <translation>Empresa productora</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="301"/>
        <source>An organization that is responsible for financial, technical, and organizational management of a production for stage, screen, audio recording, television, webcast, etc.</source>
        <translation>Organització responsable de la gestió financera, tècnica i organitzativa d&apos;una producció escènica, audiovisual, enregistrament d&apos;àudio, televisió, difusió web, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="302"/>
        <source>Production designer</source>
        <translation>Dissenyador de producció</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="302"/>
        <source>A person or organization responsible for designing the overall visual appearance of a moving image production.</source>
        <translation>Persona o organització responsable del disseny de l&apos;aspecte visual general d&apos;una producció cinematogràfica.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="303"/>
        <source>Production manager</source>
        <translation>Director de producció</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="303"/>
        <source>Use for a person responsible for all technical and business matters in a production.</source>
        <translation>Persona responsable de totes les qüestions tècniques i financeres d&apos;una producció.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="304"/>
        <source>Production personnel</source>
        <translation>Personal de producció</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="304"/>
        <source>Use for a person or organization associated with the production (props, lighting, special effects, etc.) of a musical or dramatic presentation or entertainment.</source>
        <translation>Persona o organització associada amb la producció (utillatge, il·luminació, efectes especials, etc.) d&apos;una representació musical, dramàtica o d&apos;entreteniment.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="305"/>
        <source>Production place</source>
        <translation>Lloc de producció</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="305"/>
        <source>The place of production (e.g., inscription, fabrication, construction, etc.) of a resource in an unpublished form.</source>
        <translation>Lloc de producció (per exemple, inscripció, fabricació, construcció, etc.) d&apos;un recurs en forma no publicada.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="306"/>
        <source>Programmer</source>
        <translation>Programador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="306"/>
        <source>Use for a person or organization responsible for the creation and/or maintenance of computer program design documents, source code, and machine-executable digital files and supporting documentation.</source>
        <translation>Persona o organització responsable de la creació o el manteniment del disseny, codi font, fitxers executables i documentació dels programes d&apos;ordinador.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="307"/>
        <source>Project director</source>
        <translation>Director del projecte</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="307"/>
        <source>Use for a person or organization with primary responsibility for all essential aspects of a project, or that manages a very large project that demands senior level responsibility, or that has overall responsibility for managing projects, or provides overall direction to a project manager.</source>
        <translation>Persona o organització amb responsabilitat principal en tots els aspectes d&apos;un projecte, o que gestiona projectes molt grans que requereixen un nivell de responsabilitat superior, o que te responsabilitat general en la gestió de projectes, o que du a terme la direcció general sobre el gestor del projecte.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="308"/>
        <source>Proofreader</source>
        <translation>Corrector de proves</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="308"/>
        <source>Use for a person who corrects printed matter. For manuscripts, use Corrector [crr].</source>
        <translation>Persona que corregeix proves d&apos;impressió. Per a manuscrits, feu servir «Corrector» [crr].</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="309"/>
        <source>Provider</source>
        <translation>Proveïdor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="309"/>
        <source>A person or organization who produces, publishes, manufactures, or distributes a resource if specific codes are not desired (e.g. [mfr], [pbl].)</source>
        <translation>Persona o organització que produeix, publica, fabrica o distribueix un recurs (si no es volen fer servir altres codis més específics com ara, [mfr], [pbl].)</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="310"/>
        <source>Publication place </source>
        <translation>Lloc de publicació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="310"/>
        <source>The place where a resource is published.</source>
        <translation>Lloc on es publica un recurs.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="311"/>
        <source>Publisher</source>
        <translation>Editorial</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="311"/>
        <source>Use for a person or organization that makes printed matter, often text, but also printed music, artwork, etc. available to the public.</source>
        <translation>Persona o organització que imprimeix materials i els posa a l&apos;abast del públic, generalment text però també música, il·lustracions, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="312"/>
        <source>Publishing director</source>
        <translation>Director editorial</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="312"/>
        <source>Use for a person or organization who presides over the elaboration of a collective work to ensure its coherence or continuity. This includes editors-in-chief, literary editors, editors of series, etc.</source>
        <translation>Persona o organització que encapçala l&apos;elaboració d&apos;una obra col·lectiva per assegurar-ne la coherència o la continuïtat. Inclou els caps de redacció, els editors literaris, els editors de sèries, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="313"/>
        <source>Puppeteer</source>
        <translation>Titellaire</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="313"/>
        <source>Use for a person or organization who manipulates, controls, or directs puppets or marionettes in a musical or dramatic presentation or entertainment.</source>
        <translation>Persona o organització que manipula, controla o dirigeix titelles en una representació musical, dràmatica o d&apos;entreteniment.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="314"/>
        <source>Radio director</source>
        <translation>Director radiofònic</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="314"/>
        <source>A director responsible for the general management and supervision of a radio program.</source>
        <translation>Director responsable de la gestió general i de la supervisió d&apos;un programa de ràdio.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="315"/>
        <source>Radio producer</source>
        <translation>Productor radiofònic</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="315"/>
        <source>A producer responsible for most of the business aspects of a radio program.</source>
        <translation>Productor responsable de la majoria dels aspectes econòmics d&apos;un programa de ràdio.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="316"/>
        <source>Recipient</source>
        <translation>Destinatari</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="316"/>
        <source>Use for a person or organization to whom correspondence is addressed.</source>
        <translation>Persona o organització a qui s&apos;adreça la correspondència.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="317"/>
        <location filename="../../Misc/MarcRelators.cpp" line="318"/>
        <source>Recording engineer</source>
        <translation>Enginyer de gravació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="317"/>
        <source>Use for a person or organization who supervises the technical aspects of a sound or video recording session.</source>
        <translation>Persona o organització que supervisa els aspectes tècnics d&apos;una sessió d&apos;enregistrament de vídeo o d&apos;àudio.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="318"/>
        <source>A person contributing to a resource by supervising the technical aspects of a sound or video recording session.</source>
        <translation>Persona que contribueix a un recurs supervisant els aspectes tècnics d&apos;una sessió d&apos;enregistrament de so o de vídeo.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="319"/>
        <source>Redactor</source>
        <translation>Redactor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="319"/>
        <source>Use for a person or organization who writes or develops the framework for an item without being intellectually responsible for its content.</source>
        <translation>Persona o organització que escriu o desenvolupa la trama d&apos;un assumpte sense ser-ne el responsable intel·lectual del contingut.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="320"/>
        <source>Renderer</source>
        <translation>Representador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="320"/>
        <source>Use for a person or organization who prepares drawings of architectural designs (i.e., renderings) in accurate, representational perspective to show what the project will look like when completed.</source>
        <translation>Persona o organització que prepara dibuixos de dissenys arquitectònics (representacions) amb una representació acurada en perspectiva per tal de mostrar l&apos;aspecte final del projecte.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="321"/>
        <source>Reporter</source>
        <translation>Reporter</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="321"/>
        <source>Use for a person or organization who writes or presents reports of news or current events on air or in print.</source>
        <translation>Persona o organització que escriu o presenta reportatges de notícies o successos.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="322"/>
        <source>Repository</source>
        <translation>Dipòsit</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="322"/>
        <source>Use for an agency that hosts data or material culture objects and provides services to promote long term, consistent and shared use of those data or objects.</source>
        <translation>Organisme que custodia dades o objectes físics culturals i proporciona serveis per promoure&apos;n l&apos;ús continuat, compartit i coherent.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="323"/>
        <source>Research team head</source>
        <translation>Cap de l&apos;equip d&apos;investigació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="323"/>
        <source>Use for a person who directed or managed a research project.</source>
        <translation>Persona que dirigeix o gestiona un projecte de recerca.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="324"/>
        <source>Research team member</source>
        <translation>Membre de l&apos;equip d&apos;investigació</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="324"/>
        <source>Use for a person who participated in a research project but whose role did not involve direction or management of it.</source>
        <translation>Persona que participa en un projecte de recerca amb una funció que no n&apos;inclou la direcció o la gestió.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="325"/>
        <source>Researcher</source>
        <translation>Investigador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="325"/>
        <source>Use for a person or organization responsible for performing research. </source>
        <translation>Persona o organització que es decica a fer investigació.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="326"/>
        <source>Respondent</source>
        <translation>Demandat contestador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="326"/>
        <source>Use for the party who makes an answer to the courts pursuant to an application for redress, usually in an equity proceeding.</source>
        <translation>Part que presenta una resposta als tribunals com a conseqüència d&apos;una sol·licitud de reparació, normalment en un procés d&apos;equitat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="327"/>
        <source>Respondent-appellant</source>
        <translation>Demandat contestador apel·lant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="327"/>
        <source>Use for a respondent who takes an appeal from one court or jurisdiction to another to reverse the judgment, usually in an equity proceeding.</source>
        <translation>Demandat contestatdor que presenta una apel·lació a un altre tribunal o jurisdicció per tal de revocar una sentència, normalment en un procés d&apos;equitat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="328"/>
        <source>Respondent-appellee</source>
        <translation>Demandat contestador apel·lat</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="328"/>
        <source>Use for a respondent against whom an appeal is taken from one court or jurisdiction to another to reverse the judgment, usually in an equity proceeding.</source>
        <translation>Demandat contestatdor en contra del qual es presenta una apel·lació a un altre tribunal o jurisdicció per tal de revocar una sentència, normalment en un procés d&apos;equitat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="329"/>
        <source>Responsible party</source>
        <translation>Part responsable</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="329"/>
        <source>Use for a person or organization legally responsible for the content of the published material.</source>
        <translation>Persona o organització legalment responsable del contingut del material publicat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="330"/>
        <source>Restager</source>
        <translation>Reescenificador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="330"/>
        <source>Use for a person or organization, other than the original choreographer or director, responsible for restaging a choreographic or dramatic work and who contributes minimal new content.</source>
        <translation>Persona o organització, diferents del coreògraf o del director originals, responsables de tornar a escenificar una obra dramàtica o coreogràfica i que hi contribueix amb un contingut nou mínim.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="331"/>
        <source>Restorationist</source>
        <translation>Restaurador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="331"/>
        <source>A person, family, or organization responsible for the set of technical, editorial, and intellectual procedures aimed at compensating for the degradation of an item by bringing it back to a state as close as possible to its original condition.</source>
        <translation>Persona, família o organització responsable del conjunt de processos tècnics editorials i intel·lectuals adreçats a contrarestar la degradació d&apos;un ítem mirant de deixar-lo en un estat tan semblant com sigui possible a la seva condició original.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="332"/>
        <source>Reviewer</source>
        <translation>Crític</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="332"/>
        <source>Use for a person or organization responsible for the review of a book, motion picture, performance, etc.</source>
        <translation>Persona o organització responsable de la ressenya o crítica d&apos;un llibre, pel·lícula cinematogràfica, representació, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="333"/>
        <source>Rubricator</source>
        <translation>Rubricador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="333"/>
        <source>Use for a person or organization responsible for parts of a work, often headings or opening parts of a manuscript, that appear in a distinctive color, usually red.</source>
        <translation>Persona o organització responsable de parts d&apos;una obra, generalment capçaleres o els títols d&apos;un manuscrit que apareixen en un color diferent, normalment vermell.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="334"/>
        <source>Scenarist</source>
        <translation>Guionista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="334"/>
        <source>Use for a person or organization who is the author of a motion picture screenplay.</source>
        <translation>Persona o organització autora d&apos;un guió cinematogràfic.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="335"/>
        <source>Scientific advisor</source>
        <translation>Assessor científic</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="335"/>
        <source>Use for a person or organization who brings scientific, pedagogical, or historical competence to the conception and realization on a work, particularly in the case of audio-visual items.</source>
        <translation>Persona o organització que aporta el seu coneixement científic, pedagògic o històric a la concepció i a la realització d&apos;una obra, especialment si es tracta d&apos;una obra audiovisual.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="336"/>
        <source>Scribe</source>
        <translation>Copista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="336"/>
        <source>Use for a person who is an amanuensis and for a writer of manuscripts proper. For a person who makes pen-facsimiles, use Facsimilist [fac].</source>
        <translation>Amanuense o escriptor de manuscrits polits. La persona que fa facsímils a mà s&apos;anomena «Autor de facsímils» [fac].</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="337"/>
        <source>Sculptor</source>
        <translation>Escultor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="337"/>
        <source>Use for a person or organization who models or carves figures that are three-dimensional representations.</source>
        <translation>Persona o organització que esculpeix figures que són representacions tridimensionals.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="338"/>
        <source>Second party</source>
        <translation>Segona part</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="338"/>
        <source>Use for a person or organization who is identified as the party of the second part. In the case of transfer of right, this is the assignee, transferee, licensee, grantee, etc. Multiple parties can be named jointly as the second party.</source>
        <translation>Persona o organització identificada com a segona part. En cas de transferència de drets, és el concessionari o destinatari, etc. La segona part pot estar formada per més d&apos;una entitat.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="339"/>
        <source>Secretary</source>
        <translation>Secretari</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="339"/>
        <source>Use for a person or organization who is a recorder, redactor, or other person responsible for expressing the views of a organization.</source>
        <translation>Persona o organització que enregistra, redacta o és potaveu dels punts de vista de l&apos;organització.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="340"/>
        <source>Seller</source>
        <translation>Venedor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="340"/>
        <source>A former owner of an item who sold that item to another owner.</source>
        <translation>Antic propietari d&apos;un objecte venut a un nou propietari.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="341"/>
        <source>Set designer</source>
        <translation>Escenògraf</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="341"/>
        <source>Use for a person or organization who translates the rough sketches of the art director into actual architectural structures for a theatrical presentation, entertainment, motion picture, etc. Set designers draw the detailed guides and specifications for building the set.</source>
        <translation>Persona o organització que interpreta els esbossos del director artístic per tal de construir les estructures físiques reals d&apos;una representació teatral, d&apos;entreteniment, pel·lícula, etc. Els escenògrafs creen els esquemes detallats i les especificacions per construir els decorats.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="342"/>
        <source>Setting</source>
        <translation>Entorn</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="342"/>
        <source>An entity in which the activity or plot of a work takes place, e.g. a geographic place, a time period, a building, an event.</source>
        <translation>Entitat dins la qual té lloc l&apos;activitat o la trama de l&apos;obra, per exemple un indret geogràfic, un període de temps, un edifici, un esdeveniment.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="343"/>
        <source>Signer</source>
        <translation>Signant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="343"/>
        <source>Use for a person whose signature appears without a presentation or other statement indicative of provenance. When there is a presentation statement, use Inscriber [ins].</source>
        <translation>Persona la signatura de la qual apareix sense cap indicació de procedència o d&apos;oferiment. Si hi ha una declaració d&apos;oferiment, feu servir «Inscriptor» [ins].</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="344"/>
        <source>Singer</source>
        <translation>Cantant</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="344"/>
        <source>Use for a person or organization who uses his/her/their voice with or without instrumental accompaniment to produce music. A performance may or may not include actual words.</source>
        <translation>Persona o orgnaització que fa servir la seva veu, amb o sense acompanyament instrumental, per fer música. Una representació pot incloure o no paraules reals.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="345"/>
        <source>Sound designer</source>
        <translation>Dissenyador de so</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="345"/>
        <source>Use for a person who produces and reproduces the sound score (both live and recorded), the installation of microphones, the setting of sound levels, and the coordination of sources of sound for a production.</source>
        <translation>Persona que produeix i reprodueix la banda sonora (en directe o enregistrada), que instal·la els micròfons, que ajusta els nivells de so i que coordina les fonts de so en una producció.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="346"/>
        <source>Speaker</source>
        <translation>Orador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="346"/>
        <source>Use for a person who participates in a program (often broadcast) and makes a formalized contribution or presentation generally prepared in advance.</source>
        <translation>Persona que participa en un programa (normalment retransmès) i fa una contribució formal o una presentació generalment no improvisada.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="347"/>
        <source>Sponsor</source>
        <translation>Patrocinador</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="347"/>
        <source>Use for a person or organization that issued a contract or under the auspices of which a work has been written, printed, published, etc.</source>
        <translation>Persona o organització que facilita un contracte que permet o afavoreix l&apos;escriptura, o la impressió, o la publicació, etc. d&apos;una obra.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="348"/>
        <source>Stage director</source>
        <translation>Director d&apos;escena</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="348"/>
        <source>A person or organization contributing to a stage resource through the overall management and supervision of a performance.</source>
        <translation>Persona o organització que contribueix amb un recurs escènic fent la gestió i la supervisió general de la representació.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="349"/>
        <source>Stage manager</source>
        <translation>Regidor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="349"/>
        <source>Use for a person who is in charge of everything that occurs on a performance stage, and who acts as chief of all crews and assistant to a director during rehearsals.</source>
        <translation>Persona encarregada de tot allò que passa en escena durant una representació i que actua com a cap de tots els equips i com a ajudant del director en els assajos.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="350"/>
        <source>Standards body</source>
        <translation>Organisme de normalització</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="350"/>
        <source>Use for an organization responsible for the development or enforcement of a standard.</source>
        <translation>Organització responsable del desenvolupar o de fer complir d&apos;un estàndard.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="351"/>
        <source>Stereotyper</source>
        <translation>Estereotipista</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="351"/>
        <source>Use for a person or organization who creates a new plate for printing by molding or copying another printing surface.</source>
        <translation>Persona o organització que crea una planxa d&apos;impressió nova a partir d&apos;una altra superfície d&apos;impressió mitjançant motlle o còpia.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="352"/>
        <source>Storyteller</source>
        <translation>Conta contes</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="352"/>
        <source>Use for a person relaying a story with creative and/or theatrical interpretation.</source>
        <translation>Persona que narra contes amb una interpretació creativa o teatral.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="353"/>
        <source>Supporting host</source>
        <translation>Anfitrió</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="353"/>
        <source>Use for a person or organization that supports (by allocating facilities, staff, or other resources) a project, program, meeting, event, data objects, material culture objects, or other entities capable of support. </source>
        <translation>Persona o organització que dóna suport (amb instal·lacions, personal o altres medis) a un projecte, programa, reunió, esdeveniment, objecte de dades, objecte cultural físic, o qualsevol altra entitat que pugui rebre suport.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="354"/>
        <source>Surveyor</source>
        <translation>Topògraf</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="354"/>
        <source>Use for a person or organization who does measurements of tracts of land, etc. to determine location, forms, and boundaries.</source>
        <translation>Persona o organització que mesura els terrenys per tal de determinar-ne les ubicacions, les formes i els límits.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="355"/>
        <source>Teacher</source>
        <translation>Mestre</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="355"/>
        <source>Use for a person who, in the context of a resource, gives instruction in an intellectual subject or demonstrates while teaching physical skills. </source>
        <translation>Persona que, en el context d&apos;un recurs, instrueix una matèria intel·lectual o ensenya a fer una habilitat física.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="356"/>
        <source>Technical director</source>
        <translation>Director tècnic</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="356"/>
        <source>Use for a person who is ultimately in charge of scenery, props, lights and sound for a production.</source>
        <translation>Responsable general dels decorats, l&apos;utillatge, les llums i el so d&apos;una producció.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="357"/>
        <source>Television director</source>
        <translation>Director de televisió</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="357"/>
        <source>A director responsible for the general management and supervision of a television program.</source>
        <translation>Director responsable de la gestió general i de la supervisió d&apos;un programa de televisió.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="358"/>
        <source>Television producer</source>
        <translation>Productor de televisió</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="358"/>
        <source>A producer responsible for most of the business aspects of a television program.</source>
        <translation>Productor responsable de la majoria dels temes econòmics d&apos;un programa de televisió.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="359"/>
        <source>Thesis advisor</source>
        <translation>Director de la tesi</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="359"/>
        <source>Use for a person under whose supervision a degree candidate develops and presents a thesis, mémoire, or text of a dissertation. </source>
        <translation>Persona que sota la seva supervisió d&apos;un canditat a grau, redacta i presenta una tesi, memòria, o dissertació.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="360"/>
        <source>Transcriber</source>
        <translation>Transcriptor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="360"/>
        <source>Use for a person who prepares a handwritten or typewritten copy from original material, including from dictated or orally recorded material. For makers of pen-facsimiles, use Facsimilist [fac].</source>
        <translation>Persona que prepara una còpia, manuscrita o tipogràfica, d&apos;un original, incloent materials dictats oralment o enregistrats. Els autors de facsímils manuals usen el codi [fac].</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="361"/>
        <source>Translator</source>
        <translation>Traductor</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="361"/>
        <source>Use for a person or organization who renders a text from one language into another, or from an older form of a language into the modern form.</source>
        <translation>Persona o organització que tradueix un text d&apos;una llengua a una altra, o d&apos;una forma antiga d&apos;una llengüa a la forma moderna.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="362"/>
        <source>Type designer</source>
        <translation>Diseñador tipogràfic</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="362"/>
        <source>Use for a person or organization who designed the type face used in a particular item. </source>
        <translation>Persona o organització que ha dissenyat el tipus de lletra d&apos;un objecte concret.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="363"/>
        <source>Typographer</source>
        <translation>Tipògraf</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="363"/>
        <source>Use for a person or organization primarily responsible for choice and arrangement of type used in an item. If the typographer is also responsible for other aspects of the graphic design of a book (e.g., Book designer [bkd]), codes for both functions may be needed.</source>
        <translation>Persona o organització que es dedica principalment a triar i organitzar la tipografia d&apos;un objecte. Si el tipògraf també és responsable d&apos;altres aspectes del disseny gràfic d&apos;un llibre (per exemple, «Dissenyador del libre [bkd]»), es poden posar els codis de les dues funcions.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="364"/>
        <source>University place</source>
        <translation>Lloc de la universitat</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="364"/>
        <source>A place where a university that is associated with a resource is located, for example, a university where an academic dissertation or thesis was presented.</source>
        <translation>Lloc on és situada la universitat associada al recurs, per exemple la universitat o es presenta una dissertació acadèmica o una tesi.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="365"/>
        <source>Videographer</source>
        <translation>Productor de vídeo</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="365"/>
        <source>Use for a person or organization in charge of a video production, e.g. the video recording of a stage production as opposed to a commercial motion picture. The videographer may be the camera operator or may supervise one or more camera operators. Do not confuse with cinematographer.</source>
        <translation>Persona o organització encarregada de la producció de vídeo; per exemple, l&apos;enregistrament de vídeo d&apos;una representació escènica en contraposició a una pel·lícula comercial. Pot ser l&apos;operador de càmera o supervisar un o més operadors de càmera. No s&apos;ha de conforndre amb el director de fotografia.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="366"/>
        <source>Voice actor</source>
        <translation>Actor de veu</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="366"/>
        <source>An actor contributing to a resource by providing the voice for characters in radio and audio productions and for animated characters in moving image works, as well as by providing voice overs in radio and television commercials, dubbed resources, etc.</source>
        <translation>Actor que contribueix amb un recurs posant veu als personatges d&apos;una producció radiofònica o d&apos;àudio, o doblant personatges animats d&apos;una obra cinematogràfica, o posant la veu de fons en anuncis de ràdio o televisió, doblatge, etc.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="367"/>
        <source>Witness</source>
        <translation>Testimoni</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="367"/>
        <source>Use for a person who verifies the truthfulness of an event or action. </source>
        <translation>Persona que confirma la veracitat d&apos;un esdeveniment o d&apos;una acció.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="368"/>
        <source>Wood-engraver</source>
        <translation>Xilògraf (a contrafibra)</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="368"/>
        <source>Use for a person or organization who makes prints by cutting the image in relief on the end-grain of a wood block.</source>
        <translation>Persona o organització que imprimeix gravant en relleu sobre una superfície perpendicular a la fibra d&apos;un bloc de fusta.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="369"/>
        <source>Woodcutter</source>
        <translation>Xilògraf (a fibra)</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="369"/>
        <source>Use for a person or organization who makes prints by cutting the image in relief on the plank side of a wood block.</source>
        <translation>Persona o organització que imprimeix gravant en relleu sobre una superfície paral·lela a la fibra d&apos;un bloc de fusta.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="370"/>
        <source>Writer of accompanying material</source>
        <translation>Autor del text addicional</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="370"/>
        <source>Use for a person or organization who writes significant material which accompanies a sound recording or other audiovisual material.</source>
        <translation>Persona o organització que escriu el material significatiu que acompanya un enregistrament de so o altres tipus de material audiovisual.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="371"/>
        <source>Writer of added commentary</source>
        <translation>Redactor de comentaris addicionals</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="371"/>
        <source>A person, family, or organization contributing to an expression of a work by providing an interpretation or critical explanation of the original work.</source>
        <translation>Persona, família o organització que contribueix amb el contingut d&apos;un recurs redactant una interpretació o una explicació crítica de l&apos;obra original.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="372"/>
        <source>Writer of added lyrics</source>
        <translation>Redactor de lletres addicionals</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="372"/>
        <source>A writer of words added to an expression of a musical work. For lyric writing in collaboration with a composer to form an original work, see lyricist.</source>
        <translation>Redactor de lletres afegides al contingut d&apos;una obra musical. Per indicar la persona que escriu lletres col·laborant amb el compositor, vegeu «Lletrista».</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="373"/>
        <source>Writer of added text</source>
        <translation>Redactor de textos addicionals</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="373"/>
        <source>A person, family, or organization contributing to a non-textual resource by providing text for the non-textual work (e.g., writing captions for photographs, descriptions of maps.)</source>
        <translation>Persona, família o organització que contribueix a un recurs no textual redactant textos per l&apos;obra no textual (per exemple, escrivint els peus de fotografia o les descripcions dels mapes.)</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="374"/>
        <source>Writer of introduction</source>
        <translation>Redactor de la introducció</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="374"/>
        <source>A person, family, or organization contributing to a resource by providing an introduction to the original work.</source>
        <translation>Persona, família o organització que contribueix amb el recurs redactant la introducció de l&apos;obra original.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="375"/>
        <source>Writer of preface</source>
        <translation>Redactor del prefaci</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="375"/>
        <source>A person, family, or organization contributing to a resource by providing a preface to the original work.</source>
        <translation>Persona, família o organització que contribueix amb el recurs redactant el prefaci de l&apos;obra original.</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="376"/>
        <source>Writer of supplementary textual content</source>
        <translation>Redactor de contingut textual suplementari</translation>
    </message>
    <message>
        <location filename="../../Misc/MarcRelators.cpp" line="376"/>
        <source>A person, family, or organization contributing to a resource by providing supplementary textual content (e.g., an introduction, a preface) to the original work.</source>
        <translation>Persona, família o organització que contribueix amb el recurs redactant continguts textuals suplementaris (per exemple la introducció o el prefaci) de l&apos;obra original.</translation>
    </message>
</context>
<context>
    <name>MetaEditor</name>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="20"/>
        <source>MetaData Editor</source>
        <translation>Editor de metadades</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="52"/>
        <source>Add a new metadata element.</source>
        <translation>Afegeix un element nou de metadades.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="55"/>
        <source>Add Metadata</source>
        <translation>Afegeix metadades</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="62"/>
        <source>Remove a metadata element or property.</source>
        <translation>Elimina un element o propietat de metadades.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="65"/>
        <source>Remove</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="72"/>
        <source>Add a new property or attribute to an existing metadata element.</source>
        <translation>Afegeix una propietat o un atribut nou a un element de metadades que ja existia.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="75"/>
        <source>Add Property</source>
        <translation>Afegeix propietat</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="97"/>
        <source>Move selected metadata element or property up.</source>
        <translation>Mou l&apos;element o la propietat de metadades seleccionada cap amunt.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="100"/>
        <location filename="../../Form_Files/MetaEditor.ui" line="113"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="110"/>
        <source>Move selected metadata element or property down.</source>
        <translation>Mou l&apos;element o la propietat de metadades seleccionada cap avall.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="148"/>
        <source>Double-click in cell to edit its value.  Minimum metadata consists of main language, title, and at least one creator.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Form_Files/MetaEditor.ui" line="172"/>
        <source>Use OK to commit your metdata changes to the epub, otherwise use Cancel.</source>
        <translation>Cliqueu «D&apos;acord» per acceptar els canvis a les metadades de l&apos;EPUB, altrament, cliqueu «Cancel·la».</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="52"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="52"/>
        <source>Value</source>
        <translation>Valor</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="171"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="234"/>
        <source>[ISBN here]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="175"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="239"/>
        <source>[ISSN here]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="179"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="244"/>
        <source>[DOI here]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="183"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="249"/>
        <source>[UUID here]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="194"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="267"/>
        <source>[Author name here]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="200"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="272"/>
        <source>[Creator name here]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="204"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="276"/>
        <source>[Contributor name here]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="254"/>
        <source>[Custom identifier here]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="443"/>
        <source>[Place value here]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="478"/>
        <source>[Your value here]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="542"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="644"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="542"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="644"/>
        <source>Represents a primary author of the book or publication</source>
        <translation>Representa l&apos;autor principal del llibre o de la publicació.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="543"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="648"/>
        <source>Subject</source>
        <translation>Matèria</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="543"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="648"/>
        <source>An arbitrary phrase or keyword describing the subject in question. Use multiple &apos;subject&apos; elements if needed.</source>
        <translation>Frase o paraula clau arbitrària que descriu el tema o l&apos;assumpte tractat.
Si cal, podeu fer servis més d&apos;un element «Tema».</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="544"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="649"/>
        <source>Description</source>
        <translation>Descripció</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="544"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="649"/>
        <source>Description of the publication&apos;s content.</source>
        <translation>Descripció del contingut de la publicació.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="545"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="650"/>
        <source>Publisher</source>
        <translation>Editorial</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="545"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="650"/>
        <source>An entity responsible for making the publication available.</source>
        <translation>Persona, organització, o servei responsables de fer disponible el recurs i proporcionar-ne accés.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="546"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="651"/>
        <source>Date: Publication</source>
        <translation>Data: Publicació</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="546"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="651"/>
        <source>The date of publication.</source>
        <translation>Data de la publicació de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="547"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="652"/>
        <source>Date: Creation</source>
        <translation>Data: Creació</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="547"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="652"/>
        <source>The date of creation.</source>
        <translation>Data de la creació de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="548"/>
        <source>Date: Issued</source>
        <translation>Data: publicació</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="548"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="549"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="653"/>
        <source>The date of modification.</source>
        <translation>Data de la modificació de l&apos;obra.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="549"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="653"/>
        <source>Date: Modification</source>
        <translation>Data: Modificació</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="550"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="654"/>
        <source>Type</source>
        <translation>Gènere</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="550"/>
        <source>Used to indicate that the given EPUB Publication is of a specialized type..</source>
        <translation>Indica que la publicació EPUB a la qual fa referència es de tipus especialitzat.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="551"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="655"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="551"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="655"/>
        <source>The media type or dimensions of the publication. Best practice is to use a value from a controlled vocabulary (e.g. MIME media types).</source>
        <translation>Format del fitxer, suport físic, o dimensions del recurs.
Es recomana usar un vocabulari controlat, per exemple, la llista de Internet Media Types (MIME).</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="552"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="656"/>
        <source>Source</source>
        <translation>Font</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="552"/>
        <source>Identifies the related resource(s) from which this EPUB Publication is derived.</source>
        <translation>Identifica els recursos relacionats dels quals se&apos;n deriva la publicació EPUB.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="553"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="657"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="553"/>
        <source>Specifies the language of the publication. Select from the dropdown menu</source>
        <translation>Especifica l&apos;idioma de la publicació. Se selecciona al menú desplegable.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="554"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="658"/>
        <source>Relation</source>
        <translation>Relació</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="554"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="658"/>
        <source>A reference to a related resource. The recommended best practice is to identify the referenced resource by means of a string or number conforming to a formal identification system.</source>
        <translation>Referència a un recurs relacionat.
Una bona pràctica és identificar el recurs mitjançant una sèrie de lletres o números d&apos;acord amb un sistema d&apos;identificació formal.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="555"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="659"/>
        <source>Coverage</source>
        <translation>Abast</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="555"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="659"/>
        <source>The extent or scope of the content of the publication&apos;s content.</source>
        <translation>Extensió o abast del contingut de la publicació.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="556"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="660"/>
        <source>Rights</source>
        <translation>Drets</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="556"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="660"/>
        <source>Information about rights held in and over the publication. Rights information often encompasses Intellectual Property Rights (IPR), Copyright, and various Property Rights. If the Rights element is absent, no assumptions may be made about any rights held in or over the publication.</source>
        <translation>Informació sobre els drets legals que afecten l&apos;obra.
Normalment, inclou els drets de propietat intel·lectual, el copyright i altres drets de propietat.
El fet que no s&apos;indiqui cap dret no vol dir que la publicació no en tingui.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="557"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="646"/>
        <source>Creator</source>
        <translation>Creador</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="557"/>
        <source>Represents the name of a person, organization, etc. responsible for the creation of the content of an EPUB Publication. The role property can be attached to the element to indicate the function the creator played in the creation of the content.</source>
        <translation>Representa el nom de la persona o de la organització responsable de la creació del contingut de la publicació EPUB. El rol propietat es pot adjuntar a l&apos;element per tal d&apos;indicar la funció que va exercir el creador en la creació del contingut.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="558"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="647"/>
        <source>Contributor</source>
        <translation>Contribuïdor</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="558"/>
        <source>Represents the name of a person, organization, etc. that played a secondary role in the creation of the content of an EPUB Publication. The role property can be attached to the element to indicate the function the creator played in the creation of the content.</source>
        <translation>Representa el nom de la persona, de la organització, etc. que va exercir un paper secundari en la creació del contingut de la publicació EPUB. El rol propietat es pot adjuntar a l&apos;element per tal d&apos;indicar la funció que va exercir el creador en la creació del contingut.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="559"/>
        <source>Belongs to Collection</source>
        <translation>Col·lecció a la qual pertany</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="559"/>
        <source>Identifies the name of a collection to which the EPUB Publication belongs. An EPUB Publication may belong to one or more collections.</source>
        <translation>Identifica el nom de la col·lecció a la qual la publicació EPUB pertany. Una publicació EPUB por pertànyer a una o a més col·leccions.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="560"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="645"/>
        <source>Title</source>
        <translation>Títol</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="560"/>
        <source>A title of the publication.  A publication may have only one main title but may have numerous other title types.  These include main, subtitle, short, collection, edition, and expanded title types.</source>
        <translation>Un dels títols de la publicació. Una publicació només pot tenir un títol principal però pot tenir uns quants títols d&apos;altre tipus. Principal, subtítol, escurçat, col·lecció, edició i títol ampliat són tipus de títol.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="561"/>
        <source>Identifier: DOI</source>
        <translation>Identificador: DOI</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="561"/>
        <source>Digital Object Identifier associated with the given EPUB publication.</source>
        <translation>Identificador d&apos;objecte digital (DOI) associat a la publicació EPUB.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="562"/>
        <source>Identifier: ISBN</source>
        <translation>Identificador: ISBN</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="562"/>
        <source>International Standard Book Number associated with the given EPUB publication.</source>
        <translation>Número internacional normalitzat per a llibres (ISBN) associat a la publicació EPUB.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="563"/>
        <source>Identifier: ISSN</source>
        <translation>Identificador: ISSN</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="563"/>
        <source>International Standard Serial Number associated with the given EPUB publication.</source>
        <translation>Número internacional normalitzat per a publicacions en sèrie (ISSN) associat a la publicació EPUB.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="564"/>
        <source>Identifier: UUID</source>
        <translation>Identificador: UUID</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="564"/>
        <source>A Universally Unique Idenitifier generated for this EPUB publication.</source>
        <translation>Identificador únic universal (UUID) generat per a la publicació EPUB.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="566"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="669"/>
        <source>Custom Element</source>
        <translation>Element personalitzat</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="566"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="669"/>
        <source>[Custom element]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="566"/>
        <source>An empty metadata element you can modify.</source>
        <translation>Un element de metadades buit que es pot modificar.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="593"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="696"/>
        <source>Id Attribute</source>
        <translation>Atribut ID</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="593"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="696"/>
        <source>Optional, typically short, unique identifier string used as an attribute in the Package (opf) document.</source>
        <translation>Opcional, normalment una cadena de text curta, identificador únic usat com a atribut al paquet del document (OPF).</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="594"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="697"/>
        <source>XML Language</source>
        <translation>Llenguatge XML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="594"/>
        <source>Optional, language specifying attribute.  Uses same codes as dc:language. Not for use with dc:langauge, dc:date, or dc:identifier metadata elements.</source>
        <translation>Atribut opcional d&apos;especificació d&apos;idioma. Fa servir els mateixos codis que dc:idioma. No s&apos;ha d&apos;usar amb els elements de metadades dc:idioma, dc:data o dc:identificador.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="595"/>
        <source>Text Direction: rtl</source>
        <translation>Sentit del text, de dreta a esquerra</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="595"/>
        <source>Optional text direction attribute for this metadata item. right-to-left (rtl). Not for use with dc:language, dc:date, or dc:identifier metadata elements.</source>
        <translation>Atribut opcional de sentit del text d&apos;aquest ítem de metadades. De dreta a esquerra. No s&apos;ha d&apos;usar amb els elements de metadades dc:idioma, dc:data o dc:identificador.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="596"/>
        <source>Text Direction: ltr</source>
        <translation>Sentit del text, d&apos;esquerra a dreta</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="596"/>
        <source>Optional text direction attribute for this metadata item. left-to-right (ltr). Not for use with dc:language, dc:date, or dc:identifier metadata elements.</source>
        <translation>Atribut opcional de sentit del text d&apos;aquest ítem de metadades. D&apos;esquerra a dreta. No s&apos;ha d&apos;usar amb els elements de metadades dc:idioma, dc:data o dc:identificador.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="597"/>
        <source>Title Type: main</source>
        <translation>Tipus de títol; principal</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="597"/>
        <source>Indicates the associated title is the main title of the publication.  Only one main title should exist.</source>
        <translation>Indica que el títol associat és el títol principal de l&apos;obra; només n&apos;hi pot haver un, de títol principal.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="598"/>
        <source>Title Type: subtitle</source>
        <translation>Tipus de títol; subtítol</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="598"/>
        <source>Indicates that the associated title is a subtitle of the publication if one exists..</source>
        <translation>Indica que el títol associat és un subtítol de la publicació, si n&apos;hi ha.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="599"/>
        <source>Title Type: short</source>
        <translation>Tipus de títol; escurçat</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="599"/>
        <source>Indicates that the associated title is a shortened title of the publication if one exists.</source>
        <translation>Indica que el títol associat és un títol escurçat de la publicació, si n&apos;hi ha.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="600"/>
        <source>Title Type: collection</source>
        <translation>Tipus de títol; col·lecció</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="600"/>
        <source>Indicates that the associated title is the title of a collection that includes this publication belongs to, if one exists.</source>
        <translation>Indica que el títol associat és el títol d&apos;una col·lecció a la que pertany aquesta publicació.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="601"/>
        <source>Title Type: edition</source>
        <translation>Tipus de títol; edició</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="601"/>
        <source>Indicates that the associated title is an edition title for this publications if one exists.</source>
        <translation>Indica que el títol associat és un títol d&apos;edició de la publicació, si n&apos;hi ha algun.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="602"/>
        <source>Title Type: expanded</source>
        <translation>Tipus de títol; ampliat</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="602"/>
        <source>Indicates that the associated title is an expanded title for this publication if one exists.</source>
        <translation>Indica que el títol associat és un títol ampliat de la publicació, si n&apos;hi ha algun.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="603"/>
        <source>Alternate Script</source>
        <translation>Sistema d&apos;escriptura alternatiu</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="603"/>
        <source>Provides an alternate expression of the associated property value in a language and script identified by an alternate-language attribute.</source>
        <translation>Indica una expressió alternativa del valor de la propietat associada en un idioma i un sistema d&apos;escriptura identificat per un atribut d&apos;idioma alternatiu.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="604"/>
        <source>Alternate Language</source>
        <translation>Idioma alternatiu</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="604"/>
        <source>Language code for the language used in the associated alternate-script property value.</source>
        <translation>Codi del llenguatge utilitzat al valor de la propietat associada script alternatiu.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="605"/>
        <source>Collection Type: set</source>
        <translation>Tipus de col·lecció; conjunt</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="605"/>
        <source>Property used with belongs-to-collection. Indicates the form or nature of a collection. The value &apos;set&apos; should be used for a finite collection of works that together constitute a single intellectual unit; typically issued together and able to be sold as a unit..</source>
        <translation>Propietat usada amb «Col·lecció a la qual pertany». Indica el tipus o l&apos;estil de col·lecció. El valor «Conjunt» s&apos;usa per una col·lecció finita d&apos;obres que juntes constitueixen una única unitat intel·lectual que poden ser publicades i venudes de manera conjunta.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="606"/>
        <source>Collection Type: series</source>
        <translation>Tipus de col·lecció; sèrie</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="606"/>
        <source>Property used with belongs-to-collection. Indicates the form or nature of a collection. The value &apos;series&apos;&apos; should be used for a sequence of related works that are formally identified as a group; typically open-ended with works issued individually over time.</source>
        <translation>Propietat utilitzada amb «Col·lecció a la qual pertany». Indica la forma o natura de la col·lecció. El valor ‘col·lecció’ s’utilitza per a sèries d’obres relacionades que es troben identificades formalment com a grup; tradicionalment, s’obren i tanquen amb obres publicades individualment al llarg del temps.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="607"/>
        <source>Display Sequence</source>
        <translation>Ordre de presentació</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="607"/>
        <source>Indicates the numeric position in which to display the current property relative to identical metadata properties (e.g., to indicate the order in which to render multiple titles or multiple authors).</source>
        <translation>Indica la posició numèrica amb la qual es mostrarà la propietat en curs relativa a propietat de metadades idèntiques (per exemple, per indicar l&apos;ordre en què es presentaran diversos títols o diversos autors).</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="608"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="698"/>
        <source>File as</source>
        <translation>Ordena com</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="608"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="698"/>
        <source>Provides the normalized form of the associated property for sorting. Typically used with author, creator, and contributor names.</source>
        <translation>Indica la manera normalitzada d&apos;ordenació de la propietat associada. Normalment s&apos;usa amb els noms de l&apos;autor, del creador o dels contribuïdors.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="609"/>
        <source>Group Position</source>
        <translation>Posició dins del grup</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="609"/>
        <source>Indicates the numeric position in which the EPUB Publication is ordered relative to other works belonging to the same group (whether all EPUB Publications or not).</source>
        <translation>Indica la posició numèrica amb què la publicació EPUB és ordenada en relació amb altres obres que pertanyen al mateix grup (tant si totes són publicacions EPUB com si no totes ho són).</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="610"/>
        <source>Identifier Type</source>
        <translation>Tipus d&apos;identificador</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="610"/>
        <source>Indicates the form or nature of an identifier. When the identifier-type value is drawn from a code list or other formal enumeration, the scheme attribute should be used to identify its source.</source>
        <translation>Indica la forma o la naturalesa d&apos;un identificador. Si aquest valor pertany a una llista de codis o a una altra enumeració formal, s&apos;ha de fer servir l&apos;atribut «Sistema» per identificar-ne la font.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="611"/>
        <source>Meta Authority</source>
        <translation>Autoritat de metadades</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="611"/>
        <source>Identifies the party or authority responsible for an instance of package metadata.</source>
        <translation>Identifica el grup o l&apos;autoritat responsable d&apos;un paquet de metadades concret.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="612"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="699"/>
        <source>Role</source>
        <translation>Funció</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="612"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="699"/>
        <source>Describes the nature of work performed by a creator or contributor (e.g., that the person is the author or editor of a work).  Typically used with the marc:relators scheme for a controlled vocabulary.</source>
        <translation>Descriu el tipus d&apos;obra fet pel creador o pel col·laborador (per exemple si la persona és l&apos;autora o l&apos;editora de l&apos;obra). Típicament s&apos;usa amb el sistema de descriptors MARC com a vocabulari controlat.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="613"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="700"/>
        <source>Scheme</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="613"/>
        <source>This attribute is typically added to dc:identifier, dc:source: dc:creator, or dc:contributor to indicate the controlled vocabulary system employed. (e.g. marc:relators to specify valid values for the role property.</source>
        <translation>Aquest atribut s’afegeix habitualment als elements dc:identifier, dc:source: dc:creator, or dc:contributor per indicar el vocabulari controlat utilitzat (p. e.: marc:relators per especificar valors vàlids per a la propietat rol).</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="614"/>
        <source>Source of Pagination</source>
        <translation>Font de paginació</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="614"/>
        <source>Indicates a unique aspect of an adapted source resource that has been retained in the given Rendition of the EPUB Publication. This specification defines the pagination value to indicate that the referenced source element is the source of the pagebreak properties defined in the content. This value should be set whenever pagination is included and the print source is known. Valid values: pagination.</source>
        <translation>Indica un únic aspecte de la font d&apos;un recurs adaptat que s&apos;ha mantingut en la interpretació de la publicació EPUB. Aquesta especificació defineix el valor de paginació per tal d&apos;indicar que el valor referenciat de la font és l&apos;origen de les propietats de salt de pàgina definides al contingut. Aquest valor s&apos;ha d&apos;establir quan s&apos;inclou la paginació i la font impresa és coneguda. Valors vàlids; paginació.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="615"/>
        <source>Custom Property</source>
        <translation>Propietat personalitzada</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="615"/>
        <source>[Custom property/attribute]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="615"/>
        <source>An empty metadata property or attribute you can modify.</source>
        <translation>Propietat o atribut de metadades buit que es pot modificar.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="645"/>
        <source>The main title of the epub publication.  Only one title may exist.</source>
        <translation>El títol principal de la publicació EPUB. Només pot haver-n&apos;hi un, de títol.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="646"/>
        <source>Represents the name of a person, organization, etc. responsible for the creation of the content of an EPUB Publication. The attributes opf:role, opf:scheme and opf:file-as can be attached to the element to indicate the function the creator played in the creation of the content.</source>
        <translation>Representa el nom de la persona o de la organització responsable de la creació del contingut de la publicació EPUB. Els atributs opf:rol, opf:sistema i opf:ordena-com es poden adjuntar a l&apos;element per tal d&apos;indicar la funció que va exercir el creador en la creació del contingut.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="647"/>
        <source>Represents the name of a person, organization, etc. that played a secondary role in the creation of the content of an EPUB Publication&apos;</source>
        <translation>Representa el nom de la persona, de la organització, etc. que va exercir un paper secundari en la creació del contingut de la publicació EPUB.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="654"/>
        <source>The nature or genre of the content of the resource.</source>
        <translation>Descripció de la naturalesa o gènere del contingut del recurs.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="656"/>
        <source>A reference to a resource from which the present publication is derived.</source>
        <translation>Referència a un altre recurs del qual se’n deriva en tot o en part el recurs descrit.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="657"/>
        <source>A language used in the publication. Choose a RFC5646 value.</source>
        <translation>Idioma usat a la publicació. Trieu un valor del RFC5646.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="661"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="662"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="663"/>
        <location filename="../../Dialogs/MetaEditor.cpp" line="664"/>
        <source>Identifier</source>
        <translation>Identificador</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="661"/>
        <source>Digital Object Identifier</source>
        <translation>Identificador d&apos;objecte digital</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="662"/>
        <source>International Standard Book Number</source>
        <translation>Número internacional normalitzat per a llibres</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="663"/>
        <source>International Standard Serial Number</source>
        <translation>Número internacional normalitzat per a publicacions en sèrie</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="664"/>
        <source>Universally Unique Identifier</source>
        <translation>Identificador universal únic</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="665"/>
        <source>Identifier: Custom</source>
        <translation>Identificador: Personalitzat</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="665"/>
        <source>A custom identifier based on a specified scheme</source>
        <translation>Identificador personalitzat basat en un sistema especificat.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="666"/>
        <source>Series</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="666"/>
        <source>Series title or name (from calibre)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="667"/>
        <source>Series Index</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="667"/>
        <source>Index of this book in the series (from calibre)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="668"/>
        <source>Title for Sorting</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="668"/>
        <source>Version of ebook title to use for sorting(from calibre)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="669"/>
        <source>An empty metadata element for you to modify</source>
        <translation>Un element de metadades buit que es pot modificar.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="697"/>
        <source>Optional, language specifying attribute.  Uses same codes as dc:language. Not for use with dc:language, dc:date, or dc:identifier metadata elements.</source>
        <translation>Atribut opcional d&apos;especificació d&apos;idioma. Fa servir els mateixos codis que dc:idioma. No s&apos;ha d&apos;usar amb els elements de metadades dc:idioma, dc:data o dc:identificador.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="700"/>
        <source>This attribute is typically added to dc:identifier to indicate the type of identifier being used: DOI, ISBN, ISSN, or UUID.</source>
        <translation>Aquest atribut típicament s&apos;afegeix a dc:identificador per tal d&apos;indicar el tipus d&apos;identificador que s&apos;esta utilitzant; DOI, ISBN, ISSN o UUID.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="701"/>
        <source>Event</source>
        <translation>Esdeveniment</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="701"/>
        <source>This attribute is typically added to dc:date elements to specify the date type: publication, creation, or modification.</source>
        <translation>Aquest atribut típicament s&apos;afegeix als elements dc:data per tal d&apos;indicar-ne el tipus de data; publicació, creació o modificació.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="702"/>
        <source>Custom Attribute</source>
        <translation>Atribut personalitzat</translation>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="702"/>
        <source>[Custom metadata property/attribute]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/MetaEditor.cpp" line="702"/>
        <source>An empty metadata attribute you can modify.</source>
        <translation>Un atribut de metadades buit que es pot modificar.</translation>
    </message>
</context>
<context>
    <name>NCXResource</name>
    <message>
        <location filename="../../ResourceObjects/NCXResource.cpp" line="159"/>
        <location filename="../../ResourceObjects/NCXResource.cpp" line="161"/>
        <source>Start</source>
        <translation>Inici</translation>
    </message>
</context>
<context>
    <name>OPFModel</name>
    <message>
        <location filename="../../MainUI/OPFModel.cpp" line="595"/>
        <source>A filename cannot contains the character &quot;%1&quot;.</source>
        <translation>El caràcter «%1» no és permès als noms de fitxer.</translation>
    </message>
    <message>
        <location filename="../../MainUI/OPFModel.cpp" line="606"/>
        <source>The filename cannot be empty.</source>
        <translation>Heu d&apos;indicar un nom de fitxer.</translation>
    </message>
    <message>
        <location filename="../../MainUI/OPFModel.cpp" line="613"/>
        <source>The filename &quot;%1&quot; is already in use.
</source>
        <translation>Ja hi ha un fitxer amb el nom «%1».</translation>
    </message>
</context>
<context>
    <name>OPFResource</name>
    <message>
        <location filename="../../ResourceObjects/OPFResource.cpp" line="1118"/>
        <source>[Title here]</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../ResourceObjects/OPFResource.cpp" line="1120"/>
        <source>[Main title here]</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>OpenWithName</name>
    <message>
        <location filename="../../Form_Files/OpenWithName.ui" line="14"/>
        <source>Open With Application Name</source>
        <translation>Obre amb una altra aplicació</translation>
    </message>
    <message>
        <location filename="../../Form_Files/OpenWithName.ui" line="20"/>
        <source>Enter the name to display in the Open With menu for this application:</source>
        <translation>Introduïu el nom d&apos;aquesta aplicació que es mostrarà al menú «Obre amb...»:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/OpenWithName.ui" line="48"/>
        <source>Filename:</source>
        <translation>Nom del fixer:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/OpenWithName.ui" line="55"/>
        <source>Menu Name:</source>
        <translation>Nom del menú:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/OpenWithName.ui" line="62"/>
        <source>No File</source>
        <translation>No hi ha cap fitxer</translation>
    </message>
</context>
<context>
    <name>PluginRunner</name>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="14"/>
        <source>Plugin Runner</source>
        <translation>Executor de connectors</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="28"/>
        <source>Plugin:</source>
        <translation>Connector:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="48"/>
        <source>Start</source>
        <translation>Inici</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="61"/>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="90"/>
        <source>Message</source>
        <translation>Missatge</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="103"/>
        <source>Details...</source>
        <translation>Detalls...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="110"/>
        <source>OK</source>
        <translation>D&apos;acord</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PluginRunner.ui" line="139"/>
        <source>Status: </source>
        <translation>Estat:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="104"/>
        <source>Error: A plugin by that name does not exist</source>
        <translation>Error: No existeix cap connector amb aquest nom</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="135"/>
        <source>Error: Interpreter</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="135"/>
        <source>has no path set</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="148"/>
        <source>Installation Error: plugin launcher</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="149"/>
        <source>does not exist</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="154"/>
        <source>Error: plugin engine</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="155"/>
        <source>is not supported (yet!)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="161"/>
        <source>Status: ready</source>
        <translation>Estat: preparat</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="223"/>
        <source>Error: plugin can not start</source>
        <translation>Error: el connector no es pot inicialitzar</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="371"/>
        <source>Status: running</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="388"/>
        <source>Launcher process crashed</source>
        <translation>El procés d&apos;execució ha sofert un error</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="399"/>
        <source>Status: finished</source>
        <translation>Estat: finalitzat</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="406"/>
        <source>Status: failed</source>
        <translation>Estat: ha fallat</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="412"/>
        <location filename="../../Dialogs/PluginRunner.cpp" line="421"/>
        <source>Status: No Changes Made</source>
        <translation>Estat: No s&apos;ha fet cap canvi</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="420"/>
        <source>Error: Plugin Tried to Remove the Last XHTML file .. aborting changes</source>
        <translation>Error: El connector a intentat eliminar l&apos;últim fitxer XHTML ... s&apos;estan interrompent els canvis</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="484"/>
        <location filename="../../Dialogs/PluginRunner.cpp" line="555"/>
        <source>Status:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="511"/>
        <source>Plugin failed to start</source>
        <translation>El connector ha fallat en inicialitzar-se</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="519"/>
        <source>Status: error</source>
        <translation>Estat: error</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="533"/>
        <source>Plugin cancelled</source>
        <translation>Connector cancel·lat</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="534"/>
        <source>Status: cancelled</source>
        <translation>Estat: cancel·lat</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="627"/>
        <source>Error Parsing Result XML:  </source>
        <translation>Error d&apos;anàlisi XML:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="684"/>
        <location filename="../../Dialogs/PluginRunner.cpp" line="699"/>
        <source>Status: checking</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="688"/>
        <source>Incorrect XHTML:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="688"/>
        <source>Line/Col</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="715"/>
        <source>Check Report</source>
        <translation>Comproveu l&apos;informe</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="716"/>
        <source>Incorrect XHTML/XML Detected
Are you Sure You Want to Continue?</source>
        <translation>S&apos;ha detectat XHTML/XML incorrecte
Esteu segur de voler continuar?</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="734"/>
        <source>Status: cleaning up - deleting files</source>
        <translation>Estat: netejant - s&apos;està eliminant fitxers</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="759"/>
        <source>Status: deleting</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="798"/>
        <source>Status: Loading</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="809"/>
        <source>Input Plugin</source>
        <translation>Entrada del connector</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="810"/>
        <source>Your current book will be completely replaced losing any unsaved changes ...  Are you sure you want to proceed</source>
        <translation>El vostre llibre serà reemplaçat perdent qualsevol canvi no desat ... Esteu segur que voleu procedir</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="836"/>
        <source>Status: adding</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="877"/>
        <source>Status: cleaning up - modifying files</source>
        <translation>Estat: netejant - s&apos;està modificant fitxers</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PluginRunner.cpp" line="906"/>
        <source>Status: modifying</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>PluginWidget</name>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="14"/>
        <location filename="../../Form_Files/PPluginWidget.ui" line="167"/>
        <source>Plugins</source>
        <translation>Connectors</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="28"/>
        <source>Assign as Plugin 1</source>
        <translation>Assigna com a connector 1</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="75"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="80"/>
        <source>Version</source>
        <translation>Versió</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="85"/>
        <source>Author</source>
        <translation>Autor</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="90"/>
        <source>Type</source>
        <translation>Gènere</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="95"/>
        <source>Interpreter</source>
        <translation>Intèrpret</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="109"/>
        <source>≥Python3.4:</source>
        <translation>≥Python3.4:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="128"/>
        <source>Auto</source>
        <translation>Auto</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="135"/>
        <source>Set</source>
        <translation>Estableix</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="174"/>
        <source>Add Plugin</source>
        <translation>Afegeix un connector</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="181"/>
        <source>Remove All</source>
        <translation>Elimina-ho tot</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="188"/>
        <source>Remove Plugin</source>
        <translation>Elimina el connector</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="214"/>
        <source>Path to Interpreter Executable</source>
        <translation>Camí a l&apos;intèrpret executable</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="224"/>
        <source>Should the bundled Python interpreter be used if present?</source>
        <translation>Voleu usar l&apos;intèrpret del Python inclòs si està present?</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="227"/>
        <source>Use Bundled Python</source>
        <translation>Usa el Python inclòs</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="234"/>
        <source>Assign as Plugin 2</source>
        <translation>Assigna com a connector 2</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="241"/>
        <source>Assign as Plugin 3</source>
        <translation>Assigna com a connector 3</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="248"/>
        <source>Assign as Plugin 4</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Form_Files/PPluginWidget.ui" line="255"/>
        <source>Assign as Plugin 5</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="184"/>
        <source>Select Plugin Zip Archive</source>
        <translation>Seleccioneu un fitxer Zip amb el connector</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="184"/>
        <source>Plugin Files (*.zip)</source>
        <translation>Fitxers del connector (*.zip) </translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="200"/>
        <source>Error: Plugin plugin.xml is invalid or not supported on your operating system.</source>
        <translation>Error: el connector plugin.xml no és vàlid o no es compatible amb el vostre sistema operatiu.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="203"/>
        <source>Warning: A plugin by that name already exists</source>
        <translation>Alerta: Ja existeix un connector amb aquest nom</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="206"/>
        <source>Error: Plugin Could Not be Unzipped.</source>
        <translation>Error: el connector no s&apos;ha pogut descomprimir.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="209"/>
        <source>Error: Plugin not a valid Sigil plugin.</source>
        <translation>S&apos;ha produït un error: el connector no és un connector per al Sigil vàlid.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="249"/>
        <source>Nothing is Selected.</source>
        <translation>No hi ha res seleccionat.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="307"/>
        <source>Remove All Plugins</source>
        <translation>Elimina tots els connectors</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="308"/>
        <source>Are you sure sure you want to remove all of your plugins?</source>
        <translation>Esteu segur que voleu eliminar tots els connectors?</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="366"/>
        <source>Select Interpreter</source>
        <translation>Seleccioneu un intèrpret</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PluginWidget.cpp" line="391"/>
        <source>Incorrect Interpreter Path selected</source>
        <translation>El camí seleccionat per l&apos;intèrpret és incorrecte</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../../Form_Files/Preferences.ui" line="14"/>
        <source>Preferences</source>
        <translation>Preferències</translation>
    </message>
    <message>
        <location filename="../../Dialogs/Preferences.cpp" line="102"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/Preferences.cpp" line="102"/>
        <source>Changes will take effect when you restart Sigil.</source>
        <translation>Els canvis seran efectius després de reiniciar el Sigil.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/Preferences.cpp" line="174"/>
        <source>Open Preferences Location</source>
        <translation>Obre la ubicació de les preferències</translation>
    </message>
</context>
<context>
    <name>PreserveEntitiesWidget</name>
    <message>
        <location filename="../../Form_Files/PPreserveEntitiesWidget.ui" line="14"/>
        <source>Preserve Entities</source>
        <translation>Preserva les entitats</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPreserveEntitiesWidget.ui" line="32"/>
        <source>Entities to Preserve</source>
        <translation>Entitats a preservar</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPreserveEntitiesWidget.ui" line="47"/>
        <source>Enter or paste entities to add to the list.
Entities can be separated by lines, commas, or spaces.</source>
        <translation>Introduïu o enganxeu entitats per afegir a la llista.
Podeu separar les entitats amb línies, comes o espais.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPreserveEntitiesWidget.ui" line="51"/>
        <source>Add</source>
        <translation>Afegeix</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPreserveEntitiesWidget.ui" line="58"/>
        <source>Remove</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PPreserveEntitiesWidget.ui" line="65"/>
        <source>Remove All</source>
        <translation>Elimina-ho tot</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PreserveEntitiesWidget.cpp" line="63"/>
        <source>Add Entities</source>
        <translation>Afegeix entitats</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/PreserveEntitiesWidget.cpp" line="63"/>
        <source>Entities:</source>
        <translation>Entitats:</translation>
    </message>
</context>
<context>
    <name>PreviewWindow</name>
    <message>
        <location filename="../../MainUI/PreviewWindow.cpp" line="43"/>
        <location filename="../../MainUI/PreviewWindow.cpp" line="260"/>
        <source>Preview</source>
        <translation>Previsualització</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../BookManipulation/Book.cpp" line="1051"/>
        <source>Merging Files..</source>
        <translation>S&apos;estan combinant els fitxers...</translation>
    </message>
    <message>
        <location filename="../../BookManipulation/BookReports.cpp" line="53"/>
        <location filename="../../BookManipulation/BookReports.cpp" line="124"/>
        <source>Collecting classes...</source>
        <translation>S&apos;estan aplegant les classes...</translation>
    </message>
    <message>
        <location filename="../../BookManipulation/CleanSource.cpp" line="292"/>
        <source>Cleaning...</source>
        <translation>S&apos;està netejant...</translation>
    </message>
    <message>
        <location filename="../../BookManipulation/Index.cpp" line="47"/>
        <source>Creating Index...</source>
        <translation>S&apos;està creant l&apos;índex...</translation>
    </message>
    <message>
        <location filename="../../BookManipulation/Index.cpp" line="47"/>
        <source>Cancel</source>
        <translation>Cancel·la</translation>
    </message>
    <message>
        <location filename="../../Dialogs/Reports.cpp" line="115"/>
        <source>Creating reports...</source>
        <translation>S&apos;estan creant els informes...</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="112"/>
        <source>Cannot read EPUB: %1</source>
        <translation>No es pot llegir l&apos;EPUB %1</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="222"/>
        <source>The OPF file does not contain a valid spine.</source>
        <translation>El fitxer OPF no conté cap &lt;i&gt;spine&lt;/i&gt; vàlid.</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="223"/>
        <location filename="../../Importers/ImportEPUB.cpp" line="760"/>
        <location filename="../../Importers/ImportEPUB.cpp" line="763"/>
        <source>Sigil has created a new one for you.</source>
        <translation>El Sigil n&apos;ha creat un de nou.</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="260"/>
        <source>Error parsing encryption xml.
Line: %1 Column %2 - %3</source>
        <translation>Hi ha hagut un error analitzant l&apos;encriptat xml.
Línia %1 - Columna %2 - %3</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="392"/>
        <source>Cannot unzip EPUB: %1</source>
        <translation>No es por descomprimir l&apos;EPUB %1</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="432"/>
        <location filename="../../Importers/ImportEPUB.cpp" line="441"/>
        <location filename="../../Importers/ImportEPUB.cpp" line="458"/>
        <location filename="../../Importers/ImportEPUB.cpp" line="466"/>
        <source>Cannot extract file: %1</source>
        <translation>No es pot extreure el fitxer %1</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="479"/>
        <source>Cannot open EPUB: %1</source>
        <translation>No es pot obrir l&apos;EPUB %1</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="531"/>
        <source>Unable to parse container.xml file.
Line: %1 Column %2 - %3</source>
        <translation>No s&apos;ha pogut analitzar el fitxer contenidor.xml.
Línia %1 - Columna %2 - %3</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="539"/>
        <source>No appropriate OPF file found</source>
        <translation>No s&apos;ha trobat el fitxer OPF adient</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="590"/>
        <source>Unable to read OPF file.
Line: %1 Column %2 - %3</source>
        <translation>No s&apos;ha pogut llegir el fitxer OPF.
Línia %1 - Columna %2 - %3</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="681"/>
        <source>The OPF manifest contains duplicate ids for: %1</source>
        <translation>El manifest OPF conté identificadors duplicats per a %1</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="682"/>
        <source>A temporary id has been assigned to load this EPUB. You should edit your OPF file to remove the duplication.</source>
        <translation>S&apos;ha assignat un identificador provisional per poder carregar l&apos;EPUB. Haurieu d&apos;editar el vostre fitxer OPF per tal d&apos;eliminar-ne els duplicats.</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="726"/>
        <source>The OPF file did not identify the NCX file correctly.</source>
        <translation>El fitxer OPF no ha identificat correctament el fitxer NCX.</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="727"/>
        <source>Sigil has used the following file as the NCX:</source>
        <translation>El Sigil ha utilitzat el fitxer següent com a NCX:</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="755"/>
        <source>Sigil has created a template NCX</source>
        <translation>El Sigil ha creat una plantilla NCX</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="756"/>
        <source>to support epub2 backwards compatibility.</source>
        <translation>per tal d&apos;assegurar la compatibilitat amb l&apos;EPUB2.</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="759"/>
        <source>The OPF file does not contain an NCX file.</source>
        <translation>El fitxer OPF no conté cap fitxer NCX.</translation>
    </message>
    <message>
        <location filename="../../Importers/ImportEPUB.cpp" line="762"/>
        <source>The NCX file is not present in this EPUB.</source>
        <translation>No hi ha cap fitxer NCX en aquest EPUB.</translation>
    </message>
    <message>
        <location filename="../../MainUI/BookBrowser.cpp" line="582"/>
        <source>Adding Existing Files..</source>
        <translation>S&apos;estan afegint els fitxers...</translation>
    </message>
    <message>
        <location filename="../../Misc/OpenExternally.cpp" line="196"/>
        <source>Applications</source>
        <translation>Aplicacions</translation>
    </message>
    <message>
        <location filename="../../Misc/OpenExternally.cpp" line="206"/>
        <source>Open With</source>
        <translation>Obre amb</translation>
    </message>
    <message>
        <location filename="../../Misc/SearchOperations.cpp" line="44"/>
        <source>Counting occurrences..</source>
        <translation>S&apos;estan comptant les aparicions...</translation>
    </message>
    <message>
        <location filename="../../Misc/SearchOperations.cpp" line="64"/>
        <source>Replacing search term...</source>
        <translation>S&apos;està reemplaçant la cadena de cerca...</translation>
    </message>
    <message>
        <location filename="../../Misc/TOCHTMLWriter.cpp" line="105"/>
        <source>Table of Contents</source>
        <translation>Taula de continguts</translation>
    </message>
    <message>
        <location filename="../../Misc/UpdateChecker.cpp" line="97"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Misc/UpdateChecker.cpp" line="98"/>
        <source>&lt;p&gt;A newer version of Sigil is available, version &lt;b&gt;%1&lt;/b&gt;.&lt;br/&gt;&lt;p&gt;Would you like to go to the download page?&lt;/p&gt;</source>
        <translation>&lt;p&gt;Hi ha una nova versió del Sigil disponible, versió &lt;b&gt;%1&lt;/b&gt;.&lt;br/&gt;&lt;p&gt;Voleu anar a la pàgina de descàrregues?&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Misc/Utility.cpp" line="428"/>
        <source>Cannot read file %1:
%2.</source>
        <translation>No es pot llegir el fitxer %1:
%2.</translation>
    </message>
    <message>
        <location filename="../../Misc/Utility.cpp" line="543"/>
        <source>Sigil has encountered a problem.</source>
        <translation>El Sigil ha tingut un problema.</translation>
    </message>
    <message>
        <location filename="../../Misc/Utility.cpp" line="544"/>
        <source>Sigil may need to close.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../MiscEditors/IndexHTMLWriter.cpp" line="70"/>
        <source>Index</source>
        <translation>Índex</translation>
    </message>
    <message>
        <location filename="../../SourceUpdates/UniversalUpdates.cpp" line="207"/>
        <location filename="../../SourceUpdates/UniversalUpdates.cpp" line="273"/>
        <source>Invalid HTML file: %1</source>
        <translation>El fitxer HTML no és correcte: %1</translation>
    </message>
    <message>
        <location filename="../../SourceUpdates/UniversalUpdates.cpp" line="316"/>
        <source>Invalid OPF file: %1</source>
        <translation>El fitxer OPF no és correcte: %1</translation>
    </message>
    <message>
        <location filename="../../SourceUpdates/UniversalUpdates.cpp" line="341"/>
        <source>Invalid NCX file: %1</source>
        <translation>El fitxer NCX no és correcte: %1</translation>
    </message>
</context>
<context>
    <name>RenameTemplate</name>
    <message>
        <location filename="../../Form_Files/RenameTemplate.ui" line="20"/>
        <source>Rename Files</source>
        <translation>Canvia el nom dels fitxers</translation>
    </message>
    <message>
        <location filename="../../Form_Files/RenameTemplate.ui" line="28"/>
        <source>Enter the starting name to use for renaming all selected files, e.g.:

    filename001
    filename08.xhtml
    .html

All numbers at the END of the filename you enter will be replaced sequentially
starting at the number provided (default is 1 if no number is provided),  with
leading 0's added to match the number of digits used.

If you provide a file extension it will be used for all files, otherwise the
current extensions will be kept.  If you just provide a file extension (e.g. .xhtml)
then only file extensions will be updated.  Be careful that any extension you use is 
valid for all selected files.
</source>
        <translation>Introduïu el nom inicial comú que tindran els fitxers seleccionats.

Exemple:
    nomdefitxer001
    nomdefitxer08.xhtml
    .html

Els números del FINAL del nom que poseu s&apos;aniran incrementant seqüencialment
començant pel número introduït (si no en poseu cap, el predeterminat és 1) amb
tants zeros al davant com calguin per concordar amb el número de dígits utilitzats.

Si indiqueu una extensió de fitxer, s&apos;utilitzara per a tots els fitxers, si no poseu extensió,
es conservarà la que tinguin els fitxers originals. Si només poseu una extensió (com ara
«.xhtml»), només es canviaran les extensions. Assegureu-vos que les extensions que
poseu siguin vàlides per a tots els fitxers seleccionats.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/RenameTemplate.ui" line="45"/>
        <source>Rename Files Starting At: </source>
        <translation>Canvia el nom dels fitxer; comença per: </translation>
    </message>
    <message>
        <location filename="../../Form_Files/RenameTemplate.ui" line="52"/>
        <source>Section0001</source>
        <translation>Seccio0001</translation>
    </message>
</context>
<context>
    <name>Reports</name>
    <message>
        <location filename="../../Form_Files/Reports.ui" line="14"/>
        <source>Reports</source>
        <translation>Informes</translation>
    </message>
    <message>
        <location filename="../../Form_Files/Reports.ui" line="51"/>
        <source>Refresh</source>
        <translation>Actualitza</translation>
    </message>
</context>
<context>
    <name>SearchEditor</name>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="14"/>
        <source>Saved Searches</source>
        <translation>Cerques desades</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="23"/>
        <source>Filter Name:</source>
        <translation>Filtra el nom:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="28"/>
        <source>Filter All:</source>
        <translation>Filtra-ho tot:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="36"/>
        <source>List only the entries containing the text you enter.</source>
        <translation>Mostra només les entrades que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="65"/>
        <source>Load the selected entry into the Find &amp; Replace window.</source>
        <translation>Carrega l&apos;entrada seleccionada al diàleg de cerca i reemplaçament.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="68"/>
        <source>Load Search</source>
        <translation>Carrega una cerca</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="91"/>
        <source>Run Find using the selected entry.
If a group is selected, find the first entry in the list, 
then if not found look for the second entry in the list, etc.</source>
        <translation>Executa l&apos;ordre «Cerca» utilitzant l&apos;entrada seleccionada.
Si seleccioneu un grup, cerca la primera entrada de la llista,
i, si no la troba, cerca la segona, etc.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="96"/>
        <location filename="../../Dialogs/SearchEditor.cpp" line="68"/>
        <source>Find</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="103"/>
        <source>Run Replace using the selected entry.
If a group is selected, loop through each entry
and stop at the first successful replace.</source>
        <translation>Executa l&apos;ordre «Reemplaça» utilitzant l&apos;entrada seleccionada.
Si seleccioneu un grup, repeteix la cerca per a cada entrada
i s&apos;atura al primer reemplaçament que faci.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="108"/>
        <location filename="../../Dialogs/SearchEditor.cpp" line="69"/>
        <source>Replace</source>
        <translation>Reemplaça</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="131"/>
        <source>Run Replace/Find using the selected entry.
If a group is selected, loop through each entry
and stop at the first successful replace/find.</source>
        <translation>Executa «Reemplaça i cerca» utilitzant l&apos;entrada seleccionada.
Si seleccioneu un grup, repeteix l&apos;acció per a cada entrada
i s&apos;atura al primer reemplaçament i cerca que faci.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="136"/>
        <source>Replace/Find</source>
        <translation>Reemplaça i cerca</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="143"/>
        <source>Run Replace All for the selected entries in the order selected.
Select a group to replace all entries in the group in order.</source>
        <translation>Executa l&apos;ordre «Reemplaça-ho tot» amb les entrades seleccionades i amb l&apos;ordre seleccionat.
Seleccioneu un grup per reemplaçar totes les entrades amb l&apos;ordre del grup.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="147"/>
        <source>Replace All</source>
        <translation>Reemplaça-ho tot</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="170"/>
        <source>Run Count All for the selected entries in the order selected,
including entries in selected groups.</source>
        <translation>Executa l&apos;ordre «Compta-ho tot» amb les entrades seleccionades
i l&apos;ordre seleccionar, incloent les entrades dels grups seleccionats.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="174"/>
        <source>Count All</source>
        <translation>Compta-ho tot</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="199"/>
        <source>Move an entry up one level in the same group.</source>
        <translation>Mou una entrada una posició amunt dins del mateix grup.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="202"/>
        <location filename="../../Form_Files/SearchEditor.ui" line="232"/>
        <location filename="../../Form_Files/SearchEditor.ui" line="261"/>
        <location filename="../../Form_Files/SearchEditor.ui" line="291"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="229"/>
        <source>Move an entry to the level of its parent.</source>
        <translation>Mou una entrada al mateix nivell que el seu pare.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="258"/>
        <source>You must select an item immediately under a group to move it into the group.</source>
        <translation>Cal que l&apos;element estigui just a sota del grup per poder-lo moure dins.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="288"/>
        <source>Move an entry down one level in the same group.</source>
        <translation>Moure una entrada un nivell avall en el mateix grup.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SearchEditor.ui" line="354"/>
        <source>Click Apply to load Find &amp; Replace with the selected search.  Click OK to load your search, save your data, and close.</source>
        <translation>Cliqueu «Aplica» per carregar la cerca i reemplaçament amb la selecció.
Cliqueu «D&apos;acord» per carregar la cerca, deseu i tanqueu.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="62"/>
        <source>All searches default to Regex, All HTML Files, Down.</source>
        <translation>Totes les cerques són, per defecte, amb expressions regulats, a tots els fitxers HTML i cap avall.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="63"/>
        <source>Hold Ctrl down while clicking Find, Replace, etc. to temporarily search only the Current File.</source>
        <translation>Premeu la tecla de control mentre cliqueu cerca, reemplaça, etc.
per limitar temporalment la cerca al fitxer en curs.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="64"/>
        <source>Right click on an entry to see a context menu of actions.</source>
        <translation>Cliqueu amb el botó dret sobre una entrada per mostrar
un menú d&apos;accions contextual.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="65"/>
        <source>You can also right click on the Find text box in the Find &amp; Replace window to select an entry.</source>
        <translation>També podeu fer clic amb el botó dret al quadre de la cadena de cerca
del diàleg de cerca i reemplaçament per triar una de les entrades.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="67"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="67"/>
        <source>Name of your entry or group.</source>
        <translation>Nom de l&apos;entrada o del grup.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="68"/>
        <source>The text to put into the Find box.</source>
        <translation>Cadena de text que s&apos;ha de cercar.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="69"/>
        <source>The text to put into the Replace box.</source>
        <translation>Cadena de text de reemplaçament.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="73"/>
        <source>Save</source>
        <translation>Desa</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="73"/>
        <source>Save your changes.</source>
        <translation>Desa els canvis.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="73"/>
        <source>If any other instances of Sigil are running they will be automatically updated with your changes.</source>
        <translation>Si hi ha altres instàncies del Sigil executant-se, se n&apos;actualitzaran automàticament els canvis.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="90"/>
        <source>Cannot save entries.</source>
        <translation>No es poden desar les entrades.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="170"/>
        <source>Saved Searches loaded from file.</source>
        <translation>Cerques desades carregades d&apos;un fitxer.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="206"/>
        <source>You cannot select more than one entry when using this action.</source>
        <translation>Amb aquesta acció, només podeu seleccionar una entrada.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="214"/>
        <source>You cannot select a group for this action.</source>
        <translation>Amb aquesta acció, no podeu seleccionar cap grup.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="260"/>
        <source>You cannot select an entry and a group containing the entry.</source>
        <translation>No es pot seleccionar a la vegada una entrada i el grup que la conté.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="343"/>
        <source>You cannot Copy or Cut groups - use drag-and-drop.</source>
        <translation>Els grups no es poden copiar ni retallar. Podeu arrossegar-los i deixar-los anar.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="410"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="410"/>
        <source>Are you sure you want to reload all entries?  This will overwrite any unsaved changes.</source>
        <translation>Esteu segur que voleu tornar a carregar totes les entrades?
Tots els canvis sense desar es sobreescriuran.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="426"/>
        <source>Import Search Entries</source>
        <translation>Importa les entrades de cerca</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="499"/>
        <source>Export Selected Searches</source>
        <translation>Exporta les cerques seleccionades</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="664"/>
        <source>Add Entry</source>
        <translation>Afegeix una entrada</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="665"/>
        <source>Add Group</source>
        <translation>Afegeix un grup</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="666"/>
        <source>Edit</source>
        <translation>Edita</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="667"/>
        <source>Cut</source>
        <translation>Retalla</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="668"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="669"/>
        <source>Paste</source>
        <translation>Enganxa</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="670"/>
        <source>Delete</source>
        <translation>Suprimeix</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="671"/>
        <source>Import</source>
        <translation>Importa</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="672"/>
        <source>Reload</source>
        <translation>Torna a carregar</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="673"/>
        <source>Export</source>
        <translation>Exporta</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="674"/>
        <source>Export All</source>
        <translation>Exporta-ho tot</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="675"/>
        <source>Collapse All</source>
        <translation>Redueix-ho tot</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="676"/>
        <source>Expand All</source>
        <translation>Amplia-ho tot</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="753"/>
        <source>Search entries saved.</source>
        <translation>Entrades de cerca desades.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="782"/>
        <source>Sigil: Saved Searches</source>
        <translation>Sigil: Cerques desades</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SearchEditor.cpp" line="783"/>
        <source>The Search entries may have been modified.
Do you want to save your changes?</source>
        <translation>Les entrades de cerca poden haver estat modificades.
Voleu desar-ne els canvis?</translation>
    </message>
</context>
<context>
    <name>SearchEditorModel</name>
    <message>
        <location filename="../../MiscEditors/SearchEditorModel.cpp" line="66"/>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/SearchEditorModel.cpp" line="67"/>
        <source>Find</source>
        <translation>Cerca</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/SearchEditorModel.cpp" line="68"/>
        <source>Replace</source>
        <translation>Reemplaça</translation>
    </message>
    <message>
        <location filename="../../MiscEditors/SearchEditorModel.cpp" line="604"/>
        <source>Unable to create file %1</source>
        <translation>No s&apos;ha pogut crear el fitxer %1</translation>
    </message>
</context>
<context>
    <name>SelectCharacter</name>
    <message>
        <location filename="../../Form_Files/SelectCharacter.ui" line="14"/>
        <source>Insert Special Character</source>
        <translation>Insereix un caràcter especial</translation>
    </message>
</context>
<context>
    <name>SelectFiles</name>
    <message>
        <location filename="../../Form_Files/SelectFiles.ui" line="14"/>
        <source>Insert File</source>
        <translation>Insereix un fitxer</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectFiles.ui" line="46"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>Mostra només els noms de fitxer que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectFiles.ui" line="49"/>
        <source>Filter:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectFiles.ui" line="59"/>
        <source>Choose which image, video, or audio files from your computer to add to
your book and automatically insert into your document.</source>
        <translation>Seleccioneu la imatge, el vídeo o el fitxer d&apos;àudio que voleu afegir al llibre
des del vostre ordinador i s&apos;inserirà automàticament al document.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectFiles.ui" line="63"/>
        <source>Other Files...</source>
        <translation>Altres fitxers...</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectFiles.ui" line="129"/>
        <source>Thumbnail size:</source>
        <translation>Mida de la miniatura:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="80"/>
        <source>All</source>
        <translation>Tot</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="81"/>
        <source>Images</source>
        <translation>Imatges</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="82"/>
        <source>Video</source>
        <translation>Vídeo</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="83"/>
        <source>Audio</source>
        <translation>Àudio</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="127"/>
        <source>Files In the Book</source>
        <translation>Fitxers del llibre</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="130"/>
        <source>Thumbnails</source>
        <translation>Miniatures</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="286"/>
        <source>shades</source>
        <translation>nivells</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="286"/>
        <source>colors</source>
        <translation>colors</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="287"/>
        <source>Grayscale</source>
        <translation>Escala de grisos</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectFiles.cpp" line="287"/>
        <source>Color</source>
        <translation>Color</translation>
    </message>
</context>
<context>
    <name>SelectHyperlink</name>
    <message>
        <location filename="../../Form_Files/SelectHyperlink.ui" line="14"/>
        <source>Select Target</source>
        <translation>Seleccioneu l&apos;objectiu</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectHyperlink.ui" line="22"/>
        <source>List only the entries that match the text you enter.</source>
        <translation>Mostra només les entrades que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectHyperlink.ui" line="25"/>
        <source>Filter:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectHyperlink.ui" line="58"/>
        <source>Enter the target URL for this hyperlink.  You can select or 
double click on existing destinations in your book from the list above.</source>
        <translation>Introduïu l&apos;URL objectiu de l&apos;enllaç.
Podeu seleccionar o fer doble clic sobre objectius presents al llibre
a la llista del damunt.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectHyperlink.ui" line="62"/>
        <source>Target:</source>
        <translation>Objectiu:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SelectHyperlink.cpp" line="61"/>
        <source>Targets in the Book</source>
        <translation>Objectius del llibre</translation>
    </message>
</context>
<context>
    <name>SelectId</name>
    <message>
        <location filename="../../Form_Files/SelectId.ui" line="14"/>
        <source>Insert ID </source>
        <translation>Insereix un identificador</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectId.ui" line="22"/>
        <source>Enter an ID name to use as a destination for hyperlinks, notes, and TOC entries.

The dropdown box shows existing ID names in the current file.

ID names must be unique and start with a letter.</source>
        <translation>Introduïu un nom d&apos;identificador per als enllaços, notes i entrades de la taula de continguts.

El menú emergent mostra els noms d&apos;identificador disponibles al fixer actual.

Els noms d&apos;identificador han de únics i començar amb una lletra.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectId.ui" line="29"/>
        <source>ID:</source>
        <translation>Identificador:</translation>
    </message>
</context>
<context>
    <name>SelectIndexTitle</name>
    <message>
        <location filename="../../Form_Files/SelectIndexTitle.ui" line="14"/>
        <source>Mark For Index</source>
        <translation>Marca per a incloure a l&apos;índex</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectIndexTitle.ui" line="22"/>
        <source>Enter the index entry to create for the selected text.</source>
        <translation>Introduïu l&apos;entrada de l&apos;índex que es crearà per al text seleccionat.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SelectIndexTitle.ui" line="25"/>
        <source>Index Entry:</source>
        <translation>Entrada de l&apos;índex:</translation>
    </message>
</context>
<context>
    <name>SpellCheckWidget</name>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="14"/>
        <source>Spellcheck Dictionaries</source>
        <translation>Diccionaris de verificació ortogràfica</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="34"/>
        <source>Dictionary:</source>
        <translation>Diccionari:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="64"/>
        <source>Highlight misspelled words in Code View.</source>
        <translation>Cerca les paraules incorrectes a la vista de codi.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="67"/>
        <source>Highlight Misspelled Words</source>
        <translation>Ressalta les paraules incorrectes</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="74"/>
        <source>Check words with numbers in them.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="77"/>
        <source>Check Numbers</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="130"/>
        <source>User Dictionaries</source>
        <translation>Diccionaris de l&apos;usuari</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="138"/>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="222"/>
        <source>Add</source>
        <translation>Afegeix</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="145"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="212"/>
        <source>Rename</source>
        <translation>Canvia el nom</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="152"/>
        <source>Copy</source>
        <translation>Copia</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="159"/>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="236"/>
        <source>Remove</source>
        <translation>Elimina</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="162"/>
        <source>Remove the selected dictionary.

You cannot remove the last dictionary.</source>
        <translation>Suprimeix el diccionari seleccionat.

L&apos;últim diccionari no es pot suprimir.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="189"/>
        <source>Mark which dictionaries are enabled for
spell checking.

Select a dictionary to display its words,
and to make it the default dictionary.</source>
        <translation>Marca els diccionaris activats per fer la
correcció ortogràfica.

Seleccioneu un diccionari per a veure&apos;n les paraules
i per fer-que sigui el predeterminat.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="203"/>
        <source>User Dictionary Word List</source>
        <translation>Llista de paraules del diccionari de l&apos;usuari</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="218"/>
        <source>Enter or paste words to add to the dictionary.
Words can be separated by lines, commas, or spaces.</source>
        <translation>Introduïu o enganxeu les paraules que volgueu afegir al diccionari.
Les paraules es poden separar amb línies, comes o espais.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="229"/>
        <source>Edit</source>
        <translation>Edita</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="243"/>
        <source>Remove All</source>
        <translation>Elimina-ho tot</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="272"/>
        <source>The default dictionary is used when you add words to the
default dictionary or use the shortcuts for Add Misspelled Words.</source>
        <translation>El diccionari predeterminat s&apos;utilitza quan s&apos;hi afegeixen paraules
o quan es fan servir les dreceres de teclat per afegir-hi
paraules no reconegudes.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="276"/>
        <source>Default Dictionary:</source>
        <translation>Diccionari predeterminat:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/PSpellCheckWidget.ui" line="283"/>
        <source>none</source>
        <translation>cap</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="52"/>
        <source>Enable</source>
        <translation>Activa</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="53"/>
        <source>Dictionary</source>
        <translation>Diccionari</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="109"/>
        <source>Add Dictionary</source>
        <translation>Afegeix un diccionari</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="109"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="212"/>
        <source>Name:</source>
        <translation>Nom:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="123"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="163"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="225"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="233"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="252"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="123"/>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="225"/>
        <source>A user dictionary already exists with this name!</source>
        <translation>Ja hi ha un diccionari de l&apos;usuari amb aquest nom!</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="132"/>
        <source>Add Words</source>
        <translation>Afegeix paraules</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="132"/>
        <source>Words:</source>
        <translation>Paraules:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="163"/>
        <source>Could not create file!</source>
        <translation>No s&apos;ha pogut crear el fitxer!</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="233"/>
        <source>Could not rename file!</source>
        <translation>No s&apos;ha pogut canviar el nom del fitxer!</translation>
    </message>
    <message>
        <location filename="../../Dialogs/PreferenceWidgets/SpellCheckWidget.cpp" line="252"/>
        <source>You cannot delete the last dictionary.</source>
        <translation>L&apos;últim diccionari no es pot suprimir.</translation>
    </message>
</context>
<context>
    <name>SpellcheckEditor</name>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="14"/>
        <source>Spellcheck</source>
        <translation>Verificació ortogràfica</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="22"/>
        <source>Filter:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="29"/>
        <source>List only the entries containing the text you enter.</source>
        <translation>Mostra només les entrades que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="58"/>
        <source>Ignore the selected words until Sigil
is restarted or a new book is opened.</source>
        <translation>Ignora les paraules seleccionades fins que el Sigil
es reinicïi o s&apos;obri un altre llibre.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="62"/>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="532"/>
        <source>Ignore</source>
        <translation>Ignora</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="91"/>
        <source>Add the selected words to the
dictionary selected below.</source>
        <translation>Afegeix les paraules seleccionades
al diccionari seleccionat de sota.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="95"/>
        <source>Add To Dictionary:</source>
        <translation>Afegeix al diccionari:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="134"/>
        <source>Change all occurrences of the selected word  in
HTML files to the word you select or type below.
The selected word does not have to be misspelled.</source>
        <translation>Canvia totes les aparicions de la paraula seleccionada
als fitxers HTML amb la paraula que trieu o tecelegeu a sota.
No es verifica l&apos;ortografia de la paraula seleccionada.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="139"/>
        <source>Change Selected Word To:</source>
        <translation>Canvia la paraula seleccionada per:</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="181"/>
        <source>Show All Words</source>
        <translation>Mostra totes les paraules</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="188"/>
        <source>Sort words as AaBbCc instead of ABCabc.</source>
        <translation>Ordena les paraules com a AaBbCc en lloc de ABCabc.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="191"/>
        <source>Case-Insensitive Sort</source>
        <translation>Ordenació natural de caixa alta i baixa.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="215"/>
        <source>Re-check the HTML files for misspelled words.
Use if you edit any HTML files while Spellcheck is open.</source>
        <translation>Torna a fer la verificació ortogràfica dels fitxers HTML.
Utilitzeu-ho si editeu un fitxer HTML mentre la verificació
ortogràfica és oberta.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/SpellcheckEditor.ui" line="219"/>
        <source>Refresh</source>
        <translation>Actualitza</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="53"/>
        <source>f</source>
        <comment>Filter</comment>
        <translation>f</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="54"/>
        <source>s</source>
        <comment>ShowAllWords</comment>
        <translation>s</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="55"/>
        <source>c</source>
        <comment>Case-InsensitiveSort</comment>
        <translation>c</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="56"/>
        <source>r</source>
        <comment>Refresh</comment>
        <translation>r</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="154"/>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="177"/>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="216"/>
        <source>No words selected.</source>
        <translation>No hi ha cap paraula seleccionada.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="170"/>
        <source>Ignored word(s).</source>
        <translation>Paraules ignorades.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="205"/>
        <source>Added word(s) to dictionary.</source>
        <translation>Paraules afegides al diccionari.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="207"/>
        <source>Added word(s) to dictionary. The dictionary is not enabled in Preferences.</source>
        <translation>Paraules afegides al diccionari. El diccionari no és habilitat a les preferències.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="222"/>
        <source>The new word cannot contain &quot;&lt;&quot;, &quot;&gt;&quot;, or &quot;&amp;&quot;.</source>
        <translation>La paraula nova no pot tenir cap «&lt;», «&gt;» ni «&amp;».</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="233"/>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="301"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="252"/>
        <source>Word</source>
        <translation>Paraula</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="253"/>
        <source>Count</source>
        <translation>Compta</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="254"/>
        <source>Misspelled?</source>
        <translation>És un error ortogràfic?</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="299"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="314"/>
        <source>Misspelled Words</source>
        <translation>Errors ortogràfics</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="314"/>
        <source>Total Unique Words</source>
        <translation>Total de paraules úniques</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="533"/>
        <source>Add to Dictionary</source>
        <translation>Afegeix al diccionari</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="534"/>
        <source>Find in Text</source>
        <translation>Cerca al text</translation>
    </message>
    <message>
        <location filename="../../Dialogs/SpellcheckEditor.cpp" line="535"/>
        <source>Select All</source>
        <translation>Selecciona-ho tot</translation>
    </message>
</context>
<context>
    <name>StylesInCSSFilesWidget</name>
    <message>
        <location filename="../../Form_Files/ReportsStylesInCSSFilesWidget.ui" line="14"/>
        <source>Style Classes in CSS Files</source>
        <translation>Classes d&apos;estils als fitxers CSS</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsStylesInCSSFilesWidget.ui" line="34"/>
        <source>List only the file names which contain the text you enter.</source>
        <translation>Mostra només els noms de fitxer que continguin el text introduït.</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ReportsStylesInCSSFilesWidget.ui" line="37"/>
        <source>Filter:</source>
        <translation>Filtre:</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="86"/>
        <source>CSS File</source>
        <translation>Fitxer CSS</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="87"/>
        <source>Class Selector</source>
        <translation>Selector de classes</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="88"/>
        <source>Used In HTML File</source>
        <translation>Utilitzat al fitxer HTML</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="94"/>
        <source>&lt;p&gt;This is a list of the class based selectors in all CSS files and whether or not the selector was matched from a style in an HTML file.&lt;p&gt;</source>
        <translation>&lt;p&gt;Llista dels selectors de classe de tots els fitxers CSS amb indicació d&apos;ús en algun dels fitxers HTML.&lt;p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="95"/>
        <source>&lt;p&gt;NOTE:&lt;/p&gt;</source>
        <translation>&lt;p&gt;NOTA:&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="96"/>
        <source>&lt;p&gt;Due to the complexities of CSS you must check your code manually to be certain if a style is used or not.&lt;/p&gt;</source>
        <translation>&lt;p&gt;La complexitat del CSS obliga a revisar el codi manualment per comprovar si un estil s&apos;utilitza o no.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="252"/>
        <source>Save Report As Comma Separated File</source>
        <translation>Desa l&apos;informe com a fitxer de text separat per comes</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="265"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="265"/>
        <source>Cannot save report file.</source>
        <translation>No es pot desar el fitxer d&apos;informe.</translation>
    </message>
    <message>
        <location filename="../../Dialogs/ReportsWidgets/StylesInCSSFilesWidget.cpp" line="276"/>
        <source>Delete From Stylesheet</source>
        <translation>Esborra del full d&apos;estil</translation>
    </message>
</context>
<context>
    <name>TabBar</name>
    <message>
        <location filename="../../Tabs/TabBar.cpp" line="80"/>
        <source>Close Other Tabs</source>
        <translation>Tanca les altres pestanyes</translation>
    </message>
</context>
<context>
    <name>TabManager</name>
    <message>
        <location filename="../../Tabs/TabManager.cpp" line="218"/>
        <source>Cannot edit file</source>
        <translation>No es pot editar el fitxer</translation>
    </message>
</context>
<context>
    <name>TableOfContents</name>
    <message>
        <location filename="../../MainUI/TableOfContents.cpp" line="42"/>
        <source>Table Of Contents</source>
        <translation>Taula de continguts</translation>
    </message>
    <message>
        <location filename="../../MainUI/TableOfContents.cpp" line="123"/>
        <source>The file &quot;%1&quot; does not exist.</source>
        <translation>El fitxer «%1» no existeix.</translation>
    </message>
    <message>
        <location filename="../../MainUI/TableOfContents.cpp" line="154"/>
        <source>Collapse All</source>
        <translation>Redueix-ho tot</translation>
    </message>
    <message>
        <location filename="../../MainUI/TableOfContents.cpp" line="155"/>
        <source>Expand All</source>
        <translation>Amplia-ho tot</translation>
    </message>
</context>
<context>
    <name>TextTab</name>
    <message>
        <location filename="../../Tabs/TextTab.cpp" line="309"/>
        <source>Print %1</source>
        <translation>Imprimeix %1</translation>
    </message>
</context>
<context>
    <name>Utility</name>
    <message>
        <location filename="../../Misc/Utility.cpp" line="656"/>
        <source>Sigil</source>
        <translation>Sigil</translation>
    </message>
    <message>
        <location filename="../../Misc/Utility.cpp" line="657"/>
        <source>The requested file name contains non-ASCII characters. You should only use ASCII characters in filenames. Using non-ASCII characters can prevent the EPUB from working with some readers.

Continue using the requested filename?</source>
        <translation>El nom de fitxer que heu indicat conté caràcters no ASCII. Es recomana que els noms de fitxer només tinguin caràcters ASCII ja que, altrament, l&apos;EPUB podria donar problemes en alguns dispositius de lectura.

Encara voleu fer servir aquest nom de fitxer?</translation>
    </message>
</context>
<context>
    <name>ValidationResultsView</name>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="44"/>
        <source>Validation Results</source>
        <translation>Resultat de la validació</translation>
    </message>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="227"/>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="231"/>
        <source>N/A</source>
        <translation>No disponible</translation>
    </message>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="254"/>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="270"/>
        <source>Message</source>
        <translation>Missatge</translation>
    </message>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="255"/>
        <source>No problems found!</source>
        <translation>No s&apos;ha trobat cap problema!</translation>
    </message>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="270"/>
        <source>File</source>
        <translation>Fitxer</translation>
    </message>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="270"/>
        <source>Line</source>
        <translation>Línia</translation>
    </message>
    <message>
        <location filename="../../MainUI/ValidationResultsView.cpp" line="270"/>
        <source>Offset</source>
        <translation>Desplaçament</translation>
    </message>
</context>
<context>
    <name>ViewImage</name>
    <message>
        <location filename="../../Form_Files/ViewImage.ui" line="20"/>
        <source>View Image</source>
        <translation>Visualitza la imatge</translation>
    </message>
    <message>
        <location filename="../../Form_Files/ViewImage.ui" line="33"/>
        <source>about:blank</source>
        <translation>about:blank</translation>
    </message>
</context>
<context>
    <name>WellFormedCheckComponent</name>
    <message>
        <location filename="../../Tabs/WellFormedCheckComponent.cpp" line="42"/>
        <source>&lt;p&gt;The operation you requested cannot be performed because &lt;b&gt;%1&lt;/b&gt; is not a well-formed XML document.&lt;/p&gt;&lt;p&gt;An error was found &lt;b&gt;at or above line %2: %3.&lt;/b&gt;&lt;/p&gt;&lt;p&gt;The &lt;i&gt;Fix Manually&lt;/i&gt; option will let you fix the problem by hand.&lt;/p&gt;</source>
        <translation>&lt;p&gt;No es pot fer l&apos;operació que heu demanat ja que el document XML &lt;b&gt;%1&lt;/b&gt; no és ben format.&lt;/p&gt;
&lt;p&gt;Hi ha un error &lt;b&gt;a la línia %2: %3 o abans.&lt;/b&gt;&lt;/p&gt;
&lt;p&gt;L&apos;opció &lt;i&gt;Corregeix manualment&lt;/i&gt; permet solucionar el problema manualment.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Tabs/WellFormedCheckComponent.cpp" line="47"/>
        <source>&lt;p&gt;The &lt;i&gt;Fix Automatically&lt;/i&gt; option will instruct Sigil to try to repair the document. &lt;b&gt;This option may lead to loss of data!&lt;/b&gt;&lt;/p&gt;</source>
        <translation>&lt;p&gt;L&apos;opció &lt;i&gt;Corregeix automàticament&lt;/i&gt; farà que el Sigil intenti corregir el document. &lt;b&gt;Això pot fer que es perdin dades!&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../../Tabs/WellFormedCheckComponent.cpp" line="54"/>
        <source>Fix &amp;Automatically</source>
        <translation>Corregeix &amp;automàticament</translation>
    </message>
    <message>
        <location filename="../../Tabs/WellFormedCheckComponent.cpp" line="56"/>
        <source>Fix &amp;Manually</source>
        <translation>Corregeix &amp;manualment</translation>
    </message>
</context>
<context>
    <name>XMLEntities</name>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="97"/>
        <source>quotation mark</source>
        <translation>cometes rectes</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="98"/>
        <source>ampersand</source>
        <translation>et (i comercial)</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="99"/>
        <source>apostrophe</source>
        <translation>apòstrof</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="100"/>
        <source>less-than sign</source>
        <translation>més petit que</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="101"/>
        <source>greater-than sign</source>
        <translation>més gran que</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="102"/>
        <source>no-break space</source>
        <translation>espai indivisible</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="103"/>
        <source>inverted exclamation mark</source>
        <translation>exclamació inicial</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="104"/>
        <source>cent sign</source>
        <translation>símbol de centau</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="105"/>
        <source>pound sign</source>
        <translation>símbol de lliura</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="106"/>
        <source>currency sign</source>
        <translation>símbol de moneda</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="107"/>
        <source>yen sign</source>
        <translation>símbol del ien</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="108"/>
        <source>broken bar</source>
        <translation>barra trencada</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="109"/>
        <source>section sign</source>
        <translation>signe de secció</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="110"/>
        <source>diaeresis</source>
        <translation>dièresi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="111"/>
        <source>copyright symbol</source>
        <translation>símbol de copyright</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="112"/>
        <source>feminine ordinal indicator</source>
        <translation>Indicador ordinal femení</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="113"/>
        <source>left-pointing double angle quotation mark</source>
        <translation>cometes baixes inicials</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="114"/>
        <source>not sign</source>
        <translation>signe de negació</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="115"/>
        <source>soft hyphen</source>
        <translation>guionet opcional</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="116"/>
        <source>registered sign</source>
        <translation>símbol de registrat</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="117"/>
        <source>macron</source>
        <translation>màcron</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="118"/>
        <source>degree symbol</source>
        <translation>símbol de grau</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="119"/>
        <source>plus-minus sign</source>
        <translation>signe més menys</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="120"/>
        <source>superscript two</source>
        <translation>dos volat</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="121"/>
        <source>superscript three</source>
        <translation>tres volat</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="122"/>
        <source>acute accent</source>
        <translation>accent agut</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="123"/>
        <source>micro sign</source>
        <translation>signe micro</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="124"/>
        <source>pilcrow sign</source>
        <translation>Calderó</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="125"/>
        <source>middle dot</source>
        <translation>punt volat</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="126"/>
        <source>cedilla</source>
        <translation>vírgula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="127"/>
        <source>superscript one</source>
        <translation>u volat</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="128"/>
        <source>masculine ordinal indicator</source>
        <translation>Indicador ordinal masculí</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="129"/>
        <source>right-pointing double angle quotation mark</source>
        <translation>cometes baixes finals</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="130"/>
        <source>vulgar fraction one quarter</source>
        <translation>fracció un quart</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="131"/>
        <source>vulgar fraction one half</source>
        <translation>fracció un mig</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="132"/>
        <source>vulgar fraction three quarters</source>
        <translation>fracció tres quarts</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="133"/>
        <source>inverted question mark</source>
        <translation>interrogant inicial</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="134"/>
        <source>Latin capital letter A with grave accent</source>
        <translation>Lletra llatina majúscula A amb accent greu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="135"/>
        <source>Latin capital letter A with acute accent</source>
        <translation>Lletra llatina majúscula A amb accent agut</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="136"/>
        <source>Latin capital letter A with circumflex</source>
        <translation>Lletra llatina majúscula A amb accent circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="137"/>
        <source>Latin capital letter A with tilde</source>
        <translation>Lletra llatina majúscula A amb accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="138"/>
        <source>Latin capital letter A with diaeresis</source>
        <translation>Lletra llatina majúscula A amb dièresi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="139"/>
        <source>Latin capital letter A with ring above</source>
        <translation>lletra llatina A majúscula amb rodoneta damunt</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="140"/>
        <source>Latin capital letter AE</source>
        <translation>lletra llatina AE majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="141"/>
        <source>Latin capital letter C with cedilla</source>
        <translation>Lletra llatina majúscula C amb c trencada</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="142"/>
        <source>Latin capital letter E with grave accent</source>
        <translation>Lletra llatina majúscula E amb accent greu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="143"/>
        <source>Latin capital letter E with acute accent</source>
        <translation>Lletra llatina majúscula E amb accent agut</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="144"/>
        <source>Latin capital letter E with circumflex</source>
        <translation>Lletra llatina majúscula E amb accent circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="145"/>
        <source>Latin capital letter E with diaeresis</source>
        <translation>Lletra llatina majúscula E amb dièresi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="146"/>
        <source>Latin capital letter I with grave accent</source>
        <translation>Lletra llatina majúscula I amb accent greu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="147"/>
        <source>Latin capital letter I with acute accent</source>
        <translation>Lletra llatina majúscula I amb accent agut</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="148"/>
        <source>Latin capital letter I with circumflex</source>
        <translation>Lletra llatina majúscula I amb accent circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="149"/>
        <source>Latin capital letter I with diaeresis</source>
        <translation>Lletra llatina majúscula I amb dièresi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="150"/>
        <source>Latin capital letter Eth</source>
        <translation> Lletra llatina majúscula Eth</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="151"/>
        <source>Latin capital letter N with tilde</source>
        <translation>Lletra llatina majúscula N amb accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="152"/>
        <source>Latin capital letter O with grave accent</source>
        <translation>Lletra llatina majúscula O amb accent greu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="153"/>
        <source>Latin capital letter O with acute accent</source>
        <translation>Lletra llatina majúscula O amb accent agut</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="154"/>
        <source>Latin capital letter O with circumflex</source>
        <translation>Lletra llatina majúscula O amb accent circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="155"/>
        <source>Latin capital letter O with tilde</source>
        <translation>Lletra llatina majúscula O amb accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="156"/>
        <source>Latin capital letter O with diaeresis</source>
        <translation>Lletra llatina majúscula O amb dièresi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="157"/>
        <source>multiplication sign</source>
        <translation>signe de multiplicació</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="158"/>
        <source>Latin capital letter O with stroke</source>
        <translation>lletra llatina O barrada majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="159"/>
        <source>Latin capital letter U with grave accent</source>
        <translation>Lletra llatina majúscula U amb accent greu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="160"/>
        <source>Latin capital letter U with acute accent</source>
        <translation>Lletra llatina majúscula U amb accent agut</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="161"/>
        <source>Latin capital letter U with circumflex</source>
        <translation>Lletra llatina majúscula U amb accent circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="162"/>
        <source>Latin capital letter U with diaeresis</source>
        <translation>Lletra llatina majúscula U amb dièresi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="163"/>
        <source>Latin capital letter Y with acute accent</source>
        <translation>Lletra llatina majúscula Y amb accent agut</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="164"/>
        <source>Latin capital letter THORN</source>
        <translation>Lletra llatina majúscula Þ</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="165"/>
        <source>Latin small letter sharp s</source>
        <translation>lletra llatina eszett minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="166"/>
        <source>Latin small letter a with grave accent</source>
        <translation>Lletra llatina minúscula a amb accent greu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="167"/>
        <source>Latin small letter a with acute accent</source>
        <translation>Lletra llatina minúscula a amb accent agut</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="168"/>
        <source>Latin small letter a with circumflex</source>
        <translation>Lletra llatina minúscula a amb accent circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="169"/>
        <source>Latin small letter a with tilde</source>
        <translation>Lletra llatina minúscula a amb accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="170"/>
        <source>Latin small letter a with diaeresis</source>
        <translation>Lletra llatina minúscula a amb dièresi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="171"/>
        <source>Latin small letter a with ring above</source>
        <translation>lletra llatina a minúscula amb rodoneta damunt</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="172"/>
        <source>Latin small letter ae</source>
        <translation>lletra llatina ae minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="173"/>
        <source>Latin small letter c with cedilla</source>
        <translation>Lletra llatina minúscula c amb ce trencada</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="174"/>
        <source>Latin small letter e with grave accent</source>
        <translation>Lletra llatina minúscula e amb accent greu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="175"/>
        <source>Latin small letter e with acute accent</source>
        <translation>Lletra llatina minúscula e amb accent agut</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="176"/>
        <source>Latin small letter e with circumflex</source>
        <translation>Lletra llatina minúscula e amb accent circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="177"/>
        <source>Latin small letter e with diaeresis</source>
        <translation>Lletra llatina minúscula e amb dièresi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="178"/>
        <source>Latin small letter i with grave accent</source>
        <translation>Lletra llatina minúscula i amb accent greu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="179"/>
        <source>Latin small letter i with acute accent</source>
        <translation>Lletra llatina minúscula i amb accent agut</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="180"/>
        <source>Latin small letter i with circumflex</source>
        <translation>Lletra llatina minúscula i amb accent circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="181"/>
        <source>Latin small letter i with diaeresis</source>
        <translation>Lletra llatina minúscula i amb dièresi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="182"/>
        <source>Latin small letter eth</source>
        <translation> Lletra llatina minúscula eth</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="183"/>
        <source>Latin small letter n with tilde</source>
        <translation>Lletra llatina minúscula n amb accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="184"/>
        <source>Latin small letter o with grave accent</source>
        <translation>Lletra llatina minúscula o amb accent greu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="185"/>
        <source>Latin small letter o with acute accent</source>
        <translation> Lletra llatina minúscula o amb accent agut</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="186"/>
        <source>Latin small letter o with circumflex</source>
        <translation> Lletra llatina minúscula o amb accent circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="187"/>
        <source>Latin small letter o with tilde</source>
        <translation> Lletra llatina minúscula o amb accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="188"/>
        <source>Latin small letter o with diaeresis</source>
        <translation> Lletra llatina minúscula o amb dièresi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="189"/>
        <source>division sign</source>
        <translation>signe de dividir</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="190"/>
        <source>Latin small letter o with stroke</source>
        <translation>lletra llatina o barrada minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="191"/>
        <source>Latin small letter u with grave accent</source>
        <translation> Lletra llatina minúscula u amb accent greu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="192"/>
        <source>Latin small letter u with acute accent</source>
        <translation> Lletra llatina minúscula u amb accent agut</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="193"/>
        <source>Latin small letter u with circumflex</source>
        <translation> Lletra llatina minúscula u amb accent circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="194"/>
        <source>Latin small letter u with diaeresis</source>
        <translation> Lletra llatina minúscula u amb dièresi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="195"/>
        <source>Latin small letter y with acute accent</source>
        <translation> Lletra llatina minúscula y amb accent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="196"/>
        <source>Latin small letter thorn</source>
        <translation>Lletra llatina minúscula Þ</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="197"/>
        <source>Latin small letter y with diaeresis</source>
        <translation> Lletra llatina minúscula y amb dièresi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="198"/>
        <source>Latin capital ligature oe</source>
        <translation>lligadura llatina OE majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="199"/>
        <source>Latin small ligature oe</source>
        <translation>lligadura llatina oe minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="200"/>
        <source>Latin capital letter s with caron</source>
        <translation>Lletra llatina majúscula s amb anticircumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="201"/>
        <source>Latin small letter s with caron</source>
        <translation>Lletra llatina minúscula s amb anticircumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="202"/>
        <source>Latin capital letter y with diaeresis</source>
        <translation> Lletra llatina majúscula y amb dièresi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="203"/>
        <source>Latin small letter f with hook</source>
        <translation>lletra llatina f minúscula amb ganxo</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="204"/>
        <source>modifier letter circumflex accent</source>
        <translation>Lletra modificada d&apos;accent circumflex</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="205"/>
        <source>small tilde</source>
        <translation>titlla</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="206"/>
        <source>Greek capital letter Alpha</source>
        <translation>lletra grega ALFA majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="207"/>
        <source>Greek capital letter Beta</source>
        <translation>lletra grega BETA majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="208"/>
        <source>Greek capital letter Gamma</source>
        <translation>lletra grega GAMMA majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="209"/>
        <source>Greek capital letter Delta</source>
        <translation>lletra grega DELTA majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="210"/>
        <source>Greek capital letter Epsilon</source>
        <translation>lletra grega ÈPSILON majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="211"/>
        <source>Greek capital letter Zeta</source>
        <translation>lletra grega ZETA majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="212"/>
        <source>Greek capital letter Eta</source>
        <translation>lletra grega ETA majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="213"/>
        <source>Greek capital letter Theta</source>
        <translation>lletra grega THETA majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="214"/>
        <source>Greek capital letter Iota</source>
        <translation>lletra grega IOTA majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="215"/>
        <source>Greek capital letter Kappa</source>
        <translation>lletra grega KAPPA majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="216"/>
        <source>Greek capital letter Lambda</source>
        <translation>lletra grega LAMBDA majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="217"/>
        <source>Greek capital letter Mu</source>
        <translation>lletra grega MI majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="218"/>
        <source>Greek capital letter Nu</source>
        <translation>lletra grega NI majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="219"/>
        <source>Greek capital letter Xi</source>
        <translation>lletra grega CSI majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="220"/>
        <source>Greek capital letter Omicron</source>
        <translation>lletra grega ÒMICRON majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="221"/>
        <source>Greek capital letter Pi</source>
        <translation>lletra grega PI majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="222"/>
        <source>Greek capital letter Rho</source>
        <translation>lletra grega RO majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="223"/>
        <source>Greek capital letter Sigma</source>
        <translation>lletra grega SIGMA majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="224"/>
        <source>Greek capital letter Tau</source>
        <translation>lletra grega TAU majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="225"/>
        <source>Greek capital letter Upsilon</source>
        <translation>lletra grega ÍPSILON majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="226"/>
        <source>Greek capital letter Phi</source>
        <translation>lletra grega FI majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="227"/>
        <source>Greek capital letter Chi</source>
        <translation>lletra grega KHI majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="228"/>
        <source>Greek capital letter Psi</source>
        <translation>lletra grega PSI majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="229"/>
        <source>Greek capital letter Omega</source>
        <translation>lletra grega OMEGA majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="230"/>
        <source>Greek small letter alpha</source>
        <translation>lletra grega alfa minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="231"/>
        <source>Greek small letter beta</source>
        <translation>lletra grega beta minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="232"/>
        <source>Greek small letter gamma</source>
        <translation>lletra grega gamma minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="233"/>
        <source>Greek small letter delta</source>
        <translation>lletra grega delta minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="234"/>
        <source>Greek small letter epsilon</source>
        <translation>lletra grega èpsilon minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="235"/>
        <source>Greek small letter zeta</source>
        <translation>lletra grega zeta minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="236"/>
        <source>Greek small letter eta</source>
        <translation>lletra grega eta minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="237"/>
        <source>Greek small letter theta</source>
        <translation>lletra grega theta minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="238"/>
        <source>Greek small letter iota</source>
        <translation>lletra grega iota minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="239"/>
        <source>Greek small letter kappa</source>
        <translation>lletra grega kappa minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="240"/>
        <source>Greek small letter lambda</source>
        <translation>lletra grega lambda minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="241"/>
        <source>Greek small letter mu</source>
        <translation>lletra grega mi minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="242"/>
        <source>Greek small letter nu</source>
        <translation>lletra grega ni minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="243"/>
        <source>Greek small letter xi</source>
        <translation>lletra grega csi minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="244"/>
        <source>Greek small letter omicron</source>
        <translation>lletra grega òmicron minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="245"/>
        <source>Greek small letter pi</source>
        <translation>lletra grega pi minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="246"/>
        <source>Greek small letter rho</source>
        <translation>lletra grega ro minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="247"/>
        <source>Greek small letter final sigma</source>
        <translation>lletra grega sigma final minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="248"/>
        <source>Greek small letter sigma</source>
        <translation>lletra grega sigma minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="249"/>
        <source>Greek small letter tau</source>
        <translation>lletra grega tau minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="250"/>
        <source>Greek small letter upsilon</source>
        <translation>lletra grega ípsilon minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="251"/>
        <source>Greek small letter phi</source>
        <translation>lletra grega fi minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="252"/>
        <source>Greek small letter chi</source>
        <translation>lletra grega khi minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="253"/>
        <source>Greek small letter psi</source>
        <translation>lletra grega psi minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="254"/>
        <source>Greek small letter omega</source>
        <translation>lletra grega omega minúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="255"/>
        <source>Greek theta symbol</source>
        <translation>símbol grec theta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="256"/>
        <source>Greek Upsilon with hook symbol</source>
        <translation>símbol grec ípsilon amb ganxo</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="257"/>
        <source>Greek pi symbol</source>
        <translation>símbol grec pi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="258"/>
        <source>en space</source>
        <translation>mig quadratí</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="259"/>
        <source>em space</source>
        <translation>quadratí</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="260"/>
        <source>thin space</source>
        <translation>espai fi</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="261"/>
        <source>zero-width non-joiner</source>
        <translation>separador sense amplada</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="262"/>
        <source>zero-width joiner</source>
        <translation>unió sense amplada</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="263"/>
        <source>left-to-right mark</source>
        <translation>marca de esquerra a dreta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="264"/>
        <source>right-to-left mark</source>
        <translation>marca de dreta a esquerra</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="265"/>
        <source>en dash</source>
        <translation>guió mig</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="266"/>
        <source>em dash</source>
        <translation>guió llarg</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="267"/>
        <source>left single quotation mark</source>
        <translation>Cometa simple esquerra</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="268"/>
        <source>right single quotation mark</source>
        <translation>Cometa simple dreta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="269"/>
        <source>single low-9 quotation mark</source>
        <translation>Cometes simples alemanyes -9</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="270"/>
        <source>left double quotation mark</source>
        <translation>Cometa doble esquerra</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="271"/>
        <source>right double quotation mark</source>
        <translation>Cometa doble dreta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="272"/>
        <source>double low-9 quotation mark</source>
        <translation>Cometes dobles alemanyes -9</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="273"/>
        <source>dagger, obelisk</source>
        <translation>creu</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="274"/>
        <source>double dagger, double obelisk</source>
        <translation>creu doble</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="275"/>
        <source>bullet</source>
        <translation>pic</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="276"/>
        <source>horizontal ellipsis</source>
        <translation>punts suspensius</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="277"/>
        <source>per mille sign</source>
        <translation>signe per mil</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="278"/>
        <source>prime</source>
        <translation>prima</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="279"/>
        <source>double prime</source>
        <translation>doble prima</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="280"/>
        <source>single left-pointing angle quotation mark</source>
        <translation>cometa baixa angular inicial</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="281"/>
        <source>single right-pointing angle quotation mark</source>
        <translation>cometa baixa angular final</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="282"/>
        <source>overline</source>
        <translation>línia superior</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="283"/>
        <source>fraction slash</source>
        <translation>ratlla de fracció</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="284"/>
        <source>euro sign</source>
        <translation>símbol de l&apos;euro</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="285"/>
        <source>black-letter capital I</source>
        <translation>lletra gòtica I majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="286"/>
        <source>script capital P</source>
        <translation>lletra cal·ligràfica P majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="287"/>
        <source>black-letter capital R</source>
        <translation>lletra gòtica R majúscula</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="288"/>
        <source>trademark symbol</source>
        <translation>símbol de marca registrada</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="289"/>
        <source>alef symbol</source>
        <translation>àlef</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="290"/>
        <source>leftwards arrow</source>
        <translation>fletxa esquerra</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="291"/>
        <source>upwards arrow</source>
        <translation>flrtxa amunt</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="292"/>
        <source>rightwards arrow</source>
        <translation>fletxa dreta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="293"/>
        <source>downwards arrow</source>
        <translation>fletxa avall</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="294"/>
        <source>left right arrow</source>
        <translation>fletxa esquerra dreta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="295"/>
        <source>downwards arrow with corner leftwards</source>
        <translation>fletxa avall amb cantonada esquerra</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="296"/>
        <source>leftwards double arrow</source>
        <translation>doble fletxa esquerra</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="297"/>
        <source>upwards double arrow</source>
        <translation>doble fletxa amunt</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="298"/>
        <source>rightwards double arrow</source>
        <translation>doble fletxa dreta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="299"/>
        <source>downwards double arrow</source>
        <translation>doble fletxa avall</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="300"/>
        <source>left right double arrow</source>
        <translation>doble fletxa esquerra dreta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="301"/>
        <source>for all</source>
        <translation>per a tot</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="302"/>
        <source>partial differential</source>
        <translation>derivada parcial</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="303"/>
        <source>there exists</source>
        <translation>existeix</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="304"/>
        <source>empty set</source>
        <translation>conjunt buit</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="305"/>
        <source>nabla</source>
        <translation>nabla</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="306"/>
        <source>element of</source>
        <translation>pertany</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="307"/>
        <source>not an element of</source>
        <translation>no pertany a</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="308"/>
        <source>contains as member</source>
        <translation>conté</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="309"/>
        <source>n-ary product</source>
        <translation>producte n-ari</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="310"/>
        <source>n-ary summation</source>
        <translation>suma n-aria</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="311"/>
        <source>minus sign</source>
        <translation>signe menys</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="312"/>
        <source>asterisk operator</source>
        <translation>operador asterisc</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="313"/>
        <source>square root</source>
        <translation>arrel quadrada</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="314"/>
        <source>proportional to</source>
        <translation>proporcional a</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="315"/>
        <source>infinity</source>
        <translation>infinit</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="316"/>
        <source>angle</source>
        <translation>angle</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="317"/>
        <source>logical and</source>
        <translation>i lògic</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="318"/>
        <source>logical or</source>
        <translation>o lògic</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="319"/>
        <source>intersection</source>
        <translation>intersecció</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="320"/>
        <source>union</source>
        <translation>unió</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="321"/>
        <source>integral</source>
        <translation>integral</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="322"/>
        <source>therefore sign</source>
        <translation>implica</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="323"/>
        <source>tilde operator</source>
        <translation>operador titlla</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="324"/>
        <source>congruent to</source>
        <translation>congruent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="325"/>
        <source>almost equal to</source>
        <translation>aproximadament igual a</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="326"/>
        <source>not equal to</source>
        <translation>diferent</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="327"/>
        <source>identical to</source>
        <translation>idèntic a</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="328"/>
        <source>less-than or equal to</source>
        <translation>igual o menor que</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="329"/>
        <source>greater-than or equal to</source>
        <translation>igual o més gran que</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="330"/>
        <source>subset of</source>
        <translation>subconjunt de</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="331"/>
        <source>superset of</source>
        <translation>superconjunt de</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="332"/>
        <source>not a subset of</source>
        <translation>no és subconjunt de</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="333"/>
        <source>subset of or equal to</source>
        <translation>subconjunt o igual a</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="334"/>
        <source>superset of or equal to</source>
        <translation>superconjunt o igual a</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="335"/>
        <source>circled plus</source>
        <translation>suma directa</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="336"/>
        <source>circled times</source>
        <translation>producte tensorial</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="337"/>
        <source>up tack</source>
        <translation>perpendicular</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="338"/>
        <source>dot operator</source>
        <translation>operador punt</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="339"/>
        <source>left ceiling</source>
        <translation>sostre esquerra</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="340"/>
        <source>right ceiling</source>
        <translation>sostre dreta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="341"/>
        <source>left floor</source>
        <translation>terra esquerra</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="342"/>
        <source>right floor</source>
        <translation>terra dreta</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="343"/>
        <source>left-pointing angle bracket</source>
        <translation>parèntesi angular inicial</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="344"/>
        <source>right-pointing angle bracket</source>
        <translation>pràntesi angular final</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="345"/>
        <source>lozenge</source>
        <translation>rombe</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="346"/>
        <source>black spade suit</source>
        <translation>coll de piques negre</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="347"/>
        <source>black club suit</source>
        <translation>coll de trèvols negre</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="348"/>
        <source>black heart suit</source>
        <translation>coll de cors negre</translation>
    </message>
    <message>
        <location filename="../../Misc/XMLEntities.cpp" line="349"/>
        <source>black diamond suit</source>
        <translation>coll de diamants negre</translation>
    </message>
</context>
</TS>